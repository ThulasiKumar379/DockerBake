'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_rooms', { roomid: Sequelize.col('room_id') }, {
      roomid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_rooms', { roomid: null }, {
      roomid: null
    });
  }
};