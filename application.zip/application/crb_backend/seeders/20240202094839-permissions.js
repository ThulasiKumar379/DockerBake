const { Op } = require('sequelize');
const permissions_data = [
  { id: 1, name: 'Dashboard', key: 'dashboard', status: true },
  { id: 2, name: 'New Booking', key: 'new_booking', status: true },
  { id: 3, name: 'Edit Booking', key: 'edit_booking', status: true },
  { id: 4, name: 'Delete Booking', key: 'delete_booking', status: true },
  { id: 5, name: 'All Master', key: 'all_master', status: true },
  { id: 6, name: 'Locations', key: 'locations', status: true },
  { id: 7, name: 'Buildings', key: 'buildings', status: true },
  { id: 8, name: 'Floors', key: 'floors', status: true },
  { id: 9, name: 'Rooms', key: 'rooms', status: true },
  { id: 10, name: 'Amenity', key: 'amenity', status: true },
  { id: 11, name: 'Room Service', key: 'room_service', status: true },
  { id: 12, name: 'Department', key: 'department', status: true },
  { id: 13, name: 'Designation', key: 'designation', status: true },
  { id: 14, name: 'Role Master', key: 'role_master', status: true },
  { id: 15, name: 'User Access Management', key: 'user_access_management', status: true },
  { id: 16, name: 'Add Location', key: 'add_location', status: true },
  { id: 17, name: 'Edit Location', key: 'edit_location', status: true },
  { id: 18, name: 'Delete Location', key: 'delete_location', status: true },
  { id: 19, name: 'Add Building', key: 'add_building', status: true },
  { id: 20, name: 'Edit Building', key: 'edit_building', status: true },
  { id: 21, name: 'Delete Building', key: 'delete_building', status: true },
  { id: 22, name: 'Add Floor', key: 'add_floor', status: true },
  { id: 23, name: 'Edit Floor', key: 'edit_floor', status: true },
  { id: 24, name: 'Delete Floor', key: 'delete_floor', status: true },
  { id: 25, name: 'Add Room', key: 'add_room', status: true },
  { id: 26, name: 'Edit Room', key: 'edit_room', status: true },
  { id: 27, name: 'Delete Room', key: 'delete_room', status: true },
  { id: 28, name: 'Add Amenity', key: 'add_amenity', status: true },
  { id: 29, name: 'Edit Amenity', key: 'edit_amenity', status: true },
  { id: 30, name: 'Delete Amenity', key: 'delete_amenity', status: true },
  { id: 31, name: 'Add Room Service', key: 'add_room_service', status: true },
  { id: 32, name: 'Edit Room Service', key: 'edit_room_service', status: true },
  { id: 33, name: 'Delete Room Service', key: 'delete_room_service', status: true },
  { id: 34, name: 'Add Department', key: 'add_department', status: true },
  { id: 35, name: 'Edit Department', key: 'edit_department', status: true },
  { id: 36, name: 'Delete Department', key: 'delete_department', status: true },
  { id: 37, name: 'Add Designation', key: 'add_designation', status: true },
  { id: 38, name: 'Edit Designation', key: 'edit_designation', status: true },
  { id: 39, name: 'Delete Designation', key: 'delete_designation', status: true },
  { id: 40, name: 'Add Role', key: 'add_role', status: true },
  { id: 41, name: 'Edit Role', key: 'edit_role', status: true },
  { id: 42, name: 'Delete Role', key: 'delete_role', status: true },
  { id: 43, name: 'Add User', key: 'add_user', status: true },
  { id: 44, name: 'Edit User', key: 'edit_user', status: true },
  { id: 45, name: 'Delete User', key: 'delete_user', status: true },
  { id: 46, name: 'Booking List', key: 'booking_list', status: true },
  { id: 47, name: 'All Settings', key: 'all_settings', status: true },
  { id: 48, name: 'Profile', key: 'profile', status: true },
  { id: 49, name: 'Configuration', key: 'configuration', status: true },
  { id: 50, name: 'Room Configuration', key: 'room_configuration', status: true },
  { id: 51, name: 'ACL', key: 'acl', status: true },
  { id: 52, name: 'Configuration Company Details', key: 'configuration_company_details', status: true },
  { id: 53, name: 'Configuration Custom Layout', key: 'confirguration_custom_layout', status: true },
  { id: 54, name: 'All Location Booking Management', key: 'all_location_booking_management', status: true }, 
  { id: 55, name: 'All Building Booking Management', key: 'all_building_booking_management', status: true },
];

module.exports = {
  up: async (queryInterface, Sequelize) => {
    for (i = 0; i < permissions_data.length; i++) {
      const keyexist = await queryInterface.sequelize.query(
        `select * from permissions where key='${permissions_data[i].key}'`
      );
      console.log(permissions_data[i]);
      console.log(keyexist[0][0]);
      if (!keyexist[0] || keyexist[0][0] == undefined) {
        await queryInterface.bulkInsert('permissions', [permissions_data[i]], {});
      }
    }

  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('permissions', { [Op.or]: permissions_data });
  }
};