'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_designations', { designationid: Sequelize.col('designation_id') }, {
      designationid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_designations', { designationid: null }, {
      designationid: null
    });
  }
};