'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_buildings', { buildingid: Sequelize.col('building_id') }, {
      buildingid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_buildings', { buildingid: null }, {
      buildingid: null
    });
  }
};
