'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_departments', { departmentid: Sequelize.col('department_id') }, {
      departmentid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_departments', { departmentid: null }, {
      departmentid: null
    });
  }
};