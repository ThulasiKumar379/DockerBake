'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_floors', { floorid: Sequelize.col('floor_id') }, {
      floorid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_floors', { floorid: null }, {
      floorid: null
    });
  }
};