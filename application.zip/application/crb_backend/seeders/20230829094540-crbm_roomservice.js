'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbm_roomservice', { serviceid: Sequelize.col('room_service_id') }, {
      serviceid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbm_roomservice', { serviceid: null }, {
      serviceid: null
    });
  }
};