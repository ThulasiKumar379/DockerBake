'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbm_aminities', { aminity_id: Sequelize.col('amenityid') }, {
      aminity_id: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbm_aminities', { aminity_id: null }, {
      aminity_id: null
    });
  }
};