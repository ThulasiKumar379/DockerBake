const { DataTypes } = require('sequelize');

const usersSeed = [
    { name: 'Alice', email: 'alice@example.com' },
    { name: 'Bob', email: 'bob@example.com' }
  ];
   //  const tableExists = await queryInterface.sequelize.query(
      //   `SELECT EXISTS (
      //     SELECT 1
      //     FROM information_schema.tables
      //     WHERE table_name = 'tt1'
      //   );`
      // );
      // console.log(tableExists,'tableExiststableExists')
      // if (tableExists[0][0].exists==true) {

// }
  
  module.exports = {
    up: async (queryInterface, Sequelize) => {
      // await queryInterface.bulkInsert('tt1', usersSeed, {});
    },
    down: async (queryInterface, Sequelize) => {
      // await queryInterface.bulkDelete('tt1', null, {});
    }
  };
  