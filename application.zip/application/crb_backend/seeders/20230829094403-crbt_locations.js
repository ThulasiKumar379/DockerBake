'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_locations', { locationid: Sequelize.col('location_id') }, {
      locationid: null
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkUpdate('crbt_locations', { locationid: null }, {
      locationid: null
    });
  }
};