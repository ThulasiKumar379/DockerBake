const { Op } = require('sequelize');
const booking_status_data = [
  { id: 1, status: 'Requested'},
  { id: 2, status: 'Approved'},
  { id: 3, status: 'Rejected'},
  { id: 4, status: 'Cancel'}
];

module.exports = {
  up: async (queryInterface, Sequelize) => {
    for (i = 0; i < booking_status_data.length; i++) {
      const statusExist = await queryInterface.sequelize.query(
        `SELECT * FROM booking_status WHERE status='${booking_status_data[i].status}'`
      );
      console.log(booking_status_data[i]);
      console.log(statusExist[0][0]);
      if (!statusExist[0] || statusExist[0][0] === undefined) {
        await queryInterface.bulkInsert('booking_status', [booking_status_data[i]], {});
      }
    }

  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('booking_status', { [Op.or]: booking_status_data });
  }
};
