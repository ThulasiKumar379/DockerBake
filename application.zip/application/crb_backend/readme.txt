Application run commands
========================
Local : npm run local
development : npm run dev
UAT : npm run uat
Production : npm run prod

 
DB migration commands
=====================
CRB - LOCAL
---
sequelize db:migrate --env local
sequelize-cli db:seed:all --env=local

CRB - DEV
---
sequelize db:migrate --env development
sequelize-cli db:seed:all --env=development
 

CRB - UAT
----
sequelize db:migrate --env uat
sequelize-cli db:seed:all --env=uat

CRB - PRODUCTION
----
sequelize db:migrate --env prod
sequelize-cli db:seed:all --env=prod
