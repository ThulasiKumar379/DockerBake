var db = require('../src/models/index')
const logger = require('../utils/winston')


function validateParams(requiredParams, reqBody) {
    const missingParams = [];
    for (const param of requiredParams) {
        if (typeof reqBody[param] === 'undefined') {
            missingParams.push(param);
        }
    }
    return missingParams;
}

function validateFields(reqBody, requiredFields) {
    const missingField = requiredFields.find(field => !reqBody[field]);
    return missingField ? missingField : null;
}

module.exports = {
    validateParams,
    validateFields
};