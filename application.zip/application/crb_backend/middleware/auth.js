var jwt = require('jsonwebtoken')
var env = require('../config/environment');
var status = require('../config/apiStatus');
var db = require('../src/models/index')

let systemUserAuth = (req, res, next) => {
    if (req.headers.authorization !== undefined) {
        let jwttoken = req.headers.authorization.split(" ");
        // console.log(jwttoken);
        if (typeof jwttoken[1] !== 'undefined') {
            jwt.verify(jwttoken[1], env.jwtkey.system_user_key, (err, user) => {
                if (err) {
                    return res.status(200).send(status.tokenError);
                }
                req.systemUser = user.userdata;
                next();
            });

        } else {
            return res.send(status.tokenError);
        }
    } else {
        return res.send(status.tokenError);
    }
}

let userAuth = (req, res, next) => {
    if (req.headers.authorization !== undefined) {
        let jwttoken = req.headers.authorization.split(" ");
        if (typeof jwttoken[1] !== 'undefined') {
            jwt.verify(jwttoken[1], env.jwtkey.end_user_key, (err, user) => {
                if (err) {
                    return res.status(200).send(status.tokenError);
                }
                req.user = user.userdata;
                next();
            });
        } else {
            return res.send(status.tokenError);
        }
    } else {
        return res.send(status.tokenError);
    }
}

const system_user_auth = (myParam) => {
    return async (req, res, next) => {
        let query = `select up.* from userpermissions up join permissions p on p.id=up.id where p.key='${myParam}' and up.role_id=${req.admin.role_id}`;
        const permissiondata = await sequelize.query(query);
        if(permissiondata[0].length==0){
            return  res.send(status.permissionError);
        }
        next();
    }
}

module.exports = { systemUserAuth, userAuth,system_user_auth };