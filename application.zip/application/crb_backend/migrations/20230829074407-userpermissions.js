
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('userpermissions', {
        id: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		}, 
        permission_id: {
			allowNull: true,
			type: DataTypes.INTEGER
		},
        role_id: {
			allowNull: true,
			type: DataTypes.INTEGER
		}
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('userpermissions');
  }
};