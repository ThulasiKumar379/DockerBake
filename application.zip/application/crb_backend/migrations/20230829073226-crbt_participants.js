const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_participants', {
        user_id: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        booking_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        participants_status: {
            allowNull: true,
            type: DataTypes.STRING(50)
        }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_participants');
  }
};