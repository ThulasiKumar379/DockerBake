
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Add a new column to an existing table
    const [results] = await queryInterface.sequelize.query(
      `SELECT COLUMN_NAME
       FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_NAME = 'crbt_buildings' AND COLUMN_NAME = 'buildingid';`
    );

    if (results.length === 0) {
    await queryInterface.addColumn('crbt_buildings', 'buildingid', {
      type: Sequelize.STRING(50),
      allowNull: true
    }
    );
  }
  },

  down: async (queryInterface, Sequelize) => {
    // Remove the previously added column
    await queryInterface.removeColumn('crbt_buildings', 'buildingid');
  }
};