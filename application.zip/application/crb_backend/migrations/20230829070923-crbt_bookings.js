const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_bookings', {
        booking_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        room_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        title_of_meeting: {
            allowNull: true,
            type: DataTypes.STRING(255)
        },
        booking_date: {
            allowNull: true,
            type: DataTypes.DATE
        },
        starttime: {
            allowNull: true,
            type: DataTypes.TIME
        },
        endtime: {
            allowNull: true,
            type: DataTypes.TIME
        },
        repeat: {
            allowNull: true,
            type: DataTypes.STRING(255)
        },
        description: {
            allowNull: true,
            type: DataTypes.TEXT
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        booking_status: {
            allowNull: true,
            type: DataTypes.STRING(255)
        },
        location_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        building_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        floor_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        duration: {
            allowNull: true,
            type: DataTypes.STRING(100)
        },
        room_capacity: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        room_service_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        booking_end_date: {
            allowNull: true,
            type: DataTypes.DATE
        },
        days: {
            allowNull: true,
            type: DataTypes.TEXT
        },
        reschedule_status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_bookings');
  }
};