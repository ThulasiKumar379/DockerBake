const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbm_subscription_plans', {
        plan_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        plan_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        description: {
            allowNull: true,
            type: DataTypes.TEXT
        },
        price: {
            allowNull: true,
            type: DataTypes.DECIMAL(10, 2)
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        tenure: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbm_subscription_plans');
  }
};