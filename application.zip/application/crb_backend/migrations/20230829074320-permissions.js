
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('permissions', {
        id: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		},
        name: {
			allowNull: true,
			type: DataTypes.STRING(255)
		},
        key: {
			allowNull: true,
			type: DataTypes.STRING(255)
		},
		status: {
			allowNull: true,
			type: DataTypes.BOOLEAN
		}
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('permissions');
  }
};