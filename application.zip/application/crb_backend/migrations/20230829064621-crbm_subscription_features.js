const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbm_subscription_features', {
      feature_id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      plan_id: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      userlimit: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      location_limit: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      building_limit: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      booking_limit: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      created_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      updated_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      status:{
        allowNull:true,
        type:DataTypes.BOOLEAN
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbm_subscription_features');
  }
};
