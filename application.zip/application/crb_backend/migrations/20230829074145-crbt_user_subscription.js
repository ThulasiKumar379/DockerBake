
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_user_subscription', {
      subscriptionid: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      system_user_id: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      plan_id: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      startdate: {
        allowNull: true,
        type: DataTypes.DATE
      },
      enddate: {
        allowNull: true,
        type: DataTypes.DATE
      },
      status: {
        allowNull: true,
        type: DataTypes.STRING(100)
      },
      paymentid: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      created_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      updated_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_user_subscription');
  }
};