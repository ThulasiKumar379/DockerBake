
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    const [results] = await queryInterface.sequelize.query(
      `SELECT COLUMN_NAME
       FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_NAME = 'crbm_aminities' AND COLUMN_NAME = 'aminity_id';`
    );

    if (results.length === 0) {
    // Add a new column to an existing table
    await queryInterface.addColumn('crbm_aminities', 'aminity_id', {
      type: Sequelize.STRING(50),
      allowNull: true
    });
  }
  },

  down: async (queryInterface, Sequelize) => {
    // Remove the previously added column
    await queryInterface.removeColumn('crbm_aminities', 'aminity_id');
  }
};