const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_queue', {
      queueid: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      que_type: {
        allowNull: true,
        type: DataTypes.STRING(50)
      },
      user_id: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      email_data: {
        allowNull: true,
        type: DataTypes.TEXT
      },
      email_to: {
          allowNull: true,
          type: DataTypes.TEXT
        },
  
      email_template: {
        allowNull: true,
        type: DataTypes.TEXT
      },
      email_attachments:{
        allowNull:true,
        type: DataTypes.TEXT
      },
      sms: {
        allowNull: true,
        type: DataTypes.TEXT
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_queue');
  }
};