const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbm_notification_type', {
      notification_type_id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      notification_type_name: {
        allowNull: true,
        type: DataTypes.STRING(50)
      },
      status: {
        allowNull: true,
        type: DataTypes.BOOLEAN
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbm_notification_type');
  }
};