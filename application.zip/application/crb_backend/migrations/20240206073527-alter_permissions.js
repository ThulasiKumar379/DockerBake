const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => { 
    await queryInterface.renameColumn('permissions', 'label', 'name');
 
    await queryInterface.addColumn('permissions', 'status', {
      type: Sequelize.STRING(20),
      allowNull: false,
      defaultValue: 'true' 
    });
  },

  down: async (queryInterface, Sequelize) => { 
    await queryInterface.removeColumn('permissions', 'status');
 
    await queryInterface.renameColumn('permissions', 'name', 'label');
  }
};
