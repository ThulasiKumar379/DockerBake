
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_setting', {
      system_user_id: {
        allowNull: false,
        primaryKey: true,
        type: DataTypes.INTEGER
      },  
      booked_room_color: {
        allowNull: true,
        type: DataTypes.STRING(50)
      },
      unbooked_room_color: {
        allowNull: true,
        type: DataTypes.STRING(50)
      },
      check_in_remain_minutes: {
        allowNull: true,
        type: DataTypes.TIME
      },
      reservation_duration: {
        allowNull: true,
        type: DataTypes.TIME
      },
      reservation_remainder: {
        allowNull: true,
        type: DataTypes.BOOLEAN
      },
      email_notification: {
        allowNull: true,
        type: DataTypes.BOOLEAN
      },
      public_access: {
        allowNull: true,
        type: DataTypes.BOOLEAN
      },
      email_notification_message: {
        allowNull: true,
        type: DataTypes.TEXT
      },   
      created_by: {
          allowNull: true,
          type: DataTypes.INTEGER
      },
      updated_by: {
          allowNull: true,
          type: DataTypes.INTEGER
      },
      created_at: {
          allowNull: true,
          type: DataTypes.DATE
      },
      updated_at: {
          allowNull: true,
          type: DataTypes.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_setting');
  }
};