const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => { 
    await queryInterface.removeConstraint('crbt_roles', 'crbt_roles_role_name_key');
  },

  down: async (queryInterface, Sequelize) => { 
    await queryInterface.addConstraint('crbt_roles', {
      type: 'unique',
      fields: ['role_name'],
      name: 'crbt_roles_role_name_key'
    });
  }
};
