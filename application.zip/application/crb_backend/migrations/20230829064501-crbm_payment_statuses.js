const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbm_payment_statuses', {
      statusid: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      statusname: {
        allowNull: true,
        type: DataTypes.STRING(50)
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE 
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbm_payment_statuses');
  }
};
