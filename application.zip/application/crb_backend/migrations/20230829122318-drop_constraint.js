
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    let [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbm_aminities' AND CONSTRAINT_NAME = 'crbm_aminities_amenityname_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbm_aminities', 'crbm_aminities_amenityname_key');
    }
     [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbm_notification_type' AND CONSTRAINT_NAME = 'crbm_notification_type_notification_type_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbm_notification_type', 'crbm_notification_type_notification_type_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbm_notification_type' AND CONSTRAINT_NAME = 'crbm_tax_info_tax_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbm_notification_type', 'crbm_tax_info_tax_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbm_subscription_plans' AND CONSTRAINT_NAME = 'crbm_subscription_plans_plan_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbm_subscription_plans', 'crbm_subscription_plans_plan_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbm_user_status' AND CONSTRAINT_NAME = 'crbm_user_status_status_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbm_user_status', 'crbm_user_status_status_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbt_buildings' AND CONSTRAINT_NAME = 'crbt_buildings_building_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbt_buildings', 'crbt_buildings_building_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbt_departments' AND CONSTRAINT_NAME = 'crbt_departments_department_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbt_departments', 'crbt_departments_department_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbt_system_users' AND CONSTRAINT_NAME = 'crbt_system_users_company_name_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbt_system_users', 'crbt_system_users_company_name_key');
    }
    [results] = await queryInterface.sequelize.query(
      `SELECT CONSTRAINT_NAME
       FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
       WHERE TABLE_NAME = 'crbt_system_users' AND CONSTRAINT_NAME = 'crbt_system_users_username_key';`
    );
    if (results.length > 0) {
    await queryInterface.removeConstraint('crbt_system_users', 'crbt_system_users_username_key');
    }
  },

  down: async (queryInterface, Sequelize) => {
    // await queryInterface.addConstraint('tablename', {
    //   fields: ['columnname'],
    //   type: 'foreign key',
    //   name: 'constraintname',
    //   references: {
    //     table: 'referencetable',
    //     field: 'refcolumn',
    //   }     
    // });
  }
};
