
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_sms_credits_usage', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      system_user_id: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      usage_date: {
        allowNull: true,
        type: DataTypes.DATE
      },
      credit_count: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      
      message: {
        allowNull: true,
        type: DataTypes.TEXT
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_sms_credits_usage');
  }
};
