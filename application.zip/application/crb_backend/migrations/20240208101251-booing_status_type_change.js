'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.sequelize.query('DELETE FROM crbt_bookings');
    // Finally, change the column type to hold integers
    await queryInterface.removeColumn('crbt_bookings', 'booking_status');
    await queryInterface.addColumn('crbt_bookings', 'booking_status', {
      type: Sequelize.INTEGER(11) // New data type here
    });
  },
  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn('crbt_bookings', 'booking_status');
    await queryInterface.addColumn('crbt_bookings', 'booking_status', {
      type: Sequelize.STRING(50) // New data type here
    });
  }
};
