const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_locations', {
        location_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        location_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        city: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        state: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        country: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_locations');
  }
};