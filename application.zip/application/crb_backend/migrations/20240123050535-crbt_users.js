
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    const [results] = await queryInterface.sequelize.query(
      `SELECT COLUMN_NAME
       FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_NAME = 'crbt_users' AND COLUMN_NAME = 'otp';`
    );
    if (results.length === 0) {
    // Add a new column to an existing table
    await queryInterface.addColumn('crbt_users', 'otp', {
      type: Sequelize.STRING(10),
      allowNull: true
    });
  }
  },

  down: async (queryInterface, Sequelize) => {
    // Remove the previously added column
    await queryInterface.removeColumn('crbt_users', 'otp');
  }
};