
const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_room_amenities', {
      room_id: {
        allowNull: false, 
        type: DataTypes.INTEGER,
        primaryKey: true
      }, 
      amenity_id: {
        allowNull: false, 
        type: DataTypes.INTEGER
      },
      created_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      updated_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      } 
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_room_amenities');
  }
};