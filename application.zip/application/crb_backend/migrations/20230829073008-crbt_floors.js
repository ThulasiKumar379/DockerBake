const { DataTypes } = require('sequelize');
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('crbt_floors', {
        floor_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        floor_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        building_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        location_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('crbt_floors');
  }
};