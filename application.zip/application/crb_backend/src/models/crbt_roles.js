const { sequelize, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_roles = sequelize.define('crbt_roles', {
        role_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.BIGINT
        },
        role_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        }
    }, {
        tableName: 'crbt_roles',
        timestamps: false
    });
    crbt_roles.associate = function(models) {
        crbt_roles.hasMany(models.crbt_roles, {
            foreignKey: 'role_id',
            as: 'crbt_roles'
        });
    };


    return crbt_roles;
};