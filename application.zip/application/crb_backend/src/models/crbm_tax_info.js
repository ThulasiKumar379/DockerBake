const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbm_tax_info = sequelize.define('crbm_tax_info', {
    tax_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    tax_name: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    description: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    taxrate: {
      allowNull: true,
      type: DataTypes.DECIMAL
    },
    taxtype: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    status: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    created_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      updated_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
   
  },
  {
    tableName: 'crbm_tax_info',
    timestamps: false
  });

  return crbm_tax_info;
};
