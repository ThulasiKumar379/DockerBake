const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_smtp_settings = sequelize.define('crbt_smtp_settings', {
    setting_id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
    },
    host: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    port: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    username: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    password: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    system_user_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    }
  },
  {
    tableName: 'crbt_smtp_settings',
    timestamps: false
  });

  return crbt_smtp_settings;
};
