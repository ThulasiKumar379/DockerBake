const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_designations = sequelize.define('crbt_designations', {
        designation_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        designation_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        designationid: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        active: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        department_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'crbt_designations',
        timestamps: false
    });
    crbt_designations.associate = function(models) {
        crbt_designations.belongsTo(models.crbt_departments, {
            foreignKey: 'department_id',
            as: 'crbt_departments'
        });
    };
    return crbt_designations;
};