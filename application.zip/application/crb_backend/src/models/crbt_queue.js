const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_queue = sequelize.define('crbt_queue', {
    queueid: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    que_type: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    user_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    email_data: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    email_to: {
        allowNull: true,
        type: DataTypes.TEXT
      },

    email_template: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    email_attachments:{
      allowNull:true,
      type: DataTypes.TEXT
    },
    sms: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    }
  },
  {
    tableName: 'crbt_queue',
    timestamps: false
  });
  

  return crbt_queue;
};
