const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_floors = sequelize.define('crbt_floors', {
        floor_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        floor_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        floorid: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        building_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        location_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        }
    }, {
        tableName: 'crbt_floors',
        timestamps: false
    });
    crbt_floors.associate = function(models) {
        crbt_floors.belongsTo(models.crbt_locations, {
            foreignKey: 'location_id',
            as: 'crbt_locations'
        });
        crbt_floors.belongsTo(models.crbt_buildings, {
            foreignKey: 'building_id',
            as: 'crbt_buildings'
        });
    };
    return crbt_floors;
};