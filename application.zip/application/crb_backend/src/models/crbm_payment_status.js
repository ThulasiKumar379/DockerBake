const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbm_payment_statuses = sequelize.define('crbm_payment_statuses', {
    statusid: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    statusname: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE 
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE 
    }
  },
  {
    tableName: 'crbm_payment_statuses',
    timestamps: false
  });

  return crbm_payment_statuses;
};
