const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_buildings = sequelize.define('crbt_buildings', {
        building_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        building_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        buildingid: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        location_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        address: {
            allowNull: true,
            type: DataTypes.TEXT
        },
        pincode: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        }

    }, {
        tableName: 'crbt_buildings',
        timestamps: false
    });
    crbt_buildings.associate = function(models) {
        crbt_buildings.belongsTo(models.crbt_locations, {
            foreignKey: 'location_id',
            as: 'crbt_locations'
        });
        // crbt_buildings.belongsTo(models.crbt_bookings, {
        //     foreignKey: 'building_id',
        //     as: 'crbt_bookings'
        // });
    };

    return crbt_buildings;
};