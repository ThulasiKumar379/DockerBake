const { sequelize,DataTypes } = require('sequelize'); 
module.exports = (sequelize) => {
	let userpermissions= sequelize.define('userpermissions', {
		id: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		}, 
        permission_id: {
			allowNull: true,
			type: DataTypes.INTEGER
		},
        role_id: {
			allowNull: true,
			type: DataTypes.INTEGER
		},
        
	},
	{
		tableName: 'userpermissions',
		timestamps: false
	  });
	  userpermissions.associate = function(models) {
		userpermissions.belongsTo(models.permissions, {
			foreignKey : 'permission_id', 
			as:'permissions'
		}); 
	  };  
	  return userpermissions;
};