const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbm_user_status = sequelize.define('crbm_user_status', {
    status_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    status_name: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    created_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE 
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE 
    }
  },
  {
    tableName: 'crbm_user_status',
    timestamps: false
  });

  return crbm_user_status;
};
