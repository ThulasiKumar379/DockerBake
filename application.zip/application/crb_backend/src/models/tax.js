const { sequelize,DataTypes } = require('sequelize'); 
module.exports = (sequelize) => {
	let tax= sequelize.define('tax', {
		id: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		},
        tax_name: {
			allowNull: true,
			type: DataTypes.STRING(255)
		},
        type: {
			allowNull: true,
			type: DataTypes.STRING(255)
		},
        value: {
			allowNull: true,
			type: DataTypes.FLOAT
		},
		active: {
			allowNull: false,
			type: DataTypes.BOOLEAN,
		},
		createdby: {
			allowNull: true,
			type: DataTypes.INTEGER
		},
		updatedby: {
			allowNull: true,
			type: DataTypes.INTEGER
		},
		createdat: {
			allowNull: true,
			type: DataTypes.DATE
		},
        updatedat: {
			allowNull: true,
			type: DataTypes.DATE
		} 
	},
	{
		tableName: 'tax',
		timestamps: false
	  });

	  return tax;
};