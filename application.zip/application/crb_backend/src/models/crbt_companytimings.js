const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_companytimings = sequelize.define('crbt_companytimings', {
    companytimings_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    company_name: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    system_user_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    start_time: {
      allowNull: false,
      type: DataTypes.TIME
    },
    end_time: {
      allowNull: false,
      type: DataTypes.TIME
    },
    monday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    tuesday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    wednesday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    thursday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    friday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    saturday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    sunday: {
      allowNull: false,
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    created_by: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.STRING(255)
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
  }, {
    tableName: 'crbt_companytimings',
    timestamps: false
  });
  
  return crbt_companytimings;
};
