const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_participants = sequelize.define('crbt_participants', {
        id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        user_id: {
            allowNull: false,
            type: DataTypes.INTEGER,
        },
        booking_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        participants_status: {
            allowNull: true,
            type: DataTypes.STRING(50)
        }
    }, {
        tableName: 'crbt_participants',
        timestamps: false,
        freezeTableName: true
    });
    crbt_participants.associate = function(models) { 
        crbt_participants.belongsTo(models.crbt_users, {
            foreignKey: 'user_id',
            as: 'crbt_users'
        });
    };
    return crbt_participants;
    crbt_participants.removeAttribute('id');
};