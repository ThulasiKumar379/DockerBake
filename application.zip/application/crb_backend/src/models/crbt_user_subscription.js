const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_user_subscription = sequelize.define('crbt_user_subscription', {
    subscriptionid: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    system_user_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    plan_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    startdate: {
      allowNull: true,
      type: DataTypes.DATE
    },
    enddate: {
      allowNull: true,
      type: DataTypes.DATE
    },
    status: {
      allowNull: true,
      type: DataTypes.STRING(100)
    },
    paymentid: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    created_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    }
  },
  {
    tableName: 'crbt_user_subscription',
    timestamps: false
  });
//   crbt_user_subscription.associate = function(models) {
//     crbt_user_subscription.belongsTo(models.crbt_user, {
//         foreignKey : 'user_id', 
//         as:'crbt_user'
//     });
//     crbt_user_subscription.belongsTo(models.crbm_subscription_plan, {
//         foreignKey : 'plan_id', 
//         as:'crbm_subscription_plan'
//     });
// }

  return crbt_user_subscription;
};
