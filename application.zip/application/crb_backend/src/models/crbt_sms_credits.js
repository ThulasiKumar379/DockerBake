const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_sms_credits = sequelize.define('crbt_sms_credits', {
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    system_user_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    available_credits: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    }
  },
  {
    tableName: 'crbt_sms_credits',
    timestamps: false
  });
 

  return crbt_sms_credits;
};
