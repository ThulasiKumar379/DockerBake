const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_room_amenities = sequelize.define('crbt_room_amenities', {
    room_id: {
      allowNull: false, 
      type: DataTypes.INTEGER,
      primaryKey: true
    }, 
    amenity_id: {
      allowNull: false, 
      type: DataTypes.INTEGER
    },
    created_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    } 
  },
  {
    tableName: 'crbt_room_amenities',
    timestamps: false,
    freezeTableName: true
  });

  crbt_room_amenities.associate = function(models) {
    crbt_room_amenities.belongsTo(models.crbt_rooms, {
        foreignKey: 'room_id',
        as: 'crbt_rooms'
    });
    
    crbt_room_amenities.belongsTo(models.crbm_aminities, {
      foreignKey: 'amenity_id',
      as: 'crbm_aminities'
  });
};
    return crbt_room_amenities;
};