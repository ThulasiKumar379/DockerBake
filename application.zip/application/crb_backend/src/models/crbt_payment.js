const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_payment = sequelize.define('crbt_payment', {
    payment_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    system_user_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    plan_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    subscription_plan_details: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    order_id: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    payment_ref_id: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    status: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    payment_status: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    payment_response: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    payment_request: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    purchase_type: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    amount: {
      allowNull: true,
      type: DataTypes.DECIMAL(10, 2)
    },
    tax: {
      allowNull: true,
      type: DataTypes.DECIMAL(10, 2)
    },
    total_amount: {
      allowNull: true,
      type: DataTypes.DECIMAL(10, 2)
    },
    payment_method: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    transaction_message: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    transaction_time: {
      allowNull: true,
      type: DataTypes.DATE
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    tax_breakup: {
      allowNull: true,
      type: DataTypes.TEXT
    }
  },
  {
    tableName: 'crbt_payment',
    timestamps: false
  });
 

  return crbt_payment;
};
