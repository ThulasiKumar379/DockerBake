const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const crbt_system_users = sequelize.define('crbt_system_users', {
    system_user_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.BIGINT
    },
    company_gst_number: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    company_name: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    company_officialwebsite: {
      allowNull: true,
      type: DataTypes.STRING(100)
    },
    company_address: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    username: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    password: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    email: {
      allowNull: true,
      type: DataTypes.STRING(100)
    },
    email_verify: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    mobile_verify: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    last_login: {
      allowNull: true,
      type: DataTypes.DATE
    },
    phone_number: {
      allowNull: true,
      type: DataTypes.STRING(20)
    },
    status: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    termsandconditions_accepted: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    key:{
      allowNull:true,
      type:DataTypes.STRING(50)
    },
  },
  {
    tableName: 'crbt_system_users',
    timestamps: false
  });
  return crbt_system_users;
};
