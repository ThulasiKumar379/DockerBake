const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
    const crbm_roomservice = sequelize.define('crbm_roomservice', {
        room_service_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        serviceid:{
            allowNull:false,
            type:DataTypes.STRING
        },
        room_service_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        service_icon: {
            allowNull: true,
            type: DataTypes.STRING(100)
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        }
    }, {
        tableName: 'crbm_roomservice',
        timestamps: false
    });
    crbm_roomservice.associate = function(models) {
        crbm_roomservice.hasMany(models.crbm_roomservice, {
            foreignKey: 'room_service_id',
            as: 'crbm_roomservice'
        });
    }
    return crbm_roomservice;

};