const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_departments = sequelize.define('crbt_departments', {
        department_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        department_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        departmentid: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        }
    }, {
        tableName: 'crbt_departments',
        timestamps: false
    });
    crbt_departments.associate = function(models) {
        crbt_departments.hasMany(models.crbt_departments, {
            foreignKey: 'department_id',
            as: 'crbt_departments'
        });
    };



    return crbt_departments;
};