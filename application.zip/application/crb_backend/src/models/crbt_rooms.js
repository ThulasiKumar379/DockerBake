const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_rooms = sequelize.define('crbt_rooms', {
        room_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        roomid: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        room_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        floor_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        capacity: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        building_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        location_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
    }, {
        tableName: 'crbt_rooms',
        timestamps: false
    });
    crbt_rooms.associate = function(models) {
        crbt_rooms.belongsTo(models.crbt_buildings, {
            foreignKey: 'building_id',
            as: 'crbt_buildings'
        });
        crbt_rooms.belongsTo(models.crbt_locations, {
            foreignKey: 'location_id',
            as: 'crbt_locations'
        });
        crbt_rooms.belongsTo(models.crbt_floors, {
            foreignKey: 'floor_id',
            as: 'crbt_floors'
        });
        crbt_rooms.belongsTo(models.crbt_room_amenities, {
            foreignKey: 'room_id',
            as: 'crbt_room_amenities'
        });
        // crbt_rooms.belongsTo(models.crbt_bookings, {
        //     foreignKey: 'room_id',
        //     as: 'crbt_bookings'
        // });
    };
    return crbt_rooms;
};