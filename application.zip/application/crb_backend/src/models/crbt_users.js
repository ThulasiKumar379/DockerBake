const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbt_users = sequelize.define('crbt_users', {
        user_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        first_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        last_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        email: {
            allowNull: true,
            type: DataTypes.STRING(100)
        },
        password: {
            allowNull: true,
            type: DataTypes.TEXT
        },
        designation_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        role_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        department_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        creation_date: {
            allowNull: true,
            type: DataTypes.DATE
        },
        employee_code: {
            allowNull: true,
            type: DataTypes.STRING(20)
        },
        location_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        building_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        mobile_number: {
            allowNull: true,
            type: DataTypes.STRING(100)
        },
        isactive: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        system_user_id: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        profilepic_key: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        user_type: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        otp:{
            allowNull:true,
            type:DataTypes.STRING(10)
          },
    }, {
        tableName: 'crbt_users',
        timestamps: false
    });

    crbt_users.associate = function(models) {
        crbt_users.belongsTo(models.crbt_roles, {
            foreignKey: 'role_id',
            as: 'crbt_roles'
        });
        crbt_users.belongsTo(models.crbt_designations, {
            foreignKey: 'designation_id',
            as: 'crbt_designations'
        });
        crbt_users.belongsTo(models.crbt_departments, {
            foreignKey: 'department_id',
            as: 'crbt_departments'
        });
        crbt_users.belongsTo(models.crbt_locations, {
            foreignKey: 'location_id',
            as: 'crbt_locations'
        });
        crbt_users.belongsTo(models.crbt_buildings, {
            foreignKey: 'building_id',
            as: 'crbt_buildings'
        });


    };
    return crbt_users;

};