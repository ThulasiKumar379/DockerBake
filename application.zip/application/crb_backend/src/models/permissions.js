const { sequelize,DataTypes } = require('sequelize'); 
module.exports = (sequelize) => {
	let permissions= sequelize.define('permissions', {
		id: {
			allowNull: false,
			autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
		},
        name: {
			allowNull: true,
			type: DataTypes.STRING(255)
		},
        key: {
			allowNull: true,
			type: DataTypes.STRING(255)
		},
		status: {
			allowNull: true,
			type: DataTypes.BOOLEAN
		},
	},
	{
		tableName: 'permissions',
		timestamps: false
    });  
	permissions.associate = function(models) {
		permissions.hasMany(models.userpermissions, {
			foreignKey : 'permission_id', 
			as:'userpermissions'
		}); 
	  };  
	return permissions;
};