const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const crbm_subscription_plans = sequelize.define('crbm_subscription_plans', {
        plan_id: {
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            type: DataTypes.INTEGER
        },
        plan_name: {
            allowNull: true,
            type: DataTypes.STRING(50)
        },
        description: {
            allowNull: true,
            type: DataTypes.TEXT
        },
        price: {
            allowNull: true,
            type: DataTypes.DECIMAL(10, 2)
        },
        status: {
            allowNull: true,
            type: DataTypes.BOOLEAN
        },
        tenure: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        updated_by: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        created_at: {
            allowNull: true,
            type: DataTypes.DATE
        },
        updated_at: {
            allowNull: true,
            type: DataTypes.DATE
        },

    }, {
        tableName: 'crbm_subscription_plans',
        timestamps: false
    });
    crbm_subscription_plans.associate = function(models) {
		crbm_subscription_plans.hasMany(models.crbm_subscription_features, {
			foreignKey : 'plan_id', 
			as:'crbm_subscription_features'
		});  
  }; 
    return crbm_subscription_plans;
};