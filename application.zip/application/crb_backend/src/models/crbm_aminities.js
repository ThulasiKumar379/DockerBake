const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbm_aminities = sequelize.define('crbm_aminities', {
    amenityid: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    aminity_id:{
      allowNull:false,
      type:DataTypes.STRING
    },
    amenityname: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    thumbnail_key: {
      allowNull: true,
      type: DataTypes.STRING(100)
    },
    status: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    created_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    }
  },
  {
    tableName: 'crbm_aminities',
    timestamps: false
  });
  crbm_aminities.associate = function(models) {
    crbm_aminities.hasMany(models.crbt_room_amenities, {
        foreignKey: 'amenity_id',
        as: 'crbt_room_amenities'
    }); 
  };
    return crbm_aminities;
};