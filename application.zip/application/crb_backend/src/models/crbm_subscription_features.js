const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbm_subscription_features = sequelize.define('crbm_subscription_features', {
    feature_id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    plan_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    userlimit: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    location_limit: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    building_limit: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    booking_limit: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    updated_by: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    status:{
      allowNull:true,
      type:DataTypes.BOOLEAN
    },
    
  },
  {
    tableName: 'crbm_subscription_features',
    timestamps: false
  });
  crbm_subscription_features.associate = function(models) {
		crbm_subscription_features.belongsTo(models.crbm_subscription_plans, {
			foreignKey : 'plan_id', 
			as:'crbm_subscription_plans'
		});  
  }; 
  return crbm_subscription_features;
};
