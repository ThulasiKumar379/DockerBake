const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const crbt_notifications = sequelize.define('crbt_notifications', {
    notificationid: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: DataTypes.INTEGER
    },
    user_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    notification_type: {
      allowNull: true,
      type: DataTypes.STRING(50)
    },
    message: {
      allowNull: true,
      type: DataTypes.TEXT
    },
    read: {
      allowNull: true,
      type: DataTypes.BOOLEAN
    },
    created_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
    updated_at: {
      allowNull: true,
      type: DataTypes.DATE
    },
  },
  {
    tableName: 'crbt_notifications',
    timestamps: false
  });
 

  return crbt_notifications; 
};
