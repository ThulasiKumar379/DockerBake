var db = require('../../models/index')
const logger = require('../../../utils/winston')

const userprofile=async function(req,res,next)
{
    try {
        if (typeof req.query.user_id == 'undefined') {
            return logger.error(res, "User ID parameter is missing");
        }
        if (/^\s*$/.test(req.query.user_id)) {
            return logger.error(res, "User ID cannot be empty");
        }
        if (isNaN(req.query.user_id)) {
            return logger.error(res, "Invalid User ID. Only number are allowed.");
        }
        let userdata = await db.crbt_users.findOne({
            attributes: ["user_id", "isactive"],
            where: { user_id: req.query.user_id, isactive: false, system_user_id: req.systemUser.system_user_id }
        })
        if (userdata) {
            return logger.error(res, "User is inactive");
        }
        let useredit = await db.crbt_users.findOne({
            attributes: ['user_id'],
            where: { user_id: req.query.user_id },
        });
        if (!useredit) {
            return logger.error(res, "User ID not found");
        }
        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in User Profile");
    }
};

const passwordupdate=async function(req,res,next)
{
    try{
        if (typeof req.body.Currentpassword == 'undefined') {
            return logger.error(res, "Currentpassword parameter is missing");
        }
        if (/^\s*$/.test(req.body.Currentpassword)) {
            return logger.error(res, "Currentpassword cannot be empty");
        }
        if (typeof req.body.Newpassword == 'undefined') {
            return logger.error(res, "Newpassword parameter is missing");
        }
        if (/^\s*$/.test(req.body.Newpassword)) {
            return logger.error(res, "Newpassword cannot be empty");
        }
        if (typeof req.body.Confirmpassword == 'undefined') {
            return logger.error(res, "Confirmpassword parameter is missing");
        }
        if (/^\s*$/.test(req.body.Confirmpassword)) {
            return logger.error(res, "Confirmpassword cannot be empty");
        }
        next();
    }
    catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Password Update");
    }
};

module.exports=
{
    userprofile,
    passwordupdate
}