var db = require('../../models/index')
const logger = require('../../../utils/winston')
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");
const { S3bucketupload, deleteProfilePic } = require('../../../lib/s3/s3'); 
var jwt = require('jsonwebtoken')
var bcrypt = require('bcrypt');
var moment = require('moment')
var fs = require('fs')
const multer = require('multer');
var env = require('../../../config/environment');
const path = require('path');
const AWS = require('aws-sdk');
const systemUser = require('../../../middleware/auth')
// const { deleteProfilePic } = require('../../../lib/s3/s3');


const getuserprofile = async function(req, res, next) {
  try {
    db.crbt_users.belongsTo(db.crbt_designations, { foreignKey: 'designation_id', as: 'designation' });
    db.crbt_users.belongsTo(db.crbt_roles, { foreignKey: 'role_id' });
    db.crbt_users.belongsTo(db.crbt_departments, { foreignKey: 'department_id' });
    db.crbt_users.belongsTo(db.crbt_locations, {foreignKey: 'location_id'})

    const userdataa = await db.crbt_users.findAll({
      attributes: ["user_id", "email", "employee_code", "mobile_number"],
      order: [['user_id', "ASC"]],
      where: {
        isactive: true,
        system_user_id: req.systemUser.system_user_id,
        user_id: req.query.user_id
      },
      include: [
        { model: db.crbt_designations, attributes: ['designation_name'], as: 'designation' },
        { model: db.crbt_roles, attributes: ['role_name'] },
        { model: db.crbt_departments, attributes: ['department_name'] },
        { model: db.crbt_locations, attributes: ['location_name'] }
      ]
    });

    if (userdataa.length === 0) {
      return res.status(400).send({ status: false, message: "User Data not available" });
    } else {
      return res.status(200).send({ status: true, message: "User Data retrieved successfully", userdataa });
    }
  } catch (error) {
    logger.createLog(__filename, error.message, req);
    return logger.error(res, "Exception in User Data");
  }
};

let changepassword = async function (req, res, next) {
  try {
    if (!req.user || !req.user.user_id) {
      return logger.error(res,"User information not found or invalid token." );
    }

    let profiledata = await db.crbt_users.findOne({
      where: { user_id: req.user.user_id },
    });

    if (!profiledata) {
      return logger.error(res,"Profile not found." );
    }

    if (!req.body.Currentpassword ) {
      return logger.error(res,"Current Password can not be empty.");
    }
    if ( !req.body.Newpassword) {
      return logger.error(res,"New password can not be empty.");
    }
    if ( !req.body.Confirmpassword) {
      return logger.error(res,"Confirm password can not be empty.");
    }

    const passwordMatches = await bcrypt.compare(req.body.Currentpassword, profiledata.password);
    if (!passwordMatches) {
      return logger.error(res, "Current password is incorrect." );
    }

    if (req.body.Newpassword !== req.body.Confirmpassword) {
      return logger.error(res,"New password and confirm password did not match." );
    }
    const hashedNewPassword = await bcrypt.hash(req.body.Newpassword, parseInt(process.env.SALT_ROUNDS));

    await db.crbt_users.update({ password: hashedNewPassword }, {
      where: { user_id: req.user.user_id },
    });

    return logger.success(res,"Password updated successfully." );

  } catch (error) {
    logger.createLog(__filename, error.message, req);
    return logger.error(res,"Exception in password update.");
  }
}

var storage = multer.diskStorage({ 
  destination: function (req, file, cb) {
      cb(null, './uploads/userprofilepic')
  },
  filename: function (req, file, cb) {
    const uniquePrefix = req.user.user_id+Date.now();
      req.userprofilepic= uniquePrefix+".jpg"; 
    cb(null, req.userprofilepic); // Generate a unique filename for the uploaded file
  }
})
const maxSize = 1 * 1000 * 1000;
var upload = multer({ 
  storage: storage,
  limits: { fileSize: maxSize },
  fileFilter: function (req, file, cb){ 
      var filetypes = /jpeg|jpg|png|gif/;
      var mimetype = filetypes.test(file.mimetype);  
      var extname = filetypes.test(path.extname(
                  file.originalname).toLowerCase());
      
      if (mimetype && extname) {
          return cb(null, true);
      } 
      cb("Error: File upload only supports the "
              + "following filetypes - " + filetypes);
    }  
}).single("mypic");

let uploadtoS3 = async function (req, res, next) {
  try {
    await fs.mkdir("./uploads/userprofilepic",{ recursive: true },function(err) {
      if (err) {
         
      } else {
          
      }
    });
    return upload(req,res,function(err) { 
      if(err) { 
          res.send({status:false,errorMessage:err})
      }
      else { 
          next();
      }
  }) 
  } catch (error) {
    logger.createLog(__filename, error.message, req); 
    return logger.error(res, "Exception in Uploading");
  }
}

let uploadprofile = async function (req, res, next) {
  try {
    let uploadpath="./uploads/userprofilepic/"+req.userprofilepic;
    let profilepic_key="userprofilepic/"+req.userprofilepic; 
    S3bucketupload(profilepic_key,uploadpath).then(async function(data){ 
      fs.unlink(uploadpath, async (err) => {
        if (err) {
          console.error(err)
          return err;
        } else{
        let pic= await db.crbt_users.findOne({
                     where:{user_id:req.user.user_id,isactive:true}
                 });
         if(pic!=null){
             await db.crbt_users.update({
                 profilepic_key:profilepic_key
             },{
                 where:{ 
                     user_id:req.user.user_id,
                     isactive:true
                 }
             });  
             console.log(pic.dataValues.key);
             deleteProfilePic(pic.dataValues.key);
         }else{
            await db.crbt_users.create({ 
                 user_id:req.user.user_id,
                 profilepic_key:profilepic_key,
             });  
         }  
        }
    })
});
      return logger.success(res,"Profile Pic updated successfully",profilepic_key);
      } catch (error) {
      logger.createLog(__filename,error.message,req)
      return logger.error(res,"Exception in Profile Pic Update");
      }
};

const deleteProfilePicture = async function(req, res, next) {
  try {
    if (!req.user || !req.user.user_id) {
      return res.status(400).send({ status: false, message: "User information not found" });
    }
    const userProfile = await db.crbt_users.findOne({
      where: { user_id: req.user.user_id, isactive: true }
    });
    if (!userProfile) {
      return res.status(404).send({ status: false, message: "Profile not found" });
    }
    if (!userProfile.profilepic_key) {
      return res.status(400).send({ status: false, message: "No profile picture found for the user" });
    }
    deleteProfilePic(userProfile.profilepic_key);
    await db.crbt_users.update({ profilepic_key: null }, {
      where: {
        user_id: req.user.user_id,
        isactive: true
      }
    });
    return res.status(200).send({ status: true, message: "Profile picture deleted successfully" });
  } catch (error) {
    logger.createLog(__filename, error.message, req);
    return res.status(500).send({ status: false, message: "Exception in deleting profile picture" });
  }
};

module.exports = {
  getuserprofile,
  changepassword,
  uploadtoS3,
  uploadprofile,
  deleteProfilePicture
};