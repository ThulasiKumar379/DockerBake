var db = require('../../models/index')
const logger = require('../../../utils/winston');
var { sequelize } = require('../../models/index');
const { Sequelize, Op } = require("sequelize");

function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

let createLocation = async function(req, res, next) {

    try {

        req.body.location_name = req.body.location_name.trim();

        let existingLocationID = await db.crbt_locations.findOne({
            where: { locationid: req.body.location_id.toString() }
        });
        

        if (existingLocationID) {
            return res.status(400).send({ status: false, message: "Location ID already exists." });
        }

        let existingLocationName = await db.crbt_locations.findOne({
            where: { location_name: req.body.location_name }
        });

        if (existingLocationName) {
            return logger.error(res, "Location Name already exists." );
        }

        let insertdata = {

            locationid: req.body.location_id.toString(),
            location_name: req.body.location_name,
            city: req.body.city,
            state: req.body.state,
            country: req.body.country,
            system_user_id: req.systemUser.system_user_id,
            created_by: req.systemUser.system_user_id,
            status: req.body.status
        };
        const createdLocation = await db.crbt_locations.create(insertdata);

        if (createdLocation) {
            const responseData = {

                location_id: createdLocation.locationid,
                location_name: createdLocation.location_name,
                city: createdLocation.city,
                state: createdLocation.state,
                country: createdLocation.country,
                status: createdLocation.status,
                system_user_id: createdLocation.system_user_id,
                created_by: createdLocation.created_by

            };
            return res.status(200).send({ status: true, message: "New Location inserted", data: responseData });
        } else {
            return logger.error(res, "Error in Location");
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req);
        console.log(error)
        return logger.error(res, "Exception in inserting new Location");
    }
};

let updatelocation = async function(req, res, next) {
    try {
        let updatelocation = await db.crbt_locations.findOne({
            where: { locationid: req.body.location_id.toString() }
        })
        if(req.body.status=='Active'){req.body.status=true}
        if(req.body.status=='Inactive'){req.body.status=false}
        
        // if(req.body.status=='Active'){req.body.status=true}
        let locationupdate = await db.crbt_locations.update({
            location_name: req.body.location_name.trim(),
            city: req.body.city,
            state: req.body.state,
            country: req.body.country,
            status: req.body.status,
            system_user_id: req.systemUser.system_user_id,
            updated_at: Date.now(),
            updated_by: req.systemUser.system_user_id
        }, {
            where: {
                locationid: req.body.location_id.toString(),
                system_user_id: req.systemUser.system_user_id
            },
        })
        if (updatelocation.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (updatelocation.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Location Updated Successfully", locationupdate });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location update");
    }
}


let deletelocation = async function (req, res, next) {
    try {
        let deletelocation = await db.crbt_locations.findOne({
          attributes:['system_user_id'],
            where: { locationid: req.body.location_id}
        })
        let locationdelete=  await db.crbt_locations.update(
            {
                status:false
            },
            {
                where: {
                    locationid: req.body.location_id,
                    system_user_id: req.systemUser.system_user_id,
                },
            }
        )
        if (deletelocation.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied"});
        } else if (deletelocation.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Location deleted successfully" ,locationdelete});
        }
    } catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Location delete");
    }
  };

let getlocation = async function(req, res, next) {
    try {
        let query = {}
        if (req.query.location_name && req.query.location_name != "") {
            if (Object.keys(query).length === 0) {
                query = ` and lower(location_name) like '${req.query.location_name.toLowerCase()}%'`
            } else {
                query = `${query} and lower(location_name) like '${req.query.location_name.toLowerCase()}%'`
            }
        };

        if (req.query.location_id) {
            query = ` and location_id = ${req.query.location_id}`
        }
        if (Object.keys(query).length === 0) {
            query = ''
        }
        const [data] = await sequelize.query(
            `SELECT locationid AS location_id, location_name,city,state,country,created_at,updated_at,status
            FROM crbt_locations
            WHERE system_user_id = ${req.systemUser.system_user_id} ${query}
            ORDER BY locationid DESC`
        );
        return logger.success(res, "Locations retrived successfully", data)

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location List");
    }
}


let fetchLocations = async function(req, res, next) {
    try {
        let location = await db.crbt_locations.findAll({
            attributes: [
                "location_id",["locationid", "ulocation_id"], "location_name"
            ],
            order: [
                [db.crbt_locations.rawAttributes.locationid, "DESC"]
            ],
            where: {
                status: true,
                system_user_id: req.systemUser.system_user_id,
                status: true,
            }
        });
        if (location.length === 0) {
            return res.status(200).send({ status: false, message: "Data not found", location });
        } else {
            return res.status(200).send({ status: true, message: "Locations retrived successfully", location });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location");
    }
}

let getlocationbyid = async function(req, res, next) {
    try {
        let getlocation = await db.crbt_locations.findOne({
            where: { locationid: req.query.location_id }
        })
        let locationn = await db.crbt_locations.findOne({
            attributes: [
                ["locationid", "location_id"], "location_name", "city", "state", "country", "status", "created_at", "updated_at"
            ],
            where: {
                locationid: req.query.location_id,
                system_user_id: req.systemUser.system_user_id
            },
            order: [
                [db.crbt_locations.rawAttributes.locationid, "DESC"]
            ],
        })
        if (getlocation.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (getlocation.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Location Retrived Successfully", locationn });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location");
    }
}

let getlocationsDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        console.log(order_data)
        let locationTotal = await db.crbt_locations.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`location_id`)), 'locationCount'],
            ],
            where: {
                status: true
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.department_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        var where_query = '';

        if (req.query.location_id != "") {
            where_query = where_query + ` and a.location_id='${req.query.location_id}'`
        }

        if (req.query.location_name != "") {
            where_query = where_query + ` and a.location_name LIKE'${req.query.location_name}'`
        }
        if (req.query.location_address != "") {
            where_query = where_query + ` and a.location_name LIKE '${req.query.location_address}'`
        }

        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and  (a.location_id::text = '${search_value}' OR LOWER(a.location_name)::text LIKE '%${search_value}%' OR LOWER(a.location_address)::text LIKE '%${search_value}%' OR  a.status::text LIKE '%${search_value}%' )`;
        }
        const locationsearchdata = await sequelize.query(`select COUNT(a.location_id) AS Total from crbt_locations a where status = 'true' ${where_query} ${search_query}`);
        let query = `select a.location_id,a.location_name,a.location_address,a.status from crbt_locations a where status = 'true' ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const locationData = await sequelize.query(query);
        let data = [];
        if (locationData[0].length != 0) {
            for (i = 0; i < locationData[0].length; i++) {
                data.push({
                    location_id: locationData[0][i].location_id,
                    location_name: locationData[0][i].location_name,
                    location_address: locationData[0][i].location_address,
                    status: locationData[0][i].status,
                    action: `<div> 
                    <span class='a-edit' catid='${locationData[0][i].location_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${locationData[0][i].location_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${locationData[0][i].location_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': locationTotal.dataValues.locationCount,
            'iTotalDisplayRecords': locationsearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}

let Locationdeactivate = async function(req, res, next) {
    try {
        let locationdataa = await db.crbt_locations.findOne({
                where: { locationid: req.body.location_id.toString() }
            })
            // await detectNumeric(req.body.status);
        let status_location = parseInt(req.body.status);
        if (status_location === 1) {
            status_value = true;
        } else if (status_location === 0) {
            status_value = false;
        } else {
            return res.status(400).send({ status: false, message: "Only 0 or 1 is allowed." });
        }
        let locationupdate = await db.crbt_locations.update({ status: status_value }, {
            where: {
                locationid: req.body.location_id.toString(),
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (locationdataa.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", locationupdate });
        } else if (locationdataa.system_user_id === req.systemUser.system_user_id) {
            if (status_location === 0) {
                return res.status(200).send({ status: true, message: "Location deactivated successfully", locationupdate });
            } else {
                return res.status(200).send({ status: true, message: "Location activated successfully", locationupdate });
            }
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return res.status(500).send({ status: false, message: "Exception in location deactivation" });
    }
}

module.exports = {
    createLocation,
    updatelocation,
    deletelocation,
    getlocation,
    getlocationbyid,
    getlocationsDataTable,
    fetchLocations,
    Locationdeactivate
}