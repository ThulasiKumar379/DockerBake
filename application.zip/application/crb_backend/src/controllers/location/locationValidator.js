var db = require('../../models/index');
const logger = require('../../../utils/winston');

function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

let locationcreate = async function (req, res, next) {
    try {
        await detectNumeric(req.body);
        if(typeof req.body.location_id=='undefined'){
            return logger.error(res,"Location ID Parameter is missing");
        }
        if (typeof req.body.location_name == 'undefined')  {
            return logger.error(res,"Location Name Parameter is missing");
        } 
        if ( typeof req.body.city == 'undefined' ) {
            return logger.error(res,"City Parameter is missing");
        }
        if (typeof req.body.state == 'undefined') {
            return logger.error(res,"State Parameter is missing");
        }
        if (typeof req.body.country == 'undefined' ) {
            return logger.error(res,"Country Parameter is missing");
        }
        if (!req.body.status) {
            return logger.error(res,"Status is Inactive");
        }
        if ( typeof req.body.status == 'undefined') {
            return logger.error(res,"Status Parameter is missing");
        }
        if (!req.body.location_id) {
            return logger.error(res,"Location ID Parameter should not be empty");
        }
        if (!req.body.location_name) {
            return logger.error(res,"Location Name Parameter should not be empty");
        }
        if (!req.body.city) {
            return logger.error(res,"city Parameter should not be empty");
        }
        if (!req.body.state) {
            return logger.error(res,"State Parameter should not be empty");
        }
        if  (!req.body.country) {
            return logger.error(res,"Country Parameter should not be empty");
        }
        if (/^\s*$/.test(req.body.location_id)||/^\s*$/.test(req.body.location_name)||/^\s*$/.test(req.body.city) || /^\s*$/.test(req.body.state) || /^\s*$/.test(req.body.country)|| /^\s*$/.test(req.body.status)) {
            return logger.error(res, "Parameters cannot be empty");
        }        
        if (Number(req.body.location_name) || Number(req.body.city) || Number(req.body.state) || Number(req.body.country)) {
            return logger.error(res, "Numbers are not allowed, please try using a string.");
        }
        next();
    } catch (error) {
        logger.createLog(__filename,error.message,req)
        console.log(error)
        return logger.error(res,"Exception in insert Location");
    }
}


const locationdelete = async function(req, res, next) {
    try {
        // await detectNumeric(req.body);
        if (req.body.location_id == 'undefined') {
            return logger.error(res, "Location id parameter is missing.");
        }
        if (/^\s*$/.test(req.body.location_id)) {
            return logger.error(res, "Location ID cannot be empty");
        } 
        // if (!Number.isInteger(req.body.location_id)) {
        //     return logger.error(res,"Invalid format.");
        // }
        let deletelocation = await db.crbt_locations.findOne({
            attributes: ["locationid", "status","system_user_id"],
            where: { locationid: req.body.location_id, status:false, system_user_id: req.systemUser.system_user_id}
        })
        if (deletelocation) {
            return logger.error(res, "Location already inactive.");
        }
        let findlocations = await db.crbt_locations.findOne({
            
            where: { locationid: req.body.location_id },
        });
        if (!findlocations) {
            return logger.error(res, "Location id not found");
        }
        
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location delete");
    }
};

let locationupdate = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.body.location_name == 'undefined'||typeof req.body.location_id=='undefined' || typeof req.body.city == 'undefined' || typeof req.body.state == 'undefined' ||  typeof req.body.country == 'undefined'|| typeof req.body.status == 'undefined') {
            return logger.error(res, "Parameter is missing");
        }
        if (/^\s*$/.test(req.body.location_id)||/^\s*$/.test(req.body.location_name)||/^\s*$/.test(req.body.city) || /^\s*$/.test(req.body.state) || /^\s*$/.test(req.body.country)|| /^\s*$/.test(req.body.status)) {
            return logger.error(res, "Parameters cannot be empty");
        } 
        if (Number(req.body.location_name||req.body.city || req.body.state|| req.body.country|| req.body.status)) {
            return logger.error(res, "Invalid input");
        }
        const location_name = req.body.location_name.trim();
        if (location_name && location_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Location Name exceeds maximum length of 255 characters' });
        }
        if (typeof req.body.location_name !== 'string') {
            return logger.error(res, "Invalid Location Name");
        }
       
        let locationedit = await db.crbt_locations.findOne({
            attributes: ['location_id'],
            where: { locationid: req.body.location_id.toString() },
        });
        if (!locationedit) {
            return logger.error(res, "Location with the given Location ID not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Location update");
    }
}

let getlocationbyid = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.query.location_id=='undefined') {
            return logger.error(res,"Parameter Missing");
        }
        if (/^\s*$/.test(req.query.location_id)) {
            return logger.error(res, "Location ID cannot be empty");
        } 
        if (!Number(req.query.location_id)) {
            return logger.error(res, "Invalid input location ID cannot be String");
        }
        let locationget = await db.crbt_locations.findOne({
            attributes: ['location_id'],
            where: { locationid: req.query.location_id },
        });
        if (!locationget) {
            return logger.error(res, "Location ID not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in retrieving Location.");
    }
};

const getlocationfetch = async function(req, res, next) {
    try {
        await detectNumeric(req.query);
        console.log(req.query);
        if (req.query.location_id && typeof req.query.location_id !== 'number') {
            return logger.error(res, "Invalid Location ID");
        }
        if (req.query.location_name && typeof req.query.location_name !== 'string') {
            return logger.error(res, "Invalid Location name");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location");
    }
};

const locationdeactivate = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        console.log(req.body);

        if (typeof req.body.location_id == 'undefined') {
            return logger.error(res, "Location ID parameter is missing");
        }
        if (req.body.location_id === null) {
            return logger.error(res, "Location ID cannot be empty.");
        }
        if (/^\s*$/.test(req.body.location_id)) {
            return logger.error(res, "Location ID cannot be empty");
        }
        if (!Number.isInteger(req.body.location_id)) {
            return logger.error(res, "Invalid Location ID");
        }
        let locationchange = await db.crbt_locations.findOne({
            attributes: ['location_id'],
            where: { locationid: req.body.location_id.toString() },
        })
        if (!locationchange) {
            return logger.error(res, "Location ID Not Found.");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Location Deactive");
    }
}





module.exports = {
    locationcreate,
    locationdelete,
    locationupdate,
    getlocationbyid,
    getlocationfetch,
    locationdeactivate
};