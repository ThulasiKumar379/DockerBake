var db = require('../../models/index')
const logger = require('../../../utils/winston')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}

const createDepartment = async function(req, res, next) {
    try {
        if (typeof req.body.department_id == 'undefined') {
            return logger.error(res, "Department ID parameter is missing");
        }
        if (/^\s*$/.test(req.body.department_id)) {
            return logger.error(res, "Department ID cannot be empty");
        }
        if (typeof req.body.department_name == 'undefined') {
            return logger.error(res, "Department Name Parameter is Missing");
        }
        if (typeof req.body.status == 'undefined') {
            return logger.error(res, "Status parameter is missing");
        }
        const department_name = req.body.department_name;
        if (department_name && department_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Department Name exceeds maximum length of 255 characters' });
        }
        if (req.body.department_name == null) {
            return logger.error(res, "Department Name cannot be empty ");
        }
        if (req.body.status == null) {
            return logger.error(res, "Status cannot be empty ");
        }
        if (/^\s*$/.test(req.body.department_name)) {
            return logger.error(res, "Department Name cannot be empty");
        }
        if (typeof req.body.department_name !== 'string' || !/^[a-zA-Z\s]+$/.test(req.body.department_name)) {
            return logger.error(res, "Invalid Data Type for Department Name. Only characters are allowed.");
        }
        let departmentnamecheckk = await db.crbt_departments.findOne({
            attributes: ["department_name"],
            where: db.sequelize.where(db.sequelize.fn('LOWER', db.sequelize.col('department_name')), req.body.department_name.toLowerCase())
        });
        if (departmentnamecheckk != null) {
            return logger.error(res, "Department Name already exists");
        }        

        let departmentidCheck = await db.crbt_departments.findOne({
            attributes: ["departmentid"],
            where: { departmentid: req.body.department_id, system_user_id: req.systemUser.system_user_id }
        });
        if (departmentidCheck) {
            return logger.error(res, "Department ID already exists");
        }

        let departmentnamecheck = await db.crbt_departments.findOne({
            attributes: ["department_name"],
            where: { department_name: req.body.department_name }
        });
        if (departmentnamecheck != null) {
            if (departmentnamecheck.department_name === req.body.department_name) {
                return logger.error(res, "Department Name already exists");
            }
        }
        next();

    } catch (error) {
        console.log()
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department Creation");
    }
}
let editDepartment = async function(req, res, next) {
    try {
        // console.log("res====", req.body);
        // // await detectNumeric(req.body);
        // console.log(req.body);
        req.body.department_id = req.body.department_id.toString()
        if (typeof req.body.department_name == 'undefined') {
            return logger.error(res, "Department Name parameter is missing");
        }
        if (typeof req.body.department_id == 'undefined') {
            return logger.error(res, "Department ID parameter is missing");
        }
        if (/^\s*$/.test(req.body.department_id)) {
            return logger.error(res, "Department ID cannot be empty");
        }
        if (req.body.department_id == null) {
            return logger.error(res, "Department ID cannot be empty ");
        }
        if (req.body.department_name == null) {
            return logger.error(res, "Department Name cannot be empty ");
        }
        if (/^\s*$/.test(req.body.department_name)) {
            return logger.error(res, "Department Name cannot be empty");
        }
        const department_name = req.body.department_name;
        if (department_name && department_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Department Name exceeds maximum length of 255 characters' });
        }

        if (typeof req.body.department_name !== 'string') {
            return logger.error(res, "Invalid Department Name");
        }

        let departmentEdit = await db.crbt_departments.findOne({
            attributes: ['departmentid'],
            where: { departmentid: req.body.department_id, system_user_id: req.systemUser.system_user_id },
        });
        if (!departmentEdit) {
            return logger.error(res, "Department ID not found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Department update");
    }
}
const deleteDepartment = async function(req, res, next) {
    try {

        console.log("res=======", req.body);
        // await detectNumeric(req.body);
        req.body.department_id = req.body.department_id
        if (typeof req.body.departmentid == 'undefined') {
            return logger.error(res, "Department ID parameter is missing");
        }
        if (/^\s*$/.test(req.body.departmentid)) {
            return logger.error(res, "Department ID cannot be empty");
        }
        if (req.body.departmentid === null) {
            return logger.error(res, "Department ID parameter is missing.");
        }
        // if (typeof req.body.department_id !== 'number') {
        //     return logger.error(res, "Invalid Department ID");
        // }

        let departmentData = await db.crbt_departments.findOne({
            attributes: ["departmentid", "status"],
            where: { departmentid: req.body.department_id, status: false, system_user_id: req.systemUser.system_user_id }
        });
        if (departmentData) {
            return logger.error(res, "Department is already Inactive");
        }
        let departmentdelete = await db.crbt_departments.findOne({
            attributes: ['departmentid'],
            where: { departmentid: req.body.department_id, system_user_id: req.systemUser.system_user_id },
        });
        if (!departmentdelete) {
            return logger.error(res, "Department ID not found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department Delete");
    }
}
const getDepartment = async function(req, res, next) {
    try {
        console.log("res==============", req.query);
        detectNumeric(req.query.id);
        // req.body.department_id = req.body.department_id
        if (typeof req.query.department_id == 'undefined') {
            return logger.error(res, "Department Name parameter is missing");
        }
        if (/^\s*$/.test(req.query.department_id)) {
            return logger.error(res, "Department ID cannot be empty");
        }
        if (req.query.department_id == null) {
            return logger.error(res, "Department ID cannot be empty ");
        }
        if (isNaN(req.query.department_id)) {
            return logger.error(res, "Invalid data type for Department ID. Only number are allowed.");
        }
        let departmentEdit = await db.crbt_departments.findOne({
            attributes: ['departmentid'],
            where: { departmentid: req.query.department_id },
        });
        console.log(departmentEdit);
        if (!departmentEdit) {
            return logger.error(res, "Department ID  not found");
        }


        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department get");
    }
}

const getDepartmentfetch = async function(req, res, next) {
    try {
        
        await detectNumeric(req.query);
        req.body.department_id = req.body.department_id
        console.log(req.query);
        if (req.query.department_name && typeof req.query.department_name !== 'string') {
            return logger.error(res, "Invalid Department Name");
        }
        // if (req.query.department_id && typeof req.query.department_id !== 'number') {
        //     return logger.error(res, "Invalid Department ID");
        // }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department Fetching");
    }
}
 
const departmentActDec = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        console.log(req.body);

        if (typeof req.body.department_id == 'undefined') {
            return logger.error(res, "Department ID parameter is missing");
        }
        if (req.body.department_id === null) {
            return logger.error(res, "Department ID cannot be empty.");
        }
        if (/^\s*$/.test(req.body.department_id)) {
            return logger.error(res, "Department ID cannot be empty");
        }
        // if (!Number.isInteger(req.body.department_id)) {
        //     return logger.error(res, "Invalid Department ID");
        // }
        let departmentedit = await db.crbt_departments.findOne({
            attributes: ['departmentid'],
            where: { departmentid: req.body.department_id.toString() },
        })
        if (!departmentedit) {
            return logger.error(res, "Department ID Not Found.");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department Deactive");
    }
}


module.exports = {
    createDepartment,
    editDepartment,
    deleteDepartment,
    getDepartment,
    getDepartmentfetch,
    departmentActDec
}