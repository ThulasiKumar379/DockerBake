var db = require('../../models/index')
const logger = require('../../../utils/winston')
    // const systemUser = require('../../../middleware/auth') 
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}

let createDepartment = async function(req, res, next) {
    try {
         
        req.body.department_name = req.body.department_name.trim();
        let insertdata = {
            departmentid: req.body.department_id,
            department_name: req.body.department_name,
            status: req.body.status,
            system_user_id: req.systemUser.system_user_id,
            created_by: req.systemUser.system_user_id
        }
        return await db.crbt_departments.create(insertdata).then(function(data) {
            if (data) {
                const responseData = {
                    department_id: data.departmentid,
                    department_name: data.department_name,
                    location_id: data.location_id,
                    status: data.status,
                    system_user_id: data.system_user_id,
                    created_by: data.created_by
                };
                return res.status(200).send({ status: true, message: "New Department Created Successfully.", data: responseData });
            } else {
                return logger.error(res, "Error in Creating Department.");
            }
        });

    } catch (error) {
        console.log('error', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Creating New Department");
    }
}

let editDepartment = async function(req, res, next) {
    try {
        let deptData = await db.crbt_departments.findOne({
            where: { departmentid: req.body.department_id }

        })
        let updateDepartment = await db.crbt_departments.update({
            department_name: req.body.department_name,
            updated_at: Date.now(),
            updated_by: req.systemUser.system_user_id,
            status: req.body.status
        }, {
            where: {
                departmentid: req.body.department_id,
                system_user_id: req.systemUser.system_user_id
            },
        })

        if (deptData.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", updateDepartment });
        } else if (deptData.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Department Updated successfully", updateDepartment });
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department Update");
    }
}
let deleteDepartment = async function(req, res, next) {
    try {
        let deptDelData = await db.crbt_departments.findOne({
            where: { departmentid: req.body.department_id }

        })
        const deleted = await db.crbt_departments.update({
            status: false

        }, {
            where: {
                departmentid: req.body.department_id,
                system_user_id: req.systemUser.system_user_id
            },
        })
        if (deptDelData.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", deleted });
        } else if (deptDelData.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Department Deleted Successfully", deleted });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Department Delete");
    }

}
let getDepartmentList = async function(req, res, next) {
    try {
        let departmentData = await db.crbt_departments.findAll({
            attributes: [
                ["departmentid", "department_id"], "department_name", "created_at", "updated_at", "status"
            ],
            order: [
                [db.crbt_departments.rawAttributes.departmentid, "DESC"]
            ],
            where: {
                system_user_id: req.systemUser.system_user_id
            }
        })
        if (departmentData.length === 0) {
            return res.status(400).send({ status: false, message: "Departments Not Available", departmentData });
        } else {
            return res.status(200).send({ status: true, message: "Departments Retrived Successfully", departmentData });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Departments List");
    }
}

let getDepartmentfetch = async function(req, res, next) {
    try {
        let query2 = {}

        if (req.query.department_name && req.query.department_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(department_name) like '${req.query.department_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(department_name) like '${req.query.department_name.toLowerCase()}%'`
            }
        };
        if (req.query.department_name && req.query.department_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(department_name) like '${req.query.department_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(department_name) like '${(req.query.department_name.toLowerCase())}%'`
            }
        };
        if (req.query.department_id) {
            query2 = ` and departmentid = ${req.query.department_id}`
        }
        if (Object.keys(query2).length === 0) {
            query2 = ''
        }
        const [results] = await sequelize.query(
            `SELECT departmentid AS department_id, department_name, system_user_id,status,created_by,updated_by,created_at, updated_at FROM crbt_departments             
             where system_user_id=${req.systemUser.system_user_id} ${query2}
             ORDER BY departmentid DESC`
        );
        if (results.length === 0) {
            return logger.success(res, "Departments data no found")
        } else {
            return logger.success(res, "Departments retrived successfully", results)
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Departments List");
    }
}

let getDepartment = async function(req, res, next) {
    try {
        let deptGetData = await db.crbt_departments.findOne({
            where: { departmentid: req.query.department_id }
        })
        let departmentDataa = await db.crbt_departments.findOne({
            attributes: [
                ["departmentid", "department_id"], "department_name", "status"
            ],
            order: [
                [db.crbt_departments.rawAttributes.departmentid, "DESC"]
            ],
            where: {
                departmentid: req.query.department_id,
                system_user_id: req.systemUser.system_user_id
            }
        })
        if (deptGetData.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", departmentDataa });
        } else if (deptGetData.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Departments retrived successfully", departmentDataa });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Get departments");
    }
}
let getDepartmentDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        console.log(order_data)
        let dep = await db.crbt_departments.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`department_id`)), 'depCount'],
            ],
            where: {
                status: true,
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.department_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and system_user_id=${req.systemUser.system_user_id} and  (d.department_id::text = '${search_value}' OR LOWER(d.department_name)::text LIKE '%${search_value}%' OR  d.status::text LIKE '%${search_value}%' )`;
        }
        const depsearchdata = await sequelize.query(`select COUNT(d.department_id) AS Total from crbt_departments d where status = 'true' ${search_query}`);
        let query = `select  d.department_id,d.department_name,d.status from crbt_departments d where status = 'true' ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const degData = await sequelize.query(query);
        let data = [];
        if (degData[0].length != 0) {
            for (i = 0; i < degData[0].length; i++) {
                data.push({
                    department_id: degData[0][i].department_id,
                    department_name: degData[0][i].department_name,
                    status: degData[0][i].status,
                    action: `<div> 
                    <span class='a-edit' catid='${degData[0][i].department_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${degData[0][i].department_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${degData[0][i].department_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': dep.dataValues.depCount,
            'iTotalDisplayRecords': depsearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}

let fetchDepartments = async function(req, res, next) {
    try {

        let departmentData = await db.crbt_departments.findAll({
            attributes: [
                'department_id', ["departmentid", "udepartment_id"], "department_name"
            ],
            order: [
                [db.crbt_departments.rawAttributes.departmentid, "DESC"]
            ],
            where: {
                status: true,
                system_user_id: req.systemUser.system_user_id
            }
        })
        if (departmentData.length != 0) {
            return res.status(200).send({ status: true, message: "Departments Retrived Successfully", departmentData });
        } else {
            return res.status(200).send({ status: false, message: "Data not found", departmentData });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Departments");
    }
}

let departmentActDec = async function(req, res, next) {
    try {
        let departmentdata = await db.crbt_departments.findOne({
            where: { departmentid: req.body.department_id.toString() }
        })
        // await detectNumeric(req.body.status);
        let status_department = req.body.status;
        if (status_department === 1) {
            status_value = true;
        } else if (status_department === 0) {
            status_value = false;
        }else{
          return res.status(400).send({ status: false, message: "Only 0 or 1 is allowed."});
        }
        let departmentupdate = await db.crbt_departments.update({ status: status_value }, {
            where: {
                departmentid: req.body.department_id.toString(),
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (departmentdata.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", departmentupdate });
        } else if (departmentdata.system_user_id === req.systemUser.system_user_id) {
            if (status_department === 0) {
                return res.status(200).send({ status: true, message: "Department deactivated successfully", departmentupdate });
            } else {
                return res.status(200).send({ status: true, message: "Department activated successfully", departmentupdate });
            }
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return res.status(500).send({ status: false, message: "Exception in Department deactivation" });
    }
  }


module.exports = {
    fetchDepartments,
    getDepartmentDataTable,
    createDepartment,
    editDepartment,
    deleteDepartment,
    getDepartmentList,
    getDepartment,
    getDepartmentfetch,
    departmentActDec
};