var db = require('../../models/index') 
const { Sequelize,Op, where } = require("sequelize");
var AWS = require('aws-sdk');
var env = require('../../../config/environment');
const logger = require('../../../utils/winston');
var jwt = require('jsonwebtoken');
const sharp = require('sharp');

var status = { 
    "success":{ status:true, message:"",  data:"", },
    "error":{ status:false, errorMessage:""  }  
  };
delete status['fc'];

let getthumbnail = async function (req,res,next) {  
    try {  
        const s3 = new AWS.S3({
            accessKeyId: env.s3.accessKeyId,
            secretAccessKey: env.s3.secretAccessKey
          })
           
            if (req.query.amenityid !== undefined ||  req.query.thumbnail_key !== undefined ) {
                let thumbnaildata = await db.crbm_aminities.findOne({
                    attributes: ["thumbnail_key"],
                    where: {aminity_id:req.query.amenityid.toString()},
                });  
            if(thumbnaildata!=null ){
                if(thumbnaildata.dataValues.thumbnail_key!="" && thumbnaildata.dataValues.thumbnail_key!=null ){
                    if(thumbnaildata.dataValues.thumbnail_key==req.query.thumbnail_key){
                        var params = { Bucket:env.s3.bucketname, Key:"Amenity_thumnails/"+thumbnaildata.dataValues.thumbnail_key};
                       console.log(params);
                        s3.headObject(params,async function (err, metadata) {  
                            console.log(err);
                            if (err == null) {  
                                s3.getObject(params, function(err, data) {
                                    console.log(data);
                                    res.writeHead(200, {'Content-Type': 'image/jpeg'});
                                    res.write(data.Body, 'binary');
                                    res.end(null, 'binary');
                                });
                            } else {  
                                defaultthumbnail(s3,res)
                            }
                        });
                    }else{
                        defaultthumbnail(s3,res)
                    } 
                
                }else{
                    defaultthumbnail(s3,res)
                }
            }else{
                defaultthumbnail(s3,res)
            }
        }else{
                defaultthumbnail(s3,res)
            }   
    } catch (error) {  
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Thumbnail Fetch.");        
    } 
}

let getRoomThumbnails = async function (req,res,next) {  
    try {  
        const s3 = new AWS.S3({
            accessKeyId: env.s3.accessKeyId,
            secretAccessKey: env.s3.secretAccessKey
          })
           
            if (req.query.amenityid !== undefined ||  req.query.thumbnail_key !== undefined ) {
                let thumbnaildata = await db.crbm_aminities.findOne({
                    attributes: ["thumbnail_key"],
                    where: {amenityid:req.query.amenityid.toString()},
                });  
            if(thumbnaildata!=null ){
                if(thumbnaildata.dataValues.thumbnail_key!="" && thumbnaildata.dataValues.thumbnail_key!=null ){
                    if(thumbnaildata.dataValues.thumbnail_key==req.query.thumbnail_key){
                        var params = { Bucket:env.s3.bucketname, Key:"Amenity_thumnails/"+thumbnaildata.dataValues.thumbnail_key};
                       console.log(params);
                        s3.headObject(params,async function (err, metadata) {  
                            console.log(err);
                            if (err == null) {  
                                s3.getObject(params, function(err, data) {
                                    console.log(data);
                                    res.writeHead(200, {'Content-Type': 'image/jpeg'});
                                    res.write(data.Body, 'binary');
                                    res.end(null, 'binary');
                                });
                            } else {  
                                defaultthumbnail(s3,res)
                            }
                        });
                    }else{
                        defaultthumbnail(s3,res)
                    } 
                
                }else{
                    defaultthumbnail(s3,res)
                }
            }else{
                defaultthumbnail(s3,res)
            }
        }else{
                defaultthumbnail(s3,res)
            }   
    } catch (error) {  
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Thumbnail Fetch.");        
    } 
}
function defaultthumbnail(s3,res){
    s3.getObject({ Bucket: env.s3.bucketname, Key: "default_thumbnail.png"}, function(err, data) {
        res.writeHead(200, {'Content-Type': 'image/jpeg'});
        res.write(data.Body, 'binary');
        res.end(null, 'binary'); 
    }); 
}

module.exports=
{ 
    getthumbnail,getRoomThumbnails
};  