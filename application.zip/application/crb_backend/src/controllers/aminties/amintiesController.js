const { Sequelize,Op, where } = require("sequelize");
var db = require('../../models/index') 
const logger = require('../../../utils/winston');
const fs = require('fs');
const app = require('express');
const multer = require('multer');
const path = require('path');
var { sequelize } = require('../../models/index')
var AWS = require('aws-sdk');
var env = require('../../../config/environment');

function detectNumeric(obj) {
  for (var index in obj) {
      if (!isNaN(obj[index])) {
          obj[index] = Number(obj[index]);
      } else if (typeof obj === "object") {
          detectNumeric(obj[index]);
      }
  }
}

var storage = multer.diskStorage({ 
  destination: function (req, file, cb) {
      cb(null, './uploads/Aminitiy_thumnails')
  },
  filename: function (req, file, cb) {
    const uniquePrefix = Date.now();
      req.Aminitiy_thumnails= req.systemUser.system_user_id+uniquePrefix+".jpg"; 
    cb(null, req.Aminitiy_thumnails);
  }
})
const maxSize = 1 * 1000 * 1000;
var upload = multer({ 
  storage: storage,
  limits: { fileSize: maxSize },
  fileFilter: function (req, file, cb){ 
      var filetypes = /jpeg|jpg|png/;
      var mimetype = filetypes.test(file.mimetype);  
      var extname = filetypes.test(path.extname(
                  file.originalname).toLowerCase());
      
      if (mimetype && extname) {
          return cb(null, true);
      } 
      cb("Error: File upload only supports the "
              + "following filetypes - " + filetypes);
    }  
}).single("thumbnail_key");

let uploadAminities = async function (req, res, next) {
  try {
    await fs.mkdir("./uploads/Aminitiy_thumnails",{ recursive: true },function(err) {
      if (err) {

      } else {

      }
    });
    return upload(req,res,function(err) { 
      if(err) { 
          res.send({status:false,errorMessage:err})
      }
      else { 
          next();
      }
  }) 
  } catch (error) {
    logger.createLog(__filename, error.message, req); 
    return logger.error(res, "Exception in inserting new Aminity");
  }
}

let profilepicupload = async function(key,uploadpath) {
  const s3 = new AWS.S3({
      accessKeyId: env.s3.accessKeyId,
      secretAccessKey: env.s3.secretAccessKey
    })
    console.log(key);
    console.log(uploadpath);
     const fileContent = fs.readFileSync(uploadpath)
     console.log(fileContent);
     const params = {
        Bucket:  env.s3.bucketname,
        Key: key,
        Body: fileContent
      }
      return new Promise((resolve, reject) => {
        s3.upload(params, (err, data) => {
            if (err) {
              reject(err)
            }
            resolve(params)
          })
    });
    
};

let createaminities = async function (req, res, next) {
  try {
    let uploadpath = "./uploads/Aminitiy_thumnails/" + req.Aminitiy_thumnails;
    let key = "Amenity_thumnails/" + req.Aminitiy_thumnails;
    profilepicupload(key, uploadpath)
      .then(async function (data) {
        fs.unlink(uploadpath, async (err) => {
          const aminityData = {    
            aminity_id: req.body.amenityid.toString(),
            amenityname: req.body.amenityname.trim(),
            thumbnail_key: req.Aminitiy_thumnails,
            created_by: req.systemUser.system_user_id,
            status: req.body.status
        };  
        const createdAmenity = await db.crbm_aminities.create(aminityData);
        if (createdAmenity) {
          const responseData = {
              amenityid: createdAmenity.aminity_id.toString(),
              amenityname: createdAmenity.amenityname,
              thumbnail_key: createdAmenity.thumbnail_key,
              created_by: createdAmenity.created_by,
              status: createdAmenity.status
          };
          return res.status(200).send({
              status: true,
              message: "Amenity created successfully",
              data: responseData
          });
      }else {
        return logger.error(res, "Error in creating Amenity");
    }
        });
      })
      .catch(function (error) {
        logger.createLog(__filename, error.message, req);
        console.error(error);
        return logger.error(res, "Exception in inserting new Aminity");
      });
  } catch (error) {
    logger.createLog(__filename, error.message, req);
    console.error(error);
    return logger.error(res, "Exception in inserting new Aminity");
  }
};


let updateaminities = async function (req, res, next) {
  try {
    let amenityData = await db.crbm_aminities.findOne({
      where: { aminity_id: req.body.amenityid.toString() }
    });
    let updateData = {
      amenityname: req.body.amenityname.trim(),
      updated_at: new Date(),
      updated_by: req.systemUser.system_user_id,
      status: req.body.status 
      // status: req.body.status === 'Active' 
    };
    if (req.Aminitiy_thumnails) {
      let uploadpath = "./uploads/Aminitiy_thumnails/" + req.Aminitiy_thumnails;
      let key = "Amenity_thumnails/" + req.Aminitiy_thumnails;
      await profilepicupload(key, uploadpath);
      updateData.thumbnail_key = req.Aminitiy_thumnails;

      fs.unlink(uploadpath, (err) => {
        if (err) {
          console.error(err);
        }
      });
    }

    if (amenityData.created_by !== req.systemUser.system_user_id) {
      return res.status(400).send({ status: false, message: "Permission Denied" });
    }

    const updatedAmenity = await db.crbm_aminities.update(updateData, {
      where: { aminity_id: req.body.amenityid.toString() },
      returning: true
    });

    if(updatedAmenity){

      let amenityData = await db.crbm_aminities.findOne({
        attributes: [
            ["aminity_id", "amenityid"], "amenityname", "thumbnail_key", "status", "created_by", "updated_by", "created_at","updated_at"
        ],
        where: {
            "aminity_id": req.body.amenityid.toString(),
            "created_by": req.systemUser.system_user_id
        }
    })      
      return res.status(200).send({
        status: true,
        message: "Amenity updated successfully",
        updateamenity: amenityData
      });
    }
  } catch (error) {
    logger.createLog(__filename, error.message, req);
    console.error(error);
    return logger.error(res, "Exception in Amenity Update");
  }
}



let deleteamenity = async function (req, res, next) {
  try {
      let deleteamenity = await db.crbm_aminities.findOne({
        attributes:['created_by'],
          where: { aminity_id: req.body.amenityid}
      })
      let Amenitydelete=  await db.crbm_aminities.update(
          {
              status:false
          },
          {
              where: {
                  aminity_id: req.body.amenityid,
                  created_by: req.systemUser.system_user_id,
              },
          }
      )
      if (deleteamenity.created_by !== req.systemUser.system_user_id) {
          return res.status(400).send({ status: false, message: "Perimission Denied"});
      } else if (deleteamenity.created_by === req.systemUser.system_user_id) {
          return res.status(200).send({ status: true, message: "Amenity deleted successfully" ,Amenitydelete});
      }
  } catch (error) {
      logger.createLog(__filename,error.message,req)
      return logger.error(res,"Exception in Amenity delete");
  }
};

let Amenitydeactivate = async function(req, res, next) {
  try {
      let amenitydataa = await db.crbm_aminities.findOne({
          where: { aminity_id: req.body.amenityid.toString() }
      })
      // await detectNumeric(req.body.status);
      let status_amenity = req.body.status;
      if (status_amenity === 1) {
          status_value = true;
      } else if (status_amenity === 0) {
          status_value = false;
      }else{
        return res.status(400).send({ status: false, message: "Only 0 or 1 is allowed."});
      }
      let amenityupdate = await db.crbm_aminities.update({ status: status_value }, {
          where: {
              aminity_id: req.body.amenityid.toString(),
              created_by: req.systemUser.system_user_id
          }
      });
      if (amenitydataa.created_by !== req.systemUser.system_user_id) {
          return res.status(400).send({ status: false, message: "Perimission Denied", amenityupdate });
      } else if (amenitydataa.created_by === req.systemUser.system_user_id) {
          if (status_amenity === 0) {
              return res.status(200).send({ status: true, message: "Amenity deactivated successfully", amenityupdate });
          } else {
              return res.status(200).send({ status: true, message: "Amenity activated successfully", amenityupdate });
          }
      }
  } catch (error) {
      logger.createLog(__filename, error.message, req);
      return res.status(500).send({ status: false, message: "Exception in Amenity deactivation" });
  }
}

let getamenitie = async function (req, res, next) {
  try {
      let whereCondition = {
          created_by: req.systemUser.system_user_id
      };
      if (req.query.amenityid && req.query.amenityid !== "") {
          whereCondition.aminity_id = req.query.amenityid;
      }
      if (req.query.amenityname && req.query.amenityname !== "") {
          whereCondition.amenityname = {
              [Op.iLike]: `%${req.query.amenityname}%`
          };
      }
      const data = await db.crbm_aminities.findAll({
          attributes: [['aminity_id','amenityid'], 'amenityname', 'thumbnail_key', 'status'],
          where: whereCondition,
          order: [['aminity_id', 'DESC']]
      });
      return logger.success(res, "Amenities retrieved successfully", data);
  } catch (error) {
      logger.createLog(__filename, error.message, req);
      return logger.error(res, "Exception in Amenities List");
  }
};

let getamenitiebyid = async function (req,res,next) {  
  try {
      let getamenity = await db.crbm_aminities.findOne({
          where: { aminity_id:req.query.amenityid}
      })
      let amenity = await db.crbm_aminities.findOne({
          attributes: [["aminity_id","amenityid"],"amenityname","thumbnail_key","status"],
          where: {
            aminity_id: req.query.amenityid,
            created_by:req.systemUser.system_user_id
        },   
      })
      if (getamenity.created_by !== req.systemUser.system_user_id) {
          return res.status(400).send({ status: false, message: "Perimission Denied" });
      } else if (getamenity.created_by === req.systemUser.system_user_id) {
          return res.status(200).send({ status: true, message: "Amenity Retrived Successfully", amenity });
      }
  } catch (error) {
      logger.createLog(__filename,error.message,req)
      return logger.error(res,"Exception in Amenity");
  }
}

let getAmenitiesDataTable = async function (req,res,next) {  
  try {
    console.log(req.query);
      var draw = req.query.draw;
      var start = req.query.start;
      var length = req.query.length;
      var order_data = req.query.order;
      console.log(order_data)
      let amenityTotal = await db.crbm_aminities.findOne({
          attributes: [[Sequelize.fn("count", sequelize.col(`amenityid`)), 'amenityCount'],
          ],where:{
              status:true
          }
      });
      if (typeof order_data == 'undefined') {
          var column_name = 'd.amenityid';
          var column_sort_order = 'desc';
      }
      else {
          var column_index = req.query.order[0]['column'];
          var column_name = req.query.columns[column_index]['data'];
          var column_sort_order = req.query.order[0]['dir'];
      }

      var search_value = req.query.search['value'];
      var search_query = '';
      var where_query = '';

      if(req.query.amenityid !=""){
        where_query=where_query+` and a.amenityid='${req.query.amenityid}'`
    }

      if(req.query.amenityname !=""){
          where_query=where_query+` and a.amenityname LIKE'${req.query.amenityname}'`
      }
      // if(req.query.amenitystatus !="") {
      //   where_query=where_query+` and a.amenitystatus LIKE'${req.query.amenitystatus}'`
      // }

      if (search_value != "") {
          search_value = search_value.toLowerCase();
          search_query = ` and  (a.amenityid::text = '${search_value}' OR LOWER(a.amenityname)::text LIKE '%${search_value}%' OR  a.status::text LIKE '%${search_value}%' )`;
      }
      console.log(where_query);
      const aminitysearchdata = await sequelize.query(`select COUNT(a.amenityid) AS Total from crbm_aminities a where status = 'true' ${where_query} ${search_query}`);
      let query = `select a.amenityid,a.amenityname,a.thumbnail_key,a.status from crbm_aminities a where status = 'true' ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
      const aminityData = await sequelize.query(query);
      let data = [];
      if (aminityData[0].length != 0) {
          for (i = 0; i < aminityData[0].length; i++) {
              data.push({
                  amenityid: aminityData[0][i].amenityid,
                  amenityname: aminityData[0][i].amenityname,
                  thumbnail: 'image part need to work',
                  status: aminityData[0][i].status,
                  action: `<div> 
                  <span class='a-edit' catid='${aminityData[0][i].amenityid}'><i class="bi bi-pencil-square"></i></span>
                  <span class='a-view' catid='${aminityData[0][i].amenityid}'><i class="bi bi-eye-fill"></i></span>
                  <span  class='a-delete' catid='${aminityData[0][i].amenityid}'><i class="bi bi-trash-fill"></i></span>
                  </div>`,
              });
          }
      }
      var output = {
          'draw': draw,
          'iTotalRecords':amenityTotal.dataValues.amenityCount,
          'iTotalDisplayRecords': aminitysearchdata[0][0].total,
          'aaData': data
      };
      return res.send(output);
  } catch (error) {
      logger.createLog(__filename, error.message, req)
      var output = {
          'draw': draw,
          'iTotalRecords': 0,
          'iTotalDisplayRecords': 0,
          'aaData': []
      };
      return res.send(output);
  }
}

let fetchAmenities = async function(req, res, next) {
  try {
      let amenitydata = await db.crbm_aminities.findAll({
          attributes: [
            "amenityid", "amenityname"
          ],
          order: [
              [db.crbm_aminities.rawAttributes.aminity_id, "DESC"]
          ],
          where: {
              status:true,
              created_by: req.systemUser.system_user_id,
          }
      });
      if (amenitydata.length === 0) {
          return res.status(400).send({ status: false, message: "Data not found", amenitydata });
      } else {
          return res.status(200).send({ status: true, message: "Amenities retrived successfully", amenitydata });
      }
  } catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in Amenity");
  }
};

module.exports = {
  fetchAmenities,
  createaminities,
  updateaminities,
  deleteamenity,
  getamenitie,
  getamenitiebyid,
  uploadAminities,
  getAmenitiesDataTable,
  Amenitydeactivate
}