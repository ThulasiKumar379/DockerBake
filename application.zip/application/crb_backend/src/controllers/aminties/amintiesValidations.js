var db = require('../../models/index');
const logger = require('../../../utils/winston');
var env = require('../../../config/environment');
const multer = require('multer');


function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

const createAminity = async function(req, res, next) {
    try {
        if (typeof req.body.amenityid == 'undefined') {
            return logger.error(res, "Amenity ID parameter is missing");
        }
        if (typeof req.body.amenityname == 'undefined') {
            return logger.error(res, "Amenity Name parameter is missing");
        }
        const amenityname = req.body.amenityname.trim();
        if (amenityname && amenityname.length > 255) {
            return res.status(400).send({ status: false, message: 'Amenity Name exceeds maximum length of 255 characters' });
        }
        if (req.body.amenityid == null) {
            return logger.error(res, "Amenity ID cannot be empty ");
        }
        if (req.body.amenityname == null) {
            return logger.error(res, "Amenity Name cannot be empty ");
        }
        if (/^\s*$/.test(req.body.amenityname)) {
            return logger.error(res, "Amenity Name cannot be empty");
        }
        if (typeof req.body.amenityname !== 'string' || !/^[a-zA-Z\s]+$/.test(req.body.amenityname)) {
            return logger.error(res, "Invalid data type for Amenity Name. Only characters are allowed.");
        }
        if(!req.Aminitiy_thumnails)
        {
            return logger.error(res,"Thumbnail should not be empty");
        }
        let createaminity = await db.crbm_aminities.findOne({
            attributes: ["amenityname"],
            where: { amenityname: req.body.amenityname }
        });
        if (createaminity != null) {
            if (createaminity.amenityname === req.body.amenityname) {
                return logger.error(res, "Amenity Name already exists");
            }
        }
        next();


    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Amenity creation");
    }
}

const deleteAminity = async function(req, res, next) {
    try {
        // await detectNumeric(req.body);
        if (req.body.amenityid == 'undefined') {
            return logger.error(res, "Amenity id parameter is missing.");
        }
        if (/^\s*$/.test(req.body.amenityid)) {
            return logger.error(res, "Amenity ID cannot be empty");
        } 
        // if (!Number.isInteger(req.body.amenityid)) {
        //     return logger.error(res,"Invalid format.");
        // }
        let deleteAmenity = await db.crbm_aminities.findOne({
            attributes: ["aminity_id", "status","created_by"],
            where: { aminity_id: req.body.amenityid, status:false, created_by: req.systemUser.system_user_id}
        })
        if (deleteAmenity) {
            return logger.error(res, "Amenity already inactive.");
        }
        let findAmenitys = await db.crbm_aminities.findOne({
            
            where: { aminity_id: req.body.amenityid },
        });
        if (!findAmenitys) {
            return logger.error(res, "Amenity id not found");
        }
        
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Amenity delete");
    }
};


let editAminity = async function(req, res, next) {
    try {
        detectNumeric(req.body);
        const amenityname = req.body.amenityname.trim();

        if (typeof req.body.amenityid === 'undefined' || typeof req.body.amenityname === 'undefined') {
            return logger.error(res, "Invalid or missing parameter in the request.");
        }
        
        // if (!req.Aminitiy_thumnails) {
        //     return logger.error(res, "Thumbnail should not be empty");
        // }
        
        if (req.body.amenityname === "" || req.body.amenityid === "") {
            return logger.error(res, "Amenity name should not be empty (or) Amenity ID should not be empty");
        }

        if (typeof req.body.amenityname !== 'string' || !/^[a-zA-Z\s]+$/.test(req.body.amenityname)) {
            return logger.error(res, "Invalid data type for Amenity Name. Only characters are allowed.");
        }
        let amenityedit = await db.crbm_aminities.findOne({
            attributes: ['aminity_id'],
            where: { aminity_id: req.body.amenityid.toString() },
        });
        
        if (!amenityedit) {
            return logger.error(res, "Amenity with the given amenity ID not found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in amenity update");
    }
};

let getamenityList = async function(req, res, next) {
    try {
        let amenitydata = await db.crbm_aminities.findAll({
            attributes: ["aminity_id", "amenityname", "thumbnail_key","created_at", "updated_at", "status"],
            order: [
                ['aminity_id', "ASC"]
            ],
            where: {
                created_by: req.systemUser.system_user_id
            }

        })
        if (amenitydata.length === 0) {
            return res.status(400).send({ status: false, message: "Amenities not available", amenitydata });
        } else {
            return res.status(200).send({ status: true, message: "Amenities retrived successfully", amenitydata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Amenity List");
    }
}



let getAminitybyid = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.query.amenityid=='undefined') {
            return logger.error(res,"Parameter Missing");
        }
        if (/^\s*$/.test(req.query.amenityid)) {
            return logger.error(res, "Amenity ID cannot be empty");
        } 
         
        let amenityget = await db.crbm_aminities.findOne({
            attributes: ['aminity_id'],
            where: { aminity_id: req.query.amenityid },
        });
        if (!amenityget) {
            return logger.error(res, "Amenity ID not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in retrieving Amenity.");
    }
};

 

const amenitydeactivate = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        console.log(req.body);

        if (typeof req.body.amenityid == 'undefined') {
            return logger.error(res, "Amenity ID parameter is missing");
        }
        if (req.body.amenityid === null) {
            return logger.error(res, "Amenity ID cannot be empty.");
        }
        if (/^\s*$/.test(req.body.amenityid)) {
            return logger.error(res, "Amenity ID cannot be empty");
        }
        // if (!Number.isInteger(req.body.amenityid)) {
        //     return logger.error(res, "Invalid Amenity ID");
        // }
        let amenityeditt = await db.crbm_aminities.findOne({
            attributes: ['aminity_id'],
            where: { aminity_id: req.body.amenityid.toString() },
        })
        if (!amenityeditt) {
            return logger.error(res, "Amenity ID Not Found.");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Amenity Deactive");
    }
}

module.exports = {
    createAminity,
    deleteAminity,
    editAminity,
    getAminitybyid,
    getamenityList, 
    amenitydeactivate
};