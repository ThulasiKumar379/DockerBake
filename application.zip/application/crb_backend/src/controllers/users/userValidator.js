var db = require('../../models/index')
const logger = require('../../../utils/winston')
const { validateParams, validateFields } = require('../../../middleware/validators')

function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

function ValidateEmail(mail) {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
        return (true)
    }
    return (false)
}
const createUser = async function(req, res, next) {
    try {
        // await detectNumeric(req.body);
        console.log(req.body);
        const { first_name, last_name, employee_code, email, mobile_number, designation_id, role_id, department_id, location_id, building_id } = req.body;
        const requiredParams = ['first_name', 'last_name', 'employee_code', 'email', 'mobile_number', 'designation_id', 'role_id', 'department_id', 'location_id', 'building_id'];

        const missingParams = validateParams(requiredParams, req.body);
        if (missingParams.length > 0) {
            const missingField = missingParams[0];
            return logger.error(res, `${missingField} parameter is missing`);
        }

        const missingField = validateFields(req.body, requiredParams);
        if (missingField) {
            return logger.error(res, `${missingField} cannot be empty`);
        }
        const userdataEmail = await db.crbt_users.findOne({
            attributes: ["email"],
            where: { email,system_user_id: req.systemUser.system_user_id }
        });
        const userdatanumber = await db.crbt_users.findOne({
            attributes: ["mobile_number"],
            where: { mobile_number: mobile_number, system_user_id: req.systemUser.system_user_id }
        });

        if (userdatanumber && userdatanumber.mobile_number === mobile_number) {
            return logger.error(res, "mobile number already exists");
        }
        if (userdataEmail && userdataEmail.email === email) {
            return logger.error(res, "Email already exists");
        }
        const userdataName = await db.crbt_users.findOne({
            attributes: ["first_name", "last_name"],
            where: { first_name, last_name }
        });
        if (userdataName && userdataName.first_name === first_name && userdataName.last_name === last_name) {
            return logger.error(res, "First name and Last name already exist");
        }
        const [findDesignation, findRole, findDepartment, findLocation, findBuilding] = await Promise.all([
            db.crbt_designations.findOne({ attributes: ["designationid"], where: { designation_id:designation_id } }),
            db.crbt_roles.findOne({ attributes: ["role_id"], where: { role_id:role_id } }),
            db.crbt_departments.findOne({ attributes: ["departmentid"], where: { department_id:department_id } }),
            db.crbt_locations.findOne({ attributes: ["locationid"], where: { location_id:location_id } }),
            db.crbt_buildings.findOne({ attributes: ["buildingid"], where: { building_id:building_id } })
        ]);
        if (!findDesignation) {
            return logger.error(res, "Designation id not found");
        }
        if (!findRole) {
            return logger.error(res, "Role id not found");
        }
        if (!findDepartment) {
            return logger.error(res, "Department id not found");
        }
        if (!findLocation) {
            return logger.error(res, "Location id not found");
        }
        if (!findBuilding) {
            return logger.error(res, "Building id not found");
        }
        next();
    } catch (error) {
        console.log('signup error', error);
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Signup validation");
    }
}

const userlogin = async function(req, res, next) {
    try {
        // detectNumeric(req.query);
        if (typeof req.query.email == 'undefined' || typeof req.query.password == 'undefined') {
            return logger.error(res, "email or password parameter is missing");
        }
        if (!req.query.email) {
            return logger.error(res, "email is cannot be empty.");
        }
        if (!req.query.password) {
            return logger.error(res, "password is cannot be empty.");
        }
        if (!ValidateEmail(req.query.email)) {
            return logger.error(res, "Invalid email");
        }
        if (/^\s*$/.test(req.query.email)) {
            return logger.error(res, "email cannot be empty");
        }
        if (/^\s*$/.test(req.query.password)) {
            return logger.error(res, "password cannot be empty");
        }
        next();
    } catch (error) {
        console.log('error', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in login");
    }
}

const userDeactive = async function(req, res, next) {
    try {
        console.log("res=======", req.body);
        await detectNumeric(req.body);
        console.log(req.body);

        if (typeof req.body.user_id == 'undefined') {
            return logger.error(res, "User id parameter is missing");
        }
        if (req.body.user_id === null) {
            return logger.error(res, "user_id cannot be empty.");
        }
        if (/^\s*$/.test(req.body.user_id)) {
            return logger.error(res, "User id cannot be empty");
        }
        if (!Number.isInteger(req.body.user_id)) {
            return logger.error(res, "Invalid user_id");
        }
        let buildingEdit = await db.crbt_users.findOne({
            attributes: ['user_id'],
            where: { user_id: req.body.user_id },
        })
        if (!buildingEdit) {
            return logger.error(res, "Users with the given user_id not found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in User Deactive");
    }
}

const getUser = async function(req, res, next) {
    try {
        console.log("res==============", req.query);
        await detectNumeric(req.body);
        console.log(req.body);
        if (typeof req.query.user_id == 'undefined') {
            return logger.error(res, "User id parameter is missing");
        }
        if (req.query.user_id == null) {
            return logger.error(res, "User id cannot be empty ");
        }
        if (isNaN(req.query.user_id)) {
            return logger.error(res, "Invalid data type for User id. Only number are allowed.");
        }
        if (/^\s*$/.test(req.query.user_id)) {
            return logger.error(res, "user id cannot be empty");
        }
        let userDataa = await db.crbt_users.findOne({
            attributes: ["user_id", "isactive"],
            where: { user_id: req.query.user_id, isactive: false }
        })
        if (userDataa) {
            return logger.error(res, "User is inactive");
        }
        let UserDataget = await db.crbt_users.findOne({
            attributes: ['user_id'],
            where: { user_id: req.query.user_id },
        });
        if (!UserDataget) {
            return logger.error(res, "User with the given user_id not found");
        }
        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in user get");
    }
}

let editUser = async function(req, res, next) {
    try {
        console.log("res====", req.body);
        // await detectNumeric(req.body);
        console.log(req.body);
        const { user_id, first_name, last_name, employee_code, email, mobile_number, designation_id, role_id, department_id, location_id, building_id } = req.body;
        const requiredParams = ['first_name', 'last_name', 'employee_code', 'email', 'mobile_number', 'designation_id', 'role_id', 'department_id', 'location_id', 'building_id'];
        for (const param of requiredParams) {
            if (typeof req.body[param] === 'undefined') {
                return logger.error(res, `${param} parameter is missing`);
            }
        }
        const emptyFields = [
            { field: 'user_id', message: 'User id cannot be empty' },
            { field: 'first_name', message: 'First name cannot be empty' },
            { field: 'last_name', message: 'Last name cannot be empty' },
            { field: 'employee_code', message: 'Employee code cannot be empty' },
            { field: 'email', message: 'Email cannot be empty' },
            { field: 'mobile_number', message: 'Mobile number cannot be empty' },
            { field: 'designation_id', message: 'Designation id' },
            { field: 'role_id', message: 'Role id' },
            { field: 'department_id', message: 'Department id' },
            { field: 'location_id', message: 'location id' },
            { field: 'building_id', message: 'building id' }
        ];

        for (const param of requiredParams) {
            if (typeof req.body[param] === 'undefined') {
                return logger.error(res, `${param} parameter is missing`);
            }
        }
        for (const field of emptyFields) {
            if (/^\s*$/.test(req.body[field.field])) {
                return logger.error(res, field.message);
            }
        }
        if (typeof req.body.user_id !== 'number') {
            return logger.error(res, 'Invalid User id');
        }
        if (typeof req.body.first_name !== 'string' || typeof req.body.last_name !== 'string') {
            return logger.error(res, 'Invalid Datatype please check');
        }
        if (req.body.last_name && typeof req.body.last_name !== 'string') {
            return logger.error(res, 'Invalid Datatype please check');
        }
        const fields = [
            { field: user_id, maxLength: 255, fieldName: 'User id' },
            { field: first_name, maxLength: 255, fieldName: 'first_name' },
            { field: last_name, maxLength: 255, fieldName: 'last_name' },
            { field: employee_code, maxLength: 255, fieldName: 'employee_code' },
        ];
        for (const { field, maxLength, fieldName }
            of fields) {
            if (field && field.length > maxLength) {
                return res.status(400).send({ status: false, message: `${fieldName} exceeds maximum length of ${maxLength} characters` });
            }
        }
        // let SubscriptionEdittt = await db.crbt_users.findOne({
        //     attributes: ['user_id', 'isactive'],
        //     where: { user_id: req.body.user_id, isactive: false },
        // });
        // if (SubscriptionEdittt) {
        //     return logger.error(res, 'User is inactive, cannot edit');
        // }
        let SubscriptionEdit = await db.crbt_users.findOne({
            attributes: ['user_id'],
            where: { user_id: req.body.user_id },
        });
        if (!SubscriptionEdit) {
            return logger.error(res, 'Users with the given user_id not found');
        }
        const [findDesignation, findRole, findDepartment, findLocation, findBuilding] = await Promise.all([
            db.crbt_designations.findOne({ attributes: ["designation_id"], where: { designation_id } }),
            db.crbt_roles.findOne({ attributes: ["role_id"], where: { role_id } }),
            db.crbt_departments.findOne({ attributes: ["department_id"], where: { department_id } }),
            db.crbt_locations.findOne({ attributes: ["location_id"], where: { location_id } }),
            db.crbt_buildings.findOne({ attributes: ["building_id"], where: { building_id } })
        ]);
        if (!findDesignation) {
            return logger.error(res, "Designation id not found");
        }
        if (!findRole) {
            return logger.error(res, "Role id not found");
        }
        if (!findDepartment) {
            return logger.error(res, "Department id not found");
        }
        if (!findLocation) {
            return logger.error(res, "Location id not found");
        }
        next();
    } catch (error) {
        console.log("error", error)
        logger.createLog(__filename, error.message, req);
        return logger.error(res, 'Exception in User update');
    }
}


module.exports = {
    createUser,
    userlogin,
    userDeactive,
    getUser,
    editUser
}