var env = require('../../../config/environment');
var sequelize = require('../../models/index')
var db = require('../../models/index')
var jwt = require('jsonwebtoken')
var bcrypt = require('bcrypt');
const logger = require('../../../utils/winston')
const emailer = require('../../../lib/email/mailer')
const emailTemplate = require('../../../views/approveEmail.hbs');
const { Sequelize, Op } = require("sequelize");
function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

function generateRandomPassword(length) {
    const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';


    const allChars = uppercaseChars + lowercaseChars;

    let password = '';

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * allChars.length);
        password += allChars.charAt(randomIndex);
    }

    return password;
}



let createUser = async function(req, res, next) {
    try {

        const password = generateRandomPassword(12);
        const checkPass = password;
        const hash = await bcrypt.hash(password, env.saltRounds);

        const [findDesignationuser, findroleuser, finddeptuser, findlocationuser, findbuildinguser] = await Promise.all([
            db.crbt_designations.findOne({
                attributes: ["designationid", "system_user_id"],
                where: { designation_id: req.body.designation_id }
            }),
            db.crbt_roles.findOne({
                attributes: ["role_id", "system_user_id"],
                where: { role_id: req.body.role_id }
            }),
            db.crbt_departments.findOne({
                attributes: ["departmentid", "system_user_id"],
                where: { department_id: req.body.department_id }
            }),
            db.crbt_locations.findOne({
                attributes: ["locationid", "system_user_id"],
                where: { location_id: req.body.location_id }
            }),
            db.crbt_buildings.findOne({
                attributes: ["buildingid", "system_user_id"],
                where: { building_id: req.body.building_id }
            })
        ]);

        if (
            findDesignationuser.system_user_id !== req.systemUser.system_user_id ||
            findroleuser.system_user_id !== req.systemUser.system_user_id ||
            finddeptuser.system_user_id !== req.systemUser.system_user_id ||
            findlocationuser.system_user_id !== req.systemUser.system_user_id ||
            findbuildinguser.system_user_id !== req.systemUser.system_user_id
        ) {
            return res.status(400).send({ status: false, message: "Permission Denied" });
        }

        const insertdata = {
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            designation_id: req.body.designation_id,
            role_id: req.body.role_id,
            department_id: req.body.department_id,
            employee_code: req.body.employee_code,
            location_id: req.body.location_id,
            building_id: req.body.building_id,
            mobile_number: req.body.mobile_number,
            isactive: true,
            system_user_id: req.systemUser.system_user_id,
            created_by: req.systemUser.system_user_id,
            password: hash,
            user_type: false,
            // ismanager: req.body.isManager
        }; 
        const createdUser = await db.crbt_users.create(insertdata);  
        if (createdUser) {
            const emailData = {
                subject: "CRB welcomes you - Signed up successfully!!!",
                name: createdUser.first_name + " " + createdUser.last_name,
                email: createdUser.email,
                password: checkPass,
            }
            // const emailBody = emailTemplate(emailData);
            emailer.sendEmail(
                // emailData, '../../../views/endUserEmail', { email: createdUser.email }
                {
                    subject: "CRB welcomes you - Signed up successfully!!!",
                    name: createdUser.first_name + " " + createdUser.last_name,
                    email: createdUser.email,
                    password: checkPass,
                },'views/endUserEmail',{ email: createdUser.email }
                );
            return res.status(200).send({ status: true, message: "Data inserted successfully in Created User", data: createdUser });
        } else {
            return logger.error(res, "Error in Created User");
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Create User API");
    }
}
 

let userDeactivate = async function(req, res, next) {
    try {
        let dataUser = await db.crbt_users.findOne({
            where: { user_id: req.body.user_id }
        })
        await detectNumeric(req.body.isactive);
        let status_user = req.body.isactive;
        if (status_user === 1) {
            isactive_value = true;
        } else if (status_user === 0) {
            isactive_value = false;
        }
        let updateBuilding = await db.crbt_users.update({ isactive: isactive_value }, {
            where: {
                // isactive: true,
                user_id: req.body.user_id,
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (dataUser.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", updateBuilding });
        } else if (dataUser.system_user_id === req.systemUser.system_user_id) {
            if (status_user === 0) {
                return res.status(200).send({ status: true, message: "User deactivated successfully", updateBuilding });
            } else {
                return res.status(200).send({ status: true, message: "User activated successfully", updateBuilding });
            }
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return res.status(500).send({ status: false, message: "Exception in user deactivation" });
    }
}
 
let userlogin = async function(req, res, next) {
    try {

        let userdata = await db.crbt_users.findOne({
            attributes: ["user_id", "system_user_id", "email", "isactive", "password"],
            where: { email: req.query.email },
        });
        console.log('userdatauserdata', userdata)
        if (userdata != null) {
            if (userdata.dataValues.isactive) {
                bcrypt.compare(req.query.password, userdata.dataValues.password).then(async function(match) {
                    if (match) {
                        return logger.success(res, " User loggedin", { token: jwt.sign({ userdata }, env.jwtkey.end_user_key, { expiresIn: env.expiresIn }),user_id:userdata.dataValues.user_id });
                    } else {
                        return res.json({ success: false, message: "authentication failed" });
                    }
                });
            } else {
                return logger.error(res, "User is inactive");
            }

        } else {
            return logger.error(res, "Email not exist in database");
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in user login");
    }
}

let editUser = async function(req, res, next) {
    try {
        const userId = req.body.user_id;
        const [findDesignationuser, findroleuser, finddeptuser, findlocationuser, findbuildinguser] = await Promise.all([
            db.crbt_designations.findOne({
                attributes: ["designationid", "system_user_id"],
                where: { designation_id: req.body.designation_id }
            }),
            db.crbt_roles.findOne({
                attributes: ["role_id", "system_user_id"],
                where: { role_id: req.body.role_id }
            }),
            db.crbt_departments.findOne({
                attributes: ["departmentid", "system_user_id"],
                where: { department_id: req.body.department_id }
            }),
            db.crbt_locations.findOne({
                attributes: ["locationid", "system_user_id"],
                where: { location_id: req.body.location_id }
            }),
            db.crbt_buildings.findOne({
                attributes: ["buildingid", "system_user_id"],
                where: { building_id: req.body.building_id }
            })
        ])
        if (
            findDesignationuser.system_user_id !== req.systemUser.system_user_id ||
            findroleuser.system_user_id !== req.systemUser.system_user_id ||
            finddeptuser.system_user_id !== req.systemUser.system_user_id ||
            findlocationuser.system_user_id !== req.systemUser.system_user_id ||
            findbuildinguser.system_user_id !== req.systemUser.system_user_id
        ) {
            return res.status(400).send({ status: false, message: "Permission Denied" });
        }
        if(req.body.isactive=="Active"){
            req.body.isactive=true;
        }
        else if(req.body.isactive=="Inactive"){
            req.body.isactive=false;
        }else{
            req.body.isactive=req.body.isactive
        }

        // const hashedPassword = await bcrypt.hash(req.body.password, env.saltRounds);
        const updatedData = {
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            designation_id: req.body.designation_id,
            role_id: req.body.role_id,
            department_id: req.body.department_id,
            employee_code: req.body.employee_code,
            location_id: req.body.location_id,
            building_id: req.body.building_id,
            mobile_number: req.body.mobile_number,
            isactive: req.body.isactive,
            system_user_id: req.systemUser.system_user_id,
            created_by: req.systemUser.system_user_id,
            // ismanager: req.body.isManager
        }
        if (req.body.newpassword && req.body.confirmpassword) {
            if (req.body.newpassword === req.body.confirmpassword) {
                const hashedPassword = await bcrypt.hash(req.body.confirmpassword, env.saltRounds);
                updatedData.password = hashedPassword;

            }

        }
        const updatedUser = await db.crbt_users.update(updatedData, {
            where: { user_id: userId, system_user_id: req.systemUser.system_user_id }
        })
        return res.status(200).send({ status: true, message: "User updated successfully", data: updatedUser });
    } catch (error) {
        console.log("Error", error)
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Edit User");
    }
}

let getUser = async function(req, res, next) {
    try {
        whereObj = req.query.user_id;
        let userDatafind = await db.crbt_users.findOne({
            where: { user_id: req.query.user_id }
        })
        let userData = await db.crbt_users.findOne({
            attributes: ["user_id", "first_name", "last_name", "email", "employee_code", "mobile_number", "isactive"],
            where: { user_id: req.query.user_id },
            include: [{
                model: db.crbt_designations,
                as: "crbt_designations",
                attributes: ['designation_id', 'designation_name'],
                required: true
            }, {
                model: db.crbt_roles,
                as: "crbt_roles",
                attributes: ['role_id', 'role_name'],
                required: true

            }, {
                model: db.crbt_departments,
                as: "crbt_departments",
                attributes: ['department_id', 'department_name'],
                required: true
            }, {
                model: db.crbt_locations,
                as: "crbt_locations",
                attributes: ['location_id', 'location_name'],
                required: true

            }, {
                model: db.crbt_buildings,
                as: "crbt_buildings",
                attributes: ['building_id', 'building_name'],
                required: true
            }]
        })
        if (userDatafind.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (userDatafind.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "User retrived successfully", userData });
        }
        // return logger.success(res, "User retrived successfully", userData);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in GetUser");
    }
}

let fetchUsers = async function(req, res, next) {
    try {
        let whereCondition={  system_user_id: req.systemUser.system_user_id  };
        if(req.query.roll_ids){
            whereCondition.role_id={[Op.in]: req.query.roll_ids}
        }
        if(req.query.location_ids){
            whereCondition.location_id={[Op.in]: req.query.location_ids}
        } 
        if(req.query.building_ids){
            whereCondition.building_id={[Op.in]: req.query.building_ids}
        } 
        if(req.query.designation_ids){
            whereCondition.designation_id={[Op.in]: req.query.designation_ids}
        } 
        if(req.query.department_ids){
            whereCondition.department_id={[Op.in]: req.query.department_ids}
        } 
        let settingData = await db.crbt_users.findAll({
            attributes: ["user_id", "first_name", "last_name", "email", "designation_id", "role_id", "department_id", "employee_code", "location_id", "mobile_number", "isactive", "building_id"],
            where: whereCondition,
            include: [{
                    model: db.crbt_designations,
                    as: 'crbt_designations',
                    attributes: ['designation_id', 'designation_name'],
                    required: false,
                },
                {
                    model: db.crbt_roles,
                    as: 'crbt_roles',
                    attributes: ['role_id', 'role_name'],
                    required: false,
                },
                {
                    model: db.crbt_departments,
                    as: 'crbt_departments',
                    attributes: ['department_id', 'department_name'],
                    required: false,
                },
                {
                    model: db.crbt_locations,
                    as: 'crbt_locations',
                    attributes: ['location_id', 'location_name'],

                },
                {
                    model: db.crbt_buildings,
                    as: 'crbt_buildings',
                    attributes: ['building_id', 'building_name'],

                },
            ],

        });
        return logger.success(res, "UserData retrieved successfully", settingData);
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in User List");
    }
};


let getUserData = async function(req, res, next) {
    // try {
        let settingData = await db.crbt_users.findAll({
            attributes: ["user_id", [Sequelize.literal("CONCAT(first_name,' ',last_name)"), 'full_name'],"employee_code" ],
            where: {
                system_user_id: req.systemUser.system_user_id,
                isactive:true, 
                [Op.or]: [
                    { first_name:{  [Op.iLike]: `%${req.query.term}%`}  },
                    {  last_name:{  [Op.iLike]: `%${req.query.term}%`}  },
                ],
            }  
        });
        return logger.success(res, "UserData retrieved successfully", settingData);
    // } catch (error) {
    //     logger.createLog(__filename, error.message, req);
    //     return logger.error(res, "Exception in User List");
    // }
};



module.exports = {
    createUser,
    userlogin,
    userDeactivate,
    editUser,
    getUser,
    fetchUsers,
    getUserData
}