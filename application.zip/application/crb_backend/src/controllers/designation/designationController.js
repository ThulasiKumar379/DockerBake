var db = require('../../models/index')
var logger = require('../../../utils/winston')
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");
var { sequelize } = require('../../models/index')

let createDesignation = async function(req, res, next) {
    try {
        let insertdata = {
            designationid: req.body.designation_id,
            system_user_id: req.systemUser.system_user_id,
            department_id: req.body.department_id,
            created_by: req.systemUser.system_user_id,
            updated_at: null,
            active: true
        }
        if (req.body.active) {
            insertdata.active = req.body.active
        }
        if (req.body.designation_name) {
            insertdata.designation_name = req.body.designation_name.trim()
        }
        await db.crbt_designations.create(insertdata).then(async function(users) {
            if (users) {
                console.log('data inserted')
            } else {
                return logger.error(res, "Error in Creating Designation");
            }
        });
        let designationData = await db.crbt_designations.findAll({
            attributes: [
                ["designationid", "designation_id"], "designation_name", "system_user_id", "created_by", "updated_by", "created_at", "updated_at", "active", "department_id"
            ],
            where: {
                "designation_name": req.body.designation_name.trim(),
                "system_user_id": req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_departments,
                as: "crbt_departments",
                attributes: ['department_name', ['departmentid', 'department_id']],
                required: false
            }]
        })
        return logger.success(res, "Designation Created Successfully", designationData);
    } catch (error) {
        console.log("error",error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Create Designation");
    }
} 

let updateDesignation = async function(req, res, next) {
    try {
        console.log("coming in controllers")
        console.log("bodyyy",req.body);
        let updatedesignation = await db.crbt_designations.findOne({
            where: { designationid: req.body.designation_id.toString() }
        });

        let designationupdate = await db.crbt_designations.update({
            designation_name: req.body.designation_name.trim(),
            active: req.body.active,
            department_id: req.body.department_id,
            system_user_id: req.systemUser.system_user_id,
            updated_at: Date.now(),
            updated_by: req.systemUser.system_user_id
        }, {
            where: {
                designationid: req.body.designation_id.toString(),
                system_user_id: req.systemUser.system_user_id
            },
        });

        if (updatedesignation.system_user_id !== req.systemUser.system_user_id) {
            return res.status(200).send({ status: false, message: "Permission Denied" });
        } else {
            return res.status(200).send({ status: true, message: "Designation Updated Successfully", designationupdate });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Designation Update");
    }
}


let getDesignations = async function(req, res, next) {
    try {
        let query2 = {}
        if (req.query.designation_name && req.query.designation_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(designation_name) like '${req.query.designation_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(designation_name) like '${req.query.designation_name.toLowerCase()}%'`
            }
        };
        if (req.query.department_name && req.query.department_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(department_name) like '${req.query.department_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(department_name) like '${(req.query.department_name.toLowerCase())}%'`
            }
        };
        if (req.query.designation_id) {
            query2 = ` and designationid = ${req.query.designation_id}`
        }
        if (req.query.department_ids) {
            query2 = ` and d.department_id in (${req.query.department_ids})`
        }
        if (Object.keys(query2).length === 0) {
            query2 = ''
        }

        
        const [results] = await sequelize.query(
            `SELECT
            d.designationid AS designation_id,
            d.designation_name,
            d.system_user_id,
            d.active,
            d.created_by,
            d.updated_by,
            d.created_at,
            d.updated_at,
            dept.department_id,
            dept.departmentid as udepartment_id,
            dept.department_name
        FROM
            crbt_designations AS d
        JOIN
            crbt_departments AS dept ON d.department_id = dept.department_id
        WHERE
            d.system_user_id = ${req.systemUser.system_user_id} ${query2}
        ORDER BY
            d.designationid DESC`
        );
        if (results.length == 0) {
            return logger.success(res, "No record found !!!")
        }
        return logger.success(res, "Designations retrived successfully", results)
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Designation List");
    }
}

let deleteDesignation = async function(req, res, next) {
    try {
        const deletedDesignation = await db.crbt_designations.update({
            active: false
        }, {
            where: {
                designationid: req.body.designation_id.toString(),
                system_user_id: req.systemUser.system_user_id
            },
        });
        return logger.success(res, "Designation Deleted");
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in delete designation");
    }
}
let getDesignationByID = async function(req, res, next) {
    try {
        let designationDataById = await db.crbt_designations.findAll({
            attributes: [
                ["designationid", "designation_id"], "designation_name", "system_user_id", "created_by", "updated_by", "created_at", "updated_at", "active", "department_id"
            ],
            where: {
                "designationid": req.query.designation_id,
                system_user_id: req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_departments,
                as: "crbt_departments",
                attributes: ['department_name', ['departmentid', 'department_id']],
                required: false
            }]
        })
        return logger.success(res, "Designations retrived successfully", designationDataById)
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in get Designation List");
    }
}
let viewDesignations = async function(req, res, next) {
    try {
        let viewdesignationData = await db.crbt_designations.findAll({
            attributes: [
                ["designationid", "designation_id"], "designation_name", "system_user_id", "created_by", "updated_by", "created_at", "updated_at", "active", "department_id"
            ],
            where: {
                system_user_id: req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_departments,
                as: "crbt_departments",
                attributes: ['department_name', ['departmentid', 'department_id']],
                required: false
            }]
        })
        return logger.success(res, "Designations retrived successfully", viewdesignationData)
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Designation View");
    }
}
let getDesignationsDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        console.log(order_data)
        let deg = await db.crbt_designations.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`designation_id`)), 'degCount'],
            ]
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.designation_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        var where_query = '';
        if (req.query.designation_id) {
            where_query = where_query + ` and d.designation_id=${req.query.designation_id}`
        }
        if (req.query.designation_name) {
            where_query = where_query + ` and d.designation_name=${req.query.designation_name}`
        }
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and system_user_id=${req.systemUser.system_user_id} and  (d.designation_id::text = '${search_value}' OR LOWER(d.designation_name)::text LIKE '%${search_value}%' OR  d.active::text LIKE '%${search_value}%' )`;
        }
        const degsearchdata = await sequelize.query(`select COUNT(d.designation_id) AS Total from crbt_designations d where active = 'true' ${where_query} ${search_query}`);
        let query = `select d.designation_id,d.designation_name,d.active,d.department_id from crbt_designations d where active = 'true' ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const degData = await sequelize.query(query);
        let data = [];
        if (degData[0].length != 0) {
            for (i = 0; i < degData[0].length; i++) {
                data.push({
                    designation_id: degData[0][i].designation_id,
                    designation_name: degData[0][i].designation_name,
                    active: degData[0][i].active,
                    action: `<div> 
                    <span class='a-edit' catid='${degData[0][i].designation_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${degData[0][i].designation_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${degData[0][i].designation_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': deg.dataValues.degCount,
            'iTotalDisplayRecords': degsearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}

let actionDesignation = async function(req, res, next) {
    try {
        let query = {
            updated_by: req.systemUser.system_user_id,
            updated_at: Date.now()
        }
        if (req.body.active) {
            query.active = req.body.active
        }
        if (req.body.active == 1 || req.body.active == true) {
            query.active = true
        }
        if (req.body.active == 0 || req.body.active == false) {
            query.active = false
        }

        let designationUpdate = await db.crbt_designations.update(
            query, {
                where: {
                    designationid: req.body.designation_id,
                    system_user_id: req.systemUser.system_user_id
                },
            }
        )
        let designationData = await db.crbt_designations.findAll({
            attributes: [
                ["designationid", "designation_id"], "active", "updated_by", "updated_at", "designation_name", "department_id"
            ],
            where: {
                "system_user_id": req.systemUser.system_user_id,
                "designationid": req.body.designation_id
            }
        })
        return logger.success(res, "Designation Action updated successfully", designationData);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update designation Action", error);
    }
}
let fetchDesignations = async function(req, res, next) {
    try {
        let whereCondition = {
            active: true,
            system_user_id: req.systemUser.system_user_id
        }
        if (req.query.department_id != undefined) {
            if (req.query.department_id != "") {
                whereCondition.department_id = {
                    [Op.in]: req.query.department_id.split(",")
                }
            }
        }
        let DesignationsData = await db.crbt_designations.findAll({
            attributes: [
               "designation_id", ["designationid", "udesignation_id"], "designation_name", "department_id"
            ],
            order: [
                [db.crbt_designations.rawAttributes.designationid, "ASC"]
            ],
            where: whereCondition
        }) 
        if (DesignationsData.length == 0) {
            return res.status(200).send({ status: false, message: "Data not found", DesignationsData });
        } else {
            return res.status(200).send({ status: true, message: "Designations Retrived Successfully", DesignationsData });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Designations");
    }
}
module.exports = {
    getDesignationsDataTable,
    createDesignation,
    updateDesignation,
    getDesignations,
    deleteDesignation,
    getDesignationByID,
    viewDesignations,
    actionDesignation,
    fetchDesignations
}