var db = require('../../models/index')
const logger = require('../../../utils/winston')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}
const createDesignation = async function(req, res, next) {
    try {
        detectNumeric(req.body);
        req.body.designation_id = req.body.designation_id;
        if (typeof req.body.designation_id == 'undefined') {
            return logger.error(res, "Designation ID  parameter is missing");
        }
        // if (!req.body.designation_id) {
        //     return res.status(400).send('Designation ID parameter is missing or empty');
        // }
        if (/^\s*$/.test(req.body.designation_id)) {
            return logger.error(res, "Designation ID cannot be empty");
        }
        if (typeof req.body.designation_name == 'undefined') {
            const errorMessage = 'Designation Name parameter is missing';
            console.error(errorMessage);
            return logger.error(res, errorMessage);
        }
        if (/^\s*$/.test(req.body.designation_name)) {
            return logger.error(res, "Designation Name cannot be empty");
        }
        if (typeof req.body.department_id == 'undefined') {
            return logger.error(res, 'Department ID parameter is missing');
        }
        if (/^\s*$/.test(req.body.department_id)) {
            return logger.error(res, "Department ID cannot be empty");
        }
        // if (typeof req.body.department_id === "string") {
        //     return logger.error(res, 'Department ID should be Number');
        // }
        if (typeof req.body.department_id !== "number") {
            return logger.error(res, 'Department ID should be Number');
        }
        if (typeof req.body.designation_name !== 'string') {
            return logger.error(res, 'Designation Name should be string');
        }
        // let designationidCheck = await db.crbt_designations.findOne({
        //     attributes: ["designationid"],
        //     where: { designationid: req.body.designation_id, system_user_id: req.systemUser.system_user_id }
        // });
        let designationidCheck;
            try {
                designationidCheck = await db.crbt_designations.findOne({
                attributes: ["designationid"],
                where: { designationid: req.body.designation_id, system_user_id: req.systemUser.system_user_id }
                });
            } catch (error) {
                console.error(error);
                // Handle the error appropriately
        }
       if (designationidCheck) {
            return logger.error(res, "Designation ID already exists");
        }
        let designationData = await db.crbt_designations.findOne({
            attributes: ["designation_id", "designation_name", "system_user_id"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                designation_name: req.body.designation_name.trim()
            }
        });
        let departData = await db.crbt_departments.findOne({
            attributes: ["department_id", "system_user_id", "status"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                department_id: req.body.department_id
            }
        });
        
        if (departData == null) {
            return logger.error(res, "Department ID does not exist");
        }
        
        if (departData.status === false) {
            return logger.error(res, "Department ID is inactive.");
        }
        
        next();
    } catch (error) {
        console.error(error);
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Designation Create validation");
    }
}
const updateDesignation = async function(req, res, next) {
    try {
        console.log("coming valid")
        // detectNumeric(req.body);
        req.body.designation_id = req.body.designation_id.toString()
        if (typeof req.body.designation_id == 'undefined') {
            return logger.error(res, 'Designation ID parameter is missing');
        }
        if (/^\s*$/.test(req.body.designation_id)) {
            return logger.error(res, "Designation ID cannot be empty");
        }
        let designationDataUpdate = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.body.designation_id.toString(),
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (req.body.department_id) {
            let departData = await db.crbt_departments.findOne({
                attributes: ["department_id", "system_user_id", "status"],
                where: {
                    system_user_id: req.systemUser.system_user_id,
                    departmentid: req.body.department_id.toString()
                }
            });
            if (departData != null) {
                if (departData.status == false) {
                    return logger.error(res, "Department ID is in Inactive active.");
                }
            }
        }
        // if (designationDataUpdate == null) {
        //     return logger.error(res, "Designation does not exist");
        // }
        console.log("valid complete");
        next();

    } catch (error) {
    console.error(error);
    logger.createLog(__filename, error.message, req);
    return logger.error(res, "Exception in update Designation validation", error);
}
}
const getDesignationByID = async function(req, res, next) {
    try {
        // detectNumeric(req.query);
        req.body.designation_id = req.body.designation_id.toString()
        if (typeof req.query.designation_id == 'undefined') {
            return logger.error(res, 'Designation ID parameter is missing');
        }
        if (/^\s*$/.test(req.query.designation_id)) {
            return logger.error(res, "Designation ID cannot be empty");
        }
        // if (typeof req.query.designation_id !== "number") {
        //     return logger.error(res, 'Invalid Designation ID ');
        // }
        let designationDataUpdate = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.query.designation_id
            }
        });
        let designationDataStatus = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.query.designation_id,
                active: false
            }
        });
        if (designationDataUpdate && (designationDataUpdate.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }
        next();
    } catch (error) {
        console.log('updateDesignation errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update Designation validation");
    }
}

const deleteDesignation = async function(req, res, next) {
    try {
        // detectNumeric(req.body);
        req.body.designation_id = req.body.designation_id.toString()
        if (typeof req.body.designation_id == 'undefined') {
            return logger.error(res, 'Designation ID parameter is missing');
        }
        if (/^\s*$/.test(req.body.designation_id)) {
            return logger.error(res, "Designation ID cannot be empty");
        }
        // if (typeof req.body.designation_id !== "number") {
        //     return logger.error(res, 'Invalid Designation ID ');
        // }
        let designationDataUpdate = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.body.designation_id
            }
        });
        let designationDataStatus = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.body.designation_id.toString(),
                active: false
            }
        });
        if (designationDataStatus) {
            return logger.error(res, "Designation ID is Inactive");
        }
        if (designationDataUpdate && (designationDataUpdate.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }
        next();
    } catch (error) {
        console.log('updateDesignation errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update Designation validation");
    }
}
const getDesignations = async function(req, res, next) {
    try {
        detectNumeric(req.query);
        if (typeof req.query.designation_id !== "number") {
            return logger.error(res, 'Invalid Designation ID ');
        }
        if (typeof req.body.designation_name !== 'string') {
            return logger.error(res, 'Designatiom Name should be string');
        }
        if (typeof req.body.department_name !== 'string') {
            return logger.error(res, 'Department Name should be string');
        }
        let designationDataUpdate = await db.crbt_designations.findOne({
            attributes: ["designation_id", "designation_name", "system_user_id"],
            where: {
                designation_id: req.query.designation_id
            }
        });
        let designationDataStatus = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.query.designation_id,
                active: false
            }
        });
        if (designationDataUpdate && (designationDataUpdate.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }
        next();
    } catch (error) {
        console.log('updateDesignation errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update Designation validation");
    }
}
const actionDesignation = async function(req, res, next) {
    try {
        // detectNumeric(req.body);
        let designation_id = req.body.designation_id;
        if (req.body.active == null) {
            return logger.error(res, 'Action is parameter is null');
        }
        if (typeof designation_id == 'undefined') {
            return logger.error(res, 'Designation ID parameter is missing');
        }
        if (/^\s*$/.test(designation_id)) {
            return logger.error(res, "Designation ID cannot be empty");
        }
        // if (typeof req.body.designation_id !== "number") {
        //     return logger.error(res, 'Invalid Designation ID ');
        // }
        let designationDataUpdate = await db.crbt_designations.findOne({
            attributes: ["designationid", "designation_name", "system_user_id"],
            where: {
                designationid: req.body.designation_id,
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (designationDataUpdate == null) {
            return logger.error(res, "Designation does not exists");
        }
        next();

    } catch (error) {
        console.log(console.error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update Designation action validation", error);
    }
}
module.exports = {
    createDesignation,
    updateDesignation,
    getDesignationByID,
    deleteDesignation,
    getDesignations,
    actionDesignation
}