var db = require('../../models/index')
const logger = require('../../../utils/winston')
var env = require('../../../config/environment');
const multer = require('multer');

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}

const createroomservice = async function(req, res, next) {
    try {
        if (typeof req.body.room_service_id == 'undefined') {
            return logger.error(res, "Room Service ID parameter is missing");
        }
        if (typeof req.body.room_service_name == 'undefined') {
            return logger.error(res, "Room Service Name parameter is missing");
        }
        if (typeof req.body.status == 'undefined') {
            return logger.error(res, "Status parameter is missing");
        }
        const room_service_name = req.body.room_service_name.trim();
        if (room_service_name && room_service_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Room Service Name exceeds maximum length of 255 characters' });
        }
        if (req.body.room_service_id == null) {
            return logger.error(res, "Room Service ID cannot be empty ");
        }
        if (req.body.room_service_name == null) {
            return logger.error(res, "Room Service Name cannot be empty ");
        }
        if (/^\s*$/.test(req.body.room_service_id)) {
            return logger.error(res, "Room Service ID cannot be empty");
        }
        if (/^\s*$/.test(req.body.room_service_name)) {
            return logger.error(res, "Room Service Name cannot be empty");
        }
        if (typeof req.body.room_service_name !== 'string' || !/^[a-zA-Z\s]+$/.test(req.body.room_service_name)) {
            return logger.error(res, "Invalid data type for Room Service Name. Only characters are allowed.");
        }
        if(!req.Room_service_icons)
        {
            return logger.error(res,"Icon should not be empty");
        }

        let serviceiddata = await db.crbm_roomservice.findOne({
            attributes: ["serviceid"],
            where: { serviceid: req.body.room_service_id }
        });

        if (serviceiddata != null) {
            if (serviceiddata.serviceid === req.body.room_service_id) {
                return logger.error(res, "Room Service ID already exists");
            }
        }
        let servicedata = await db.crbm_roomservice.findOne({
            attributes: ["room_service_name"],
            where: { room_service_name: req.body.room_service_name }
        });
        if (servicedata != null) {
            if (servicedata.room_service_name === req.body.room_service_name) {
                return logger.error(res, "Room Service Name already exists");
            }
        }
        next();


    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service creation");
    }
}
let editroomservice = async function(req, res, next) {
    try {

        if (typeof req.body.room_service_id === 'undefined' || typeof req.body.room_service_name === 'undefined') {
            return logger.error(res, "Invalid or missing parameter in the request.");
        }

        if (typeof req.body.room_service_id ==" " ||typeof req.body.room_service_id == null||typeof req.body.room_service_id == "undefined" ) {
            return logger.error(res, "Room Service ID cannot not be empty");
        }
         if (req.body.room_service_name == null) {
            return logger.error(res, "Room Service Name cannot be empty ");
        }

        if (!/^[a-zA-Z\s]+$/.test(req.body.room_service_name)) {
            return logger.error(res, "Room service name should contain only characters.");
        }
        const room_service_name = req.body.room_service_name.trim();
        if (room_service_name && room_service_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Room Service Name exceeds maximum length of 255 characters' });
        }
       
        let serviceedit = await db.crbm_roomservice.findOne({
            attributes: ['serviceid'],
            where: { serviceid: req.body.room_service_id.toString() },
        });
        if (!serviceedit) {
            return logger.error(res, "Room Service with the given Room Service ID not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Room Service update");
    }
}
const deleteroomservice = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        // if (typeof req.body.room_service_id == 'undefined') {
        //     return logger.error(res, "Room Service Name parameter is missing");
        // }
        if (/^\s*$/.test(req.body.room_service_id.toString())) {
            return logger.error(res, "Room Service ID cannot be empty");
        }
        if (req.body.room_service_id === null) {
            return logger.error(res, "Room Service ID parameter is missing.");
        }
        if (typeof req.body.room_service_id !== 'number') {
            return logger.error(res, "Invalid Room Service ID");
        }

        let servicedeletedata = await db.crbm_roomservice.findOne({
            attributes: ["serviceid", "status"],
            where: { serviceid: req.body.room_service_id.toString(), status: false, created_by: req.systemUser.system_user_id }
        });
        if (servicedeletedata) {
            return logger.error(res, "Room Service is already inactive");
        }
        let deleteservice = await db.crbm_roomservice.findOne({
            attributes: ['serviceid'],
            where: { serviceid: req.body.room_service_id.toString() },
        });
        if (!deleteservice) {
            return logger.error(res, "Room Service with the given Room Service ID not found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service delete");
    }
}
const getroomservice = async function(req, res, next) {
    try {
        detectNumeric(req.query.id);
        if (typeof req.query.room_service_id == 'undefined') {
            return logger.error(res, "Room Service ID parameter is missing");
        }
        if (/^\s*$/.test(req.query.room_service_id)) {
            return logger.error(res, "Room Service ID cannot be empty");
        }
        if (req.query.room_service_id == null) {
            return logger.error(res, "Room Service ID cannot be empty ");
        }
        if (isNaN(req.query.room_service_id)) {
            return logger.error(res, "Invalid data type for Room Service ID. Only number are allowed.");
        }
        let servicedata = await db.crbm_roomservice.findOne({
            attributes: ["serviceid"],
            where: { serviceid: req.query.room_service_id, created_by: req.systemUser.system_user_id }
        })
        if (!servicedata) {
            return logger.error(res, "Room Service Not Found.");
        }
        let serviceedit = await db.crbm_roomservice.findOne({
            attributes: ['serviceid'],
            where: { serviceid: req.query.room_service_id },
        });
        console.log(serviceedit);
        if (!serviceedit) {
            return logger.error(res, "Room Service with the given Room Service ID or Name not found");
        }
        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service get");
    }
}

const getroomservicefetch = async function(req, res, next) {
    try {
        await detectNumeric(req.query);

        if (req.query.room_service_id && typeof req.query.room_service_id !== 'number') {
            return logger.error(res, "Invalid Room Service ID");
        }
        if (req.query.room_service_name && typeof req.query.room_service_name !== 'string') {
            return logger.error(res, "Invalid Room Service Name");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service Fetching");
    }
}

const serviceicon = async function(req, res, next) {
    try {
        await detectNumeric(req.query);
        console.log(req.query);
        if (req.query.room_service_id && typeof req.query.room_service_id !== 'number') {
            return logger.error(res, "Invalid Room Service ID");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service");
    }
};

const servicedeactivate = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        console.log(req.body);

        if (typeof req.body.room_service_id == 'undefined') {
            return logger.error(res, "Room Service ID parameter is missing");
        }
        if (req.body.room_service_id === null) {
            return logger.error(res, "Room Service ID cannot be empty.");
        }
        if (/^\s*$/.test(req.body.room_service_id)) {
            return logger.error(res, "Room Service ID cannot be empty");
        }
        if (!Number.isInteger(req.body.room_service_id)) {
            return logger.error(res, "Invalid Room Service ID");
        }
        let Serviceeditt = await db.crbm_roomservice.findOne({
            attributes: ['serviceid'],
            where: { serviceid: req.body.room_service_id.toString() },
        })
        if (!Serviceeditt) {
            return logger.error(res, "Room Service ID Not Found.");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service Deactive");
    }
}

module.exports = {
    createroomservice,
    editroomservice,
    deleteroomservice,
    getroomservice,
    getroomservicefetch,
    serviceicon,
    servicedeactivate
}