const { Sequelize,Op, where } = require("sequelize");
var db = require('../../models/index') 
const logger = require('../../../utils/winston');
const fs = require('fs');
const app = require('express');
const multer = require('multer');
const path = require('path');
var { sequelize } = require('../../models/index');
var AWS = require('aws-sdk');
var env = require('../../../config/environment');

function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

var storage = multer.diskStorage({ 
    destination: function (req, file, cb) {
        cb(null, './uploads/Room_service_icons')
    },
    filename: function (req, file, cb) {
      const uniquePrefix = Date.now();
        req.Room_service_icons= req.systemUser.system_user_id+uniquePrefix+".jpg"; 
      cb(null, req.Room_service_icons);
    }
  })
  const maxSize = 1 * 1000 * 1000;
  var upload = multer({ 
    storage: storage,
    limits: { fileSize: maxSize },
    fileFilter: function (req, file, cb){ 
        var filetypes = /jpeg|jpg|png/;
        var mimetype = filetypes.test(file.mimetype);  
        var extname = filetypes.test(path.extname(
                    file.originalname).toLowerCase());
        
        if (mimetype && extname) {
            return cb(null, true);
        } 
        cb("Error: File upload only supports the "
                + "following filetypes - " + filetypes);
      }  
  }).single("service_icon");
  
  let uploadicon = async function (req, res, next) {
    try {
       fs.mkdir("./uploads/Room_service_icons/",{ recursive: true },function(err) {
        if (err) {
           
        } else {
            
        }
      });
      return upload(req,res,function(err) { 
        if(err) { 
            res.send({status:false,errorMessage:err})
        }
        else { 
            next();
        }
    }) 
    } catch (error) {
      logger.createLog(__filename, error.message, req); 
      return logger.error(res, "Exception in Inserting New Room Service");
    }
  }
  
  let iconupload = async function(key,uploadpath) {
    const s3 = new AWS.S3({
        accessKeyId: env.s3.accessKeyId,
        secretAccessKey: env.s3.secretAccessKey
      })
      console.log(key);
      console.log(uploadpath);
       const fileContent = fs.readFileSync(uploadpath);
       console.log("data",fileContent);
       const params = {
          Bucket:  env.s3.bucketname,
          Key: key,
          Body: fileContent
        }
        return new Promise((resolve, reject) => {
          s3.upload(params, (err, data) => {
              if (err) {
                reject(err)
              }
              resolve(params)
            })
      });
      
  };
  
let createroomservice = async function (req, res, next) {
    try {
      const uploadpath = "./uploads/Room_service_icons/" + req.Room_service_icons;
      const key = "service_icons/" + req.Room_service_icons;
  
      const uploadedData = await iconupload(key, uploadpath);
  
      fs.unlink(uploadpath, async (err) => {
        if (err) {
          console.error("Error deleting temporary file:", err);
        }
  
        const roomServiceData = {
          serviceid: req.body.room_service_id,
          room_service_name: req.body.room_service_name.trim(),
          service_icon: req.Room_service_icons,
          status: req.body.status,
          created_by: req.systemUser.system_user_id,
          created_at: Date.now(),
        };
  
        const createdRoomService = await db.crbm_roomservice.create(roomServiceData);
  
        if (createdRoomService) {
          const responseData = {
            room_service_id: createdRoomService.serviceid,
            room_service_name: createdRoomService.room_service_name,
            service_icon: createdRoomService.service_icon,
            status: createdRoomService.status,
            created_by: createdRoomService.created_by,
            created_at: createdRoomService.created_at,
          };
  
          return res.status(200).send({
            status: true,
            message: "Room Service Created Successfully",
            data: responseData,
          });
        } else {
          return logger.error(res, "Error in creating new Room Service");
        }
      });
    } catch (error) {
      logger.createLog(__filename, error.message, req);
      console.error(error);
      return logger.error(res, "Exception in inserting new Room Service");
    }
  };
  
  let editroomservice = async function (req, res, next) {
    try {
        if(req.body.status=='Active'){
            req.body.status=true;
           }
           if(req.body.status=='Inactive'){
            req.body.status=false;
           }
      let servicedata = await db.crbm_roomservice.findOne({
        where: { serviceid: req.body.room_service_id }
      });
  
      let updateData = {
        room_service_name: req.body.room_service_name.trim(),
        updated_at: Date.now(),
        updated_by: req.systemUser.system_user_id,
        status: req.body.status
      };
  
      if (req.Room_service_icons) {
        let uploadpath = "./uploads/Room_service_icons/" + req.Room_service_icons;
        let key = "service_icons/" + req.Room_service_icons;
  
        await iconupload(key, uploadpath);  
        updateData.service_icon = req.Room_service_icons; 
        fs.unlink(uploadpath, (err) => {
          if (err) {
            console.error(err);
          }
        });
      }
  
      if (servicedata.created_by !== req.systemUser.system_user_id) {
        return res.status(400).send({ status: false, message: "Permission Denied" });
      }
  
      let updatedService = await db.crbm_roomservice.update(updateData, {
        where: { serviceid: req.body.room_service_id.toString() },
        returning: true
      });

      if(updatedService){

        let Servicedata = await db.crbm_roomservice.findOne({
          attributes: [
              ["serviceid", "room_service_id"], "room_service_name", "service_icon", "status", "created_by", "updated_by", "created_at","updated_at"
          ],
          where: {
              "serviceid": req.body.room_service_id.toString(),
              "created_by": req.systemUser.system_user_id
          }
      })
  
      return res.status(200).send({
        status: true,
        message: "Service updated successfully",
        updateservice: Servicedata
      });
    }} 
    catch (error) {
      logger.createLog(__filename, error.message, req);
      console.error(error);
      return logger.error(res, "Exception in Service Update");
    }
}
  

let deleteroomservice = async function(req, res, next) {
    try {
        let servicedeletedata = await db.crbm_roomservice.findOne({
            where: { serviceid: req.body.room_service_id.toString() }

        })
        const deleted = await db.crbm_roomservice.update({
            status: false

        }, {
            where: {
              serviceid: req.body.room_service_id.toString(),
                created_by: req.systemUser.system_user_id
            },
        })
        if (servicedeletedata.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", deleted });
        } else if (servicedeletedata.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Room Service deleted successfully", deleted });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service delete");
    }

}
let getroomservicelist = async function(req, res, next) {
    try {
        let service = await db.crbm_roomservice.findAll({
            attributes: [["serviceid","room_service_id"], "room_service_name","service_icon", "created_at", "updated_at", "status"],
            order: [
                ['serviceid', "DESC"]
            ],
            where: {
                created_by: req.systemUser.system_user_id
            }

        })
        if (service.length === 0) {
            return res.status(400).send({ status: false, message: "Room Service not available", service });
        } else {
            return res.status(200).send({ status: true, message: "Room Service retrived successfully", service });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service List");
    }
}

let getroomservicefetch = async function(req, res, next) {
    try {
        let query2 = {}
        if (req.query.room_service_name && req.query.room_service_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(room_service_name) like '${req.query.room_service_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(room_service_name) like '${req.query.room_service_name.toLowerCase()}%'`
            }
        };
        if (req.query.room_service_name && req.query.room_service_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(room_service_name) like '${req.query.room_service_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(room_service_name) like '${(req.query.room_service_name.toLowerCase())}%'`
            }
        };
        if (req.query.room_service_id) {
            query2 = ` and serviceid = ${req.query.room_service_id}`
        }
        if (Object.keys(query2).length === 0) {
            query2 = ''
        }
        const [results] = await sequelize.query(
            `SELECT serviceid AS room_service_id, room_service_name,service_icon,created_at,updated_at,status
             FROM crbm_roomservice             
             where created_by=${req.systemUser.system_user_id} ${query2} ORDER BY serviceid DESC`
        );
        if (results.length === 0) {
            return logger.success(res, "Room Service Data Not Found")
        } else {
            return logger.success(res, "Room Service Retrived Successfully", results)
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Room Service List");
    }
}

let getroomservice = async function(req, res, next) {
    try {
        let getroomservicedata = await db.crbm_roomservice.findOne({
            where: { serviceid: req.query.room_service_id.toString() }
        })
        let servicesdata = await db.crbm_roomservice.findOne({
            attributes: [["serviceid","room_service_id"], "room_service_name","service_icon","status","created_at","updated_at"],
            order: [
                [db.crbm_roomservice.rawAttributes.serviceid, "DESC"]
            ],
            where: {
                serviceid: req.query.room_service_id.toString(),
                created_by: req.systemUser.system_user_id
            }
        })
        if (getroomservicedata.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", servicesdata });
        } else if (getroomservicedata.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Room Service retrived successfully", servicesdata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Get Room Service");
    }
}

let fetchroomservice = async function(req, res, next) {
    try {
        
        let servicesdata = await db.crbm_roomservice.findAll({
            attributes: ["serviceid", "room_service_name"],
            order: [
                ['serviceid', "DESC"]
            ],
            where: {
                created_by: req.systemUser.system_user_id
            }
        })
        if (servicesdata.length !=0 ) {
            return res.status(200).send({ status: false, message: "Room Service retrived successfully", servicesdata });
        } else {
            return res.status(400).send({ status: true, message: "Data not found", servicesdata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Room Service");
    }
}

  let Roomservicedeactivate = async function(req, res, next) {
    try {
        let servicedataa = await db.crbm_roomservice.findOne({
            where: { serviceid: req.body.room_service_id.toString() }
        })
        // await detectNumeric(req.body.status);
        let status_service = req.body.status;
        if (status_service === 1) {
            status_value = true;
        } else if (status_service === 0) {
            status_value = false;
        }else{
          return res.status(400).send({ status: false, message: "Only 0 or 1 is allowed."});
        }
        let serviceupdate = await db.crbm_roomservice.update({ status: status_value }, {
            where: {
              serviceid: req.body.room_service_id.toString(),
                created_by: req.systemUser.system_user_id
            }
        });
        if (servicedataa.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", serviceupdate });
        } else if (servicedataa.created_by === req.systemUser.system_user_id) {
            if (status_service === 0) {
                return res.status(200).send({ status: true, message: "Room Service deactivated successfully", serviceupdate });
            } else {
                return res.status(200).send({ status: true, message: "Room Service activated successfully", serviceupdate });
            }
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return res.status(500).send({ status: false, message: "Exception in Room Service deactivation" });
    }
  }


module.exports = {
    fetchroomservice,
    uploadicon,
    createroomservice,
    editroomservice,
    deleteroomservice,
    getroomservicelist,
    getroomservice,
    getroomservicefetch,
    Roomservicedeactivate
};