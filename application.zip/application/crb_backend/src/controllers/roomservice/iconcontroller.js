var db = require('../../models/index') 
var AWS = require('aws-sdk');
var env = require('../../../config/environment');
const logger = require('../../../utils/winston');
var jwt = require('jsonwebtoken');
const sharp = require('sharp');

var status = { 
    "success":{ status:true, message:"",  data:"", },
    "error":{ status:false, errorMessage:""  }  
  };
delete status['fc'];

let geticon = async function (req,res,next) {  
    try {  
        const s3 = new AWS.S3({
            accessKeyId: env.s3.accessKeyId,
            secretAccessKey: env.s3.secretAccessKey
          })
           
            if (req.query.room_service_id !== undefined || req.query.service_icon !== undefined ) {
                let icondata = await db.crbm_roomservice.findOne({
                    attributes: ["service_icon"],
                    where: {serviceid:req.query.room_service_id.toString()},
                });  
            if(icondata!=null ){
                if(icondata.dataValues.service_icon!="" && icondata.dataValues.service_icon!=null ){
                    if(icondata.dataValues.service_icon==req.query.service_icon){
                        var params = { Bucket:env.s3.bucketname, Key:"service_icons/"+icondata.dataValues.service_icon};
                       console.log(params);
                        s3.headObject(params,async function (err, metadata) {  
                            console.log(err);
                            if (err == null) {  
                                s3.getObject(params, function(err, data) {
                                    console.log(data);
                                    res.writeHead(200, {'Content-Type': 'image/jpeg'});
                                    res.write(data.Body, 'binary');
                                    res.end(null, 'binary');
                                });
                            } else {  
                                defaulticon(s3,res)
                            }
                        });
                    }else{
                        defaulticon(s3,res)
                    } 
                
                }else{
                    defaulticon(s3,res)
                }
            }else{
                defaulticon(s3,res)
            }
        }else{
                defaulticon(s3,res)
            }   
    } catch (error) {  
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Get Icon");        
    } 
}
function defaulticon(s3,res){
    s3.getObject({ Bucket: env.s3.bucketname, Key: "default_service_icon.png"}, function(err, data) {
        res.writeHead(200, {'Content-Type': 'image/jpeg'});
        res.write(data.Body, 'binary');
        res.end(null, 'binary'); 
    }); 
}

module.exports=
{ 
    geticon
};  