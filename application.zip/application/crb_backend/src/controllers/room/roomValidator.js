var db = require('../../models/index');
var logger = require('../../../utils/winston');
const { Sequelize,Op, where } = require("sequelize");

function detectNumeric(obj) {
  for (var index in obj) {
      if (!isNaN(obj[index])) {
          obj[index] = Number(obj[index]);
      } else if (typeof obj === "object") {
          detectNumeric(obj[index]);
      }
  }
}



const createRoomValidator = async function(req, res, next) {
  try {
      await detectNumeric(req.body.capacity)
          // console.log(req.body.capacity)
      const capacity_data = parseInt(req.body.capacity)

      const requiredFields = [
          'room_id',
          'room_name',
          'status',
          'capacity',
          'location_id',
          'building_id',
          'floor_id'
      ];
      const missingFields = requiredFields.filter(field => typeof req.body[field] === 'undefined');

      if (missingFields.length > 0) {
          return logger.error(res, `${missingFields.join(' / ')} parameter(s) is missing`);
      }
      if (!Number.isInteger(capacity_data)) {
          return logger.error(res, "Invalid capacity");
      }
      const users = [
          { key: "building_id", value: req.body.building_id },
          { key: "location_id", value: req.body.location_id },
          { key: "floor_id", value: req.body.floor_id },
          // { key: "capacity", value: req.body.capacity },
      ];
      for (const user of users) {
          if (!Number.isInteger(user.value)) {
              return logger.error(res, `${user.key} should be an integer`);
          }
      }
      req.body.room_id = req.body.room_id.toString();
      const buildingExists = await db.crbt_buildings.findOne({
          where: { building_id: req.body.building_id.toString() }
      });
      if (!buildingExists) {
          return logger.error(res, 'building id does not exist ');
      }
      const locationExists = await db.crbt_locations.findOne({
          where: { location_id: req.body.location_id.toString() }
      });
      if (!locationExists) {
          return logger.error(res, 'location id does not exist ');
      }
      const floorExists = await db.crbt_floors.findOne({
          where: { floor_id: req.body.floor_id.toString() }
      });
      if (!floorExists) {
          return logger.error(res, 'floor id does not exist ');
      }

      if (typeof req.body.room_name == 'undefined') {
          return logger.error(res, "Invalid Parameters room name ");
      }
      if (typeof req.body.room_amenities == 'undefined') {
          return logger.error(res, "Invalid Parameters room amenities ");
      }

      const room_name = req.body.room_name;
      if (room_name && room_name.length > 255) {
          return res.status(400).send({ status: false, message: 'room name exceeds maximum length of 255 characters' });
      }
      if (!req.body.room_name || !req.body.floor_id || !req.body.capacity || !req.body.room_amenities || !req.body.status || !req.body.location_id) {
          return logger.error(res, "Data should not be empty");
      }

      if (req.body.room_name == ' ' || req.body.room_name == null || req.body.room_name == " ") {
          return logger.error(res, "room name cannot be empty ");
      }
      const room_amenities = req.body.room_amenities;
      if (!Array.isArray(room_amenities) && req.body.room_amenities.length == 0) {
          return logger.error(res, "Room amenities array cannot be empty");
      }
      if (/^\s*$/.test(req.body.room_name)) {
          return logger.error(res, "room name cannot be empty");
      }
      let userdataEmail = await db.crbt_rooms.findOne({
          attributes: ["room_name"],
          where: { room_name: req.body.room_name, system_user_id: req.systemUser.system_user_id }
      });
      if (userdataEmail) {
          return logger.error(res, "room name already exists");
      }
      next();
  } catch (error) {
      logger.createLog(__filename, error.message, req);
      return res.status(500).send({ status: false, message: 'Exception in createRoomValidator' });

  }

};

const deleteRoomValidator = async function(req, res, next) {
  try {
    req.body.room_id = req.body.room_id.toString();
      if (typeof req.body.room_id === 'undefined') {
          return logger.error(res,"room id parameter is missing.");
      }
      if (req.body.room_id === null) {
        return logger.error(res, "room id parameter is missing.");
    }
    // if (typeof req.body.room_id !== 'string') {
    //   return res.status(400).send({ status: false, message: "Invalid room_id. Please provide a string." });
    // }
      if (req.body.room_id == "") {
          return logger.error(res, 'room id cannot be empty.');
      }
      // if (!Number.isInteger(req.body.room_id)) {
      //     return logger.error(res, "Invalid room id. It should be an integer.");
      // }
      let roomDelete = await db.crbt_rooms.findOne({
        attributes: ['room_id'],
        where: { roomid: req.body.room_id },
    });
    if (!roomDelete) {
        return logger.error(res, "room with the given room id room name not found");
    }
      let roomData = await db.crbt_rooms.findOne({
        attributes: ["room_id", "status"],
         where: { roomid: req.body.room_id, status: false, system_user_id: req.systemUser.system_user_id }
    });
      if (roomData) {
        return logger.error(res, "room is already inactive");
      }
      next();
  } 
  catch (error) {
      logger.createLog(__filename, error.message, req);
      return logger.error(res, "Exception in room delete");
  }
}

const viewRoomValidator = async function (req, res, next) {
  try {
    
    if (req.body.room_id == ' ' || req.body.room_id == null || req.body.room_id == " ") {
      return logger.error(res, "room id cannot be empty ");
    }
    if (typeof req.body.room_id !== 'number') {
      return logger.error(res, "Invalid data type for room_id. Only number are allowed.");
    }
    let roomData = await db.crbt_rooms.findOne({
      attributes: ["room_id"],
      where: {room_id: req.body.room_id }
    });
    if (!roomData) {
      return logger.error(res, "room with the given room id not found");
    }
      next(); 
  } 
  catch (error) {
  logger.createLog(__filename, error.message, req)
  return logger.error(res, "Exception in room get");}
}
    
function removeDuplicates(room_amenities) {
  return room_amenities.filter((item, index) => room_amenities.indexOf(item) === index);
}  


let updateRoomValidator = async function(req, res, next) {
  try {
    await detectNumeric(req.body.capacity)
    // console.log(req.body.capacity)
    const capacity_data = parseInt(req.body.capacity)   
      const requiredFields = [
        'room_name','room_id','status','capacity', 
        'location_id','building_id','floor_id'];
      const missingFields = requiredFields.filter(field => typeof req.body[field] === 'undefined');
      if (missingFields.length > 0) {
          return logger.error(res, `${missingFields.join(' / ')} parameter(s) is missing`);
      }
      if (!Number.isInteger(capacity_data)) {
        return logger.error(res, "Invalid capacity");
    } 
      const users = [
          { key: "building_id", value: parseInt(req.body.building_id) },
          { key: "location_id", value: parseInt(req.body.location_id)  },
          { key: "floor_id", value: parseInt(req.body.floor_id)  },
          // { key: "room_id", value: req.body.room_id }
      ];
      for (const user of users) {
          if (!Number.isInteger(user.value)) {
              return logger.error(res, `${user.key} should be an integer`);
          }
      }
      req.body.room_id = req.body.room_id.toString();
      const buildingExists = await db.crbt_buildings.findOne({
          where: { building_id: req.body.building_id }
      });
      if (!buildingExists) {
          return logger.error(res, 'building id does not exist');
      }
      const locationExists = await db.crbt_locations.findOne({
          where: { location_id: req.body.location_id}
      });
      if (!locationExists) {
          return logger.error(res, 'location id does not exist');
      }
      const floorExists = await db.crbt_floors.findOne({
          where: { floor_id: req.body.floor_id }
      });
      if (!floorExists) {
          return logger.error(res, 'floor id does not exist');
      }
      const room_name = req.body.room_name.trim();
      if (room_name === '') {
          return logger.error(res, "room name cannot be empty");
      }
       if (room_name.length > 255) {
          return res.status(400).send({ status: false, message: 'room name exceeds maximum length of 255 characters' });
      }
      if (typeof req.body.room_name !== 'string') {
          return logger.error(res, "Invalid room name");
      }
      // Check if room is active
      const roomUpdate = await db.crbt_rooms.findOne({
          attributes: ['room_id', 'status'],
          where: { room_id: req.body.room_id },
      });
      if (!roomUpdate) {
          return logger.error(res, "room is inactive");
      }
     
      const room_amenities = req.body.room_amenities;
      if (!Array.isArray(room_amenities)) {
          return logger.error(res, "room_amenities should be an array");
      }      
          
      const unique_room_amenities = removeDuplicates(room_amenities);      
      console.log('Unique room_amenities:', unique_room_amenities);     
     
      let amenityData = await db.crbm_aminities.findAll({
        attributes:['amenityid'],
        where: { amenityid:  {[Op.in]: unique_room_amenities} }
      }); 
      if(amenityData.length!=unique_room_amenities.length){
        return logger.error(res, "some amenities are not existing");
      }
      next();
  } 
  catch (error) {
      logger.createLog(__filename, error.message, req);
      return logger.error(res, "Exception in room update");
  }
}


const userDeactivevalidator = async function(req, res, next) {
  try {

      console.log("res=======", req.body);
      // await detectNumeric(req.body);
      console.log(req.body);

      if (typeof req.body.room_id == 'undefined') {
          return logger.error(res, "Room id parameter is missing");
      }
      // if (typeof req.body.room_id !== 'string') {
      //   return res.status(400).send({ status: false, message: "Invalid room_id. Please provide a string." });
      // }
      req.body.room_id = req.body.room_id.toString();
      if (req.body.room_id === null) {
          return logger.error(res, "Room id cannot be empty.");
      }
      if (/^\s*$/.test(req.body.room_id)) {
          return logger.error(res, "Room id cannot be empty");
      }
      // if (!Number.isInteger(req.body.room_id)) {
      //     return logger.error(res, "Invalid room_id");
      // }
      let roomEdit = await db.crbt_rooms.findOne({
          attributes: ['room_id'],
          where: { room_id: req.body.room_id },
      })
      if (!roomEdit) {
          return logger.error(res, "Room with the given room_id not found");
      }
      // if (buildingData) {
      //     return logger.error(res, "user_id already inactive.");
      // }
      next();
  } 
  catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in Room Deactive");
  }
}

let getRoomByIdValidator = async function(req, res, next) {
  try {
      await detectNumeric(req.body);
      if (typeof req.query.room_id=='undefined') {
          return logger.error(res,"Parameter Missing");
      }
      if (/^\s*$/.test(req.query.room_id)) {
          return logger.error(res, "room id cannot be empty");
      } 
      if (!Number(req.query.room_id)) {
          return logger.error(res, "Invalid input room id cannot be String");
      }
      let roomget = await db.crbt_rooms.findOne({
          attributes: ['room_id'],
          where: { roomid: req.query.room_id },
      });
      if (!roomget) {
          return logger.error(res, "room id  not found");
      }
      next();
  } catch (error) {
      logger.createLog(__filename, error.message, req);
      return logger.error(res, "Exception in retrieving room.");
  }
};


module.exports = {
  createRoomValidator,
  viewRoomValidator,
  updateRoomValidator,
  deleteRoomValidator,
  userDeactivevalidator,
  getRoomByIdValidator
};
