var db = require('../../models/index');
const logger = require('../../../utils/winston');
const emailer = require("../../../lib/email/mailer");
const { Sequelize, Op } = require('sequelize');
var { sequelize } = require('../../models/index');
const {literal} = require("sequelize");

function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
  }

let createRoom = async function(req, res, next) {
    try {
        const [findlocationid, findrbuildingid, findfloorid] = await Promise.all([
            db.crbt_locations.findOne({
                attributes: ["locationid", "system_user_id"],
                where: { location_id: req.body.location_id }
            }),
            db.crbt_buildings.findOne({
                attributes: ["buildingid", "system_user_id"],
                where: { building_id: req.body.building_id }
            }),
            db.crbt_floors.findOne({
                attributes: ["floorid", "system_user_id"],
                where: { floor_id: req.body.floor_id}
            }),
        ]);

        if (
            findlocationid.system_user_id !== req.systemUser.system_user_id ||
            findrbuildingid.system_user_id !== req.systemUser.system_user_id |
            findfloorid.system_user_id !== req.systemUser.system_user_id
            // findlocationuser.system_user_id !== req.systemUser.system_user_id
        ) {
            return res.status(400).send({ status: false, message: "Permission Denied" });
        }
        req.body.room_name = req.body.room_name.trim();
        let roomData = {
            roomid: req.body.room_id.toString(),
            room_name: req.body.room_name,
            capacity: req.body.capacity,
            floor_id: req.body.floor_id ,
            location_id: req.body.location_id,
            building_id: req.body.building_id,
            status: req.body.status,
            created_by: req.systemUser.system_user_id,
            system_user_id: req.systemUser.system_user_id
        };
        
        const createdRoom = await db.crbt_rooms.create(roomData);
        
        if (createdRoom) {
            let room_amenities = req.body.room_amenities;
            if (!Array.isArray(room_amenities)) {
                room_amenities = [room_amenities];
            }
            let record = room_amenities.map((amenity_id) => {
                return { room_id: createdRoom.dataValues.room_id, amenity_id: amenity_id, created_by: req.systemUser.system_user_id };
            });
            const createdRoomAmenities = await db.crbt_room_amenities.bulkCreate(record);
            if (createdRoomAmenities) {
                return res.status(200).send({ status: true, message: "Room created successfully", data: createdRoom });
            } else {
                return logger.error(res, "Error in creating room amenities");
            }
        } else {
            return logger.error(res, "Error in creating room");
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in createRoom");
    }
};

let updateRoom = async function(req, res, next) {
    try { 
        const [findlocationid, findbuildingid, findfloorid] = await Promise.all([
            db.crbt_locations.findOne({
            attributes: ["locationid", "system_user_id"],
            where: { location_id: req.body.location_id }
        }),
            db.crbt_buildings.findOne({
            attributes: ["buildingid", "system_user_id"],
            where: { building_id: req.body.building_id }
        }),
            db.crbt_floors.findOne({
            attributes: ["floorid", "system_user_id"],
            where: { floor_id: req.body.floor_id }
        }),
        ]);

        if (
            findlocationid.system_user_id !== req.systemUser.system_user_id ||
            findbuildingid.system_user_id !== req.systemUser.system_user_id ||
            findfloorid.system_user_id !== req.systemUser.system_user_id 
        ) {
            return res.status(400).send({ status: false, message: "Room ID and Location ID and Floor ID and Building ID Combination does not exist" });
        }

        let subData = await db.crbt_rooms.findOne({
            where: { room_id: req.body.room_id }
        });

        if (!Array.isArray(subData.room_amenities)) {
            subData.room_amenities = []; 
        }

        if(req.body.status=="Active"){
            req.body.status=true;
        }
        if(req.body.status=="Inactive"){
            req.body.status=false;
        }
        let roomData = await db.crbt_rooms.update({
            capacity: req.body.capacity,
            room_name: req.body.room_name,
            floor_id: req.body.floor_id,
            location_id: req.body.location_id,
            building_id: req.body.building_id,
            status: req.body.status,
            room_amenities: req.body.room_amenities, 
        }, {
            where: {
                room_id: req.body.room_id.toString(),
                system_user_id: req.systemUser.system_user_id
            },
        }); 
        await db.crbt_room_amenities.destroy({
            where: {
                room_id: req.body.room_id,
            },
        }); 
        if (Array.isArray(req.body.room_amenities) && req.body.room_amenities.length !== 0) {
            let newAmenities = req.body.room_amenities.map((amenity_id) => ({
                room_id: req.body.room_id,
                amenity_id: amenity_id,
                created_by: req.systemUser.system_user_id,
            }));

            await db.crbt_room_amenities.bulkCreate(newAmenities);
        }

        if (subData.system_user_id !== req.systemUser.system_user_id) {
            return res.status(200).send({ status: false, message: "Permission Denied", roomData });
        } else if (subData.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Room updated successfully", roomData });
        }
    } 
    catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in updateRoom");
    }
};

// let updateRoom = async function(req, res, next) {
//     // try {
//         const [findlocationid, findbuildingid, findfloorid] = await Promise.all([
//             db.crbt_locations.findOne({
//                 attributes: ["locationid", "system_user_id"],
//                 where: { locationid: req.body.location_id.toString()}
//             }),
//             db.crbt_buildings.findOne({
//                 attributes: ["buildingid", "system_user_id"],
//                 where: { buildingid: req.body.building_id.toString() }
//             }),
//             db.crbt_floors.findOne({
//                 attributes: ["floorid", "system_user_id"],
//                 where: { floorid: req.body.floor_id.toString() }
//             }),
//         ]);

//         if (
//             !findlocationid || 
//             !findbuildingid || 
//             !findfloorid ||
//             findlocationid.system_user_id !== req.systemUser.system_user_id ||
//             findbuildingid.system_user_id !== req.systemUser.system_user_id ||
//             findfloorid.system_user_id !== req.systemUser.system_user_id 
//         ) {
//             return res.status(400).send({ status: false, message: "Room ID and Location ID and Floor ID and Building ID Combination does not exist" });
//         }

//         let subData = await db.crbt_rooms.findOne({
//             where: { room_id: req.body.room_id }
//         });

//         if (!Array.isArray(subData.room_amenities)) {
//             subData.room_amenities = []; 
//         }

//         let roomData = await db.crbt_rooms.update({
//             capacity: req.body.capacity,
//             room_name: req.body.room_name,
//             floor_id: req.body.floor_id,
//             location_id: req.body.location_id,
//             building_id: req.body.building_id,
//             status: req.body.status,
//             room_amenities: req.body.room_amenities, 
//         }, {
//             where: {
//                 room_id: req.body.room_id,
//                 system_user_id: req.systemUser.system_user_id
//             },
//         });

//         await db.crbt_room_amenities.destroy({
//             where: {
//                 room_id: req.body.room_id,
//             },
//         });

//         if (Array.isArray(req.body.room_amenities) && req.body.room_amenities.length !== 0) {
//             let newAmenities = req.body.room_amenities.map((amenity_id) => ({
//                 room_id: req.body.room_id,
//                 amenity_id: amenity_id,
//                 created_by: req.systemUser.system_user_id,
//             }));

//             await db.crbt_room_amenities.bulkCreate(newAmenities);
//         }

//         if (subData.system_user_id !== req.systemUser.system_user_id) {
//             return res.status(400).send({ status: false, message: "Permission Denied", roomData });
//         } else if (subData.system_user_id === req.systemUser.system_user_id) {
//             return res.status(200).send({ status: true, message: "Room updated successfully", roomData });
//         }
// //     } catch (error) {
// //         console.error(error);
// //         return res.status(500).send({ status: false, message: "Exception in updateRoom" });
// //     }
// };


let roomDeactivate = async function(req, res, next) {
    try {
        let dataUser = await db.crbt_rooms.findOne({
            where: { room_id: req.body.room_id }
        })
        await detectNumeric(req.body.isactive);
        let status_user = req.body.isactive;
        if (status_user === 1) {
            isactive_value = true;
        } else if (status_user === 0) {
            isactive_value = false;
        }
        let updateRoom = await db.crbt_rooms.update({ status: isactive_value }, {
            where: {
                // isactive: true,
                room_id: req.body.room_id.toString(),
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (dataUser.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", updateRoom });
        } else if (dataUser.system_user_id === req.systemUser.system_user_id) {
            if (status_user === 0) {
                return res.status(200).send({ status: true, message: "Room deactivated successfully", updateRoom });
            } else {
                return res.status(200).send({ status: true, message: "Room activated successfully", updateRoom });
            }
        }
    } 
    catch (error) {
        logger.createLog(__filename, error.message, req);
        return res.status(500).send({ status: false, message: "Exception in Room deactivation" });
    }
}


let deleteRoom = async function(req, res, next) {
    try {
        let roomdelete = await db.crbt_rooms.findOne({
            where: { roomid: req.body.room_id.toString()}

        })
        const rooms = await db.crbt_rooms.update({
            status: false

        }, {
            where: {
                roomid: req.body.room_id.toString(),
                system_user_id: req.systemUser.system_user_id
            },
        })
        if (roomdelete.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", rooms });
        } else if (roomdelete.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "room deleted successfully", rooms });
        }
    } 
    catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Rooms deletion");
    }

}
        
 

let viewRoom = async function (req, res, next) {
    try { 
        let whereCondition={ system_user_id: req.systemUser.system_user_id };
        if(req.query.location_id){ 
            whereCondition.location_id=  {
                [Sequelize.Op.in]:req.query.location_id.split(',')
            }
        }
        if(req.query.building_id){ 
            whereCondition.building_id=  {
                [Sequelize.Op.in]:req.query.building_id.split(',')
            }
        }
        if(req.query.floor_id){ 
            whereCondition.floor_id=  {
                [Sequelize.Op.in]:req.query.floor_id.split(',')
            }
        }
        if(req.query.capacity){
            let capacity=req.query.capacity.split('-');
            console.log('capacity capacity capacity : ',capacity[0],capacity[1])
            whereCondition.capacity=  {
                [Sequelize.Op.between]:capacity
            }
        }
        if (req.query.amenity_id) {
            let amenityIds = req.query.amenity_id.split(',');
            whereCondition.room_id = {
                [Sequelize.Op.in]: Sequelize.literal(`
                    (SELECT room_id FROM crbt_room_amenities WHERE amenity_id IN (${amenityIds.join(',')}))
                `)
            };
        }


        let rooms = await db.crbt_rooms.findAll({
            attributes: [
                "room_id","roomid", "room_name", "system_user_id", "capacity", "created_by", "updated_by",
                "created_at", "updated_at", "status",
            [
            Sequelize.literal(`(
                SELECT COALESCE(
                ARRAY_AGG(
                    json_build_object(
                    'amenityid', amenityid,
                    'amenityname', amenityname,
                    'thumbnail_key', thumbnail_key
                    )
                ) FILTER (WHERE amenityid IS NOT NULL), '{}'::json[]
                )
                FROM crbm_aminities 
                JOIN crbt_room_amenities ON crbm_aminities.amenityid = crbt_room_amenities.amenity_id 
                WHERE crbt_room_amenities.room_id = crbt_rooms.room_id
            )`),
            'amenities'
            ]],
            where: whereCondition, 
            raw: true,
            nest: true,
            include: [
                {
                    model: db.crbt_floors,
                    as: "crbt_floors",
                    attributes: ["floor_id",["floorid","ufloor_id"], "floor_name"],
                    required: false,
                                       
                },
                {
                    model: db.crbt_buildings,
                    as: "crbt_buildings",
                    attributes: ["building_id",["buildingid","ubuilding_id"], "building_name"],
                    required: false,
                    
                },
                {
                    model: db.crbt_locations,
                    as: "crbt_locations",
                    attributes: ["location_id",["locationid","ulocation_id"], "location_name"],
                    required: false,
                     
                },
            ],
            order: [
                ['created_at', 'DESC'], 
            ],
        });

        if (rooms.length === 0) {
            return res.status(200).send({ status: false, message: "Rooms not available", rooms });
        } else {
            return res.status(200).send({ status: true, message: "Rooms retrieved successfully", rooms });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in room List");
    }
};


// let getRoomById = async function (req, res, next) {
//     // try {
//         let rooms = await db.crbt_rooms.findAll({
//             attributes: [
//                 "room_id","roomid", "room_name", "system_user_id", "capacity", "created_by", "updated_by",
//                 "created_at", "updated_at", "status",
//                 [Sequelize.literal('(SELECT ARRAY_AGG(json_build_object(\'amenityid\', amenityid,\'amenityname\', amenityname, \'thumbnail_key\', thumbnail_key)) FROM crbm_aminities JOIN crbt_room_amenities ON crbm_aminities.amenityid = crbt_room_amenities.amenity_id WHERE crbt_room_amenities.room_id = crbt_rooms.room_id)'), 'amenities']
//             ],
//             where: {
//                 roomid: req.query.room_id,
//                 system_user_id: req.systemUser.system_user_id
//             },
//             include: [
//                 {
//                     model: db.crbt_floors,
//                     as: "crbt_floors",
//                     attributes: ["floorid", "floor_name"],
//                     required: false,
//                 },
//             ],
//             raw: true,
//             nest: true,
//             include: [
//                 {
//                     model: db.crbt_floors,
//                     as: "crbt_floors",
//                     attributes: ["floorid", "floor_name"],
//                     required: false,
//                     on: {
//                         "$crbt_rooms.floor_id$": {
//                             [Sequelize.Op.eq]: Sequelize.literal('CAST(regexp_replace("crbt_floors"."floorid", \'\\D\', \'\', \'g\') AS INTEGER)'),
//                         },
//                     },                    
//                 },
//                 {
//                     model: db.crbt_buildings,
//                     as: "crbt_buildings",
//                     attributes: [["buildingid","building_id"], "building_name"],
//                     required: false,
//                     on: {
//                         "$crbt_rooms.building_id$": {
//                             [Sequelize.Op.eq]: Sequelize.literal('CAST(regexp_replace("crbt_buildings"."buildingid", \'\\D\', \'\', \'g\') AS INTEGER)'),
//                         },
//                     },
//                 },
//                 {
//                     model: db.crbt_locations,
//                     as: "crbt_locations",
//                     attributes: [["locationid","location_id"], "location_name"],
//                     required: false,
//                     on: {
//                         "$crbt_rooms.location_id$": {
//                             [Sequelize.Op.eq]: Sequelize.literal('CAST(regexp_replace("crbt_locations"."locationid", \'\\D\', \'\', \'g\') AS INTEGER)'),
//                         },
//                     },
//                 },
//             ],
//         });

//         if (rooms.length === 0) {
//             return res.status(200).send({ status: false, message: "Rooms not available", rooms });
//         } else {
//             return res.status(200).send({ status: true, message: "Rooms retrieved successfully", rooms });
//         }
//     // } catch (error) {
//     //     logger.createLog(__filename, error.message, req);
//     //     return logger.error(res, "Exception in room List");
//     // }
// };
let getRoomById = async function (req,res,next) {  
    try {
    
      console.log(req.systemUser.system_user_id)
        let getroom = await db.crbt_rooms.findOne({
            where: { roomid:req.query.room_id}
        })
        let room = await db.crbt_rooms.findAll({
            attributes: [["roomid","room_id"], "room_name", "system_user_id", "capacity","created_by", "updated_by",
                "created_at", "updated_at", "status", "floor_id",
                [Sequelize.literal('(SELECT ARRAY_AGG(json_build_object(\'amenityid\', amenityid,\'amenityname\', amenityname, \'thumbnail_key\', thumbnail_key)) FROM crbm_aminities JOIN crbt_room_amenities ON crbm_aminities.amenityid = crbt_room_amenities.amenity_id WHERE crbt_room_amenities.room_id = crbt_rooms.roomid::integer)'), 'amenities']
            
        ],
            where: {
            //   status:true,
              roomid: req.query.room_id,
              system_user_id:req.systemUser.system_user_id
          },  
          include: [
        {
            model: db.crbt_floors,
            as: "crbt_floors",
            attributes: ["floor_id", "floor_name"],
            required: false,
        },
        {
            model: db.crbt_buildings,
            as: "crbt_buildings",
            attributes: ["building_id", "building_name"],
            required: false,
        },
        {
            model: db.crbt_locations,
            as: "crbt_locations",
            attributes: ["location_id", "location_name"],
            required: false,
        },
    ],  
        order: [[db.crbt_rooms.rawAttributes.roomid, 'DESC']],   
        })
     
        if (getroom.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (getroom.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Room Retrived Successfully", room });
        }
    } 
    catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Room");
    }
}
  
  

let getRoomDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        console.log(order_data)
        let room = await db.crbt_rooms.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`room_id`)), 'roomcount'],
            ],
            where: {
                status: true,
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'r.room_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        var where_query = '';
        if (req.query.room_name != "") {
            where_query = where_query + ` and room_name=${req.query.room_name}`

        }
        if (req.query.room_id != "") {
            where_query = where_query + ` and r.room_id=${req.query.room_id}`

        }
        if (req.query.floor_id != "") {
            where_query = where_query + ` and r.floor_name=${req.query.floor_id}`

        }
        if (req.query.capacity != "") {
            where_query = where_query + ` and r.capacity=${req.query.capacity}`

        }
        if (req.query.room_amenities != "") {
            where_query = where_query + ` and r.room_id=${req.query.room_amenities}`

        }
        if (req.query.status != "") {
            where_query = where_query + ` and r.status=${req.query.status}`

        }

        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and system_user_id=${req.systemUser.system_user_id}  and  (r.room_id::text = '${search_value}' OR LOWER(r.room_name)::text LIKE '%${search_value}%' OR r.status::text LIKE '%${search_value}%' OR r.room_amenities::text LIKE '%${req.query.room_amenities}%' OR r.capacity::text LIKE '%${req.query.capacity}%' OR r.floor_id::text LIKE '%${req.query.floor_id}%' )`;
        }
        const roomsearchdata = await sequelize.query(`select COUNT(r.room_id) AS Total from crbt_rooms r where status = 'true' ${where_query} ${search_query}`);
        let query = `select r.room_id,room_name,status from crbt_rooms r where status = 'true' ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const roomData = await sequelize.query(query);
        let data = [];
        if (roominfo[0].length != 0) {
            for (i = 0; i < roominfo[0].length; i++) {
                data.push({
                    room_id: roomData[0][i].room_id,
                    room_name: roomData[0][i].room_name,
                    floor_name: roomData[0][i].floor_name,
                    capacity: roomData[0][i].capacity,
                    room_amenities: roomData[0][i].room_amenities,
                    status: roomData[0][i].status,
                    action: `<div> 
                <span class='a-edit' catid='${roomData[0][i].room_id}'><i class="bi bi-pencil-square"></i></span>
                <span class='a-view' catid='${roomData[0][i].room_id}'><i class="bi bi-eye-fill"></i></span>
                <span  class='a-delete' catid='${roomData[0][i].room_id}'><i class="bi bi-trash-fill"></i></span>
                </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': room.dataValues.roomcount,
            'iTotalDisplayRecords': roomsearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }

};
let fetchrooms = async function(req, res, next) {
    try {
        let whereCondition = {
            status: true,
            system_user_id: req.systemUser.system_user_id
        }
        if (req.query.floor_id != undefined) {
            if (req.query.floor_id != "") {
                whereCondition.floor_id = {
                    [Op.in]: req.query.floor_id.split(",")
                }
            }
        }
        let roomData = await db.crbt_rooms.findAll({
            attributes: ["room_id",["roomid","uroom_id"], "room_name","floor_id",'capacity'],
            order: [
                ['roomid', "DESC"]
            ],
            where: whereCondition
        })

        if (roomData.length == 0) {
            return res.status(200).send({
                status: false,
                message: "Data not found",
                roomData
            });
        } else {
            return res.status(200).send({
                status: true,
                message: "Rooms retrived successfully",
                roomData
            });
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Rooms");
    }
}
let fetchUserrooms = async function(req, res, next) {
    try { 
        console.log(req.systemUser.user_id)
        let rooms=[];
       let buildingdata= await db.crbt_users.findOne({
            attributes: ["building_id"],
            where: { user_id: req.systemUser.user_id }
        })
        if(buildingdata?.dataValues?.building_id){
              rooms= await db.crbt_rooms.findAll({   
                attributes: ["room_id","room_name",["roomid","uroom_id"],"location_id","building_id","floor_id"],   
                where: { building_id: buildingdata?.dataValues?.building_id }
            })
        } 
        return res.status(200).send({ status: true, message: "User rooms Retrived Successfully",data:rooms });
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Rooms");
    }
}

module.exports = {
    createRoom,
    updateRoom,
    roomDeactivate,
    viewRoom,
    deleteRoom,
    getRoomById,
    getRoomDataTable,
    fetchrooms,
    fetchUserrooms
};

