var db = require('../../models/index')
const logger = require('../../../utils/winston')
const { Sequelize, Op } = require("sequelize");

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}
const pinRegex = /^\d{6}$/;
const createBuilding = async function(req, res, next) {
    try {
        //  tectNumeric(req.body);
        req.body.building_id = req.body.building_id.toString()
        const new_pincode = parseInt(req.body.pincode)
        console.log(req.body);
        const requiredParams = ['building_name', 'address', 'pincode', 'location_id', 'status'];
        for (const param of requiredParams) {
            if (typeof req.body[param] === 'undefined') {
                return logger.error(res, `${param} Parameter is missing`);
            }
        }
        req.body.building_name = req.body.building_name.trim();
        if (typeof req.body.building_name !== 'string' || !/^[a-zA-Z\s]+$/.test(req.body.building_name)) {
            return logger.error(res, "Invalid Data Type for Building Name. Only characters are allowed.");
        }
        const building_name = req.body.building_name;
        if (building_name && building_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Building name exceeds maximum length of 255 characters' });
        }
        if (/^\s*$/.test(req.body.building_name)) {
            return logger.error(res, "Building name cannot be empty");
        }
        if (/^\s*$/.test(req.body.address)) {
            return logger.error(res, "Address cannot be empty");
        }
        if (/^\s*$/.test(new_pincode)) {
            return logger.error(res, "Pincode cannot be empty");
        }
        if (typeof new_pincode !== 'number') {
            return logger.error(res, "Invalid Pincode. Only numbers are allowed");
        }
        if (!pinRegex.test(req.body.pincode)) {
            return logger.error(res, "Pincode code should consist of 6 digit number");
        }
        if (isNaN(req.body.pincode)) {
            return logger.error(res, "Invalid Pincode. Only numbers are allowed");
        }
        if (req.body.building_name == null) {
            return logger.error(res, "Building Name cannot be empty ");
        }
        if (req.body.location_id == null) {
            return logger.error(res, "Location id cannot be empty ");
        }
        if (/^\s*$/.test(req.body.status)) {
            return logger.error(res, "Building Name cannot be empty");
        }
        let userdataEmail = await db.crbt_buildings.findOne({
            attributes: ["building_name"],
            where: { building_name: req.body.building_name, system_user_id: req.systemUser.system_user_id }
        });
        let buildingidCheck = await db.crbt_buildings.findOne({
            attributes: ["buildingid"],
            where: { buildingid: req.body.building_id, system_user_id: req.systemUser.system_user_id }
        });
        if (buildingidCheck) {
            return logger.error(res, "Building ID already exists");
        }
        if (userdataEmail) {
            return logger.error(res, "Building Name already exists");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        console.log(error)
        return logger.error(res, "Exception in Building Create validtaion");
    }
}
const deleteBuilding = async function(req, res, next) {
    try {

        // await detectNumeric(req.body);
        req.body.building_id = req.body.building_id.toString()
        if (typeof req.body.building_id == 'undefined') {
            return logger.error(res, "Building ID parameter is missing");
        }
        if (req.body.building_id === null) {
            return logger.error(res, "Building ID cannot be empty.");
        }
        if (/^\s*$/.test(req.body.building_id)) {
            return logger.error(res, "Building ID cannot be empty");
        }
        // if (!Number.isInteger(req.body.building_id)) {
        //     return logger.error(res, "Invalid Building ID");
        // }
        let buildingData = await db.crbt_buildings.findOne({
            attributes: ["buildingid", "status"],
            where: { buildingid: req.body.building_id, status: false }
        })
        let buildingEdit = await db.crbt_buildings.findOne({
            attributes: ['buildingid'],
            where: { buildingid: req.body.building_id },
        })
        if (!buildingEdit) {
            return logger.error(res, "Building ID not found");
        }
        if (buildingData) {
            return logger.error(res, "Building ID already Inactive.");
        }
        next();
    } catch (error) {
        console.log(error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building Delete");
    }
}
let editBuilding = async function(req, res, next) {
    try {
        console.log("res====", req.body);
        await detectNumeric(req.body.pincode);
        const new_pincode = parseInt(req.body.pincode)
        req.body.building_id = req.body.building_id.toString()
        const requiredParams = ['building_name', 'address', 'pincode', 'location_id', 'status'];
        for (const param of requiredParams) {
            if (typeof req.body[param] === 'undefined') {
                return logger.error(res, `${param} Parameter is missing`);
            }
        }
        req.body.building_name = req.body.building_name.trim();
        if (req.body.building_id == null) {
            return logger.error(res, "Building ID cannot be empty ");
        }
        if (/^\s*$/.test(req.body.building_id)) {
            return logger.error(res, "Building ID cannot be empty");
        }
        if (/^\s*$/.test(req.body.building_name)) {
            return logger.error(res, "Building Name cannot be empty");
        }
        if (/^\s*$/.test(req.body.address)) {
            return logger.error(res, "Address cannot be empty");
        }
        if (!pinRegex.test(req.body.pincode)) {
            return logger.error(res, "Pincode code should consist of 6 digit number");
        }
        if (isNaN(req.body.pincode)) {
            return logger.error(res, "Invalid Pincode. Only numbers are allowed");
        }
        if (/^\s*$/.test(new_pincode)) {
            return logger.error(res, "Pincode cannot be empty");
        }
        // if (typeof req.body.building_id !== 'number') {
        //     return logger.error(res, "Invalid Building ID");
        // }
        if (req.body.building_name && typeof req.body.building_name !== 'string') {
            return logger.error(res, "Invalid Building Name");
        }
        if (req.body.address && typeof req.body.address !== 'string') {
            return logger.error(res, "Invalid Building Address");
        }
        if (typeof new_pincode !== 'number') {
            return logger.error(res, "Invalid Pincode. Only numbers are allowed");
        }
        const building_name = req.body.building_name;
        if (building_name && building_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Building Name exceeds maximum length of 255 characters' });
        }

        if (building_name && building_name.trim().length > 0) {
            const BuildingEditcheck = await db.crbt_buildings.findOne({
                attributes: ['buildingid'],
                where: {
                    building_name: building_name.trim(),
                    system_user_id: req.systemUser.system_user_id,
                    buildingid: {
                        [db.Sequelize.Op.not]: req.body.building_id
                    }
                },
            });

            if (BuildingEditcheck) {
                return logger.error(res, "Building Name already exists");
            }
        }
        let BuildingEdit = await db.crbt_buildings.findOne({
            attributes: ['buildingid'],
            where: { buildingid: req.body.building_id },
        })
        if (!BuildingEdit) {
            return logger.error(res, "Building ID Not Found");
        }
        next();
    } catch (error) {
        console.log("error ", error);
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Building Update");
    }
}
const getBuildingbyid = async function(req, res, next) {
    try {
        // await detectNumeric(req.query);
        req.body.building_id = req.body.building_id.toString()
        if (typeof req.query.building_id == 'undefined') {
            return logger.error(res, "Building ID parameter is missing");
        }
        if (/^\s*$/.test(req.query.building_id)) {
            return logger.error(res, "Building ID cannot be empty");
        }
        if (req.query.building_id == null) {
            return logger.error(res, "Building ID cannot be empty ");
        }
        // if (isNaN(req.query.building_id)) {
        //     return logger.error(res, "Invalid Data Type for Building ID. Only number are allowed.");
        // }
        let BuildingData = await db.crbt_buildings.findOne({
            attributes: ["buildingid", "status"],
            where: { buildingid: req.query.building_id, status: false, system_user_id: req.systemUser.system_user_id }
        })
        if (BuildingData) {
            return logger.error(res, "Building is inactive");
        }
        let Buildingeditt = await db.crbt_buildings.findOne({
            attributes: ['buildingid', 'status'],
            where: { buildingid: req.query.building_id, status: true },
        });
        console.log(Buildingeditt);
        if (!Buildingeditt) {
            return logger.error(res, "Building ID not found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Getting Building");
    }
}

const getBuildingfetch = async function(req, res, next) {
    try {
        await detectNumeric(req.query);

        console.log(req.query);
        if (req.query.building_name && typeof req.query.building_name !== 'string') {
            return logger.error(res, "Invalid Building Name");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building Fetching");
    }
}
const buildingActDec = async function(req, res, next) {
    try {
        // await detectNumeric(req.body);
        req.body.building_id = req.body.building_id.toString()
        const status = parseInt(req.body.status)
        if (typeof req.body.building_id == 'undefined') {
            return logger.error(res, "Building ID parameter is missing");
        }
        if (typeof status == 'undefined') {
            return logger.error(res, "Status parameter is missing");
        }
        if (req.body.building_id === null) {
            return logger.error(res, "Building ID cannot be empty.");
        }
        if (status !== 0 || status !== 1) {
            return logger.error(res, "Invalid Value.");
        }
        if (/^\s*$/.test(req.body.building_id)) {
            return logger.error(res, "Building ID cannot be empty");
        }
        if (/^\s*$/.test(status)) {
            return logger.error(res, "Status cannot be empty");
        }
        if (!Number.isInteger(req.body.building_id)) {
            return logger.error(res, "Invalid Building ID");
        }
        let buildingEdit = await db.crbt_buildings.findOne({
            attributes: ['buildingid'],
            where: { buildingid: req.body.building_id },
        })
        if (!buildingEdit) {
            return logger.error(res, "Building ID Not Found");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building Active and Deactivate");
    }
}

module.exports = {
    createBuilding,
    deleteBuilding,
    editBuilding,
    getBuildingbyid,
    getBuildingfetch,
    buildingActDec

};