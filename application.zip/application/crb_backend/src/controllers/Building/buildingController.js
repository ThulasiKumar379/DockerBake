var db = require('../../models/index')
const logger = require('../../../utils/winston')
const { Sequelize, Op } = require("sequelize");
var { sequelize } = require('../../models/index')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}




let createBuilding = async function(req, res, next) {
    try {
        
        req.body.building_name = req.body.building_name.trim(); 
        let checklocation = await db.crbt_locations.findOne({
            attributes: ["locationid", "system_user_id"],
            where: { location_id: req.body.location_id }
        });

        if (!checklocation || checklocation.system_user_id !== req.systemUser.system_user_id) {
            return logger.error(res, "Location ID not found or invalid");
        }

        let insertdata = {
            buildingid: req.body.building_id,
            building_name: req.body.building_name,
            location_id: req.body.location_id,
            address: req.body.address,
            status: req.body.status,
            pincode: req.body.pincode,
            system_user_id: req.systemUser.system_user_id,
            created_by: req.systemUser.system_user_id
        };
        
        const createdBuilding = await db.crbt_buildings.create(insertdata);

        if (createdBuilding) {
            // Construct a response object with only the desired fields
            const responseData = {
                building_id: createdBuilding.buildingid,
                building_name: createdBuilding.building_name,
                location_id: createdBuilding.location_id,
                address: createdBuilding.address,
                status: createdBuilding.status,
                pincode: createdBuilding.pincode,
                system_user_id: createdBuilding.system_user_id,
                created_by: createdBuilding.created_by
            };

            return res.status(200).send({ status: true, message: "New Building inserted", data: responseData });
        } else {
            return logger.error(res, "Error in Building");
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, error.message);
    }
};


let editBuilding = async function(req, res, next) {
    try { 
       if(req.body.status=='Active'){
        req.body.status=true;
       }
       if(req.body.status=='Inactive'){
        req.body.status=false;
       }
        let buildingData = await db.crbt_buildings.findOne({
            where: { buildingid: req.body.building_id }
        })
        if(req.body.status=='Active'){req.body.status=true}
        if(req.body.status=='Inactive'){req.body.status=false}
        
        req.body.building_name = req.body.building_name.trim();
      
        let checklocation = await db.crbt_locations.findOne({
            attributes: ["location_id", "system_user_id"],
            where: { location_id: req.body.location_id }
        }); 
        if (!checklocation || checklocation.system_user_id !== req.systemUser.system_user_id) {
            return logger.error(res, "Location ID not found or invalid");
        }
        let updateBuilding = await db.crbt_buildings.update({
            building_name: req.body.building_name,
            address: req.body.address,
            pincode: req.body.pincode,
            location_id: req.body.location_id,
            updated_by: req.systemUser.system_user_id,
            status: req.body.status
        }, {
            where: {
                buildingid: req.body.building_id,
                system_user_id: req.systemUser.system_user_id
            },
        })
        if (buildingData.system_user_id !== req.systemUser.system_user_id) {
            return res.status(200).send({ status: false, message: "Perimission Denied", updateBuilding });
        } else if (buildingData.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Building Updated Successfully", updateBuilding });
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building update");
    }
}

let deleteBuilding = async function(req, res, next) {
    try {
        let buildingDeldata = await db.crbt_buildings.findOne({
            where: { buildingid: req.body.building_id }
        })
        const deleted = await db.crbt_buildings.update({
            status: false

        }, {
            where: {
                buildingid: req.body.building_id,
                system_user_id: req.systemUser.system_user_id
            },
        })
        if (buildingDeldata.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", deleted });
        } else if (buildingDeldata.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Building Deleted Successfully", deleted });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building delete");
    }
}

let getBuildingList = async function(req, res, next) {
    try {
        let BuildingData = await db.crbt_buildings.findAll({
            attributes: [
                ["buildingid", "building_id"], "building_name", "location_id", "status", "pincode", "created_at", "updated_at"
            ],
            order: [
                [db.crbt_buildings.rawAttributes.buildingid, "DESC"]
            ],
            where: {
                system_user_id: req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_locations,

                as: "crbt_locations",
                attributes: [
                    ['locationid', 'location_id'], 'location_name'
                ],
                required: true
            }]

        })
        if (BuildingData.length === 0) {
            return res.status(400).send({ status: false, message: "Building not available", BuildingData });
        } else {
            return res.status(200).send({ status: true, message: "Building retrived successfully", BuildingData });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building");
    }
}

let getBuildingfetch = async function(req, res, next) {
    try {
        let query2 = {}
        if (req.query.building_name && req.query.building_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(building_name) like '${req.query.building_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(building_name) like '${req.query.building_name.toLowerCase()}%'`
            }
        };
        if (req.query.building_name && req.query.building_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(building_name) like '${req.query.building_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(building_name) like '${(req.query.building_name.toLowerCase())}%'`
            }
        };
        if (req.query.location_name && req.query.location_name != "") {
            if (Object.keys(query2).length === 0) {
                query2 = ` and lower(location_name) like '${req.query.location_name.toLowerCase()}%'`
            } else {
                query2 = `${query2} and lower(location_name) like '${(req.query.location_name.toLowerCase())}%'`
            }
        };
        if (req.query.building_id) {
            query2 = ` and buildingid = ${req.query.building_id}`
        }
        if (Object.keys(query2).length === 0) {
            query2 = ''
        }
        console.log(req.systemUser.system_user_id);
        const [results] = await sequelize.query(
            `SELECT crbt_buildings.buildingid AS building_id,crbt_buildings.building_name,crbt_buildings.address,
            crbt_buildings.system_user_id,crbt_buildings.created_by,crbt_buildings.updated_by,
            crbt_buildings.created_at,crbt_buildings.updated_at,crbt_buildings.status,crbt_buildings.pincode, 
            crbt_locations.location_id,crbt_locations.locationid AS ulocation_id,crbt_locations.location_name 
            FROM crbt_buildings join 
            crbt_locations on crbt_buildings.location_id = crbt_locations.location_id  where crbt_buildings.system_user_id=${req.systemUser.system_user_id} ${query2} ORDER BY buildingid DESC            `);
        console.log(results);
        if (results.length === 0) {
            return logger.success(res, "Buildings data no found")
        } else {
            return logger.success(res, "Buildings retrived successfully", results)
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Building List");
    }
}


let getBuildingbyid = async function(req, res, next) {
    try {
        let subGetData = await db.crbt_buildings.findOne({
            where: { building_id: req.query.building_id }
        })
        let subscriptionplansDataa = await db.crbt_buildings.findOne({
            attributes: [
                ["buildingid", "building_id"], "building_name", "location_id"
            ],
            order: [
                [db.crbt_buildings.rawAttributes.buildingid, "ASC"]
            ],
            where: {
                buildingid: req.query.building_id,
                status: true,
                system_user_id: req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_locations,
                as: "crbt_locations",
                attributes: [
                    ['locationid', 'location_id'], 'location_name'
                ],
                required: false,
            }]

        })
        if (subGetData.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", data: subscriptionplansDataa });
        } else if (subGetData.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Building retrived successfully", data: subscriptionplansDataa });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in getBuildings");
    }
}

let getbuildingDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        console.log(order_data)
        let building = await db.crbt_buildings.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`building_id`)), 'buildingcount'],
            ],
            where: {
                status: true,
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'r.building_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        var where_query = '';
        if (req.query.building_name != "") {
            where_query = where_query + ` and b.building_name=${req.query.building_name}`

        }
        if (req.query.building_id != "") {
            where_query = where_query + ` and b.building_id=${req.query.building_id}`

        }
        if (req.query.location_id != "") {
            where_query = where_query + ` and b.location_id=${req.query.location_id}`

        }

        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and system_user_id=${req.systemUser.system_user_id}  and  (b.building_id::text = '${search_value}' OR LOWER(b.building_name)::text LIKE '%${search_value}%' OR b.location_id::text LIKE '%${search_value}%' )`;
        }
        const buildingdata = await sequelize.query(`select COUNT(r.building_id) AS Total from crbt_buildings r where status = 'true' ${where_query} ${search_query}`);
        let query = `select b.building_id,b.building_name,b.location_id from crbt_buildings r where status = 'true' ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const buildingData = await sequelize.query(query);
        let data = [];
        if (buildingData[0].length != 0) {
            for (i = 0; i < buildingData[0].length; i++) {
                data.push({
                    building_id: buildingData[0][i].building_id,
                    building_name: buildingData[0][i].building_name,
                    location_id: buildingData[0][i].location_id,
                    action: `<div> 
                  <span class='a-edit' catid='${buildingData[0][i].building_id}'><i class="bi bi-pencil-square"></i></span>
                  <span class='a-view' catid='${buildingData[0][i].building_id}'><i class="bi bi-eye-fill"></i></span>
                  <span  class='a-delete' catid='${buildingData[0][i].building_id}'><i class="bi bi-trash-fill"></i></span>
                  </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': building.dataValues.buildingcount,
            'iTotalDisplayRecords': buildingdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }

};

// let fetchBuildings = async function(req, res, next) {
//     try {
//         let whereCondition = {
//             status: true,
//             system_user_id: req.systemUser.system_user_id
//         }
//         if (req.query.location_id != undefined) {
//             if (req.query.location_id != "") {
//                 whereCondition.location_id = {
//                     [Op.in]: req.query.location_id.split(",")
//                 }
//             }
//         }
//         let BuildingsData = await db.crbt_buildings.findAll({
//             attributes: [
//                 "building_id",["buildingid", "ubuilding_id"], "building_name", "location_id"
//             ],
//             order: [
//                 [db.crbt_buildings.rawAttributes.buildingid, "ASC"]
//             ],
//             where: whereCondition
//         })
//         console.log(BuildingsData);
//         if (BuildingsData.length == 0) {
//             return res.status(200).send({ status: false, message: "Data not found", BuildingsData });
//         } else {
//             return res.status(200).send({ status: true, message: "Building Retrived Successfully", BuildingsData });
//         }
//     } catch (error) {
//         logger.createLog(__filename, error.message, req)
//         return logger.error(res, "Exception in Fetch Buildings");
//     }
// }

let fetchBuildings = async function(req, res, next) {
    try {
        let whereCondition = {
            status: true,
            system_user_id: req.systemUser.system_user_id
        }
        if (req.query.location_id != undefined) {
            if (req.query.location_id != "") {
                whereCondition.location_id = {
                    [Op.in]: req.query.location_id.split(",")
                }
            }
        }
        let BuildingsData = await db.crbt_buildings.findAll({
            attributes: [
                "building_id",["buildingid", "ubuilding_id"], "building_name", "location_id"
            ],
            order: [
                [db.crbt_buildings.rawAttributes.buildingid, "ASC"]
            ],
            where: whereCondition
        })
        console.log(BuildingsData);
        if (BuildingsData.length == 0) {
            return res.status(200).send({ status: false, message: "Data not found", BuildingsData });
        } else {
            return res.status(200).send({ status: true, message: "Building Retrived Successfully", BuildingsData });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Buildings");
    }
}


let buildingActDec = async function(req, res, next) {
    try {
        let dataUser = await db.crbt_buildings.findOne({
                where: { buildingid: req.body.building_id.toString() }
            })
            // await detectNumeric(req.body);
        req.body.building_id = req.body.building_id.toString()
        const statusdata = parseInt(req.body.status);
        const status_user = statusdata;
        if (status_user === 1) {
            status_value = true;
        } else if (status_user === 0) {
            status_value = false;
        }
        let updateBuilding = await db.crbt_buildings.update({ status: status_value }, {
            where: {
                buildingid: req.body.building_id.toString(),
                system_user_id: req.systemUser.system_user_id
            }
        });
        if (dataUser.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", updateBuilding });
        } else if (dataUser.system_user_id === req.systemUser.system_user_id) {
            if (status_user === 0) {
                return res.status(200).send({ status: true, message: "Building Deactivated Successfully", updateBuilding });
            } else {
                return res.status(200).send({ status: true, message: "Building Activated Successfully", updateBuilding });
            }
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return res.status(500).send({ status: false, message: "Exception in Building Action." });
    }
}

module.exports = {
    fetchBuildings,
    createBuilding,
    editBuilding,
    deleteBuilding,
    getBuildingList,
    getBuildingbyid,
    getbuildingDataTable,
    getBuildingfetch,
    buildingActDec
};