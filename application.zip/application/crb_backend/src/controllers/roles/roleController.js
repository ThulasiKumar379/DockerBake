var db = require("../../models/index");
const logger = require("../../../utils/winston");
const emailer = require("../../../lib/email/mailer");
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");

function detectNumeric(obj) {
  for (var index in obj) {
      if (!isNaN(obj[index])) {
          obj[index] = Number(obj[index]);
      } else if (typeof obj === "object") {
          detectNumeric(obj[index]);
      }
  }
}

let createRoles = async function(req, res, next) {
  try {
      req.body.role_name = req.body.role_name.trim();
      let insertdata = {
          // roleid: req.body.role_id.toString(),
          role_name: req.body.role_name,
          status: req.body.status,
          system_user_id: req.systemUser.system_user_id,
          created_by: req.systemUser.system_user_id
      };

      const createdrole = await db.crbt_roles.create(insertdata);

      if (createdrole) {
          const responseData = {
            // role_id: createdrole.role_id,
            role_name: createdrole.role_name,
            status: createdrole.status,
            system_user_id: createdrole.system_user_id,
            created_by: createdrole.system_user_id
          };

          return res.status(200).send({ status: true, message: "New role inserted", data: createdrole });
      } else {
          return logger.error(res, "Error in role");
      }
  } catch (error) {
      logger.createLog(__filename, error.message, req);
      return logger.error(res, "Exception in inserting new role");
  }
};

let updateRoles = async function (req, res, next) {
  try {
    if(req.body.status=='Active'){
      req.body.status=true;
     }
     if(req.body.status=='Inactive'){
      req.body.status=false;
     }
    let roleData = await db.crbt_roles.findOne({
      where: { role_id: req.body.role_id}
    })
      let updateRoles=  await db.crbt_roles.update(
          {
            role_name: req.body.role_name,
            status: req.body.status,
            updated_by : req.systemUser.system_user_id
          },
          {
              where: {
                role_id: req.body.role_id,
                system_user_id: req.systemUser.system_user_id,
              },
          }
      ) 
      console.log(roleData.system_user_id);
      if (roleData.system_user_id !== req.systemUser.system_user_id) {
          return res.status(400).send({ status: false, message: "Perimission Denied", updateRoles });
      } else if (roleData.system_user_id=== req.systemUser.system_user_id) {
          return res.status(200).send({ status: true, message: "Role updated successfully", updateRoles });
      }
      return logger.success(res, "Role updated successfully", updateRoles);
    }
     catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in updateRole ");
    }
}

let roleDeactivate = async function(req, res, next) {
  try {
      let dataUser = await db.crbt_roles.findOne({
          where: { role_id: req.body.role_id.toString() }
      })
      // await detectNumeric(req.body.isactive);
      let status_user = req.body.isactive;
      if (status_user === 1) {
          isactive_value = true;
      } else if (status_user === 0) {
          isactive_value = false;
      }
      let updateRole = await db.crbt_roles.update({ status: isactive_value }, {
          where: {
              // isactive: true,
              role_id: req.body.role_id.toString(),
              system_user_id: req.systemUser.system_user_id
          }
      });
      if (dataUser.system_user_id !== req.systemUser.system_user_id) {
          return res.status(400).send({ status: false, message: "Perimission Denied", updateRole });
      } else if (dataUser.system_user_id === req.systemUser.system_user_id) {
          if (status_user === 0) {
              return res.status(200).send({ status: true, message: "Role deactivated successfully", updateRole });
          } else {
              return res.status(200).send({ status: true, message: "Role activated successfully", updateRole });
          }
      }
  } 
  catch (error) {
      logger.createLog(__filename, error.message, req);
      return res.status(500).send({ status: false, message: "Exception in role deactivation" });
  }
}

let deleteRoles = async function (req, res, next) {
  try {
    let roledelete = await db.crbt_roles.findOne({
        where: { role_id: req.body.role_id.toString() }

    })
    const roles = await db.crbt_roles.update({
        status: false

    }, {
        where: {
          role_id: req.body.role_id.toString(),
            system_user_id: req.systemUser.system_user_id
        },
    })
    if (roledelete.system_user_id !== req.systemUser.system_user_id) {
        return res.status(400).send({ status: false, message: "Perimission Denied", roles });
    } else if (roledelete.system_user_id === req.systemUser.system_user_id) {
        return res.status(200).send({ status: true, message: "role deleted successfully", roles });
    }
  }
  catch (error) {
    logger.createLog(__filename, error.message, req)
    return logger.error(res, "Exception in Roles delete");
  }

}

let viewRoles = async function (req, res, next) {
   try {
    let roleData = await db.crbt_roles.findAll({
      attributes: ["role_id","role_name","status","updated_at","created_at","system_user_id", "created_by"],
      order: [
        [db.crbt_roles.rawAttributes.role_id, "DESC"]
    ],
      where: {
        // status: true,
        system_user_id: req.systemUser.system_user_id
      },
      order: [['role_id', 'DESC']],

    })
    if (roleData.length === 0) {
      return res.status(400).send({ status: false, message: "roles not available", roleData });
    } else {
      return res.status(200).send({ status: true, message: "roles retrived successfully", roleData });
    }
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req)
    return logger.error(res, "Exception in roles");
  }
}

let getrolefetch = async function(req, res, next) {
  try {
      let query2 = {}

      if (req.query.role_name && req.query.role_name != "") {
          if (Object.keys(query2).length === 0) {
              query2 = ` and lower(role_name) like '${req.query.role_name.toLowerCase()}%'`
          } else {
              query2 = `${query2} and lower(role_name) like '${req.query.role_name.toLowerCase()}%'`
          }
      };
      // if (req.query.role_name && req.query.role_name != "") {
      //     if (Object.keys(query2).length === 0) {
      //         query2 = ` and lower(role_name) like '${req.query.role_name.toLowerCase()}%'`
      //     } else {
      //         query2 = `${query2} and lower(role_name) like '${(req.query.role_name.toLowerCase())}%'`
      //     }
      // };
      if (req.query.role_id) {
          query2 = ` and role_id = ${req.query.role_id.toString()}`
      }
      if (Object.keys(query2).length === 0) {
          query2 = ''
      }
      const [results] = await sequelize.query(
          `SELECT role_id AS role_id, role_name, system_user_id,status,created_by,updated_by,created_at, updated_at FROM crbt_roles             
           where system_user_id=${req.systemUser.system_user_id} ${query2}
           ORDER BY role_id DESC`
      );
      if (results.length === 0) {
          return logger.success(res, "Roles data no found")
      } else {
          return logger.success(res, "Roles retrived successfully", results)
      }

  } 
  catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in Roles List");
  }
}


let getRoleById = async function (req,res,next) {  
  try {
    console.log(req.systemUser.system_user_id)
      let getrole = await db.crbt_roles.findOne({
          where: { role_id:req.query.role_id.toString()}
      })
      let rolee = await db.crbt_roles.findOne({
          attributes: [ "role_id", "role_name", "system_user_id", "created_by", "updated_by",
          "created_at", "updated_at", "status"],
          order: [
            [db.crbt_roles.rawAttributes.role_id, "DESC"]
        ],
          where: {
            // status:true,
            role_id: req.query.role_id.toString(),
            system_user_id:req.systemUser.system_user_id
        },  
      })
      if (getrole.system_user_id !== req.systemUser.system_user_id) {
          return res.status(400).send({ status: false, message: "Perimission Denied" });
      } else if (getrole.system_user_id === req.systemUser.system_user_id) {
          return res.status(200).send({ status: true, message: "Role Retrived Successfully", rolee });
      }
  } catch (error) {
      logger.createLog(__filename,error.message,req)
      return logger.error(res,"Exception in Role");
  }
}


let getRoleDataTable = async function (req, res, next) { 
  try {
    var draw = req.query.draw;
    var start = req.query.start;
    var length = req.query.length;
    var order_data = req.query.order;
    console.log(order_data)
    let role = await db.crbt_roles.findOne({
        attributes: [[Sequelize.fn("count", sequelize.col(`role_id`)), 'rolecount'],
        ],where:{
            status:true,system_user_id:req.systemUser.system_user_id
        }
    });
    if (typeof order_data == 'undefined') {
        var column_name = 'r.role_id';
        var column_sort_order = 'desc';
    }
    else {
        var column_index = req.query.order[0]['column'];
        var column_name = req.query.columns[column_index]['data'];
        var column_sort_order = req.query.order[0]['dir'];
    }

    var search_value = req.query.search['value'];
    var search_query = '';
    var where_query = '';

    if(req.query.role_name!=""){
      where_query=where_query+` and role_name=${req.query.role_name}`

    }
    if(req.query.role_id!=""){
      where_query=where_query+` and r.role_id=${req.query.role_id}`

    }
    if(req.query.status!=""){
      where_query=where_query+` and r.status=${req.query.status}`

    }

    if (search_value != "") {
        search_value = search_value.toLowerCase();
        search_query = ` and system_user_id=${req.systemUser.system_user_id}  and  (r.role_id::text = '${search_value}' OR LOWER(r.role_name)::text LIKE '%${search_value}%' OR r.status::text LIKE '%${search_value}%' )`;
    }
    const roledata = await sequelize.query(`select COUNT(r.role_id) AS Total from crbt_roles r where status = 'true' ${where_query} ${search_query}`);
    let query = `select r.role_id,role_name,status from crbt_roles r where status = 'true' ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
    const roleData = await sequelize.query(query);
    let data = [];
    if (roleData[0].length != 0) {
        for (i = 0; i < roleData[0].length; i++) {
            data.push({
                role_id: roleData[0][i].role_id,
                role_name: roleData[0][i].role_name,
                status: roleData[0][i].status,
                action: `<div> 
                <span class='a-edit' catid='${roleData[0][i].role_id}'><i class="bi bi-pencil-square"></i></span>
                <span class='a-view' catid='${roleData[0][i].role_id}'><i class="bi bi-eye-fill"></i></span>
                <span  class='a-delete' catid='${roleData[0][i].role_id}'><i class="bi bi-trash-fill"></i></span>
                </div>`,
            });
        }
    }
    var output = {
        'draw': draw,
        'iTotalRecords': role.dataValues.rolecount,
        'iTotalDisplayRecords': roledata[0][0].total,
        'aaData': data
    };
    return res.send(output);
} catch (error) {
    logger.createLog(__filename, error.message, req)
    var output = {
        'draw': draw,
        'iTotalRecords': 0,
        'iTotalDisplayRecords': 0,
        'aaData': []
    };
    return res.send(output);
}

};

let fetchRoles = async function (req, res, next) {
  try {  
      let roles = await db.crbt_roles.findAll({
        attributes: [ "role_id", "role_name"],
        order: [
          [db.crbt_roles.rawAttributes.role_id, "DESC"]
      ],
        where: {   
          // status: true,
          system_user_id: req.systemUser.system_user_id},
        order: [['role_id', 'DESC']],


    });
    if (roles.length !=0 ) {
        return res.status(200).send({ status: true, message: "Role retrieved successfully", roles });
    } else   {
        return res.status(400).send({ status: true, message: "Data not found", roles });
    }
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return logger.error(res, "Exception in Fetch Roles");
  }
};



module.exports = {
  fetchRoles,
  createRoles,
  updateRoles,
  roleDeactivate,
  viewRoles,
  deleteRoles,
  getRoleById,
  getRoleDataTable,
  getrolefetch

};
