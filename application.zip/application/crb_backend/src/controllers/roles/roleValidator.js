var db = require('../../models/index');
const logger = require('../../../utils/winston');

function detectNumeric(obj) {
  for (var index in obj) {
      if (/^\s*$/.test(obj[index])) {
          continue;
      }
      if (!isNaN(obj[index])) {
          obj[index] = Number(obj[index]);
      } else if (typeof obj[index] === "object") {
          detectNumeric(obj[index]);
      }
  }
}


const createRoleValidator = async function (req, res, next) {
  try {
    // await detectNumeric(req.body);
    req.body.role_name = req.body.role_name.trim();
    // req.body.role_id = req.body.role_id;
    if (typeof req.body.role_name === 'undefined') {
      return logger.error(res,"role name parameter is missing.");
    }
    // if (typeof req.body.role_id === 'undefined') {
    //   return logger.error(res, "role id parameter is missing.");
    // }
    // if (typeof req.body.role_id !== 'string') {
    //   return res.status(400).send({ status: false, message: "Invalid role_id. Please provide a string." });
    // }
    const existingRole = await db.crbt_roles.findOne({ 
      attributes: ["role_name"],

      where: { 
        role_name: req.body.role_name 
      } });
    if (existingRole) {
      return res.status(400).send({ status: false, message: 'role name already exists' });
    }
    // const existingRoleid = await db.crbt_roles.findOne({ 
    //   attributes: ["roleid"],
    //   where: { 
    //     roleid: req.body.role_id 
    //   } });
    // if (existingRoleid) {
    //   return res.status(400).send({ status: false, message: 'role id already exists' });
    // }
    if (/^\s*$/.test(req.body.role_name)) {
      return logger.error(res, "role name cannot be empty");
    }
    // if (/^\s*$/.test(req.body.role_id)) {
    //   return logger.error(res, "role id  cannot be empty");
    // }

    if (Number(req.body.role_name) ) {
      return logger.error(res, "Numbers are not allowed, please try using a string.");
    }
    if (req.body.role_name == ' ' || req.body.role_name == null || req.body.role_name == " ") {
      return logger.error(res, "role name cannot be empty ");
    }
    // if (req.body.role_id == ' ' || req.body.role_id == null || req.body.role_id == " ") {
    //   return logger.error(res, "role id  cannot be empty ");
    // }
    if (typeof req.body.status == 'undefined' ) {
      return logger.error(res, "Invalid Parameters status ");
    }
    let userdataEmail = await db.crbt_roles.findOne({
        attributes: ["role_name"],
        where: { role_name: req.body.role_name, system_user_id: req.systemUser.system_user_id }
    });
    if (userdataEmail) {
      return logger.error(res, "role name already exists");
    }   
      next();
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return res.status(500).send({ status: false, message: 'Exception in createRole' });
  }
}

const deleteRoleValidator = async function (req, res, next) {
  try {
    req.body.role_id = req.body.role_id.toString();
    if (typeof req.body.role_id === 'undefined') {
       return logger.error(res,"role id parameter is missing.");
    }
    if (req.body.role_id === null) {
       return logger.error(res, "role id parameter is missing.");
    }
    if (req.body.role_id == "") {
      return logger.error(res, 'role id cannot be empty.');
    }
    // if (typeof req.body.role_id !== 'string') {
    //   return res.status(400).send({ status: false, message: "Invalid role_id. Please provide a string." });
    // }
    // if (!Number.isInteger(req.body.roleid)) {
    //   return logger.error(res, "Invalid role id. It should be an integer.");
    // }
    const roleToDelete = await db.crbt_roles.findOne({
      where: { role_id: req.body.role_id }
    });
    if (!roleToDelete) {
      return res.status(404).send({ status: false, message: "Role not found" });
    }
    if (roleToDelete.system_user_id !== req.systemUser.system_user_id) {
      return res.status(403).send({ status: false, message: "Permission Denied" });
    }
    let roleDelete = await db.crbt_roles.findOne({
      attributes: ['role_id'],
      where: {  role_id: req.body.role_id.toString() },
    });
    if (!roleDelete) {
      return logger.error(res, "role with the given role id role name not found");
    }
    let roleData = await db.crbt_roles.findOne({
      attributes: ["role_id", "status"],
      where: {  role_id: req.body.role_id, status: false, system_user_id: req.systemUser.system_user_id }
    });
    if (roleData) {
       return logger.error(res, "role is already inactive");
    }
    const updatedRolesCount = await db.crbt_roles.update(
      { status: false },
      {
        where: {
          role_id: req.body.role_id,
          system_user_id: req.systemUser.system_user_id
        }
      }
    );
    if (updatedRolesCount[0] === 0) {
      return res.status(400).send({ status: false, message: "Role deletion failed" });
    }
    return res.status(200).send({ status: true, message: "Role deleted successfully" });
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return res.status(500).send({ status: false, message: "Exception in Roles delete" });
  }
};

const roleDeactivevalidator = async function(req, res, next) {
  try {
      console.log("res=======", req.body);
      // await detectNumeric(req.body);
      console.log(req.body);
      req.body.role_id = req.body.role_id.toString();

      if (typeof req.body.role_id == 'undefined') {
          return logger.error(res, "Role id parameter is missing");
      }
      if (req.body.role_id === null) {
          return logger.error(res, "Role id cannot be empty.");
      }
      // if (typeof req.body.role_id !== 'string') {
      //   return res.status(400).send({ status: false, message: "Invalid role_id. Please provide a string." });
      // }
      if (/^\s*$/.test(req.body.role_id)) {
          return logger.error(res, "Role id cannot be empty");
      }
      // if (!Number.isInteger(req.body.role_id)) {
      //     return logger.error(res, "Invalid role_id");
      // }
      let roleEdit = await db.crbt_roles.findOne({
          attributes: ['role_id'],
          where: { role_id: req.body.role_id },
      })
      if (!roleEdit) {
          return logger.error(res, "Role with the given role_id not found");
      }
      const roleUpdate = await db.crbt_roles.findOne({
        attributes: ['role_id', 'status'],
        where: { role_id: req.body.role_id },
    });
    if (!roleUpdate) {
        return logger.error(res, "role is inactive");
    }
    next();
  } 
  catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in Role Action");
  }
}

const viewRoleValidator = async function (req, res, next) {
    try {
    // if (req.body.role_id == ' ' || req.body.role_id == null || req.body.role_id == " ") {
    // return logger.error(res, "role id cannot be empty ");
    // }
    // if (typeof req.body.role_id !== 'number') {
    // return logger.error(res, "Invalid data type for role id. Only number are allowed.");
    // }
    let roleData = await db.crbt_role.findOne({
    attributes: ["role_id"],
    where: {role_id: req.body.role_id.toString() }
    });
    if (!roleData) {
    return logger.error(res, "role with the given role id not found");
    }
    next(); 
    } 
    catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in role get");}
}
    
let updateRoleValidator = async function(req, res, next) {
      try {
          console.log("res====", req.body);
  
          if (typeof req.body.role_name == 'undefined') {
              return logger.error(res, "Role name parameter is missing");
          }
          // if (typeof req.body.role_id == 'undefined') {
          //     return logger.error(res, "role id parameter is missing");
          // }
          req.body.role_id = req.body.role_id.toString();
          if (typeof req.body.status == 'undefined') {
            return logger.error(res, "status parameter is missing");
        }
          // if (req.body.role_id == ' ' || req.body.role_id == null || req.body.role_id == " ") {
          //     return logger.error(res, "role id cannot be empty ");
          // }
          if (req.body.role_name == ' ' || req.body.role_name == null || req.body.role_name == " ") {
              return logger.error(res, "role name cannot be empty ");
          }
          const role_name = req.body.role_name;
          if (role_name && role_name.length > 255) {
              return res.status(400).send({ status: false, message: 'role name exceeds maximum length of 255 characters' });
          }
        //  let userdataEmail = await db.crbt_roles.findOne({
        //     attributes: ["role_name"],
        //     where: { role_name: req.body.role_name, system_user_id: req.systemUser.system_user_id }
        // });
        // if (userdataEmail) {
        //   return logger.error(res, "role name already exists");
        // }   
          // if (typeof req.body.role_id !== 'number') {
          //     return logger.error(res, "Invalid role id");
          // }
          if (typeof req.body.role_name !== 'string') {
              return logger.error(res, "Invalid role name");
          }
          const existingRole = await db.crbt_roles.findOne({
            where: {
              role_name: req.body.role_name.trim(),
              system_user_id: req.systemUser.system_user_id
            }
          });
          let roleUpdateee = await db.crbt_roles.findOne({
              attributes: ['role_id'],
              where: { role_id: req.body.role_id.toString()},
          });
          if (!roleUpdateee) {
              return logger.error(res, "role with the given role id role name not found");
          }
          next();
      } 
      catch (error) {
          logger.createLog(__filename, error.message, req);
          return logger.error(res, "Exception in role update");
      }
  }

  let getRoleByIdValidator = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        // req.body.role_id = req.body.role_id.toString();
        // if (typeof req.query.role_id=='undefined') {
        //     return logger.error(res,"Parameter Missing");
        // }
        // if (/^\s*$/.test(req.query.role_id)) {
        //     return logger.error(res, "role id cannot be empty");
        // } 
        // if (!Number(req.query.role_id)) {
        //     return logger.error(res, "Invalid input role id cannot be String");
        // }
        let roleget = await db.crbt_roles.findOne({
            attributes: ['role_id'],
            where: { role_id: req.query.role_id.toString() },
        });
        if (!roleget) {
            return logger.error(res, "role id  not found");
        }

        next();
    } 
    catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in retrieving Role.");
    }
};


const getrolefetchValidator = async function(req, res, next) {
  try {
      console.log("res==============", req.query);
      await detectNumeric(req.query);
      console.log(req.query);
      if (req.query.role_name && typeof req.query.role_name !== 'string') {
          return logger.error(res, "Invalid Department Name");
      }
      next();
  } 
  catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in Role Fetching");
  }
}

module.exports = {
  createRoleValidator,
  viewRoleValidator,
  updateRoleValidator,
  deleteRoleValidator,
  roleDeactivevalidator,
  getRoleByIdValidator,
  getrolefetchValidator
};

