var db = require('../../models/index')
const logger = require('../../../utils/winston')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}
const createFloor = async function (req, res, next) {
    try { 
    // detectNumeric(req.body);
    // req.body.floor_id = req.body.floor_id.toString()
    if (typeof req.body.floor_id == 'undefined') {
        return logger.error(res, 'Floor ID parameter is missing');
    }
    if (/^\s*$/.test(req.body.floor_id)) {
        return logger.error(res, "FLoor ID cannot be empty");
    }
    if (typeof req.body.building_id == 'undefined') {
        return logger.error(res, 'Build ID parameter are missing');
    }
    if (typeof req.body.floor_name == 'undefined') {
        return logger.error(res, 'FLoor Name parameter are missing');
    }
    if (/^\s*$/.test(req.body.building_id)) {
        return logger.error(res, "Building ID cannot be empty");
    }
    if ((req.body.floor_name == "")) {
        return logger.error(res, "Floor Name cannot be empty");
    }
    // if (typeof req.body.building_id !== "number") {
    //     return logger.error(res, 'Invalid Building ID ');
    // }
    let flooridCheck = await db.crbt_floors.findOne({
        attributes: ["floorid"],
        where: { floorid: req.body.floor_id, system_user_id: req.systemUser.system_user_id }
    });
    if (flooridCheck) {
        return logger.error(res, "Floor ID already exists");
    }
    const buildingExists = await db.crbt_buildings.findOne({
        attributes: ["location_id", "system_user_id"],
        where: {
            "system_user_id": req.systemUser.system_user_id,
            "building_id": req.body.building_id
        }
    })
    if (buildingExists == null) {
        return logger.error(res, "Building ID does not exists.");
    }
    let FloorData = await db.crbt_floors.findOne({
        attributes: ["floorid", "building_id", "floor_name"],
        where: {
            system_user_id: req.systemUser.system_user_id,
            floor_name: req.body.floor_name.trim(),
            building_id: req.body.building_id,
            floorid: req.body.floor_id.toString(),
        }
    });
    if (FloorData) {
        // if (FloorData.floor_name === req.body.floor_name.trim()) {
        return logger.error(res, "Floor name already exists");
        // }
    }
    let buildingData = await db.crbt_buildings.findOne({
        attributes: ["buildingid", "system_user_id", "status", "location_id"],
        where: {
            system_user_id: req.systemUser.system_user_id,
            building_id: req.body.building_id
        }
    });
    if (buildingData != null) {
        if (buildingData.status === false) {
            return logger.error(res, "Building ID is in Inactive active.");
        }
        let locationData = await db.crbt_locations.findOne({
            attributes: ["location_id", "system_user_id", "status"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                location_id: String(buildingData.location_id)
            }
        });
        if (locationData != null) {
            if (locationData.status === false) {
                return logger.error(res, "Location ID is in Inactive active.");
            }
        }
    }
    if (buildingData == null) {
        return logger.error(res, "Building ID does not exist.");
    }
    next();
    } catch (error) {
        console.log('Create Floor errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in  Create Floor validation");
    }
}
const updateFloor = async function (req, res, next) {
    try {
        // await detectNumeric(req.body.building_id);
        req.body.floor_id = req.body.floor_id.toString()
        const building_id = parseInt(req.body.building_id);
        if (typeof req.body.floor_id == 'undefined') {
            return logger.error(res, 'Floor ID parameter is missing');
        }
        if (typeof req.body.building_id == 'undefined') {
            return logger.error(res, 'Building ID parameter is missing');
        }
        if (/^\s*$/.test(req.body.floor_id)) {
            return logger.error(res, "FLoor ID cannot be empty");
        }
        if (/^\s*$/.test(req.body.building_id)) {
            return logger.error(res, "Building ID cannot be empty");
        }
        if (typeof building_id !== "number") {
            return logger.error(res, 'Invalid Building ID ');
        }
        // if (typeof req.body.floor_id !== "number") {
        //     return logger.error(res, 'Invalid Floor ID ');
        // }
        let FloorData = await db.crbt_floors.findOne({
            attributes: ["floorid", "system_user_id", "building_id", "floor_name"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.body.floor_id.toString()
            }
        });
        let Floor_Data = await db.crbt_floors.findOne({
            attributes: ["floorid"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.body.floor_id.toString()
            }
        });
        if (!Floor_Data) {
            return logger.error(res, "Floor Number does not exists");
        }

        
        const buildingExists = await db.crbt_buildings.findOne({
            attributes: ["location_id", "system_user_id", "status"],
            where: {
                "system_user_id": req.systemUser.system_user_id,
                "building_id": req.body.building_id
            }
        })
        if (!buildingExists) {
            return logger.error(res, "Building ID does not exists.");
        } 
        if (buildingExists.status === false) {
            return logger.error(res, "Building ID is in Inactive please active.");
        }
        let locationData = await db.crbt_locations.findOne({
            attributes: ["locationid", "system_user_id", "status"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                location_id: buildingExists.location_id
            }
        });
        if (locationData.status === false) {
            return logger.error(res, "Location ID is in Inactive please active.");
        }
        if (FloorData == "") {
            return logger.error(res, "Floor ID not exists");
        }
        if (FloorData && (FloorData.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }

        next();
    } catch (error) {
        console.log('Update Floor validation errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res,error.message);
    }
}
const getFloorByID = async function (req, res, next) {
    // try {
        // detectNumeric(req.query);
        // req.body.floor_id = req.body.floor_id.toString()
        if (typeof req.query.floor_id == 'undefined') {
            return logger.error(res, 'Floor ID parameter is missing');
        }
        if (/^\s*$/.test(req.query.floor_id)) {
            return logger.error(res, "FLoor ID cannot be empty");
        }
        // if (typeof req.query.floor_id !== "number") {
        //     return logger.error(res, 'Invalid Floor ID ');
        // }
        let FloorDataUpdate = await db.crbt_floors.findOne({
            attributes: ["system_user_id"],
            where: {
                floorid: req.query.floor_id
            }
        });
        let FloorDataUpdateStatus = await db.crbt_floors.findOne({
            attributes: ["floorid"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.query.floor_id,
                status: false
            }
        });
        if (FloorDataUpdate && (FloorDataUpdate.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }
        next();
    // } catch (error) {
    //     console.log('getFloorByID errror', error)
    //     logger.createLog(__filename, error.message, req)
    //     return logger.error(res, "Exception in getFloorByID validation");
    // }
}
const deleteFloor = async function (req, res, next) {
    try {
        // detectNumeric(req.body);
        req.body.floor_id = req.body.floor_id.toString()
        const building_id = parseInt(req.body.building_id);
        if (typeof req.body.floor_id == 'undefined') {
            return logger.error(res, 'Floor ID parameter is missing');
        }
        if (typeof req.body.building_id == 'undefined') {
            return logger.error(res, 'Building ID parameter is missing');
        }
        if (/^\s*$/.test(req.body.floor_id)) {
            return logger.error(res, "FLoor ID cannot be empty");
        }
        if (/^\s*$/.test(building_id)) {
            return logger.error(res, "Building ID cannot be empty");
        }
        // if (typeof req.body.floor_id !== "number") {
        //     return logger.error(res, 'Invalid Floor ID ');
        // }
        if (typeof building_id !== "number") {
            return logger.error(res, 'Invalid Building ID ');
        }
        let FloorData = await db.crbt_floors.findOne({
            attributes: ["floorid", "building_id"],
            where: {
                floorid: String(req.body.floor_id),
                system_user_id: req.systemUser.system_user_id,
                building_id: req.body.building_id
            }
        });
        let FloorDataUpdate = await db.crbt_floors.findOne({
            attributes: ["system_user_id"],
            where: {
                floorid: req.body.floor_id,
                building_id: req.body.building_id
            }
        });
        let FloorDataUpdateStatus = await db.crbt_floors.findOne({
            attributes: ["floorid"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.body.floor_id,
                building_id: req.body.building_id,
                status: false
            }
        });
        if (FloorDataUpdateStatus) {
            return logger.error(res, "Floor ID is Inactive");
        }
        if (FloorDataUpdate && (FloorDataUpdate.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }
        if (FloorData == null) {
            return logger.error(res, "Floor ID and Building ID Combination does not exists");
        }
        next();
    } catch (error) {
        console.log('getFloorByID errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in getFloorByID validation");
    }
}
const getFloor = async function (req, res, next) {
    try {
        // detectNumeric(req.query);
        // if (typeof req.query.floor_id !== "number") {
        //     return logger.error(res, 'Invalid Floor ID ');
        // }
        req.body.floor_id = req.body.floor_id.toString()
        if (typeof req.query.location_name !== "string") {
            return logger.error(res, 'Invalid Location Name ');
        }
        if (typeof req.query.building_name !== "string") {
            return logger.error(res, 'Invalid Building Name');
        }
        let FloorDataUpdate = await db.crbt_floors.findOne({
            attributes: ["system_user_id"],
            where: {
                floor_id: req.query.floor_id
            }
        });
        let FloorDataUpdateStatus = await db.crbt_floors.findOne({
            attributes: ["floorid"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.query.floor_id,
                status: false
            }
        });
        if (FloorDataUpdate && (FloorDataUpdate.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }
        next();
    } catch (error) {
        console.log('getFloorByID errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in getFloorByID validation");
    }
}
const actionFloor = async function (req, res, next) {
    try {
        // detectNumeric(req.body);
        req.body.floor_id = req.body.floor_id.toString()
        if (typeof req.body.floor_id == 'undefined') {
            return logger.error(res, 'Floor ID parameter is missing');
        }
        if (/^\s*$/.test(req.body.floor_id)) {
            return logger.error(res, "FLoor ID cannot be empty");
        }
        // if (typeof req.body.floor_id !== "number") {
        //     return logger.error(res, 'Invalid Floor ID ');
        // }
        if (req.body.status == null) {
            return logger.error(res, 'Status parameter is null');
        }
        let FloorData = await db.crbt_floors.findOne({
            attributes: ["floorid", "system_user_id"],
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.body.floor_id
            }
        });
        if (FloorData == null) {
            return logger.error(res, "Floor ID not exists");
        }
        if (FloorData && (FloorData.system_user_id !== req.systemUser.system_user_id)) {
            return logger.error(res, "Perimission Denied");
        }

        next();
    } catch (error) {
        console.log('Update Floor validation errror', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update Floor validation");
    }
}

module.exports = {
    createFloor,
    updateFloor,
    getFloorByID,
    deleteFloor,
    getFloor,
    actionFloor
}