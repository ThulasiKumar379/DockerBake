const { Sequelize, Op } = require("sequelize");
var db = require('../../models/index')
var logger = require('../../../utils/winston')
var { sequelize } = require('../../models/index')

let createFloor = async function(req, res, next) {
    try {
        let insertdata = {
            floorid: req.body.floor_id.toString(),
            building_id: req.body.building_id,
            floor_name: req.body.floor_name.trim(),
            system_user_id: req.systemUser.system_user_id,
            created_by: req.systemUser.system_user_id
        }
        if (req.body.status) {
            insertdata.status = req.body.status
        } 
        const buildingExists = await db.crbt_buildings.findOne({
            attributes: ["location_id", "system_user_id"],
            where: {
                "system_user_id": req.systemUser.system_user_id,
                "building_id": req.body.building_id
            },
            raw: true
        })
        if (buildingExists) {
            insertdata.location_id = buildingExists.location_id
        }
        await db.crbt_floors.create(insertdata).then(async function(users) {
            if (users) {
                console.log('data inserted')
            } else {
                return logger.error(res, "Error in create floor");
            }
        });
        let floorData = await db.crbt_floors.findOne({
            attributes: [
                ["floorid", "floor_id"], "building_id", "floor_name", "location_id", "created_by", "updated_by", "created_at", "updated_at", "status"
            ],
            where: {
                "floor_name": req.body.floor_name.trim(),
                "location_id": req.body.location_id,
                "building_id": req.body.building_id,
                "system_user_id": req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_locations,
                as: "crbt_locations",
                attributes: [
                    ['locationid', 'location_id'], 'location_name'
                ],
                required: false
            }]
        })
        return logger.success(res, "Floor created successfully", floorData);
    } catch (error) {
    console.log(error)
    logger.createLog(__filename, error.message, req)
    return logger.error(res, "Exception in creation of FLoor", error);
    }
}

let updateFloor = async function(req, res, next) {
    try {
        let query = {
            updated_by: req.systemUser.system_user_id,
            updated_at: Date.now()
        }; 
        query.floor_name = req.body?.floor_name?.trim();
        query.buildingid = req.body.building_id;
        query.location_id =req.body.location_id;    
        if (req.body.status=='Active') {
            query.status = true;
        }else if (req.body.status=='Inctive'){
            query.status = false;
        }else{
            query.status = req.body.status;
        } 
        await db.crbt_floors.update(query, {
            where: {
                system_user_id: req.systemUser.system_user_id,
                floorid: req.body.floor_id.toString()
            },
        }); 
        let floorData = await db.crbt_floors.findOne({
            attributes: ["floorid", "status", "building_id", "floor_name", "location_id", "updated_by", "updated_at"],
            where: {
                floorid: req.body.floor_id.toString(),
                system_user_id: req.systemUser.system_user_id
            }
        });

        return logger.success(res, "Floor status updated successfully", floorData);
    } catch (error) {
    logger.createLog(__filename, error.message, req)
        return logger.error(res,  error.message);
    }
}

let getFloor = async function(req, res, next) {
    try {
        let query2 = '';
        if (req.query.building_name && req.query.building_name != "") {
            query2 += ` and lower(floor_name) like '${req.query.floor_name.toLowerCase()}%'`
        };
        if (req.query.location_name && req.query.location_name != "") {
            query2 += ` and lower(floor_name) like '${req.query.floor_name.toLowerCase()}%'`
        };
        if (req.query.floor_name && req.query.floor_name != "") {
            query2 += ` and lower(floor_name) like '${req.query.floor_name.toLowerCase()}%'`
        };
        if (req.query.location_id && req.query.location_id != "") {
            query2 += ` and crbt_locations.location_id in (${req.query.location_id })`  
        };
        if (req.query.building_id && req.query.building_id != "") {
            query2 += ` and crbt_floors.building_id in (${req.query.building_id })`  
        };
        if (req.query.floor_id) {
            query2 += ` and floorid = ${req.query.floor_id}`
        }  
        const [results] = await sequelize.query(
            `SELECT floorid AS floor_id,floor_name,crbt_floors.building_id,
            crbt_floors.system_user_id,crbt_floors.created_by,
            crbt_floors.updated_by,crbt_floors.created_at,crbt_floors.updated_at,crbt_floors.status,crbt_buildings.buildingid 
            AS ubuilding_id,crbt_buildings.building_name,crbt_locations.locationid AS ulocation_id,
            crbt_locations.location_id,
            crbt_locations.location_name FROM crbt_floors JOIN crbt_buildings 
                        ON crbt_floors.building_id = crbt_buildings.building_id
                        JOIN crbt_locations
                        ON crbt_floors.location_id=crbt_locations.location_id
                        where 
            crbt_floors.system_user_id=${req.systemUser.system_user_id} ${query2}
            order by floorid desc`
        );
        if (results.length == 0) {
            return logger.success(res, "No record found !!!",results)
        }
        return logger.success(res, "Floor Details retrived successfully", results)
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Floor Details");
    }
}

let deleteFloor = async function(req, res, next) {
    try {
        let query = {
            status: false
        }
        let deletedFloor = await db.crbt_floors.update(
            query, {
                where: {
                    system_user_id: req.systemUser.system_user_id,
                    building_id: req.body.building_id,
                    floorid: req.body.floor_id.toString()
                },
            }
        )
        return logger.success(res, "Floor Deleted");

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in delete Floor");
    }
}
let getFloorByID = async function(req, res, next) {
    try {

        let designationDataById = await db.crbt_floors.findAll({
            attributes: [
                ["floorid", "floor_id"], "building_id", "floor_name", "location_id", "created_by", "updated_by", "created_at", "updated_at", "status"
            ],
            where: {
                "floorid": req.query.floor_id.toString(),
                system_user_id: req.systemUser.system_user_id
            },
            include: [{
                model: db.crbt_locations,
                as: "crbt_locations",
                attributes: [
                    ['locationid', 'location_id'], 'location_name'
                ],
                required: false
            }]
        })
        return logger.success(res, "Floor Details retrived successfully", designationDataById)
    } catch (error) {
    logger.createLog(__filename, error.message, req)
    return logger.error(res, "Exception in get Floor List");
    }
}
let getFloorsDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        let floor = await db.crbt_floors.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`floor_id`)), 'floorCount'],
            ]
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.floor_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        var where_query = '';
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and  (d.floor_id = '${search_value}' OR d.building_id LIKE '%${search_value}%' OR  d.status::text LIKE '%${search_value}%' )`;
        }
        if (req.query.floor_id) {
            where_query = where_query + ` and d.floor_id=${req.query.floor_id}`
        }
        if (req.query.building_id) {
            where_query = where_query + ` and d.building_id=${req.query.building_id}`
        }
        if (req.query.floor_name) {
            where_query = where_query + ` and d.floor_name=${req.query.floor_name}`
        }
        if (req.query.location_id) {
            where_query = where_query + ` and d.location_id=${req.query.location_id}`
        }
        const degsearchdata = await sequelize.query(`select COUNT(d.floor_id) AS Total from crbt_floors d where status = 'true' ${where_query} ${search_query}`);
        let query = `select d.floor_id,d.building_id,d.floor_name,d.location_id,d.status from crbt_floors d where status = 'true'  ${where_query} ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const degData = await sequelize.query(query);
        let data = [];
        if (degData[0].length != 0) {
            for (i = 0; i < degData[0].length; i++) {
                data.push({
                    floor_id: degData[0][i].floor_id,
                    building_id: degData[0][i].building_id,
                    floor_name: degData[0][i].floor_name,
                    location_id: degData[0][i].location_id,
                    status: degData[0][i].status,
                    action: `<div>
                    <span class='a-edit' catid='${degData[0][i].floor_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${degData[0][i].floor_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${degData[0][i].floor_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': floor.dataValues.floorCount,
            'iTotalDisplayRecords': degsearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}
let fetchFloors = async function(req, res, next) {
    try {
        let whereCondition = {
            status: true,
            system_user_id: req.systemUser.system_user_id
        }
        if (req.query.building_id != undefined) {
            if (req.query.building_id != "") {
                whereCondition.building_id = {
                    [Op.in]: req.query.building_id.split(",")
                }
            }
        }
        let floorsData = await db.crbt_floors.findAll({
            attributes: [
               "floor_id",["floorid", "ufloor_id"], "floor_name", "building_id"
            ],
            order: [
                [db.crbt_floors.rawAttributes.floorid, "DESC"]
            ],
            where: whereCondition
        })

        if (floorsData.length == 0) {
            return res.status(200).send({
                status: false,
                message: "Data not found",
                floorsData
            });
        } else {
            return res.status(200).send({
                status: true,
                message: "Floors retrived successfully",
                floorsData
            });
        }

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Fetch Floors");
    }
}
let actionFloor = async function(req, res, next) {
    try {
        let query = {
            updated_by: req.systemUser.system_user_id,
            updated_at: Date.now()
        }
        if (req.body.status) {
            query.status = req.body.status
        }
        if (req.body.status == 1 || req.body.status == true) {
            query.status = true
        }
        if (req.body.status == 0 || req.body.status == false) {
            query.status = false
        }
        let designationUpdate = await db.crbt_floors.update(
            query, {
                where: {
                    system_user_id: req.systemUser.system_user_id,
                    floorid: req.body.floor_id.toString()
                },
            }
        )
        let floorData = await db.crbt_floors.findOne({
            attributes: [
                ["floorid", "floor_id"], "status", "building_id", "floor_name", "location_id", "updated_by", "updated_at"
            ],
            where: {
                "floorid": req.body.floor_id.toString(),
                "system_user_id": req.systemUser.system_user_id
            }
        })
        return logger.success(res, "Floor status updated successfully", floorData);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update Floor");
    }
}
module.exports = {
    createFloor,
    updateFloor,
    getFloor,
    deleteFloor,
    getFloorByID,
    getFloorsDataTable,
    fetchFloors,
    actionFloor
}