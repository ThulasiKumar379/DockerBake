var db = require('../../models/index')
const logger = require('../../../utils/winston')
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");

let createPlan = async function(req, res, next) {
    try {
        console.log('res=================================', req.body)
        req.body.plan_name = req.body.plan_name.trim();
        let insertdata = {
            plan_name: req.body.plan_name,
            description: req.body.description,
            price: req.body.price,
            status: true,
            tenure: req.body.tenure,
            created_by: req.systemUser.system_user_id
        }
        return await db.crbm_subscription_plans.create(insertdata).then(function(data) {
            if (data) {
                return res.status(200).send({ status: true, message: "New Signup subscriptiondata inserted", data });
            } else {
                return logger.error(res, "Error in subscription==========");
            }
        });

    } catch (error) {
        console.log('error------------------', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in insert new subscription***********");
    }
}

let editPlan = async function(req, res, next) {
    try {
        let subData = await db.crbm_subscription_plans.findOne({
            where: { plan_id: req.body.plan_id }
        })
        req.body.plan_name = req.body.plan_name.trim();
        let updatebscriptionFeature = await db.crbm_subscription_plans.update({
            plan_name: req.body.plan_name,
            description: req.body.description,
            price: req.body.price,
            status: req.body.status,
            tenure: req.body.tenure,
            updated_by: req.systemUser.system_user_id
        }, {
            where: {
                plan_id: req.body.plan_id,
                created_by: req.systemUser.system_user_id
            },
        })
        if (subData.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", updatebscriptionFeature });
        } else if (subData.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "subscriptionPlan updated successfully", updatebscriptionFeature });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subscriptionplan update");
    }
}
let deletePlan = async function(req, res, next) {
    try {
        let subDelete = await db.crbm_subscription_plans.findOne({
            where: { plan_id: req.body.plan_id }

        })
        const subsFeatures = await db.crbm_subscription_plans.update({
            status: false

        }, {
            where: {
                plan_id: req.body.plan_id,
                created_by: req.systemUser.system_user_id
            },
        });
        if (subDelete.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", subsFeatures });
        } else if (subDelete.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "subscriptionplan deleted successfully", subsFeatures });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subscriptionfeatures delete");
    }

}
let getPlanList = async function(req, res, next) {
    try {
        let subscriptionplandata = await db.crbm_subscription_plans.findAll({
            attributes: ["plan_id", "plan_name"],
            order: [
                ['plan_id', "ASC"]
            ],
            where: {
                status: true,
                created_by: req.systemUser.system_user_id
            }
        })
        if (subscriptionplandata.length === 0) {
            return res.status(400).send({ status: false, message: "subscriptionplan not available", subscriptionplandata });
        } else {
            return res.status(200).send({ status: true, message: "subscriptionplan retrived successfully", subscriptionplandata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subscriptionplans");
    }
}
let getSubcriptionPlanList = async function(req, res, next) {
    try {
        let subscriptionplandata = await db.crbm_subscription_plans.findAll({
            attributes: ["plan_id", "plan_name", "description", "price", "tenure", "status"],
            order: [
                ['plan_id', "ASC"]
            ],
            where: {
                status: true,
                created_by: req.systemUser.system_user_id
            }
        })
        if (subscriptionplandata.length === 0) {
            return res.status(400).send({ status: false, message: "subscriptionplan not available", subscriptionplandata });
        } else {
            return res.status(200).send({ status: true, message: "subscriptionplan retrived successfully", subscriptionplandata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subscriptionplans");
    }
}
let getsubscription = async function(req, res, next) {
    try {
        let subGetData = await db.crbm_subscription_plans.findOne({
            where: { plan_id: req.query.plan_id }
        })
        let subscriptionplansDataa = await db.crbm_subscription_plans.findOne({
            attributes: ["plan_id", "plan_name"],
            order: [
                ['plan_id', "ASC"]
            ],
            where: {
                plan_id: req.query.plan_id,
                status: true,
                created_by: req.systemUser.system_user_id
            }
        })
        if (subGetData.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied", subscriptionplansDataa });
        } else if (subGetData.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "subscriptionplans retrived successfully", subscriptionplansDataa });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subscriptionplans");
    }
}
let getSubcriptionDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        let planTotal = await db.crbm_subscription_plans.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`plan_id`)), 'planCount'],
            ],
            where: {
                status: true
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'p.plan_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }

        var search_value = req.query.search['value'];
        var search_query = '';
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = `  and  (p.plan_id::text = '${search_value}' OR LOWER(p.plan_name)::text LIKE '%${search_value}%' OR p.tenure::text LIKE '%${search_value}%' OR p.price::text LIKE '%${search_value}%' OR p.status::text LIKE '%${search_value}%' )`;
        }
        const planSearchdata = await sequelize.query(`select COUNT(p.plan_id) AS Total from crbm_subscription_plans p where status = 'true' ${search_query}`);
        let query = `select  p.plan_id,p.plan_name,p.tenure,p.price,p.status from crbm_subscription_plans p where status = 'true' ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const spData = await sequelize.query(query);
        let data = [];
        if (spData[0].length != 0) {
            for (i = 0; i < spData[0].length; i++) {
                data.push({
                    plan_id: spData[0][i].plan_id,
                    plan_name: spData[0][i].plan_name,
                    tenure: spData[0][i].tenure,
                    price: spData[0][i].price,
                    status: spData[0][i].status,
                    action: `<div> 
                    <span class='a-edit' catid='${spData[0][i].plan_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${spData[0][i].plan_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${spData[0][i].plan_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': planTotal.dataValues.planCount,
            'iTotalDisplayRecords': planSearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}

module.exports = {
    createPlan,
    editPlan,
    deletePlan,
    getPlanList,
    getsubscription,
    getSubcriptionPlanList,
    getSubcriptionDataTable
};