var db = require('../../models/index')
const logger = require('../../../utils/winston')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (typeof obj[index] === "boolean") {
            // Skip boolean values
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}

function validateDecimal(value) {
    const decimalRegex = /^\d{1,8}(\.\d{1,2})?$/; // Matches up to 8 digits before the decimal point and up to 2 digits after the decimal point
    return decimalRegex.test(value);
}

const createPlan = async function(req, res, next) {
    try {
        console.log("res==============", req.body);
        await detectNumeric(req.body);
        req.body.plan_name = req.body.plan_name.trim();
        console.log(req.body);
        if (typeof req.body.plan_name == 'undefined' || typeof req.body.description == 'undefined' || typeof req.body.price == 'undefined' || typeof req.body.tenure == 'undefined') {
            return logger.error(res, "Invalid Parameters");
        }
        if (typeof req.body.plan_name !== 'string' || !/^[a-zA-Z\s]+$/.test(req.body.plan_name)) {
            return logger.error(res, "Invalid data type for plan_name. Only characters are allowed.");
        }
        if (typeof req.body.description !== 'string') {
            return logger.error(res, "Invalid data type for description. It should be a string.");
        }
        if (!validateDecimal(req.body.price)) {
            return logger.error(res, "Invalid price");
        }
        if (req.body.plan_name == null) {
            return logger.error(res, "plan name cannot be empty ");
        }
        if (/^\s*$/.test(req.body.plan_name)) {
            return logger.error(res, "Plan name name cannot be empty");
        }
        if (/^\s*$/.test(req.body.description)) {
            return logger.error(res, "Description cannot be empty");
        }
        if (/^\s*$/.test(req.body.price)) {
            return logger.error(res, "Price cannot be empty");
        }
        if (/^\s*$/.test(req.body.tenure)) {
            return logger.error(res, "Tenure cannot be empty");
        }
        const plan_name = req.body.plan_name;
        if (plan_name && plan_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Plan name exceeds maximum length of 255 characters' });
        }

        let userdataEmail = await db.crbm_subscription_plans.findOne({
            attributes: ["plan_name", "created_by"],
            where: { plan_name: req.body.plan_name, created_by: req.systemUser.system_user_id }
        });
        if (userdataEmail) {
            return logger.error(res, "plan_name already exists");
        }
        // if (userdataEmail != null) {
        //     if (userdataEmail.plan_name === req.body.plan_name) {
        //         return logger.error(res, "plan_name already exists");
        //     }
        // }
        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subcription Plan create");
    }
}

const deletePlan = async function(req, res, next) {
    try {

        console.log("res=======", req.body);
        await detectNumeric(req.body);
        req.body.plan_name = req.body.plan_name.trim();
        if (typeof req.body.plan_id == 'undefined') {
            return logger.error(res, "Plan id parameter is missing");
        }
        if (req.body.plan_id === null) {
            return logger.error(res, "plan_id parameter is missing.");
        }
        if (!Number.isInteger(req.body.plan_id)) {
            return logger.error(res, "Invalid plan_id");
        }
        if (/^\s*$/.test(req.body.plan_id)) {
            return logger.error(res, "Plan id cannot be empty");
        }
        let planData = await db.crbm_subscription_plans.findOne({
            attributes: ["plan_id", "status"],
            where: { plan_id: req.body.plan_id }
        })
        let planEdit = await db.crbm_subscription_plans.findOne({
            attributes: ['plan_id'],
            where: { plan_id: req.body.plan_id },
        });

        if (!planEdit) {
            return logger.error(res, "Plan with the given plan_id not found");
        }
        if (planData.status === false && planData.created_by === req.systemUser.system_user_id) {
            return logger.error(res, "plan_id already inactive.");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in plan delete");
    }
}

let editPlan = async function(req, res, next) {
    try {
        console.log("res====", req.body);
        // if (typeof req.body.plan_name == 'undefined') {
        //     return logger.error(res, "Subscription name parameter is missing");
        // }
        await detectNumeric(req.body);
        console.log(req.body);
        if (typeof req.body.plan_id == 'undefined' || typeof req.body.plan_name == 'undefined' || typeof req.body.description == 'undefined' || typeof req.body.price == 'undefined' ||
            typeof req.body.status == 'undefined' || typeof req.body.tenure == 'undefined'
        ) {
            return logger.error(res, "Subscription parameter is missing");
        }
        if (req.body.plan_id == null) {
            return logger.error(res, "Subscription plan name id cannot be empty ");
        }
        if (/^\s*$/.test(req.body.plan_id)) {
            return logger.error(res, "Plan id cannot be empty");
        }
        if (/^\s*$/.test(req.body.plan_name)) {
            return logger.error(res, "Plan name name cannot be empty");
        }
        if (/^\s*$/.test(req.body.description)) {
            return logger.error(res, "Description cannot be empty");
        }
        if (/^\s*$/.test(req.body.price)) {
            return logger.error(res, "Price cannot be empty");
        }
        if (/^\s*$/.test(req.body.tenure)) {
            return logger.error(res, "Tenure cannot be empty");
        }
        if (typeof req.body.plan_id !== 'number') {
            return logger.error(res, "Invalid Subscription id");
        }
        if (!validateDecimal(req.body.price)) {
            return logger.error(res, "Invalid price");
        }
        if (req.body.plan_name && typeof req.body.plan_name !== 'string') {
            return logger.error(res, "Invalid Subscription name");
        }
        if (req.body.description && typeof req.body.description !== 'string') {
            return logger.error(res, "Invalid Subscription description");
        }
        const plan_name = req.body.plan_name;
        if (plan_name && plan_name.length > 255) {
            return res.status(400).send({ status: false, message: 'Plan name exceeds maximum length of 255 characters' });
        }
        if (typeof req.body.status !== 'boolean') {
            return logger.error(res, "Invalid Subscription status");
        }
        if (typeof req.body.tenure !== 'number') {
            return logger.error(res, "Invalid Subscription tenure");
        }
        let SubscriptionEdittt = await db.crbm_subscription_plans.findOne({
            attributes: ['plan_id'],
            where: { plan_id: req.body.plan_id },
        });
        if (!SubscriptionEdittt) {
            return logger.error(res, "Subscription is doesnt exits");
        }
        let SubscriptionEdit = await db.crbm_subscription_plans.findOne({
            attributes: ['plan_id'],
            where: { plan_id: req.body.plan_id },
        });
        if (!SubscriptionEdit) {
            return logger.error(res, "Subscription with the given plan_id not found");
        }


        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Subscription update");
    }
}

const getPlan = async function(req, res, next) {
    try {
        console.log("res==============", req.query);
        await detectNumeric(req.body);
        if (typeof req.query.plan_id == 'undefined') {
            return logger.error(res, "Plan id parameter is missing");
        }
        if (req.query.plan_id == null) {
            return logger.error(res, "Plan id cannot be empty ");
        }
        if (isNaN(req.query.plan_id)) {
            return logger.error(res, "Invalid data type for department_id. Only number are allowed.");
        }
        if (/^\s*$/.test(req.query.plan_id)) {
            return logger.error(res, "Plan id cannot be empty");
        }
        let subcriptionData = await db.crbm_subscription_plans.findOne({
            attributes: ["plan_id", "status"],
            where: { plan_id: req.query.plan_id, status: false, created_by: req.systemUser.system_user_id }
        })
        if (subcriptionData) {
            return logger.error(res, "Subcription is inactive");
        }
        let subcriptionEditt = await db.crbm_subscription_plans.findOne({
            attributes: ['plan_id', 'status'],
            where: { plan_id: req.query.plan_id, status: true },
        });
        console.log(subcriptionEditt);
        if (!subcriptionEditt) {
            return logger.error(res, "Subcription with the given plan_id not found");
        }
        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Subcription get");
    }
}

module.exports = {
    createPlan,
    deletePlan,
    editPlan,
    getPlan
};