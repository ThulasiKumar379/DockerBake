
const emailer= require("../../../lib/email/mailer")
const env = require('../../../config/environment');
const amqp = require('amqplib');
const rabbitMQConnectionString = 'amqp://localhost:5672';
const emailQueue = 'email_queue';
const fs = require('fs');
const handlebars = require('handlebars');

const createSample = async (req, res, next) => {
  async function enqueueEmail(email) {
    try {

      const connection = await amqp.connect(rabbitMQConnectionString);
      const channel = await connection.createChannel();
      await channel.assertQueue(emailQueue);
      const message= Buffer.from(JSON.stringify(email));
      channel.sendToQueue(emailQueue, message);
      console.log('Email enqueued:', email);
      await channel.close();
      await connection.close();
    } catch (error) {
      console.error('Error enqueuing email:', error);
    }

  }
  let email = {
    from : env.smtp.username,
    to: "mathig.krishnan@gmail.com",
    subject: 'Hello RabbitMQ and Nodemailer latest!!!!',
    body: 'This is a test email sent via RabbitMQ and Nodemailer.',
  };
  const templateString = fs.readFileSync('views/approveEmail.hbs', 'utf8');
  const template = handlebars.compile(templateString); 
  const renderedTemplate = template(email); 
  email.html=renderedTemplate  
  enqueueEmail(email);

   let data= await emailer.sendemail({subject:"111 welcome to my team","name":'venkatesh',"username":"venkatesh5256","password":'12345'},
   'approveEmail',{email:"mathig.krishnan@gmail.com"});
   res.end("Email sent successfully");

}

module.exports =
{
    createSample
};