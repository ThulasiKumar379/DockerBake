var db = require('../models/index') 
var AWS = require('aws-sdk');
var env = require('../../config/environment');
const logger = require('../../utils/winston');
var jwt = require('jsonwebtoken');
const sharp = require('sharp');

var status = { 
    "success":{ status:true, message:"",  data:"", },
    "error":{ status:false, errorMessage:""  }  
};
delete status['fc'];

let getprofilepic = async function (req,res,next) {  
    try {  
        const s3 = new AWS.S3({
            accessKeyId: env.s3.accessKeyId,
            secretAccessKey: env.s3.secretAccessKey
        });

        if (req.params.token !== undefined) {
            let jwttoken = req.params.token;
            
            jwt.verify(jwttoken, env.jwtkey.system_user_key, (err, user) => {
                if (err) {
                    return res.status(200).send(status.tokenError);
                }
                console.log(user);
                req.user_id = user.userdata.user_id;
            });
          
            let useracccount = await db.crbt_users.findOne({
                attributes: ["profilepic_key"],
                where: { user_id: req.user_id },
            }); 
            if (!useracccount) {
                return res.status(400).send({ status: false, message: "User ID Not Found." });
            }

            if (useracccount.dataValues.profilepic_key !== "" && useracccount.dataValues.profilepic_key !== null) {
                var params = { Bucket: env.s3.bucketname, Key: useracccount.dataValues.profilepic_key };
                console.log(params);
                s3.headObject(params, async function (err, metadata) {  
                    if (err == null) {  
                        s3.getObject(params, function(err, data) {
                            console.log(data);
                            res.writeHead(200, {'Content-Type': 'image/jpeg'});
                            res.write(data.Body, 'binary');
                            res.end(null, 'binary');
                        });
                    } else { 
                        defaultprofilepic(s3, res); // Fetch default image if profile pic not found
                    }
                });
            } else {
                defaultprofilepic(s3, res); // Fetch default image if profile pic not found
            }   
        } else {
            defaultprofilepic(s3, res); // Fetch default image if no token provided
        }
    } catch (error) {  
        logger.createLog(__filename,error.message,req);
        return logger.error(res, "Exception in get picture");        
    } 
}

function defaultprofilepic(s3, res) {
    const params = { Bucket: env.s3.bucketname, Key: "default.png" };

    s3.getObject(params, function(err, data) {
        if (err) {
            console.error("Error fetching default image:", err);
            return res.status(500).send({ status: false, message: "Error fetching default image" });
        }
        res.writeHead(200, { 'Content-Type': 'image/jpeg' });
        res.write(data.Body, 'binary');
        res.end(null, 'binary');
    });
}

module.exports = { 
    getprofilepic
};