var db = require('../../models/index');
const logger = require('../../../utils/winston');
var { sequelize } = require('../../models/index');
const { Sequelize, Op } = require("sequelize");


const aclcreate = async (req, res, next) => {
    try {     
        if (typeof req.body.permission_id == 'undefined'||typeof req.body.role_id == 'undefined') {
            return logger.error(res,"Permission or Role ID parameter is missing.");    
        }
        if(req.body.permission_id ===""|| req.body.role_id ==="") {
            return logger.error(res,"Permission or Role ID cannnot be empty.");   
        }
        if (!Number(req.body.permission_id)) {
            return logger.error(res,"Invalid Permission ID");        
        }
        if (!Number(req.body.role_id)) {
            return logger.error(res,"Invalid Role ID");        
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in permission create");
    }
}

const acldelete = async (req, res, next) => {
    try {  
        if (typeof req.body.permission_id == 'undefined'||typeof req.body.role_id == 'undefined') {
            return logger.error(res,"Permission or Role ID parameter is missing.");    
        }
        if(req.body.permission_id ===""|| req.body.role_id ==="") {
            return logger.error(res,"Permission or Role ID is cannnot be empty.");   
        }
        if (!Number( req.body.permission_id)) {
            return logger.error(res,"Invalid Permission ID");        
        }
        if (!Number( req.body.role_id)) {
            return logger.error(res,"Invalid Role ID");        
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in update settings");
    }
}
module.exports =
{
    aclcreate,
    acldelete
};