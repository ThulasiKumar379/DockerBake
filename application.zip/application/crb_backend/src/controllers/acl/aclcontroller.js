var db = require('../../models/index') 
const logger = require('../../../utils/winston');
var { sequelize } = require('../../models/index');
const { Sequelize, Op } = require("sequelize");

const aclcreate = async (req, res, next) => {
    try {    
        let permissiondata = await db.permissions.findOne({
            attributes:['id'],
              where: { id: req.body.permission_id}
          })
          let roledata = await db.crbt_roles.findOne({
            attributes:['role_id'],
              where: { role_id: req.body.role_id}
          })

          if(!permissiondata){
            return res.status(400).send({ status: false, message: "Permission ID Not Found." }); 
          }
          if(!roledata){
            return res.status(400).send({ status: false, message: "Role ID Not Found." }); 
          }
        let createacl = await db.userpermissions.create({
            permission_id: req.body.permission_id,
            role_id: req.body.role_id
        }); 
        
        return logger.success(res, "Permission Created Successfully", createacl);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in Creating Permission.");
    }
}
let updatePermissions = async function (req, res, next) {
  try {
      let { id, name } = req.body;

      let permission = await db.permissions.findOne({
         where: { id }
      });

      if (!permission) {
          return logger.error(res, "Permission not found");
      }

      await permission.update({ name });

      return logger.success(res, "Permission updated successfully");
  } catch (error) {
      logger.createLog(__filename, error.message, req)
      return logger.error(res, "Exception in updating permission by id");
  }
}
const acldelete = async (req, res, next) => {
    try {  
        let deleteacl=   await db.userpermissions.destroy({
            where:{
                permission_id: req.body.permission_id,
                role_id: req.body.role_id
            } 
        }); 
        return logger.success(res, "Permission Deleted Successfully", deleteacl);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in Settings Update.");
    }
}


const getACl = async (req, res, next) => {
    try {  
        let subscribedata = await db.permissions.findAll({
            attributes: ["id","name","key","status"],
            include: [
                {
                    model: db.userpermissions,
                    as: "userpermissions",
                    attributes: ['role_id'],
                    required: false, 
                }],
            order: [["id", "asc"],[db.userpermissions,"role_id", "asc"]]
          
        })
        let subscriber = false;
        if (subscribedata) {
            subscriber = true;
        }
        return res.status(200).send({ status: true, data: subscribedata });
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in get ACL");
    }
}

let getRoles = async function (req, res, next) {
    try {
     
     let RoleData = await db.crbt_roles.findAll({
       attributes: ["role_id","role_name"],
       where: {
        status:true,
         system_user_id: req.systemUser.system_user_id
       },
       order: [['role_id', 'ASC']],
 
     })
     if (RoleData.length === 0) {
       return res.status(400).send({ status: false, message: "Roles not available", RoleData });
     } else {
       return res.status(200).send({ status: true, message: "Roles retrived successfully", RoleData });
     }
   } 
   catch (error) {
     logger.createLog(__filename, error.message, req)
     return logger.error(res, "Exception in roles");
   }
 }

module.exports =
{
    aclcreate,
    acldelete,
    getACl,
    getRoles,
    updatePermissions
};