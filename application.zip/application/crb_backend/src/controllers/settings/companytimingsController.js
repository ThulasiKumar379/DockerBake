var db = require("../../models/index");
const logger = require("../../../utils/winston");
const emailer = require("../../../lib/email/mailer");
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");

let getCompanyTimings = async function(req, res, next) {
    try { 

        const [results] = await sequelize.query(
            `SELECT  timings."companytimings_id",timings."start_time",timings."end_time",timings."monday",timings."tuesday", timings."wednesday",timings."thursday",timings."friday",
                      timings."saturday",timings."sunday",timings."system_user_id",timings."created_by",systemusers."company_name",systemusers."company_address",systemusers."email",systemusers."phone_number"
                      FROM crbt_system_users as systemusers
                        LEFT JOIN "crbt_companytimings" AS timings ON timings."system_user_id" = systemusers."system_user_id"
                      WHERE systemusers."system_user_id" = ${req.systemUser.system_user_id}  
                      ORDER BY timings."companytimings_id";
                      `);
        if (results.length === 0) {
            return logger.success(res, "Companytimings data not found")
        } else {
            return logger.success(res, "Companytimings retrived successfully", results)
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in timings");
    }
}


const updateCompanyTimings = async function(req, res, next) {
    try {
        let timingData = await db.crbt_companytimings.findOne({
            where: { system_user_id: req.systemUser.system_user_id }

        }) 
        if(timingData!=null){
            if (timingData.system_user_id !== req.systemUser.system_user_id) {
                return res.status(400).send({ status: false, message: "Perimission Denied", updatetimings });
            } else if (timingData.system_user_id === req.systemUser.system_user_id) {
                let updatetimings = await db.crbt_companytimings.update({ 
                    start_time: req.body.start_time,
                    end_time: req.body.end_time,
                    monday: req.body.monday || false,
                    tuesday: req.body.tuesday || false,
                    wednesday: req.body.wednesday || false,
                    thursday: req.body.thursday || false,
                    friday: req.body.friday || false,
                    saturday: req.body.saturday || false,
                    sunday: req.body.sunday || false
                }, {
                    where: { 
                        system_user_id: req.systemUser.system_user_id,
                    },
                }) 
                let timingData = await db.crbt_companytimings.findOne({
                    where: { system_user_id: req.systemUser.system_user_id }
        
                }) 
                return res.status(200).send({ status: true, message: "Timings updated successfully", timingData });
            } 
        }else{
            updatetimings= await db.crbt_companytimings.create({
                company_name: req.body.company_name,
                system_user_id: req.systemUser.system_user_id,
                start_time: req.body.start_time,
                end_time: req.body.end_time,
                monday: req.body.monday || false,
                tuesday: req.body.tuesday || false,
                wednesday: req.body.wednesday || false,
                thursday: req.body.thursday || false,
                friday: req.body.friday || false,
                saturday: req.body.saturday || false,
                sunday: req.body.sunday || false
            }); 
            return res.status(200).send({ status: true, message: "Timings updated successfully", updatetimings });
        }   
        return logger.success(res, "Timings updated successfully", updatetimings);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in update timings ");
    }
}


const fetchCompanyTimings = async function(req, res, next) {
    try {
        let timingData = await db.crbt_companytimings.findOne({
            where: { system_user_id: req.systemUser.system_user_id }

        })  
        return logger.success(res, "Timings updated successfully", timingData?timingData:[]);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in updatetimings ");
    }
}
module.exports = {
    
    updateCompanyTimings,
    getCompanyTimings,
    fetchCompanyTimings
};