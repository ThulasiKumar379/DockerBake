var db = require('../../models/index');
const logger = require('../../../utils/winston');


let createCompanyTimingsValidator = async function (req, res, next) {
  try {
   
    if (!req.body.company_name) {
      return res.status(400).send({ status: false, message: "company_name is required" });
    }
    // if (!req.body.system_user_id) {
    //   return res.status(400).send({ status: false, message: "system_user_id is required" });
    // }
    if (!req.body.start_time) {
      return res.status(400).send({ status: false, message: "start_time is required" });
    }
    if (typeof req.body.company_name === 'undefined') {
      return logger.error(res,"company_name parameter is missing.");
  }
  const existingcompany = await db.crbt_companytimings.findOne({ 
    attributes: ["company_name"],
    where: { 
      company_name: req.body.company_name 
    } });
  if (existingcompany) {
    return res.status(400).send({ status: false, message: 'company_name already exists' });
  }
    if (!req.body.end_time) {
      return res.status(400).send({ status: false, message: "end_time is required" });
    }

    if (!isValidTime(req.body.start_time)) {
      return res.status(400).send({ status: false, message: "Invalid start_time format. Expected format: HH:MM:SS" });
    }
    if (!isValidTime(req.body.end_time)) {
      return res.status(400).send({ status: false, message: "Invalid end_time format. Expected format: HH:MM:SS" });
    }
    if (/^\s*$/.test(req.body.start_time)) {
      return logger.error(res, "start_time cannot be empty");
    }
    if (/^\s*$/.test(req.body.end_time)) {
      return logger.error(res, "end_time cannot be empty");
    }
    if (/^\s*$/.test(req.body.company_name)) {
      return logger.error(res, "company_name cannot be empty");
    }

    // // Construct companyTimingsData object
    let companyTimingsData = {
      company_name: req.body.company_name,
      system_user_id: req.systemUser.system_user_id,
      created_by: req.systemUser.system_user_id,
      start_time: req.body.start_time,
      end_time: req.body.end_time,
      monday: req.body.monday || false,
      tuesday: req.body.tuesday || false,
      wednesday: req.body.wednesday || false,
      thursday: req.body.thursday || false,
      friday: req.body.friday || false,
      saturday: req.body.saturday || false,
      sunday: req.body.sunday || false
      
    };

    return await db.crbt_companytimings.create(companyTimingsData).then(function (data) {
      if (data) {
        return res.status(200).send({ status: true, message: "Company timings created successfully", data });
      } else {
        return logger.error(res, "Error creating company timings");
      }
    });
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return logger.error(res, "Exception in creating companytimings");
  }
}
function isValidTime(timeString) {
  const timeRegex = /^(?:[01]\d|2[0-3]):(?:[0-5]\d):(?:[0-5]\d)$/;
  return timeRegex.test(timeString);
}

const getCompanyTimingsValidator = async function (req, res, next) {
    try {
      if (!req.body.companytimings_id || req.body.companytimings_id.trim() === '') {
        return res.status(400).send({ status: false, message: "companytimings_id cannot be empty" });
      }
  
      if (typeof req.body.companytimings_id !== 'number') {
        return res.status(400).send({ status: false, message: "Invalid data type for companytimings_id. Only numbers are allowed." });
      }
  
      let timingData = await db.crbt_smtp_settings.findOne({
        attributes: ["companytimings_id", "company_name", "company_start_time", "company_end_time", "days", "system_user_id", "created_by"],
        where: {
          companytimings_id: req.body.companytimings_id,
          status: true
        }
      });
  
      if (!timingData) {
        return res.status(400).send({ status: false, message: "Company timings not found" });
      } else {
        req.timingData = timingData; 
        next();
      }
    }
     catch (error) {
      logger.createLog(__filename, error.message, req);
      return res.status(500).send({ status: false, message: "Exception in retrieving company timings" });
    }
  };
  
  let updateCompanyTimingsValidator = async function (req, res, next) {
    try {  
      if (typeof req.body.company_name === 'undefined'|| typeof req.body.start_time === "undefined" || typeof req.body.end_time === "undefined") {
        return logger.error(res, "Parameters is Missing.");
      } 
  
      if (req.body.company_name === '' || req.body.start_time === "" || req.body.end_time === "") {
        return logger.error(res, "Company name or start time or end time cannot be empty");
      }
  
      const company_name = req.body.company_name;
  
      // if (company_name && company_name.length > 255) {
      //   return res.status(400).send({ status: false, message: 'Company name exceeds maximum length of 255 characters' });
      // } 
      // if (typeof req.body.company_name !== 'string') {
      //   return logger.error(res, "Invalid Company name");
      // } 
      next();
  
    } catch (error) {
      logger.createLog(__filename, error.message, req);
      return logger.error(res, "Exception in update Company Timings");
    }
  };
  
  module.exports = {
    createCompanyTimingsValidator,
    getCompanyTimingsValidator,
    updateCompanyTimingsValidator

}