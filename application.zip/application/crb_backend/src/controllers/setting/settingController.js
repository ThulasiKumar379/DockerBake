const { Sequelize, Op } = require("sequelize");
var db = require('../../models/index') 
var logger = require('../../../utils/winston')
var { sequelize } = require('../../models/index')

let getSettings= async function (req,res,next) {
    try {     
        let settingData = await db.crbt_setting.findAll({
            attributes: ["booked_room_color", "unbooked_room_color","check_in_remain_minutes","reservation_duration","reservation_remainder","reservation_message","email_notification","public_access","email_notification_message"],
            where: { "system_user_id": req.systemUser.system_user_id}         

        })
        return logger.success(res,"Setting Data retrived successfully",settingData)
    } catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Setting List");
    }
}

let createSetting= async function (req, res, next) {
    try {   
        let insertdata={  
            booked_room_color:req.body.booked_room_color,
            unbooked_room_color:req.body.unbooked_room_color,
            system_user_id:req.systemUser.system_user_id,
            check_in_remain_minutes:req.body.check_in_remain_minutes,
            reservation_duration:req.body.reservation_duration,
            reservation_remainder:req.body.reservation_remainder,
            reservation_message:req.body.reservation_message,
            email_notification:req.body.email_notification,
            public_access:req.body.public_access,
            email_notification_message:req.body.email_notification_message,
            created_by:req.systemUser.system_user_id,
            updated_at:null         
        } 
        return await db.crbt_setting.create(insertdata).then(async function (users) {
            if (users) {  
                    return logger.success(res,"Setting Saved successfully",users);
            } else { 
                return logger.error(res,"Error in Setting");
            }
        });
    
 } catch (error) {
     logger.createLog(__filename, error.message, req);
     return logger.error(res, "Exception in Setting");
 }    
} 


let updateSetting= async function (req, res, next) { 
    try {         
     await db.crbt_setting.update(
         {
            booked_room_color:req.body.booked_room_color,
            unbooked_room_color:req.body.unbooked_room_color,
            check_in_remain_minutes:req.body.check_in_remain_minutes,
            reservation_duration:req.body.reservation_duration,
            reservation_remainder:req.body.reservation_remainder,
            reservation_message:req.body.reservation_message,
            email_notification:req.body.email_notification,
            public_access:req.body.public_access,
            email_notification_message:req.body.email_notification_message,
            updated_by:req.systemUser.system_user_id,
            updated_at: Date.now()
         } ,
         {
             where: {
                system_user_id: req.systemUser.system_user_id
             },
         }
     ) 
     return logger.success(res,"Setting updated successfully");
 } catch (error) {
     logger.createLog(__filename, error.message, req);
     return logger.error(res, "Exception in Setting");
 }
}



module.exports ={ getSettings , createSetting, updateSetting }
    