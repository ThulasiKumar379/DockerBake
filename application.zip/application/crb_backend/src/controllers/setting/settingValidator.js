var db = require('../../models/index')
const logger = require('../../../utils/winston')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}
const createSetting = async function (req, res, next) {
    try {
        detectNumeric(req.body);          
        if (typeof req.body.check_in_remain_minutes == 'undefined') {
            return logger.error(res, 'Check In  parameter is missing');
        }
        if (/^\s*$/.test(req.body.check_in_remain_minutes)) {
            return logger.error(res, "Check In cannot be empty");
        }
        if (typeof req.body.reservation_duration == 'undefined') {
            return logger.error(res, 'Reservation Duration  parameter is missing');
        }
        if (typeof req.body.reservation_message == 'undefined') {
            return logger.error(res, 'reservation message parameter is missing');
        }
        if (/^\s*$/.test(req.body.reservation_message)) {
            return logger.error(res, "reservation message cannot be empty");
        }

        if (/^\s*$/.test(req.body.reservation_duration)) {
            return logger.error(res, "Reservation Duration cannot be empty");
        }  
        if (typeof req.body.reservation_remainder == 'undefined') {
            return logger.error(res, 'Reservation Remainder parameter is missing');
        }
        if (/^\s*$/.test(req.body.reservation_remainder)) {
            return logger.error(res, "Reservation Remainder cannot be empty");
        } 
        if (typeof req.body.booked_room_color == 'undefined') {
            return logger.error(res, 'Room color parameter is missing');
        }
        if (/^\s*$/.test(req.body.booked_room_color)) {
            return logger.error(res, "Room color  cannot be empty");
        } 
        if (typeof req.body.unbooked_room_color == 'undefined') {
            return logger.error(res, 'Unbooked Room color parameter is missing');
        }
        if (/^\s*$/.test(req.body.unbooked_room_color)) {
            return logger.error(res, "Unbooked Room color  cannot be empty");
        } 
        let settingData = await db.crbt_setting.findOne({
            attributes: ["system_user_id"],
            where: { system_user_id: req.systemUser.system_user_id}
        }); 
        if (settingData != null) {
            return logger.error(res, 'Setting already available .Please update');
        }
        next();
    } catch (error) { 
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in Setting Create validation");
    }
}
const updateSetting = async function (req, res, next) {
    try {
        detectNumeric(req.body);           
        if (typeof req.body.check_in_remain_minutes == 'undefined') {
            return logger.error(res, 'Check In parameter is missing');
        }
        if (/^\s*$/.test(req.body.check_in_remain_minutes)) {
            return logger.error(res, "Check In cannot be empty");
        }
        if (typeof req.body.reservation_duration == 'undefined') {
            return logger.error(res, 'Reservation Duration parameter is missing');
        }
        if (/^\s*$/.test(req.body.reservation_duration)) {
            return logger.error(res, "Reservation Duration cannot be empty");
        }  
        if (typeof req.body.reservation_remainder == 'undefined') {
            return logger.error(res, 'Reservation Remainder parameter is missing');
        }
        if (/^\s*$/.test(req.body.reservation_remainder)) {
            return logger.error(res, "Reservation Remainder cannot be empty");
        } 
        if (typeof req.body.reservation_message == 'undefined') {
            return logger.error(res, 'Reservation Message parameter is missing');
        }
        if (/^\s*$/.test(req.body.reservation_message)) {
            return logger.error(res, "Reservation Message cannot be empty");
        }
        if (typeof req.body.email_notification == 'undefined') {
            return logger.error(res, 'Email Notification parameter is missing');
        }
        if (/^\s*$/.test(req.body.email_notification)) {
            return logger.error(res, "Email Notification cannot be empty");
        }
        if (typeof req.body.email_notification_message == 'undefined') {
            return logger.error(res, 'Email Notification Message parameter is missing');
        }
        if (/^\s*$/.test(req.body.email_notification_message)) {
            return logger.error(res, "Email Notification Message cannot be empty");
        }
        if (typeof req.body.booked_room_color == 'undefined') {
            return logger.error(res, 'Room color parameter is missing');
        }
        if (/^\s*$/.test(req.body.booked_room_color)) {
            return logger.error(res, "Room color cannot be empty");
        } 
        if (typeof req.body.unbooked_room_color == 'undefined') {
            return logger.error(res, 'Unbooked Room color parameter is missing');
        }
        if (/^\s*$/.test(req.body.unbooked_room_color)) {
            return logger.error(res, "Unbooked Room color cannot be empty");
        } 
        let settingData = await db.crbt_setting.findOne({
            attributes: ["system_user_id"],
            where: { system_user_id: req.systemUser.system_user_id}
        }); 
        if (settingData != null) {
            if (settingData.system_user_id !== req.systemUser.system_user_id) {
                return logger.error(res, "Access Denied");
            }
        }        
        next();
    } catch (error) { 
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in Setting Create validation");
    }
}

module.exports={createSetting,updateSetting}
