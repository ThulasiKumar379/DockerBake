var db = require('../../models/index') 
const logger = require('../../../utils/winston');
var jwt = require('jsonwebtoken');
var env = require('../../../config/environment');
var crypto = require('crypto');
var { sequelize } = require('../../models/index')
let response = async function (req, res, next) {
	var status = {
		"success": { status: true, message: "", data: "", },
		"error": { status: false, errorMessage: "" }
	};
	try {	 
		let updatedata = {
			"payment_response": JSON.stringify(req.body),
			"transaction_message": req.body.txMsg,
			"transaction_time": req.body.txTime,
			"payment_status": req.body.txStatus,
			"updated_at": Date.now()
		}
		if (req.body.referenceId != "N/A") {
			updatedata.payment_ref_id = req.body.referenceId;
			updatedata.payment_method = req.body.paymentMode;
		}
		if (req.body.txStatus == "FAILED") {
			updatedata.status = 4;
		} else if (req.body.txStatus == "CANCELLED") {
			updatedata.status = 3;
		} else if (req.body.txStatus == "SUCCESS") {
				updatedata.status = 5;
				const paymentdetails = await db.crbt_payment.findOne({
					attributes: ["payment_id", "plan_id", "system_user_id"],
					where: { order_id: req.body.orderId },
				}
				); 
				const subscriptionPlans = await db.crbm_subscription_plans.findOne({
					attributes: ["tenure"],
					where: { plan_id: paymentdetails.plan_id },
				}); 
				const date = new Date();
				let startdate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
				var newDate = new Date(date.setMonth((date.getMonth()) + subscriptionPlans.tenure));
				let expirydate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				insertdata = {
					system_user_id: paymentdetails.system_user_id,
					plan_id: paymentdetails.plan_id,
					paymentid: paymentdetails.payment_id,
					startdate: startdate,
					enddate: expirydate
				}
				await db.crbt_user_subscription.create(insertdata); 
		} 
		await db.crbt_payment.update(updatedata,
			{ where: { order_id: req.body.orderId} }
		);   
		res.writeHead(301, {
			Location: env.cashfree.paymentlanding+"?orderid="+req.body.orderId
		}).end();
	} catch (error) {
		logger.createLog(__filename, error.message, req)
		status.error.errorMessage = "Exception in payment response";
		return res.status(200).send(status.error);
	}
} 
let payOnline = async function (req, res) {
	var status = {
		"success": { status: true, message: "", data: "", },
		"error": { status: false, errorMessage: "" }
	};
	try { 
		if (req.body.token !== undefined) {
			let jwttoken = req.body.token;
			jwt.verify(jwttoken,env.jwtkey.system_user_key, (err, user) => {
				if (err) {
					return res.status(403).send(status.tokenError);
				}
				console.log(user);
				req.user = user.userdata;
			});  
		} else {
			return res.send(status.tokenError);
		}
		let userdata = await db.crbt_system_users.findOne({
			attributes: ["company_name","email","phone_number"],
			where: { "system_user_id": req.user.system_user_id }
		});
		
		let subscribeplan = await db.crbm_subscription_plans.findOne({
			where: { "plan_id": req.body.plan_id }
		});
		let orderid = req.user.system_user_id + req.body.plan_id + Math.floor(100000 + Math.random() * 900000);
		
		var postData = {
			"appId": env.cashfree.appId,
			"orderId": orderid,
			"orderAmount": subscribeplan.price,
			"orderCurrency": env.cashfree.currency,
			"orderNote": "test note",
			'customerName': userdata.company_name ? userdata.company_name : userdata.email,
			"customerEmail": userdata.email ? userdata.email : userdata.phone_number + "@mm.com",
			"customerPhone": userdata.phone_number,
			"returnUrl": env.cashfree.returnUrl,
			"notifyUrl": env.cashfree.notifyUrl,
		}; 
		 
		let taxdata = await db.tax.findAll({
			attributes: ["tax_name","type","value"],
			where: {"active":true}
		});
		let percentagetax=0;
		let fixedtax=0;
		let baseprice=0;
		let pertaxamount=0;
		let taxbreakup=[];
		let totaltax=0.0; 
		if(taxdata.length!=0){
			await taxdata.map((data)=>{
				if(data.type=="PERCENTAGE"){
					percentagetax=percentagetax+data.value
				}else{
					fixedtax=fixedtax+data.value
				}
				
			});
			baseprice=postData.orderAmount-fixedtax;
			pertaxamount=baseprice/((percentagetax/100)+1);
			baseprice=pertaxamount.toFixed(2);
			await taxdata.map((data)=>{
				if(data.type=="PERCENTAGE"){
					let taxvalue=(baseprice*data.value)/100;
					data.dataValues.taxvalue=taxvalue.toFixed(2);
					let total=Number(taxvalue.toFixed(2));
					totaltax=totaltax+total;
					taxbreakup.push(data.dataValues); 
				}else{
					data.dataValues.taxvalue=data.value;
					totaltax=totaltax+data.value;
					taxbreakup.push(data.dataValues); 
				}
				
			});
			
		}  
		console.log(taxbreakup);
		let amount=baseprice;
		let insertdata = {
			system_user_id: req.user.system_user_id,
			plan_id: req.body.plan_id,
			subscription_plan_details:JSON.stringify(subscribeplan),
			amount: amount,
			payment_request: JSON.stringify(postData),
			order_id: orderid,
			status: 1,
			tax:totaltax,
			tax_breakup: JSON.stringify(taxbreakup),
			total_amount:postData.orderAmount,
		};  
		
		db.crbt_payment.create(insertdata).then(function (payment) {
			if (payment) {
				console.log(payment);
			} else {
				status.error.errorMessage = "Error in insert payment details";
				return res.status(200).send(status.error);
			}
		});  
		mode = env.cashfree.mode;
		secretKey = env.cashfree.secretKey;
		sortedkeys = Object.keys(postData),
			url = "",
			signatureData = "";
		sortedkeys.sort();
		for (var i = 0; i < sortedkeys.length; i++) {
			k = sortedkeys[i];
			signatureData += k + postData[k];
		}
		var signature = crypto.createHmac('sha256', secretKey).update(signatureData).digest('base64');
		postData['signature'] = signature;
		if (mode == "PROD") {
			url = env.cashfree.PRODUrl;
		} else {
			url = env.cashfree.TestUrl;
		} 
		res.render('request', { postData: postData, url: url });
	} catch (error) {
		logger.createLog(__filename, error.message, req)
		status.error.errorMessage = "Exception in payOnline";
		return res.status(200).send(status.error);
	}
}
let getPaymentHistory = async function (req, res) {
	var status = {
		"success": { status: true, message: "", data: "", },
		"error": { status: false, errorMessage: "" }
	};
	try {   
		let query=`select cp.payment_id,ps.name payment_status,cp.system_user_id,cp.plan_id,cp.subscription_plan_details,cp.order_id,
		cp.payment_ref_id,cp.status,cp.payment_method,cp.amount,cp.tax,
		cp.total_amount,us.startdate,us.enddate
		from crbt_payment cp
		left join payment_statuses ps on ps.id=cp.status
		left join crbt_user_subscription us on us.paymentid=cp.payment_id
		where cp.system_user_id=${req.systemUser.system_user_id}`;
		if (typeof req.query.order_id != 'undefined') {
			query=query+` and cp.order_id='${req.query.order_id}'`
        } 
		const paymentdata = await sequelize.query(`${query}`); 
		let data=paymentdata[0]; 
		return res.status(200).send({ status: true, message: "Payment history retrived successfully",data});
	 } catch (error) {
		logger.createLog(__filename, error.message, req)
		status.error.errorMessage = "Exception in payment response";
		return res.status(200).send(status.error);
	}
};
module.exports ={ 
    response,
    payOnline,
	getPaymentHistory
}