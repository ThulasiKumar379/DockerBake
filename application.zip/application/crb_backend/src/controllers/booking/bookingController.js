const schedule = require('node-schedule');
const db = require('../../models/index');
const logger = require('../../../utils/winston');
const { Sequelize, Op } = require("sequelize");
var { sequelize } = require('../../models/index')
const emailer = require('../../../lib/email/mailer')
const emailTemplate = require('../../../views/approveEmail.hbs');
const rabbitmq = require('../../../lib/rabbitmq/message');
const { Buffer } = require('buffer');



function getDateRange(startDate, endDate) {
    const dateRange = [];
    const currentDate = new Date(startDate); 
    while (currentDate <= new Date(endDate)) {
        dateRange.push(currentDate.toISOString().split('T')[0]);
        currentDate.setDate(currentDate.getDate() + 1);
    } 
    return dateRange;
}

function formatTime(time) {
    const parts = time.split(":");
    const hours = parseInt(parts[0]);
    const minutes = parseInt(parts[1]);
    const period = hours >= 12 ? 'pm' : 'am';
    const formattedHours = hours % 12 === 0 ? 12 : hours % 12;
    const formattedMinutes = minutes.toString().padStart(2, '0');
    return `${formattedHours}:${formattedMinutes}${period}`;
}

function formatDateRange(startDate, endDate) {
    const startDay = new Date(startDate).getDate();
    const endDay = new Date(endDate).getDate();
    const startMonth = new Date(startDate).toLocaleString('default', { month: 'short' });
    return `${startDay}th-${endDay}th ${startMonth}`;
}



function daysMap(week) {
    const week1 = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

    const resultDates = {};
    week.forEach((x) => {
        resultDates[week1[x]] = x;
    });

    console.log(resultDates);
    return resultDates
}


const createBooking = async(insertdata, participants_id,organizerName) => {
    const data = await db.crbt_bookings.create(insertdata);

    if (data) {
        if (participants_id && participants_id.length > 0) {
            const booking_participants = Array.isArray(participants_id) ? participants_id : [participants_id];
            const record = booking_participants.map(user_id => ({
                user_id,
                booking_id: data.dataValues.booking_id,
            }));

            await db.crbt_participants.bulkCreate(record, {
                fields: ['user_id', 'booking_id'],
                returning: false,
            });

            const participantEmails = await db.crbt_users.findAll({
                attributes: ['email'],
                where: { user_id: participants_id },
            });
            const emailData = {
                subject: insertdata.title_of_meeting,
                title_of_meeting: insertdata.title_of_meeting,
                organizer: organizerName,
                starttime: insertdata.starttime,
                endtime: insertdata.endtime,
                hbs: 'views/bookingInvitation',
            };
            const emailBody = emailTemplate(emailData);

            for (const participant of participantEmails) {
                emailData.email = participant.email;
                emailData.html = emailBody;
                await rabbitmq.sendMessage(emailData);
                await rabbitmq.consumeMessages();
            }
        }

        return data;
    } else {
        throw new Error('Error in Booking');
    }
};

const userBooking = async(req, res, next) => {
    try {
        const { user_id } = req.user;
        const { room_id, title_of_meeting, starttime, endtime, repeat, description, status, participants_id, location_id, building_id, floor_id, booking_date, duration, room_capacity, room_service_id, booking_end_date } = req.body;
        const systemUserData = await db.crbt_users.findOne({
            attributes: ['user_id', 'system_user_id','first_name'],
            where: { user_id },
        });
        let organizerName=systemUserData.first_name 
        // const [findlocationid, findbuildingid, findfloorid, findroomserverid] = await Promise.all([
            const [findlocationid, findbuildingid, findfloorid, findroomserverid] = await Promise.all([
            db.crbt_locations.findOne({
                attributes: ['locationid', 'system_user_id'],
                where: { location_id:location_id, system_user_id: systemUserData.system_user_id },
            }),
            db.crbt_buildings.findOne({
                attributes: ['buildingid', 'system_user_id'],
                where: { building_id:building_id, system_user_id: systemUserData.system_user_id },
            }),
            db.crbt_floors.findOne({
                attributes: ['floorid', 'system_user_id'],
                where: { floor_id:floor_id, system_user_id: systemUserData.system_user_id },
            }),
            // db.crbm_roomservice.findOne({
            //     attributes: ['serviceid', 'created_by'],
            //     where: { room_service_id:room_service_id, created_by: systemUserData.system_user_id },
            // }),
        ]); 
        if (!findfloorid || !findlocationid || !findbuildingid  ) {
            return res.status(200).send({ status: false, message: 'Data not found' });
        }

        if (
            findlocationid.system_user_id !== systemUserData.system_user_id ||
            findbuildingid.system_user_id !== systemUserData.system_user_id ||
            findfloorid.system_user_id !== systemUserData.system_user_id 
            //|| findroomserverid.created_by !== systemUserData.system_user_id
        ) {
            return res.status(400).send({ status: false, message: 'Permission Denied' });
        }

        const System_user_value = systemUserData.system_user_id;
        const roomServiceIds = Array.isArray(room_service_id) ? room_service_id : [room_service_id];

        const roomVerifyData = await db.crbt_rooms.findOne({
            attributes: ['roomid'],
            where: { room_id:room_id, system_user_id: systemUserData.system_user_id },
        });

        if (!roomVerifyData) {
            return res.status(400).send({ status: false, message: 'Permission Denied' });
        }

        let resultDates = {};
        if (repeat === 'Weekly' || repeat === 'Mon-Fri') { 
            const weekdaysArray = repeat === 'Mon-Fri' ? [1, 2, 3, 4, 5] : req.body.days; 
            resultDates = daysMap(weekdaysArray);
        }
        console.log("resultDates : ",resultDates)
        console.log("req.body.days : ",req.body.days)
        const insertdata = {
            room_id,
            user_id,
            system_user_id: System_user_value,
            title_of_meeting,
            starttime,
            endtime,
            repeat,
            description,
            status,
            created_by: user_id,
            booking_status: 1,
            location_id,
            building_id,
            floor_id,
            booking_date,
            duration,
            room_capacity,
            room_service_id: roomServiceIds,
            booking_end_date,
            days: JSON.stringify(resultDates),

        };

        const data = await createBooking(insertdata, participants_id,organizerName);
        return res.status(200).send({ status: true, message: 'New Booking Data inserted', insertdata, data });
    } catch (error) {
        console.error('Exception in inserting new booking:', error);
        return res.status(500).send({ status: false, message: 'Exception in inserting new booking' });
    }
};



let EdituserBooking = async function(req, res, next) {
    try {
        const { user_id } = req.user;

        const { room_id, title_of_meeting, starttime, endtime, participants_id, repeat } = req.body;

        let systemUserData = await db.crbt_users.findOne({
            attributes: ["user_id", "system_user_id","first_name"],
            where: { user_id: req.user.user_id },
        });
        let roomVerifyData = await db.crbt_rooms.findOne({
            attributes: ["room_id"],
            where: { room_id: req.body.room_id, system_user_id: systemUserData.system_user_id },
        });
        if (!roomVerifyData) {
            return res.status(400).send({ status: false, message: "Room ID is not Available" });
        }
        let resultDates = [];
        if (repeat === 'DoesNotRepeat') {
            resultDates = ["none"];
        } else if (repeat === 'weekly' || repeat === 'Mon-Fri') {
            const weekdaysArray = repeat === 'Mon-Fri' ? [1, 2, 3, 4, 5] : req.body.days;
            resultDates = daysMap(weekdaysArray);
        }
        let updatedata = {
            room_id: req.body.room_id,
            user_id: req.user.user_id,
            title_of_meeting: req.body.title_of_meeting,
            starttime: req.body.starttime,
            endtime: req.body.endtime,
            repeat: req.body.repeat,
            description: req.body.description,
            status: req.body.status,
            location_id: req.body.location_id,
            building_id: req.body.building_id,
            floor_id: req.body.floor_id,
            booking_date: req.body.booking_date,
            duration: req.body.duration,
            room_capacity: req.body.room_capacity,
            room_service_id: req.body.room_service_id,
            updated_by: req.user.user_id,
            booking_end_date: req.body.booking_end_date,
            days: JSON.stringify(resultDates),
            reschedule_status: true
        };
        let where = {
            booking_id: req.body.booking_id,
            system_user_id: systemUserData.system_user_id,
        };
        let [rowsAffected, [updatedBooking]] = await db.crbt_bookings.update(updatedata, {
            where: where,
            returning: true,
        });
        if (rowsAffected) {
            let record = [];
            if (req.body.participants_id) {
                await Promise.all(req.body.participants_id.map(async(user_id) => {
                    record.push({ user_id: user_id, booking_id: req.body.booking_id });
                }));
                const condition = {
                    where: {
                        booking_id: req.body.booking_id
                    }
                };
                await db.crbt_participants.destroy({
                    where: {
                        booking_id: req.body.booking_id
                    },
                });
                await db.crbt_participants.bulkCreate(record, {
                    fields: ['user_id', 'booking_id'],
                    returning: false
                }, condition);

                /****** mail start*/
                const participantEmails = await db.crbt_users.findAll({
                    attributes: ["email"],
                    where: { user_id: req.body.participants_id }
                });

                let emailData = {
                    subject: title_of_meeting+" Updated Meeting details",
                    title_of_meeting: title_of_meeting,
                    organizer: systemUserData.first_name,
                    starttime: starttime,
                    endtime: endtime,
                    hbs: 'views/bookingInvitation'
                };
                const emailBody = emailTemplate(emailData);
                for (const participant of participantEmails) {
                    emailData.email = participant.email;
                    emailData.html = emailBody;
                    await rabbitmq.sendMessage(emailData)
                    await rabbitmq.consumeMessages()
                }
                return res.status(200).send({ status: true, message: "Booking Data updated", updatedBooking });
            } else {
                return res.status(200).send({ status: true, message: "Booking Data updated", updatedBooking });
            }
        }
    } catch (error) {
        console.error('Exception in Update Booking:', error);
        return res.status(500).send({ status: false, message: "Exception in updating Booking" });
    }
}



let bookingCancel = async function(req, res, next) {
    try {
        let systemUserData = await db.crbt_bookings.findOne({
            attributes: ["user_id", "booking_id", "system_user_id","title_of_meeting"],
            where: { user_id: req.user.user_id, booking_id: req.body.booking_id },
        });

        const user_ids = await db.crbt_participants.findAll({
            attributes: ["user_id"],
            where: { booking_id: req.body.booking_id },
            raw: true
        });

        const map1 = user_ids.map(x => x.user_id); 

        const participant_emailids = await db.crbt_users.findAll({
            attributes: ["email"],
            where: {
                user_id: {
                    [Op.in]: map1,
                },
            },
            raw: true
        });
        const system_user_Data = systemUserData.system_user_id;
        const created_by = systemUserData.created_by;
        const user_Data = req.user.user_id;
        const user_emailid = req.user.email;
        

        let emailData = {
            subject: 'Meeting cancelled',
            title_of_meeting: systemUserData.title_of_meeting,
            organizer: user_Data,
            hbs: 'views/cancelMeeting'

        };
        
        const emailBody = emailTemplate(emailData);
        for (const participant of participant_emailids) {
            emailData.email = participant.email; 
            emailData.html = emailBody;
            await rabbitmq.sendMessage(emailData)
            await rabbitmq.consumeMessages()
        }
        
        let updatedBy;
        if (req.user.user_id) {
            if (created_by === req.user.user_id) {
                updatedBy = req.user.user_id;
            }
        } else if (req.systemUser.system_user_id) {
            updatedBy = req.systemUser.system_user_id;
        }
        await db.crbt_bookings.update({
            status: false,
            booking_status: 4,
            updated_by: updatedBy,
            updated_at: Date.now()

        }, {
            where: {
                booking_id: req.body.booking_id
            },

        });
        return logger.success(res, "Booking Cancelled successfully");

    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking Cancel");
    }

}
let changeBookingStatus = async function(req, res, next) {
    try {
        
        let systemUserData = await db.crbt_bookings.findOne({
            attributes: ["user_id", "booking_id", "system_user_id"],
            where: { user_id: req.user.user_id, booking_id: req.body.booking_id },
        });
      
        await db.crbt_bookings.update({
            status: true,
            booking_status: req.body. approveStatus,
            updated_by: req.user.user_id,
            updated_at: Date.now()

        }, {
            where: {
                booking_id: req.body.booking_id
            },

        });
        return logger.success(res, "Booking Status successfully");

    } catch (error) {
        console.log(error)
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking Status");
    }

}

let fetchStatus = async function(req, res, next) {
    try {
        let statusData = await db.booking_status.findAll({
            attributes: ["id", "status"],
        });
        return logger.success(res, "Booking status data retrieved successfully", statusData);
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        console.error(error);
        return logger.error(res, "Exception occurred while fetching booking status data");
    }
};


let getBookings = async function(req, res, next) {
    try {
        // const [results] = await sequelize.query(
        //     `select crbt_bookings.*, ARRAY_AGG(distinct crbt_participants.user_id) as user_ids, crbt_locations.location_id,
        //     crbt_locations.location_name,crbt_buildings.building_id,crbt_buildings.building_name,crbt_floors.floor_id,crbt_floors.floor_name,crbt_rooms.room_id,crbt_rooms.room_name,crbm_roomservice.room_service_id,crbm_roomservice.room_service_name
        //     from crbt_bookings JOIN crbt_locations ON crbt_bookings.location_id = crbt_locations.location_id
        //     JOIN crbt_buildings ON crbt_bookings.building_id = crbt_buildings.building_id
        //     JOIN crbt_floors ON crbt_bookings.floor_id = crbt_floors.floor_id
        //     JOIN crbt_rooms ON crbt_bookings.room_id = crbt_rooms.room_id
        //     JOIN crbm_roomservice ON crbt_bookings.room_service_id = crbm_roomservice.room_service_id
        //     JOIN crbt_participants ON crbt_bookings.booking_id = crbt_participants.booking_id
        //     WHERE crbt_buildings.system_user_id = ${req.systemUser.system_user_id} 
        //     group by crbt_bookings.booking_id, crbt_locations.location_id,crbt_locations.location_name,crbt_buildings.building_id,crbt_buildings.building_name,crbt_floors.floor_id,crbt_floors.floor_name,crbt_rooms.room_id,crbt_rooms.room_name,crbm_roomservice.room_service_id,crbm_roomservice.room_service_name ORDER BY crbt_bookings.booking_id DESC`
        // ); 
 const [results] = await sequelize.query(
            `select crbt_bookings.* from crbt_bookings where crbt_bookings.system_user_id = ${req.systemUser.system_user_id} 
            and room_id=${req.query.room_id}
            and ('${req.query.startDate}' BETWEEN booking_date AND booking_end_date 
            or '${req.query.endDate}' BETWEEN booking_date AND booking_end_date
            or booking_date  BETWEEN '${req.query.startDate}' AND '${req.query.endDate}' 
            or  booking_end_date BETWEEN '${req.query.startDate}' AND '${req.query.endDate}' )`
        ); 
        
        if (results.length === 0) {
            return logger.success(res, "bookings data no found")
        } else {
            return logger.success(res, "bookings retrived successfully", results)
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking List");
    }
};

let fetchRoomDetails = async function(req, res, next) {
    try {
        const { location_id, building_id, floor_id, room_id } = req.query; 
        let whereObj = {
            location_id: location_id,
            building_id: building_id,
        };
        if (floor_id) {
            whereObj.floor_id = floor_id;
        }
        if (room_id) {
            whereObj.room_id = room_id;
        }
        let roomDetails = await db.crbt_rooms.findAll({
            attributes:['room_id','room_name','location_id','building_id','floor_id',['roomid','uroom_id']],
             where: whereObj
        });
        if (!roomDetails) {
            return logger.success(res, "Room details not found");
        } else { 
            return logger.success(res, "Room details retrieved successfully", roomDetails);
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in fetching room details");
    }
};

let availableRooms = async function(req, res, next) {
    try {
        let whereobj = { system_user_id: req.systemUser.system_user_id };
        let amenity_where_obj = {};
        let conditions = [];
        if (req.query.location_id) {
            const locationIds = Array.isArray(req.query.location_id) ?
                req.query.location_id.map(id => parseInt(id)) : [parseInt(req.query.location_id)];

            whereobj.location_id = {
                [Op.in]: locationIds,
            };
        }
        if (req.query.building_id) {
            const buildingIds = Array.isArray(req.query.building_id) ?
                req.query.building_id.map(id => parseInt(id)) : [parseInt(req.query.building_id)];

            whereobj.building_id = {
                [Op.in]: buildingIds,
            };
        }
        if (req.query.room_capacity) {
            const [min, max] = req.query.room_capacity.split('-');
            whereobj.capacity = {
                [Op.gte]: parseInt(min),
                [Op.lte]: parseInt(max)
            }
        }
        if (req.query.amenities) {
            const amenitiesIds = Array.isArray(req.query.amenities) ?
                req.query.amenities.map(id => parseInt(id)) :
                req.query.amenities.split(',').map(id => parseInt(id));

            amenity_where_obj.amenity_id = {
                [Op.in]: amenitiesIds,
            };
        }
        let results = await db.crbt_rooms.findAll({
            attributes: ['room_id', 'room_name', 'building_id', 'location_id', 'capacity'],
            where: whereobj,
            // raw: true,
            include: [{
                model: db.crbt_room_amenities,
                as: "crbt_room_amenities",
                attributes: ['amenity_id'],
                where: amenity_where_obj,
                required: true
            }]
        });
        data = results.map(instance => instance.get({ plain: true }));
        const daysToCheck = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];

        let finaldata = await Promise.all(data.map(async(obj) => {

            const startDateTime = req.query.startDate;
            // console.log(startDateTime);
            // process.exit();
            const endDateTime = req.query.endDate;
            // console.log(startDateTime);
            const [startdate, starttime1] = req.query.startDate.split('T');
            const [enddate, endtime1] = req.query.endDate.split('T');
            const startDate = startdate;
            const endDate = enddate;
            const starttime = starttime1;
            // console.log(starttime)
            const endtime = endtime1;
            const demo1 = new Date(startDateTime);
            const dateString = demo1.toISOString();
            const [date, timeWithMillis] = dateString.split('T');
            const time = timeWithMillis.slice(0, 8);

            const availability = {};
            const range = {};


            const currentDate = new Date(date);
            const endDateObj = new Date(endDate);

            const dateRange = Array.from({ length: 5 }, (_, i) => {
                const clonedDate = new Date(currentDate);
                clonedDate.setDate(clonedDate.getDate() + i);
                return clonedDate;
            });
            await Promise.all(dateRange.map(async(clonedDate) => {
                const dateString = clonedDate.toISOString().split('T')[0];
                const dayName = daysToCheck[clonedDate.getDay()];
                let day = dayName;
                let date = dateString;
                const results = await sequelize.query(
                    `select booking_id, room_id, starttime, endtime, repeat, booking_date, booking_end_date, days->'${day}' from crbt_bookings 
            where room_id = ${obj.room_id} and booking_date <= '${dateString}' 
            and booking_end_date >= '${endDate}' 
            and starttime <= '${starttime}'
            and endtime >= '${endtime}'
            and 
            CASE
            WHEN repeat is not null  THEN 
                days->'${day}' is not null
            END`
                );
                if (results[0][0] == undefined) {
                    if (endDateObj >= clonedDate) {
                        range[dateString] = true;
                        // No booking record found, so set range to true
                    }
                } else {
                    if (endDateObj >= clonedDate) {
                        range[dateString] = false; // Booking record found, so set range to false
                    }
                }
                if (results[0][0] == undefined) {
                    isAvailable = true;
                } else {
                    isAvailable = false;
                }
                availability[dateString] = isAvailable;
            }));
            obj.availability = availability;
            obj.range = range;
            return obj;


        }));

        if (results.length === 0) {
            return logger.success(res, "Available rooms not found");
        } else {
            return logger.success(res, "Available rooms retrieved successfully", finaldata);
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Available rooms");
    }
};


let availableSlots = async function(req, res, next) {
    try {
        const { startDate, endDate, room_id } = req.query;

        const availability = {};

        const currentDate = new Date(startDate);

        const dateRange = Array.from({ length: 7 }, (_, i) => {
            const clonedDate = new Date(currentDate);
            clonedDate.setDate(clonedDate.getDate() + i);
            return clonedDate;
        });
        const daysToCheck = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];

        await Promise.all(dateRange.map(async(clonedDate, index) => {
            const dateString = clonedDate.toISOString().split('T')[0];
            const dayIndex = (index + 0) % 7; // Ensure the index loops back to 0 after reaching 6
            const dayName = daysToCheck[clonedDate.getDay()];
            const dayKey = `day${dayIndex + 1}`;
            const day = dayName;

            const results = await sequelize.query(
                `SELECT booking_id, room_id, starttime, endtime, repeat, booking_date, booking_end_date, title_of_meeting, days->'${day}' 
                FROM crbt_bookings 
                WHERE room_id = ${room_id} AND booking_date <= '${dateString}' 
                AND booking_end_date >= '${endDate}' 
                AND 
                CASE
                    WHEN repeat IS NOT NULL THEN 
                        days->>'${day}' IS NOT NULL
                END`
            );

            if (results[0].length > 0) {
                const availabilityData = results[0].map(booking => ({
                    booking_id: booking.booking_id,
                    title: booking.title_of_meeting,
                    starttime: booking.starttime,
                    endtime: booking.endtime,


                }));

                availability[dayKey] = {
                    date: dateString,
                    bookingslots: availabilityData
                };
            } else {
                availability[dayKey] = {};
            }
        }));

        // Send the availability information in the response
        return res.json({ room_id, availability });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
};

let mybookingFetch = async function(req, res, next) {
    try {
        let whereobj = { user_id: req.user.user_id};
        let results = await db.crbt_bookings.findAll({
            attributes: ['booking_id', 'room_id', 'duration', 'starttime', 'endtime', 'booking_date', 'booking_end_date', 'title_of_meeting'],
            where: whereobj,
            raw: true,
            include: [
                {
                    model: db.crbt_locations,
                    as: "crbt_locations",
                    attributes: ['location_name'],
                    required: true
                }, 
                {
                    model: db.crbt_buildings,
                    as: "crbt_buildings",
                    attributes: ['building_name'],
                    required: true
                }, 
                {
                    model: db.crbt_floors,
                    as: "crbt_floors",
                    attributes: ['floor_name'],
                    required: true
                }, 
                {
                    model: db.crbt_users,
                    as: "crbt_users",
                    attributes: ['first_name'],
                    required: true
                } 
            ]
        }); 
        const resultsWithAmenities = await Promise.all(results.map(async result => {
            const amenities = await db.crbt_room_amenities.findAll({
                attributes: ['amenity_id'],
                where: { room_id: result.room_id },
            });

            const amenities_data = await Promise.all(amenities.map(async amenity => {
                const amenitiesData = await db.crbm_aminities.findAll({
                    attributes: ['amenityid', 'amenityname', 'thumbnail_key'],
                    where: { amenityid: amenity.amenity_id },
                });
                return amenitiesData;
            }));
            

            const partipants = await db.crbt_participants.findAll({
                attributes: ['user_id'],
                where: { booking_id: result.booking_id }
            });
            const userData = await Promise.all(partipants.map(async user => {
                const userInfo = await db.crbt_users.findAll({
                    attributes: ['user_id', 'email', 'first_name'],
                    where: { user_id: user.user_id },
                });
                return userInfo;
            }));

            return {
                ...result,
                amenities_data: amenities_data.flat(),
                participants: userData.flat(),
                start_endtime: `${formatTime(result.starttime)}-${formatTime(result.endtime)}`,
                start_endDate: formatDateRange(result.booking_date, result.booking_end_date),
            };
        }));
        const transformedResults = resultsWithAmenities.map(result => {
            const transformedResult = {};
            for (const key in result) {
                const transformedKey = key.replace(/\./g, '_');
                transformedResult[transformedKey] = result[key];
            }
            return transformedResult;
        });
        return res.status(200).send({ status: true, message: 'My Booking Details', results: transformedResults });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
};

const invitedBooking = async function(req, res, next) {
    try {
        let whereobj = { user_id: req.user.user_id };
        let results = await db.crbt_participants.findAll({
            attributes: ['booking_id', 'user_id'],
            where: whereobj,
            raw: true,
        });

        const resultsWithAmenities = await Promise.all(results.map(async result => {
            const bookingdata = await db.crbt_bookings.findOne({
                attributes: ['booking_id', 'room_id', 'duration', 'starttime', 'endtime', 'booking_date', 'booking_end_date', 'title_of_meeting'],
                where: { booking_id: result.booking_id },
                raw: true,
                include: [{
                        model: db.crbt_locations,
                        as: "crbt_locations",
                        attributes: ['location_name'],
                        required: true
                    },
                    {
                        model: db.crbt_buildings,
                        as: "crbt_buildings",
                        attributes: ['building_name'],
                        required: true
                    },
                    {
                        model: db.crbt_floors,
                        as: "crbt_floors",
                        attributes: ['floor_name'],
                        required: true
                    },
                    {
                        model: db.crbt_users,
                        as: "crbt_users",
                        attributes: ['first_name'],
                        required: true
                    }
                ]
            });

            const amenities = await db.crbt_room_amenities.findAll({
                attributes: ['amenity_id'],
                where: { room_id: bookingdata.room_id },
            });

            const amenities_data = await Promise.all(amenities.map(async amenity => {
                const amenitiesData = await db.crbm_aminities.findAll({
                    attributes: ['amenityid', 'amenityname', 'thumbnail_key'],
                    where: { amenityid: amenity.amenity_id },
                });
                return amenitiesData;
            }));

            const partipants = await db.crbt_participants.findAll({
                attributes: ['user_id'],
                where: { booking_id: result.booking_id }
            });
            const userData = await Promise.all(partipants.map(async user => {
                const userInfo = await db.crbt_users.findAll({
                    attributes: ['user_id', 'email', 'first_name'],
                    where: { user_id: user.user_id },
                });
                return userInfo;
            }));


            return {
                ...bookingdata,
                start_endtime: `${formatTime(bookingdata.starttime)}-${formatTime(bookingdata.endtime)}`,
                start_endDate: formatDateRange(bookingdata.booking_date, bookingdata.booking_end_date),
                amenities: amenities_data.flat(),
                participants: userData.flat()
            };
        }));
        const transformedResults = resultsWithAmenities.map(result => {
            const transformedResult = {};
            for (const key in result) {
                const transformedKey = key.replace(/\./g, '_');
                transformedResult[transformedKey] = result[key];
            }
            return transformedResult;
        });


        return res.status(200).send({ status: true, message: 'My invitation Details', results: transformedResults });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
};

let manageBooking = async function(req, res, next) {
    try {
        let whereobj = { system_user_id: req.systemUser.system_user_id };
        let amenity_where_obj = {};

        if (req.query.location_id) {
            const locationIds = Array.isArray(req.query.location_id) ?
                req.query.location_id.map(id => parseInt(id)) :
                req.query.location_id.split(',').map(id => parseInt(id));

            whereobj.location_id = {
                [Op.in]: locationIds,
            };
        }
        if (req.query.building_id) {
            const buildingIds = Array.isArray(req.query.building_id) ?
                req.query.building_id.map(id => parseInt(id)) :
                req.query.building_id.split(',').map(id => parseInt(id));

            whereobj.building_id = {
                [Op.in]: buildingIds,
            };
        }
        if (req.query.floor_id) {
            const floorIds = Array.isArray(req.query.floor_id) ?
                req.query.floor_id.map(id => parseInt(id)) :
                req.query.floor_id.split(',').map(id => parseInt(id));

            whereobj.floor_id = {
                [Op.in]: floorIds,
            };
        }
        if (req.query.room_id) {
            const roomIds = Array.isArray(req.query.room_id) ?
                req.query.room_id.map(id => parseInt(id)) :
                req.query.room_id.split(',').map(id => parseInt(id));

            whereobj.room_id = {
                [Op.in]: roomIds,
            };
        }
        if (req.query.startdate && req.query.enddate) {
            const startDate = new Date(req.query.startdate);
            const endDate = new Date(req.query.enddate); 
            const startDateTime = req.query.startdate;
            const endDateTime = req.query.enddate;

            // const [startdate, starttime1] = startDateTime.split('T');
            // const [enddate, endtime1] = endDateTime.split('T');
            // whereobj.booking_date = {
            //     [Op.between]: [startdate, enddate]
            // };
            // whereobj.booking_end_date = {
            //     [Op.between]: [startdate, enddate]
            // };
            whereobj = {
                [Op.and]: [
                    whereobj,
                    {
                        booking_date: {
                            [Op.between]: [startDate, endDate],
                        },
                        booking_end_date: {
                            [Op.between]: [startDate, endDate],
                        },
                        // [Op.or]: [{
                        //         starttime: {
                        //             [Op.between]: [starttime1, endtime1]
                        //         }
                        //     },
                        //     {
                        //         endtime: {
                        //             [Op.between]: [starttime1, endtime1]
                        //         }
                        //     }
                        // ]
                    }
                ]
            };
        }

        let includeArray = [{
            model: db.crbt_locations,
            as: "crbt_locations",
            attributes: ['location_id', 'location_name'],
            required: true
        }, {
            model: db.crbt_buildings,
            as: "crbt_buildings",
            attributes: ['building_id', 'building_name'],
            required: true
        }, {
            model: db.crbt_floors,
            as: "crbt_floors",
            attributes: ['floor_id', 'floor_name'],
            required: true
        }, {
            model: db.crbt_users,
            as: "crbt_users",
            attributes: ['user_id', 'first_name', 'email', 'mobile_number'],
            required: true
        }, {
            model: db.crbt_rooms,
            as: "crbt_rooms",
            attributes: ['room_id', 'room_name'],
            required: true
        },
        {
            model: db.booking_status,
            as: "bookingStatus",
            attributes: ['id', 'status'],
            required: true
        }];
        let results = await db.crbt_bookings.findAll({
            attributes: ['booking_id', 'room_id', 'starttime', 'endtime', 'booking_date', 'booking_end_date', 'title_of_meeting',"booking_status"],
            where: whereobj,
            raw: true,
            include: includeArray
        });
        const resultsWithAmenities = await Promise.all(results.map(async result => {
            const amenities = await db.crbt_room_amenities.findAll({
                attributes: ['amenity_id'],
                where: { room_id: result.room_id },
            });
            const amenitiesIds = amenities.map(amenity => amenity.amenity_id);
            const amenity_where_obj = {
                amenityid: {
                    [Op.in]: amenitiesIds,
                }
            };
            if (req.query.amenities) {
                const amenitiesIds = Array.isArray(req.query.amenities) ?
                    req.query.amenities.map(id => parseInt(id)) :
                    req.query.amenities.split(',').map(id => parseInt(id));

                amenity_where_obj.amenityid = {
                    [Op.in]: amenitiesIds,
                };
            }
            const amenities_data = await db.crbm_aminities.findAll({
                attributes: ['amenityid', 'amenityname', 'thumbnail_key'],
                where: amenity_where_obj,
            });

            return {
                ...result,
                amenities_data: amenities_data,
                start_endtime: `${formatTime(result.starttime)}-${formatTime(result.endtime)}`,
                start_endDate: formatDateRange(result.booking_date, result.booking_end_date),
            };
        }));
        const transformedResults = resultsWithAmenities.map(result => {
            const transformedResult = {};
            for (const key in result) {
                const transformedKey = key.replace(/\./g, '_');
                transformedResult[transformedKey] = result[key];
            }
            return transformedResult;
        });


        return res.status(200).send({ status: true, message: 'My Booking Details', results: transformedResults });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
};



const booking_list_view = async function(req, res, next) {
    try {
        const user_id = req.systemUser.user_id;
        const email_data = req.systemUser.email;
        let Permission = await db.crbt_users.findOne({
            attributes: ['user_id', 'system_user_id', 'email'],
            where: {
                email: email_data
            },
        });
        let Permission1 = await db.crbt_system_users.findOne({
            attributes: ['system_user_id', 'email'],

            where: {
                system_user_id: req.systemUser.system_user_id
            },
        });
        if (Permission1.email === req.systemUser.email && Permission1.system_user_id !== user_id) {
            whereobj = { system_user_id: req.systemUser.system_user_id };
        } else {
            const participants = await db.crbt_participants.findAll({
                attributes: ['booking_id'],
                where: { user_id: req.systemUser.user_id }
            });

            const bookingIds = participants.map(participant => participant.booking_id);

            // console.log(participants);
            whereobj = {
                user_id: req.systemUser.user_id,
                // booking_id: bookingIds
            };
        }

        let amenity_where_obj = {};

        if (req.query.location_id) {
            const locationIds = Array.isArray(req.query.location_id) ?
                req.query.location_id.map(id => parseInt(id)) :
                req.query.location_id.split(',').map(id => parseInt(id));

            whereobj.location_id = {
                [Op.in]: locationIds,
            };
        }
        if (req.query.building_id) {
            const buildingIds = Array.isArray(req.query.building_id) ?
                req.query.building_id.map(id => parseInt(id)) :
                req.query.building_id.split(',').map(id => parseInt(id));

            whereobj.building_id = {
                [Op.in]: buildingIds,
            };
        }
        if (req.query.floor_id) {
            const floorIds = Array.isArray(req.query.floor_id) ?
                req.query.floor_id.map(id => parseInt(id)) :
                req.query.floor_id.split(',').map(id => parseInt(id));

            whereobj.floor_id = {
                [Op.in]: floorIds,
            };
        }
        if (req.query.room_id) {
            const roomIds = Array.isArray(req.query.room_id) ?
                req.query.room_id.map(id => parseInt(id)) :
                req.query.room_id.split(',').map(id => parseInt(id));

            whereobj.room_id = {
                [Op.in]: roomIds,
            };
        }
        if (req.query.startdate && req.query.enddate) {
            const startDate = new Date(req.query.startdate);
            const endDate = new Date(req.query.enddate);


            const startDateTime = req.query.startdate;
            const endDateTime = req.query.enddate;

            const [startdate, starttime1] = startDateTime.split('T');
            const [enddate, endtime1] = endDateTime.split('T');
            whereobj = {
                [Op.and]: [
                    whereobj,
                    {
                        booking_date: {
                            [Op.between]: [startDate, endDate],
                        },
                        booking_end_date: {
                            [Op.between]: [startDate, endDate],
                        },
                        [Op.or]: [{
                                starttime: {
                                    [Op.between]: [starttime1, endtime1]
                                }
                            },
                            {
                                endtime: {
                                    [Op.between]: [starttime1, endtime1]
                                }
                            }
                        ]
                    }
                ]
            };
        }

        let includeArray = [{
            model: db.crbt_locations,
            as: "crbt_locations",
            attributes: ['location_id', 'location_name'],
            required: true
        }, {
            model: db.crbt_buildings,
            as: "crbt_buildings",
            attributes: ['building_id', 'building_name'],
            required: true
        }, {
            model: db.crbt_floors,
            as: "crbt_floors",
            attributes: ['floor_id', 'floor_name'],
            required: true
        }, {
            model: db.crbt_users,
            as: "crbt_users",
            attributes: ['user_id', 'first_name', 'email', 'mobile_number'],
            required: true
        }, {
            model: db.crbt_rooms,
            as: "crbt_rooms",
            attributes: ['room_id', 'room_name'],
            required: true
        }];

        let results = await db.crbt_bookings.findAll({
            attributes: ['booking_id', 'room_id', 'user_id', 'starttime', 'endtime', 'booking_date', 'booking_end_date', 'title_of_meeting', 'status'],
            where: whereobj,
            raw: true,
            include: includeArray
        });


        const resultsWithAmenities = await Promise.all(results.map(async result => {
            const amenities = await db.crbt_room_amenities.findAll({
                attributes: ['amenity_id'],
                where: { room_id: result.room_id },
            });
            const amenitiesIds = amenities.map(amenity => amenity.amenity_id);
            const amenity_where_obj = {
                amenityid: {
                    [Op.in]: amenitiesIds,
                }
            };
            if (req.query.amenities) {
                const amenitiesIds = Array.isArray(req.query.amenities) ?
                    req.query.amenities.map(id => parseInt(id)) :
                    req.query.amenities.split(',').map(id => parseInt(id));

                amenity_where_obj.amenityid = {
                    [Op.in]: amenitiesIds,
                };
            }
            const amenities_data = await db.crbm_aminities.findAll({
                attributes: ['amenityid', 'thumbnail_key'],
                where: amenity_where_obj,
            });
            const partipants = await db.crbt_participants.findAll({
                attributes: ['user_id'],
                where: { booking_id: result.booking_id }
            });
            const userData = await Promise.all(partipants.map(async user => {
                const userInfo = await db.crbt_users.findAll({
                    attributes: ['user_id', 'email', 'first_name'],
                    where: { user_id: user.user_id },
                });
                return userInfo;
            }));

            return {
                ...result,
                amenities_data: amenities_data.flat(),
                start_endtime: `${formatTime(result.starttime)}-${formatTime(result.endtime)}`,
                start_endDate: formatDateRange(result.booking_date, result.booking_end_date),
                participants: userData.flat()
            };
        }));
        return res.status(200).send({ status: true, message: 'My Booking Details', results: resultsWithAmenities });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
};




let bookingAcceptReject = async function(req, res, next) {
    try {
        const sys_user_id = req.user.system_user_id
        if (req.query.type === 'accept') {
            let systemData = await db.crbt_bookings.findOne({
                attributes: ['user_id'],
                where: { "booking_id": req.query.booking_id },
                raw: true
            })

            let userData = await db.crbt_users.findOne({
                attributes: ['email'],
                where: { "user_id": systemData.user_id },
                raw: true
            })

            await db.crbt_participants.update({
                participants_status: 'accepted'
            }, {
                where: {
                    user_id: req.user.user_id,
                    booking_id: req.query.booking_id
                },
            })
            const user_Data = req.user.user_id;
            const user_emailid = req.user.email;

            let emailData = {
                subject: 'Meeting Accepted',
                title_of_meeting: ' meeting',
                organizer: user_Data,
                hbs: 'acceptMeeting'

            };
            const emailBody = emailTemplate(emailData);
            emailData.email = userData.email;
            emailData.html = emailBody;
            await rabbitmq.sendMessage(emailData)
            await rabbitmq.consumeMessages()
        }
        if (req.query.type === 'reject') {

            await db.crbt_participants.update({
                participants_status: 'rejected'
            }, {
                where: {
                    booking_id: req.query.booking_id,
                    user_id: req.user.user_id
                },
            })
            const user_Data = req.user.user_id;
            let systemData = await db.crbt_bookings.findOne({
                attributes: ['user_id'],
                where: { "booking_id": req.query.booking_id },
                raw: true
            })

            let userData = await db.crbt_users.findOne({
                attributes: ['email'],
                where: { "user_id": systemData.user_id },
                raw: true
            })

            let emailData = {
                subject: 'Meeting Rejected',
                title_of_meeting: ' vetti meeting',
                organizer: user_Data,
                hbs: 'rejectMeeting'

            };
            const emailBody = emailTemplate(emailData);
            emailData.email = userData.email;
            emailData.html = emailBody;
            await rabbitmq.sendMessage(emailData)
            await rabbitmq.consumeMessages()
        }
        return logger.success(res, "Participants status updated successfully");
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking Cancel");
    }
}
let getBookingDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        let setting = await db.crbt_bookings.findOne({
            attributes: [
                [Sequelize.fn("count", sequelize.col(`booking_id`)), 'settingCount'],
            ],
            where: {
                status: true
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.booking_id';
            var column_sort_order = 'desc';
        } else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }
        //var search_value = req ? .query ? .search['value'];
        var search_query = '';
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and  (d.booking_id = '${search_value}' OR d.room_id LIKE '%${search_value}%' OR  d.status::text LIKE '%${search_value}%' )`;
        }
        const degsearchdata = await sequelize.query(`select COUNT(d.booking_id) AS Total from crbt_bookings d where status='true'`);
        let query = `select d.booking_id,d.room_id,d.user_id,d.title_of_meeting,d.booking_date_time,d.purpose_of_booking,d.starttime,d.endtime,d.recurrence_frequency,d.notes,d.status from crbt_bookings d where status = 'true'  ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const degData = await sequelize.query(query);
        let data = [];
        if (degData[0].length != 0) {
            for (i = 0; i < degData[0].length; i++) {
                data.push({
                    booking_id: degData[0][i].booking_id,
                    room_id: degData[0][i].room_id,
                    user_id: degData[0][i].user_id,
                    title_of_meeting: degData[0][i].title_of_meeting,
                    booking_date_time: degData[0][i].booking_date_time,
                    purpose_of_booking: degData[0][i].purpose_of_booking,
                    starttime: degData[0][i].starttime,
                    endtime: degData[0][i].endtime,
                    recurrence_frequency: degData[0][i].recurrence_frequency,
                    notes: degData[0][i].notes,
                    status: degData[0][i].status,
                    action: `<div>
                    <span class='a-edit' catid='${degData[0][i].booking_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${degData[0][i].booking_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${degData[0][i].booking_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': setting.dataValues.settingCount,
            'iTotalDisplayRecords': degsearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}

let bookingNotification = async function() {
    try {
        var dt = new Date();
        let year = dt.getFullYear();
        let month = (dt.getMonth() + 1).toString().padStart(2, "0");
        let day = dt.getDate().toString().padStart(2, "0");
        let bb_time = dt.getHours() + ':' + dt.getMinutes().toString().padStart(2, "0") + ':' + dt.getSeconds().toString().padStart(2, "0");
        let date_time = year + '-' + month + '-' + day
        const [results] = await sequelize.query(
            `select crbt_bookings.*,STRING_AGG(email,','),starttime,starttime -interval '15 minutes' as time,booking_date
            from crbt_bookings
            join crbt_participants
            on crbt_bookings.booking_id = crbt_participants.booking_id
            join crbt_users
            on crbt_participants.user_id = crbt_users.user_id
            where (booking_status ='Booked' or booking_status ='Booked_reschemail_sent' )
            and booking_date='${date_time}'
            group by crbt_bookings.booking_id,starttime,booking_date`
        );
        // and starttime != '${bb_time}'
        const [reschedulemeetings] = await sequelize.query(
            `select crbt_bookings.*,STRING_AGG(email,','),starttime,starttime -interval '1 minutes' as time,booking_date
            from crbt_bookings
            join crbt_participants
            on crbt_bookings.booking_id = crbt_participants.booking_id
            join crbt_users
            on crbt_participants.user_id = crbt_users.user_id
            where booking_status='Booked'
            and reschedule_status = ${true}
            and booking_date='${date_time}'
            group by crbt_bookings.booking_id,starttime,booking_date`
        );
        const goodTime = `${new Date().getHours()}:${new Date().getMinutes()}`;
        let emailData = {
            subject: 'Notification Mail 15mins',
            title_of_meeting: 'Notification mail 15mins',
            // organizer: user_Data,
            hbs: 'notification'
        };
        const emailBody = emailTemplate(emailData);
        for (const result of results) {
            if (result.time == bb_time) {
                emailData.email = result.string_agg; //getting participants email id's
                emailData.html = emailBody;
                await rabbitmq.sendMessage(emailData)
                await rabbitmq.consumeMessages()
            }
            await db.crbt_bookings.update({
                booking_status: 'Booked_mail_sent'
            }, {
                where: {
                    booking_id: result.booking_id
                },
            });
        }
        let emailData1 = {
            subject: 'Rescheduled Mail',
            title_of_meeting: 'Rescheduled mail 1mins',
            // organizer: user_Data,
            hbs: 'rescheduledMeeting'
        };
        const emailBody1 = emailTemplate(emailData1);
        for (const result of reschedulemeetings) {
            emailData1.email = result.string_agg; //getting participants email id's
            emailData1.html = emailBody1;
            await rabbitmq.sendMessage(emailData1)
            await rabbitmq.consumeMessages()
            await db.crbt_bookings.update({
                booking_status: 'Booked_reschemail_sent'
            }, {
                where: {
                    booking_id: result.booking_id
                },
            });
        }
        return logger.success(res, "Email Notification sent successfully");
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking Email Notification");
    }
}

let getRoomCapacityandAmenities = async function (req,res,next) {  
    try { 
        let getroom = await db.crbt_rooms.findOne({
            where: { roomid:req.query.room_id}
        })
        if(!getroom){
            return logger.error(res,"Room ID Not Found")
        }
        let room = await db.crbt_rooms.findAll({
            attributes: [["roomid","room_id"], "room_name","capacity",
                [Sequelize.literal('(SELECT ARRAY_AGG(json_build_object(\'amenityid\', amenityid,\'amenityname\', amenityname, \'thumbnail_key\', thumbnail_key)) FROM crbm_aminities JOIN crbt_room_amenities ON crbm_aminities.amenityid = crbt_room_amenities.amenity_id WHERE crbt_room_amenities.room_id = crbt_rooms.roomid::integer)'), 'amenities']   
        ],
            where: {
              status:true,
              roomid: req.query.room_id,
              system_user_id:req.systemUser.system_user_id
          },  
        order: [[db.crbt_rooms.rawAttributes.roomid, 'DESC']],   
        })
     
        if (getroom.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (getroom.system_user_id === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Room Data Retrived Successfully", room });
        }
    } 
    catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Room Data");
    }
} 

let getbookingsbyID = async function(req, res, next) {
    try {
        let whereobj = { 
            booking_id: req.query.booking_id 
        };  
        let getbooking = await db.crbt_bookings.findOne({
            where: { booking_id: req.query.booking_id }
        })
        if(!getbooking){
            return res.status(404).json({ success: false, message: 'No booking data found'});
        }
 
        if (!req.user.isAdmin) {
            whereobj.user_id = req.user.user_id;
        }

        let BookingData = await db.crbt_bookings.findOne({
            attributes: ['booking_id', 'room_id', 'duration', 'starttime', 'endtime', 'booking_date', 'booking_end_date', 'title_of_meeting', "description",'repeat'],
            where: whereobj,
            include: [{
                    model: db.crbt_rooms,
                    as: "crbt_rooms",
                    attributes: ['room_id', 'room_name','capacity','floor_id',['roomid','uroom_id']],
                    required: true
                },
                {
                    model: db.crbt_floors,
                    as: "crbt_floors",
                    attributes: ['floor_id', 'floor_name',['floorid','ufloor_id'],'building_id'],
                    required: true

                },
                {
                    model: db.crbt_locations,
                    as: "crbt_locations",
                    attributes: ['location_id', 'location_name',['locationid','ulocation_id']],
                    required: true
                },
                {
                    model: db.crbt_buildings,
                    as: "crbt_buildings",
                    attributes: ['building_id', 'building_name',['buildingid','ubuilding_id'],'location_id'],
                    required: true
                },
                {
                    model: db.crbt_users,
                    as: "crbt_users",
                    attributes: ['user_id', 'email', 'first_name'],
                    required: true
                },
                {
                    model: db.crbm_roomservice,
                    as: "crbm_roomservice",
                    attributes: [['serviceid','room_service_id'],'room_service_name'],
                    required: false,
                    on: db.sequelize.where(db.sequelize.cast(db.sequelize.col('crbt_bookings.room_service_id'), 'VARCHAR'), '=', db.sequelize.col('crbm_roomservice.serviceid'))
                }, 
            ]
        }); 
        if(BookingData!=null){   
            BookingData.dataValues.participents=[];         
            let participents = await db.crbt_participants.findAll({ 
                attributes: ['user_id'],
                where: {booking_id:BookingData.dataValues.booking_id},
                include: [  
                    {
                        model: db.crbt_users,
                        as: "crbt_users",
                        attributes: ['user_id',[Sequelize.literal("CONCAT(first_name,' ',last_name)"), 'full_name'],'employee_code'],
                        required: true
                    }  
                ]
            }); 
            BookingData.dataValues.participents=participents; 
        }
       
        // console.log(BookingData);
        if (BookingData!=null) { 
            return res.status(200).json({ status: true, message: 'Booking data retrieved successfully', data: BookingData });
        } else { 
            return res.status(200).json({ status: false, message: 'Permission Denied' });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Get Bookings");
    }
}



module.exports = {
    userBooking,
    EdituserBooking,
    bookingCancel,
    getBookingDataTable,
    bookingAcceptReject,
    getBookings,
    fetchStatus,
    changeBookingStatus,
    bookingNotification,
    availableRooms,
    availableSlots,
    mybookingFetch,
    invitedBooking,
    manageBooking,
    booking_list_view,
    getRoomCapacityandAmenities, 
    getbookingsbyID,
    fetchRoomDetails
};