var db = require('../../models/index')
const logger = require('../../../utils/winston')
const { validateParams, validateFields } = require('../../../middleware/validators')

function detectNumeric(obj) {
    for (var index in obj) {
        if (/^\s*$/.test(obj[index])) {
            // Skip empty strings or multiple spaces
            continue;
        }
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj[index] === "object") {
            detectNumeric(obj[index]);
        }
    }
}

function validateArray(data) {
    for (let i = 0; i < data.length; i++) {
        if (typeof data[i] !== 'number' || !Number.isInteger(data[i])) {
            return false; // Invalid element found, return false
        }
    }
    return true; // All elements are valid integers
}

const userBooking = async function(req, res, next) {
    try {
        console.log(req.body)
        await detectNumeric(req.body); 
        console.log(req.body)
        const { room_id, title_of_meeting, starttime, endtime, repeat, description, status, participants_id, location_id, building_id, floor_id, booking_date, duration, room_service_id } = req.body;
        const requiredParams = ['room_id', 'title_of_meeting', 'starttime', 'endtime', 'repeat', 'description', 'status', 'participants_id', 'location_id', 'building_id', 'floor_id', 'booking_date', 'duration', 'room_service_id'];
        for (const param of requiredParams) {
            if (typeof req.body[param] === 'undefined') {
                return logger.error(res, `${param} parameter is missing`);
            }
        }
        const fields = [
            { field: room_id, fieldName: 'Room Id' },
            { field: title_of_meeting, fieldName: 'Title of the Meeting' },
            { field: starttime, fieldName: 'Start time' },
            { field: endtime, fieldName: 'End time' },
            { field: repeat, fieldName: 'repeat' },
            { field: location_id, fieldName: 'location id' },
            { field: description, fieldName: 'Description' },
            { field: status, fieldName: 'status' },
            { field: participants_id, fieldName: 'participants id' }, { field: location_id, fieldName: 'location id' }, { field: building_id, fieldName: 'building id' }, { field: floor_id, fieldName: 'floor id' }, { field: booking_date, fieldName: 'booking date' }, { field: room_service_id, fieldName: 'room service id' }

        ];
        if (fields.some(({ field, fieldName }) => !field)) {
            const missingField = fields.find(({ field }) => !field);
            return logger.error(res, `${missingField.fieldName} cannot be empty`);
        }
        if (/^\s*$/.test(req.body.room_id)) {
            return logger.error(res, "Room Id cannot be empty");
        }
        if (/^\s*$/.test(req.body.title_of_meeting)) {
            return logger.error(res, "Title of the meeting cannot be empty");
        }
        if (/^\s*$/.test(req.body.starttime)) {
            return logger.error(res, "Start time cannot be empty");
        }
        if (/^\s*$/.test(req.body.endtime)) {
            return logger.error(res, "End time cannot be empty");
        }
        if (/^\s*$/.test(req.body.repeat)) {
            return logger.error(res, "Repeat cannot be empty");
        }
        if (isNaN(req.body.room_id)) {
            return logger.error(res, "Invalid data type for room id. Only number are allowed.");
        }
        // const pattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
        // if (pattern.test(starttime)) {
        //     console.log("valid format.");
        // } else {
        //     return logger.error(res, "Invalid date and time");
        // }
        // if (pattern.test(endtime)) {
        //     console.log("valid format.");
        // } else {
        //     return logger.error(res, "Invalid date and time");
        // } 
        if(!Array.isArray(req.body.participants_id)){
            req.body.participants_id=[req.body.participants_id]
        }
        if (Array.isArray(req.body.participants_id) && validateArray(req.body.participants_id)) {
            console.log('Valid array of integers.');
        } else {
            return logger.error(res, "Invalid array format or contains non-integer element.");
        }
        next();
    } catch (error) {
        console.log('Create Booking error', error);
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking validation");
    }
}

const EdituserBooking = async function(req, res, next) {
    try {
        await detectNumeric(req.body); 
        const { booking_id, room_id, title_of_meeting, starttime, endtime, repeat, description, status, participants_id, location_id, building_id, floor_id, booking_date, duration, room_capacity, room_service_id } = req.body;
        const requiredParams = ['booking_id', 'room_id', 'title_of_meeting', 'starttime', 'endtime', 'repeat', 'description', 'status', 'participants_id', 'location_id', 'building_id', 'floor_id', 'booking_date', 'duration', 'room_capacity', 'room_service_id'];
        for (const param of requiredParams) {
            if (typeof req.body[param] === 'undefined') {
                return logger.error(res, `${param} parameter is missing`);
            }
        }
        const fields = [
            { field: booking_id, fieldName: 'Booking Id' },
            { field: room_id, fieldName: 'Room Id' },
            { field: title_of_meeting, fieldName: 'Title of the Meeting' },
            { field: starttime, fieldName: 'Start time' },
            { field: endtime, fieldName: 'End time' },
            { field: repeat, fieldName: 'repeat' },
            { field: location_id, fieldName: 'location id' },
            { field: description, fieldName: 'Description' },
            { field: status, fieldName: 'status' },
            { field: participants_id, fieldName: 'participants id' }, { field: location_id, fieldName: 'location id' }, { field: building_id, fieldName: 'building id' }, { field: floor_id, fieldName: 'floor id' }, { field: booking_date, fieldName: 'booking date' }, { field: room_capacity, fieldName: 'room capacity' }, { field: room_service_id, fieldName: 'room service id' }


        ];
        if (fields.some(({ field, fieldName }) => !field)) {
            const missingField = fields.find(({ field }) => !field);
            return logger.error(res, `${missingField.fieldName} cannot be empty`);
        }
        if (/^\s*$/.test(req.body.booking_id)) {
            return logger.error(res, "Booking Id cannot be empty");
        }
        if (/^\s*$/.test(req.body.room_id)) {
            return logger.error(res, "Room Id cannot be empty");
        }
        if (/^\s*$/.test(req.body.title_of_meeting)) {
            return logger.error(res, "Title of the meeting cannot be empty");
        }
        if (/^\s*$/.test(req.body.starttime)) {
            return logger.error(res, "Start time cannot be empty");
        }
        if (/^\s*$/.test(req.body.endtime)) {
            return logger.error(res, "End time cannot be empty");
        }
        if (/^\s*$/.test(req.body.repeat)) {
            return logger.error(res, "repeat cannot be empty");
        }
        if (isNaN(req.body.booking_id)) {
            return logger.error(res, "Invalid data type for Booking id. Only number are allowed.");
        }
        if (isNaN(req.body.room_id)) {
            return logger.error(res, "Invalid data type for room id. Only number are allowed.");
        }
        const existingBooking = await db.crbt_bookings.findOne({
            attributes:["booking_id","status"],
            where: {
                booking_id: req.body.booking_id
            },
        });
        if (!existingBooking) {
            return logger.error(res, "Booking id does not exist..!");
        }


        // const pattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
        // if (pattern.test(starttime)) {
        //     console.log("valid format.");
        // } else {
        //     return logger.error(res, "Invalid date and time");
        // }
        // if (pattern.test(endtime)) {
        //     console.log("valid format.");
        // } else {
        //     return logger.error(res, "Invalid date and time");
        // }
        if(!Array.isArray(req.body.participants_id)){
            req.body.participants_id=[req.body.participants_id]
        }
        if (Array.isArray(req.body.participants_id) && validateArray(req.body.participants_id)) {
            console.log('Valid array of integers.');
        } else { 
        console.log( req.body.participants_id,'veliadtion error',typeof req.body.participants_id)
            return logger.error(res, "Invalid array format or contains non-integer element.");
        }
        next();
    } catch (error) {
        console.log('Create Booking error', error);
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Booking validation");
    }
}

const bookingCancel = async function(req, res, next) {
    try {
        detectNumeric(req.body);
        console.log(req.body)
        if (typeof req.body.booking_id == 'undefined') {
            return logger.error(res, 'Booking ID  parameter is missing');
        }
        if (/^\s*$/.test(req.body.booking_id)) {
            return logger.error(res, "Booking ID cannot be empty");
        }
        let bookingData = await db.crbt_bookings.findOne({
            attributes: ["booking_id"],
            where: { booking_id: req.body.booking_id }
        });
        if (bookingData != null) {
            if (bookingData.booking_id !== req.body.booking_id) {
                return logger.error(res, "Booking ID is  not exists");
            }
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Booking Cancel validation");
    }
}

const bookingAcceptReject = async function(req, res, next) {
    try {
        detectNumeric(req.query);
        if (typeof req.query.booking_id == 'undefined') {
            return logger.error(res, 'Booking ID  parameter is missing');
        }
        if (typeof req.query.type == 'undefined') {
            return logger.error(res, 'Type parameter is missing');
        }
        if (/^\s*$/.test(req.query.booking_id)) {
            return logger.error(res, "Booking ID cannot be empty");
        }
        if (/^\s*$/.test(req.query.type)) {
            return logger.error(res, "Type cannot be empty");
        }
        let bookingData = await db.crbt_bookings.findOne({
            attributes: ["booking_id"],
            where: { booking_id: req.query.booking_id }
        });
        if (bookingData != null) {
            if (bookingData.booking_id !== req.query.booking_id) {
                return logger.error(res, "Booking ID is  not exists");
            }
        }
        let Permission = await db.crbt_participants.findOne({
            attributes: ["booking_id", "user_id"],
            where: { booking_id: req.query.booking_id, user_id: req.user.user_id }
        });
        if (!Permission) {
            return logger.error(res, "Permission Denied");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Booking Cancel validation");
    }
}
const availableRooms = async function(req, res, next) {
    try {
        detectNumeric(req.query);

        const requiredParams = ['startDate', 'endDate'];
        const missingParams = validateParams(requiredParams, req.query);
        if (missingParams.length > 0) {
            const missingField = missingParams[0];
            return logger.error(res, `${missingField} parameter is missing`);
        }

        const missingField = validateFields(req.query, requiredParams);
        if (missingField) {
            return logger.error(res, `${missingField} cannot be empty`);
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in available room validation");
    }
}

const getbookingbyid =async function(req,res,next)
{
    try {
        await detectNumeric(req.body);

        if (typeof req.query.booking_id=='undefined') {
            return logger.error(res,"Parameter Missing");
        }
        if (/^\s*$/.test(req.query.booking_id)) {
            return logger.error(res, "Booking ID cannot be empty");
        } 
        if (!Number(req.query.booking_id)) {
            return logger.error(res, "Invalid input Booking ID cannot be String");
        }
        let getbooking = await db.crbt_bookings.findOne({
            attributes: ['booking_id'],
            where: { booking_id: req.query.booking_id },
        });
        if (!getbooking) {
            return logger.error(res, "Booking ID not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Retrieving Booking.");
    }

}


module.exports = {
    userBooking,
    EdituserBooking,
    bookingCancel,
    bookingAcceptReject,
    availableRooms,
    getbookingbyid
}