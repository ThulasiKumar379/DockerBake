var env = require('../../../config/environment');
var db = require('../../models/index')
var jwt = require('jsonwebtoken')
var bcrypt = require('bcrypt');
const logger = require('../../../utils/winston')
const emailer = require('../../../lib/email/mailer')
var { sequelize } = require('../../models/index')
let login = async function (req, res, next) {
    try {
        let userdata = await db.crbt_users.findOne({
            attributes: ["system_user_id", "email", "password", "user_id", "role_id", "first_name", "last_name"],
            where: { email: req.body.email, isactive: true },
        });
        if (userdata != null) {
            bcrypt.compare(req.body.password, userdata.dataValues.password).then(async function (match) {
                if (match) {
                    let data = [];
                    let sysUserPermission = await sequelize.query(`select p.key,p.name from userpermissions up left join permissions 
                    p on p.id=up.permission_id where p.status='true' and role_id=${userdata.dataValues.role_id}`
                    )
                    if (sysUserPermission[0].length != 0) {
                        for (i = 0; i < sysUserPermission[0].length; i++) {
                            data.push({
                                key: sysUserPermission[0][i].key
                            });
                        }
                    }
                    return logger.success(res, "user loggedin", 
                    {username: userdata.dataValues?.first_name!=null?userdata.dataValues?.first_name:''+' '+ userdata.dataValues?.last_name!=null?userdata.dataValues?.last_name:''
                    ,permissions:data,token:jwt.sign({userdata},env.jwtkey.end_user_key,{ expiresIn: env.expiresIn })});
                } else {
                    return res.json({ success: false, message: "authentication failed" });
                }
            });
        } else {
            return logger.error(res, "Email does not Exist.");
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in admin login");
    }
}

let getPermissionsByUserID = async function (req, res, next) {
    try {
        let userdata = await db.crbt_users.findOne({
            attributes: ["role_id",],
            where: { user_id: req.user.user_id, isactive: true },
        });
        if (userdata != null) {
            let data = [];
            let sysUserPermission = await sequelize.query(`select p.key,p.name from userpermissions up left join permissions 
                    p on p.id=up.permission_id where p.status='true' and role_id=${userdata.dataValues.role_id}`
            )
            if (sysUserPermission[0].length != 0) {
                for (i = 0; i < sysUserPermission[0].length; i++) {
                    data.push({
                        key: sysUserPermission[0][i].key
                    });
                }
            }
            return logger.success(res, "user persmissions", { permissions: data });


        } else {
            return logger.error(res, "user not exist in database");
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in permission fetching by id");
    }
}


let signUp = async function (req, res, next) {
    const t = await db.sequelize.transaction();
    try {
        let insertdata = {
            company_gst_number: req.body.company_gst_number,
            company_name: req.body.company_name,
            company_officialwebsite: req.body.company_officialwebsite,
            company_address: req.body.company_address,
            username: req.body.username,
            email: req.body.email,
            phone_number: req.body.phone_number,
            status: true,
            termsandconditions_accepted: req.body.termsandconditions_accepted
        };

        const hash = await new Promise((resolve, reject) => {
            bcrypt.hash(req.body.password, env.saltRounds, (err, hash) => {
                if (err) reject(err);
                resolve(hash);
            });
        });
        insertdata.password = hash;

        const systemUserData = await db.crbt_system_users.create(insertdata, { transaction: t });
        const role = await db.crbt_roles.create({
            role_name: 'ADMIN',
            system_user_id: systemUserData.dataValues.system_user_id,
            created_by: systemUserData.dataValues.system_user_id,
            status: true
        }, { transaction: t });

        let userpermissions = [];
        const permissions = await db.permissions.findAll({
            attributes: ["id"]
        });

        permissions.forEach((item) => {
            userpermissions.push({ "permission_id": item.id, role_id: role.dataValues.role_id });
        });

        await db.userpermissions.bulkCreate(userpermissions, { transaction: t });

        const userData = await db.crbt_users.create({
            first_name: req.body.company_name,
            email: req.body.email,
            
            mobile_number: req.body.phone_number,
            isactive: true,
            password: hash,
            role_id: role.dataValues.role_id,
            system_user_id: systemUserData.system_user_id
        }, { transaction: t });

        await t.commit();

        if (systemUserData && userData) {
            return res.status(200).send({ status: true, message: "Data inserted successfully in Signup"});
        } else {
            return logger.error(res, "Error in signup");
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        await t.rollback();
        return logger.error(res, "Exception in Sign Up");
    }
};


let emailVerification = async function (req, res, next) {
    try {
        let userdata = await db.crbt_system_users.findOne({
            attributes: ["system_user_id", "company_name", "email", "email_verify", "password", "username"],
            where: { email: req.body.email },
        });
        let token = jwt.sign({ userdata }, env.jwtkey.system_user_key, { expiresIn: env.expiresIn })
        if (token && userdata) {
            emailer.sendEmail({ subject: "CRB welcomes you-Signed up successfully!!!", "name": userdata.username, "username": userdata.username, "password": userdata.password, "companyname": userdata.companyname },
                'verificationEmail', { email: userdata.email });
            await db.crbt_system_users.update({
                email_verify: true
            }, {
                where: {
                    email: req.body.email
                },
            })
        }
        return logger.success(res, "system user  updated successfully");
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in emailVerify api");
    }
}


const generateOTP = () => {
    // Generate a random 6-digit OTP
    return Math.floor(100000 + Math.random() * 900000).toString();
};


let forgotPassword = async function (req, res, next) {
    try {
        // Find the user by email
        let userdata = await db.crbt_users.findOne({
            attributes: ["user_id", "email", "first_name"],
            where: { email: req.query.email },
        });

        if (!userdata) {
            return logger.error(res, "User not found");
        }

        // Generate an OTP
        const otp = generateOTP();

        // Create a JWT token
        const token = jwt.sign({ email: userdata.email }, env.jwtkey.system_user_key, { expiresIn: '1h' });

        console.log("email token :", token)

        let data = await db.crbt_users.update(
            { otp: otp, reset_token: token },
            {
                where: {
                    user_id: userdata.user_id,
                },
            }
        );
        emailer.sendEmail({
            subject: "CRB Password Reset OTP",
            name: userdata.first_name,
            otp: otp,
            token: token,
        }, 'views/otpResetEmail', { email: userdata.email });

        // Store the token in the local storage
        // localStorage.setItem('token', token);

        return logger.success(res, "OTP and token sent successfully", token);
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in forgotPassword API");
    }
}

// Add a new route to handle OTP verification and password update
let verify_otp = async function (req, res, next) {
    try {
        const { otp } = req.query;
        console.log("Received OTP:", otp);

        if (!otp) {
            return logger.error(res, "Invalid OTP");
        }
        // Find the user by email
        let userdata = await db.crbt_users.findOne({
            attributes: ["user_id", "otp"],
            where: { otp: otp },
        });

        if (!userdata) {
            return logger.error(res, "Invalid OTP or email");
        }

        await db.crbt_users.update(
            { otp: null },
            {
                where: {
                    user_id: userdata.user_id,
                },
            }
        );

        return logger.success(res, "Password updated successfully");
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in verifyOTP API");
    }
};

let changeSysPassword = async function (req, res, next) {
    try {
        const { newPassword, confirmPassword, reset_token } = req.body;
        if (newPassword !== confirmPassword) {
            return logger.error(res, "New password and confirm password do not match");
        }
        const decodedToken = jwt.verify(reset_token, env.jwtkey.system_user_key);
        const userEmail = decodedToken.email;
        console.log(decodedToken);
        const userdata = await db.crbt_users.findOne({
            attributes: ["email"],
            where: { email: userEmail },
        });

        if (!userdata) {
            return logger.error(res, "User not found");
        }
        // Hash the new password
        const hash = await bcrypt.hash(newPassword, env.saltRounds);

        // Update the user's password with the hashed version and clear the reset token
        await db.crbt_users.update(
            { password: hash },
            {
                where: {
                    email: userEmail,
                },
            }
        );

        return logger.success(res, "Password updated successfully");
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in updatePassword API");
    }
};







module.exports = {
    login,
    signUp,
    emailVerification,
    forgotPassword,
    verify_otp,
    changeSysPassword,
    getPermissionsByUserID
};