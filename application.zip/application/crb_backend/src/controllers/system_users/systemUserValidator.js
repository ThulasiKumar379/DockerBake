var db = require('../../models/index')
const logger = require('../../../utils/winston')
var env = require('../../../config/environment');
var jwt = require('jsonwebtoken')
function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}
const login = async function (req, res, next) {   
    try {   
        if (typeof req.body.email == 'undefined' || typeof req.body.password == 'undefined') {
            return logger.error(res, "email or password parameter is missing");
        }
        if (!req.body.email) {
            return logger.error(res, "email is cannot be empty.");
        }
        if (!req.body.password) {
            return logger.error(res, "password is cannot be empty.");
        }
        if (!ValidateEmail(req.body.email)) {
            return logger.error(res,"Invalid email");
        }
        next();
    } catch (error) {
        console.log('error',error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in login");
    }
}
const signUp = async function (req, res, next) {
    try {
        // detectNumeric(req.body);
        if (typeof req.body.company_address=='undefined'||req.body.company_name == 'undefined'
            ||req.body.username=='undefined'||req.body.password=='undefined'||req.body.email=='undefined') {
            return logger.error(res, 'Some parameter is missing');
        }      
        if (!req.body.company_name) {
            return logger.error(res, 'Comapany name cannot be empty');
        }  
        if (!req.body.company_address) {
            return logger.error(res, 'Comapany address cannot be empty');
        }
        if (!req.body.username) {
            return logger.error(res, 'User name cannot be empty');
        }
        if (!req.body.password) {
            return logger.error(res, 'password cannot be empty');
        }
        if (!req.body.email) {
            return logger.error(res, 'emailid cannot be empty');
        }
        if (!req.body.phone_number) {
            return logger.error(res, 'Phone No cannot be empty');
        }   
        let userdataEmail = await db.crbt_system_users.findOne({
            attributes: ["email"],
            where: { email: req.body.email}
        });
        if (userdataEmail != null) {
            if (userdataEmail.email === req.body.email) {
                return logger.error(res, "Email already exists");
            }
        }
        let userdataGst = await db.crbt_system_users.findOne({
            attributes: ["company_gst_number"],
            where: { company_gst_number: req.body.company_gst_number}
        });
        if (userdataGst != null) {
            if (userdataGst.company_gst_number === req.body.company_gst_number) {
                return logger.error(res, "GST number already exists");
            }
        }
        let userdataCompanyName = await db.crbt_system_users.findOne({
            attributes: ["company_name",],
            where: { company_name: req.body.company_name}
        });
        if (userdataCompanyName != null) {
            if (userdataCompanyName.company_name === req.body.company_name) {
                return logger.error(res, "Company Name already exists");
            }
        }
        let userdataName = await db.crbt_system_users.findOne({
            attributes: ["username"],
            where: { username: req.body.username}
        });
        if (userdataName != null) {
            if (userdataName.username === req.body.username) {
                return logger.error(res, "User Name already exists");
            }
        }
        let userdataPhone = await db.crbt_system_users.findOne({
            attributes: ["phone_number"],
            where: { phone_number: req.body.phone_number}
        });
        if (userdataPhone != null) {
            if (userdataPhone.phone_number === req.body.phone_number) {
                return logger.error(res, "Phone No already exists");
            }
        }
        next();
    } catch (error) {
        console.log('signup errror',error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in Signup validation");
    }
}
const emailVerification = async function (req, res, next) {
    try {
        detectNumeric(req.body);
        if (typeof req.body.email == 'undefined') {
            return logger.error(res, "email or password parameter is missing");
        }
        if (req.body.email=="") {
            return logger.error(res, "email is cannot be empty.");
        }
        if (!ValidateEmail(req.body.email)) {
            return logger.error(res,"Invalid email");
        }
        next();
    } catch (error) {
        console.log('error',error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in email_verify");
    }
}
function ValidateEmail(mail) 
{
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
    return (true)
  } 
    return (false)
}


  
module.exports={login,signUp,emailVerification}
