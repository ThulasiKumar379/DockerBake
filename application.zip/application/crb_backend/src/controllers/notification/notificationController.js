var db = require('../../models/index');
const logger = require('../../../utils/winston');
const emailer = require("../../../lib/email/mailer");

const getNotifications = async function (req, res, next) {
  try {
    console.log(req.user.user_id)
    let offset = 0;
    if (req.query.page > 1) {
      offset = (req.query.page - 1) * 20;
    } 
  
    const notifications = await db.crbt_notifications.findAndCountAll({
      attributes: ["notification_type", "user_id", "created_at"],
      offset: offset,
      limit: 20,
      where: { user_id: req.user.user_id },
      order: ['notification_type', 'message'],
    });  
    if (notifications.rows.length !== 0) {
      return logger.success(res, 'Notifications retrieved successfully', notifications);
    } else {
      return logger.success(res, 'No notifications found', notifications);
    }
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return logger.error(res, 'Exception in getting notification details');
  }
};

module.exports = {
    getNotifications
}





