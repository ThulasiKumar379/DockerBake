var db = require('../../models/index');
const logger = require('../../../utils/winston');


const getNotificationsValidator = async function (req, res, next) {
    try {
        if (typeof req.query.hit == 'undefined') {
            return logger.error(res,"hit query parameter is missing");
        }
        if (req.query.hit == "") {
            return logger.error(res,"hit value should not be empty");
        }
        if (!Number.isInteger(Number(req.query.hit))) {
            return logger.error(res,"Invalid hit value");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res,"Exception in get Notifications Validator details");
    }
}

module.exports = {
    getNotificationsValidator
}