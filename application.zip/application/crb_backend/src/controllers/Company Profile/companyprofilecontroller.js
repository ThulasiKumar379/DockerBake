var db = require('../../models/index')
const logger = require('../../../utils/winston')
var { sequelize } = require('../../models/index');
var bcrypt = require('bcrypt');
var env = require('../../../config/environment');
const { Sequelize, Op } = require("sequelize");
const multer = require('multer');
const { S3bucketupload, deleteProfilePic } = require('../../../lib/s3/s3'); 
var fs = require('fs')
const AWS = require('aws-sdk');
var jwt = require('jsonwebtoken')
const path = require('path');

let getcompanyprofile = async function(req, res, next) {
    try {
        let getdata = await db.crbt_system_users.findAll({
            attributes: ["company_name","company_address","email","key","phone_number"],
            order: [
                ['system_user_id', "ASC"]
            ],
            where: {
                status: true,
                system_user_id: req.systemUser.system_user_id
            }
        })
        if (getdata.length === 0) {
            return res.status(400).send({ status: false, message: "No Data available", getdata });
        } else {
            return res.status(200).send({ status: true, message: "Data retrived successfully", getdata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Company Profile");
    }
}

let editcompanyprofile = async function(req, res, next) {
    try {
        let profiledata = await db.crbt_system_users.findOne({
            where: { system_user_id: req.systemUser.system_user_id }
        });
        if (!profiledata) {
            return res.status(400).send({ status: false, message: "Profile not found" });
        }
        

        let updateprofile = {
            email:req.body.email,
            company_name:req.body.company_name,
            company_address: req.body.company_address,
            phone_number: req.body.phone_number,
            updated_at: Date.now(),
            updated_by: req.systemUser.system_user_id
        };
        if (req.body.password) {
            bcrypt.hash(req.body.password, env.saltRounds, async (err, hash) => {
                if (err) {
                    return res.status(500).send({ status: false, message: "Error hashing password" });
                }
                updateprofile.password = hash;

                await db.crbt_system_users.update(updateprofile, {
                    where: {
                        status:true,
                        system_user_id: req.systemUser.system_user_id
                    }
                });

                return res.status(200).send({ status: true, message: "Data updated successfully",updateprofile });
            });
        } else {
            await db.crbt_system_users.update(updateprofile, {
                where: {
                    status:true,
                    system_user_id: req.systemUser.system_user_id
                }
            });
            return res.status(200).send({ status: true, message: "Organization profile updated"});
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Company Profile update");
    }
};


  var storage = multer.diskStorage({ 
    destination: function (req, file, cb) {
        cb(null, './uploads/organisationlogo')
    },
    filename: function (req, file, cb) {
      const uniquePrefix = req.systemUser.system_user_id+Date.now();
        req.orglogo= uniquePrefix+".jpg"; 
      cb(null, req.orglogo);
    }
  })
  const maxSize = 1 * 1000 * 1000;
  var upload = multer({ 
    storage: storage,
    limits: { fileSize: maxSize },
    fileFilter: function (req, file, cb){ 
        var filetypes = /jpeg|jpg|png/;
        var mimetype = filetypes.test(file.mimetype);  
        var extname = filetypes.test(path.extname(
                    file.originalname).toLowerCase());
        
        if (mimetype && extname) {
            return cb(null, true);
        } 
        cb("Error: File upload only supports the "
                + "following filetypes - " + filetypes);
      }  
  }).single("organisation_logo");
  
  let uploadtoS3bucket = async function (req, res, next) {
    try {
      await fs.mkdir("./uploads/organisationlogo",{ recursive: true },function(err) {
        if (err) {
           
        } else {
            
        }
      });
      return upload(req,res,function(err) { 
        if(err) { 
            res.send({status:false,errorMessage:err})
        }
        else { 
            next();
        }
    }) 
    } catch (error) {
      logger.createLog(__filename, error.message, req); 
      return logger.error(res, "Exception in Uploading");
    }
  }
  
  let uploadlogo = async function (req, res, next) {
    try {
      let uploadpath="./uploads/organisationlogo/"+req.orglogo;
      let key="organisationlogo/"+req.orglogo; 
      S3bucketupload(key,uploadpath).then(async function(data){ 
        fs.unlink(uploadpath, async (err) => {
          if (err) {
            console.error(err)
            return err;
          } else{
          let logo= await db.crbt_system_users.findOne({
                       where:{system_user_id:req.systemUser.system_user_id,status:true}
                   });
           if(logo!=null){
               await db.crbt_system_users.update({
                   key:key
               },{
                   where:{ 
                       system_user_id:req.systemUser.system_user_id,
                       status:true
                   }
               });  
               console.log(logo.dataValues.key);
               deleteProfilePic(logo.dataValues.key);
           }else{
              await db.crbt_system_users.create({ 
                   system_user_id:req.systemUser.system_user_id,
                   key:key,
               });  
           }  
          }
      })
  });
        return logger.success(res,"Logo updated successfully",key);
        } catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Logo Update");
        }
  };

let getuserDataTable = async function(req, res, next) {
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order;
        console.log(order_data)
        let dep = await db.crbt_users.findOne({
            attributes: [[Sequelize.fn("count", sequelize.col(`system_user_id`)), 'profileCount'],
            ],where:{
                status:true,system_user_id:req.systemUser.system_user_id
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.system_user_id';
            var column_sort_order = 'desc';
        }
        else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }
    
        var search_value = req.query.search['value'];
        var search_query = '';
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and system_user_id=${req.systemUser.system_user_id} and  (d.system_user_id::text = '${search_value}' OR LOWER(d.employee_code)::text LIKE '%${search_value}%' OR  d.status::text LIKE '%${search_value}%' )`;
        }
        const profilesearchdata = await sequelize.query(`select COUNT(d.system_user_id) AS Total from crbt_users d where status = 'true' ${search_query}`);
        let query = `select  d.system_user_id,d.employee_code,d.status from crbt_users d where status = 'true' ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const degData = await sequelize.query(query);
        let data = [];
        if (degData[0].length != 0) {
            for (i = 0; i < degData[0].length; i++) {
                data.push({
                    system_user_id: degData[0][i].system_user_id,
                    employee_code : degData[0][i].employee_code ,
                    status: degData[0][i].status,
                    action: `<div> 
                    <span class='a-edit' catid='${degData[0][i].system_user_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${degData[0][i].system_user_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${degData[0][i].system_user_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': dep.dataValues.profileCount,
            'iTotalDisplayRecords': profilesearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
}




module.exports = {
    getuserDataTable,
    getcompanyprofile,
    editcompanyprofile,
    uploadtoS3bucket,
    uploadlogo
};