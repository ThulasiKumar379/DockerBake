var db = require('../../models/index')
const logger = require('../../../utils/winston')
const { Sequelize, Op } = require("sequelize");


const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
let editprofileData = async function(req, res, next) {
    try {
        if (!req.body.company_address || 
            !req.body.phone_number || 
            !req.body.company_name || 
            !req.body.email) {
            return logger.error(res, "Please enter all the fields");
        }
        if (typeof req.body.company_address == 'undefined' ||  
            typeof req.body.phone_number  == 'undefined' || 
            typeof req.body.company_name  == 'undefined' || 
            typeof req.body.email  == 'undefined') {
            return logger.error(res, "Parameters are missing");
        }
        const company_address = req.body.company_address;
        if (company_address && company_address.length > 255) {
            return res.status(400).send({ status: false, message: 'Company Address exceeds maximum length of 255 characters' });
        }

        if (typeof req.body.company_address !== 'string') {
            return logger.error(res, "Invalid Input");
        }
 
        let existingUser = await db.crbt_system_users.findOne({
            attributes: ['system_user_id'],
            where: { phone_number: req.body.phone_number }
        });
        if (existingUser && existingUser.system_user_id !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: 'Phone Number already exists' });
        }

        let departmentEdittt = await db.crbt_system_users.findOne({
            attributes: ['system_user_id', 'status'],
            where: { system_user_id: req.systemUser.system_user_id, status: false },
        });
        if (departmentEdittt) {
            return logger.error(res, "Data doesn't exist");
        }

        let departmentEdit = await db.crbt_system_users.findOne({
            attributes: ['system_user_id'],
            where: { system_user_id: req.systemUser.system_user_id },
        });
        if (!departmentEdit) {
            return logger.error(res, "Data not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        console.log(error)
        return logger.error(res, "Exception in Company Profile update validation");
    }
}



module.exports = {
    editprofileData
}