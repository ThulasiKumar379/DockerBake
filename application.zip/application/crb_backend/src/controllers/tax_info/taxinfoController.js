var db = require("../../models/index");
const logger = require("../../../utils/winston");
const emailer = require("../../../lib/email/mailer");
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");

let createTaxInfo = async function (req, res, next) {
  try {
    let taxInfoData = {
      tax_name: req.body.tax_name,
      description: req.body.description,
      taxrate: req.body.taxrate,
      taxtype: req.body.taxtype,
      // system_user_id: req.systemUser.system_user_id,
    // status: req.body.status,
      // created_by: req.body.created_by,
    };

    return await db.crbm_tax_info.create(taxInfoData).then(function (data) {
      if (data) {
        return res.status(200).send({ status: true, message: "Tax info created successfully", data });
      } else {
        return logger.error(res, "Error creating tax info");
      }
    });
  } 
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return logger.error(res, "Exception in creating tax info");
  }
};

let updateTaxInfo = async function (req, res, next) {
  try {
    let taxInfo = await db.crbm_tax_info.findOne({
      where: { tax_id: req.body.tax_id },
    });

    if (!taxInfo) {
      return res.status(404).send({ status: false, message: "Tax info not found" });
    }
let updatedTaxInfo = await db.crbm_tax_info.update(
    {
    tax_name: req.body.tax_name,
    description: req.body.description,
    taxrate: req.body.taxrate,
    taxtype: req.body.taxtype,
    },
    {
        where: {
          tax_id: req.body.tax_id,
        },
      }
    );

    if (updatedTaxInfo[0] === 0) {
      return res.status(400).send({ status: false, message: "Permission Denied" });
    }return res.status(200).send({ status: true, message: "Tax info updated successfully" });
  }
  catch (error) {
    logger.createLog(__filename, error.message, req);
    return res.status(500).send({ status: false, message: "Exception in updating tax info" });
  }
};


let deleteTaxInfo = async function (req, res, next) {
  try { 
    const deletedtaxinfo = await db.crbm_tax_info.update(
        {  status:false
        },
        {
          where: {  
            tax_id: req.body.tax_id,
            // system_user_id: req.systemUser.system_user_id,
           
        },
        }
      );  
      return logger.success(res,"tax Deleted");
    } 
    catch (error) { 
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in delete taxinfo");
    }
}
   

  let getTaxInfo = async function (req, res, next) {
    try {
     let taxData = await db.crbm_tax_info.findAll({
       attributes: ["tax_name", "description", "taxrate","taxtype","status", "created_by"],
       order: [
         ['tax_id', "ASC"]
       ],
       where: {
         status: true,
        //  system_user_id: req.systemUser.system_user_id
       }
     })
     if (taxData.length === 0) {
       return res.status(400).send({ status: false, message: "TaxInfo not available", taxData });
     } else {
       return res.status(200).send({ status: true, message: "TaxInfo retrived successfully", taxData });
     }
   } 
   catch (error) {
     logger.createLog(__filename, error.message, req)
     return logger.error(res, "Exception in TaxInfo");
   }
 }

 let getTaxInfoDataTable = async function (req, res, next) { 
    try {
      var draw = req.query.draw;
      var start = req.query.start;
      var length = req.query.length;
      var order_data = req.query.order;
      console.log(order_data)
      let taxinfo = await db.crbm_tax_info.findOne({
          attributes: [[Sequelize.fn("count", sequelize.col(`tax_id`)), 'taxcount'],
          ],where:{
              status:true,
              // system_user_id:req.systemUser.system_user_id
          }
      });
      if (typeof order_data == 'undefined') {
          var column_name = 'r.tax_id';
          var column_sort_order = 'desc';
      }
      else {
          var column_index = req.query.order[0]['column'];
          var column_name = req.query.columns[column_index]['data'];
          var column_sort_order = req.query.order[0]['dir'];
      }
  
      var search_value = req.query.search['value'];
      var search_query = '';
      if (search_value != "") {
          search_value = search_value.toLowerCase();
          search_query = ` and system_user_id=${req.systemUser.system_user_id}  and  (r.tax_id::text = '${search_value}' OR LOWER(tax_name)::text LIKE '%${search_value}%' OR status::text LIKE '%${search_value}%' )`;
      }
      const taxdata = await sequelize.query(`select COUNT(r.tax_id) AS Total from crbm_tax_info r where status = 'true' ${search_query}`);
      let query = `select r.tax_id,tax_name,status from crbm_tax_info r where status = 'true' ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
      const taxData = await sequelize.query(query);
      let data = [];
      if (taxData[0].length != 0) {
          for (i = 0; i < taxData[0].length; i++) {
              data.push({
                tax_id: taxData[0][i].tax_id,
                tax_name: taxData[0][i].tax_name,
                  status: taxData[0][i].status,
                  action: `<div> 
                  <span class='a-edit' catid='${taxData[0][i].tax_id}'><i class="bi bi-pencil-square"></i></span>
                  <span class='a-view' catid='${taxData[0][i].tax_id}'><i class="bi bi-eye-fill"></i></span>
                  <span  class='a-delete' catid='${taxData[0][i].tax_id}'><i class="bi bi-trash-fill"></i></span>
                  </div>`,
              });
          }
      }
      var output = {
          'draw': draw,
          'iTotalRecords': taxinfo.dataValues.taxcount,
          'iTotalDisplayRecords': taxdata[0][0].total,
          'aaData': data
      };
      return res.send(output);
  } catch (error) {
      logger.createLog(__filename, error.message, req)
      var output = {
          'draw': draw,
          'iTotalRecords': 0,
          'iTotalDisplayRecords': 0,
          'aaData': []
      };
      return res.send(output);
  }
  
  };
  

module.exports = {
  createTaxInfo,
  updateTaxInfo,
  deleteTaxInfo,
  getTaxInfo,
  getTaxInfoDataTable
};
