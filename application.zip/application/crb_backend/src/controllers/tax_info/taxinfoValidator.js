var db = require('../../models/index');
const logger = require('../../../utils/winston');

const createTaxinfoValidator = async function (req, res, next) {
    try {
      
      if (typeof req.body.tax_name === 'undefined') {
        return logger.error(res,"tax_name parameter is missing.");
    }
      const existingTax = await db.crbm_tax_info.findOne({ 
        attributes: ["tax_name"],
        where: { 
            tax_name: req.body.tax_name 
        } });
      if (existingTax) {
        return res.status(400).send({ status: false, message: 'tax_name already exists' });
      }
      if (/^\s*$/.test(req.body.taxrate)) {
        return logger.error(res, "taxrate cannot be empty");
      }
      if (/^\s*$/.test(req.body.taxtype)) {
        return logger.error(res, "taxtype cannot be empty");
      }
      if (/^\s*$/.test(req.body.tax_name)) {
        return logger.error(res, "tax_name cannot be empty");
      }
  
    if (Number(req.body.tax_name) ) {
      return logger.error(res, "Numbers are not allowed, please try using a string.");
    }
    if (req.body.tax_name == ' ' || req.body.tax_name == null || req.body.tax_name == " ") {
        return logger.error(res, "tax_name cannot be empty ");
    }
    if (typeof req.body.description === 'undefined') {
      return logger.error(res,"description parameter is missing.");
  }
      const Description = req.body.description;
      if (Description && Description.length > 255) {
        return res.status(400).send({ status: false, message: 'Description exceeds maximum length of 255 characters' });
      }
      next();
    } 
    catch (error) {
      logger.createLog(__filename, error.message, req);
      return res.status(500).send({ status: false, message: 'Exception in createTaxInfo' });
    }
  }

  const deleteTaxinfoValidator = async function(req, res, next) {
    try {
        if (typeof req.body.tax_id === 'undefined') {
            return logger.error(res,"tax_id parameter is missing.");
        }
        if (req.body.tax_id === null) {
          return logger.error(res, "tax_id  parameter is missing.");
      }
        if (req.body.tax_id == "") {
            return logger.error(res, 'tax_id cannot be empty.');
        }
        if (!Number.isInteger(req.body.tax_id)) {
            return logger.error(res, "Invalid tax_id. It should be an integer.");
        }
        let taxDelete = await db.crbm_tax_info.findOne({
          attributes: ['tax_id'],
          where: { tax_id: req.body.tax_id },
      });
      if (!taxDelete) {
          return logger.error(res, "Tax with the given tax_id tax_name not found");
      }
        let taxData = await db.crbm_tax_info.findOne({
          attributes: ["tax_id", "status"],
           where: { tax_id: req.body.tax_id, status: false}
      });
        if (taxData) {
          return logger.error(res, "TaxInfo is already inactive");
        }
        next();
    } 
    catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in TaxInfo delete");
    }
  }
  
  let updateTaxinfoValidator = async function(req, res, next) {
    try {
        console.log("res====", req.body);

        if (typeof req.body.tax_name == 'undefined') {
            return logger.error(res, "tax_name parameter is missing");
        }
        if (typeof req.body.tax_id == 'undefined') {
            return logger.error(res, "tax_id parameter is missing");
        }
        if (req.body.tax_id == ' ' || req.body.tax_id == null || req.body.tax_id == " ") {
            return logger.error(res, "tax_id cannot be empty ");
        }
        if (req.body.tax_name == ' ' || req.body.tax_name == null || req.body.tax_name == " ") {
            return logger.error(res, "tax_name cannot be empty ");
        }
        const tax_name = req.body.tax_name;
        if (tax_name && tax_name.length > 255) {
            return res.status(400).send({ status: false, message: 'tax_name exceeds maximum length of 255 characters' });
        }
        if (typeof req.body.tax_id !== 'number') {
            return logger.error(res, "Invalid tax_id ");
        }
        if (typeof req.body.tax_name !== 'string') {
            return logger.error(res, "Invalid tax name");
        }
        if (typeof req.body.description === 'undefined') {
          return logger.error(res,"description parameter is missing.");
      }
        let taxinfoUpdate = await db.crbm_tax_info.findOne({
            attributes: ['tax_id', 'status', 'tax_name'],
            where: { tax_id: req.body.tax_id, status: false, tax_name: req.body.tax_name },
        });
        if (taxinfoUpdate) {
            return logger.error(res, "TaxInfo is doesnt exits");
        }
        let taxinfoUpdateee = await db.crbm_tax_info.findOne({
            attributes: ['tax_id'],
            where: { tax_id: req.body.tax_id },
        });
        if (!taxinfoUpdateee) {
            return logger.error(res, "Tax with the given tax_id tax_name not found");
        }

        let taxinfoUpdateeee = await db.crbm_tax_info.findOne({
            attributes: ['tax_name',  "tax_id"],
            where: { tax_name: req.body.tax_name, tax_id: req.body.tax_id },
        });

        if (taxinfoUpdateeee) {
            return logger.error(res, "Already exits tax name");
        }
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in tax update");
    }
}

const viewTaxinfoValidator = async function (req, res, next) {
    try {
    if (req.body.tax_id == ' ' || req.body.tax_id == null || req.body.tax_id == " ") {
    return logger.error(res, "tax_id cannot be empty ");
    }
    if (typeof req.body.tax_id !== 'number') {
    return logger.error(res, "Invalid data type for tax_id. Only number are allowed.");
    }
    let taxData = await db.crbm_tax_info.findOne({
    attributes: ["tax_id"],
    where: {tax_id: req.body.tax_id }
    });
    if (!taxData) {
    return logger.error(res, "Tax with the given tax_id not found");
    }
    next(); 
    } catch (error) {
    logger.createLog(__filename, error.message, req)
    return logger.error(res, "Exception in tax get");}
    }

  module.exports = {
    createTaxinfoValidator,
    deleteTaxinfoValidator,
    updateTaxinfoValidator,
    viewTaxinfoValidator
  };
  