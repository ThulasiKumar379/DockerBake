var db = require('../../models/index');
const logger = require('../../../utils/winston');
var { sequelize } = require('../../models/index')
const { Sequelize, Op } = require("sequelize");

let createPlanfeatures = async function(req, res, next) {
    try {
        let insertdata = {
            plan_id:req.body.plan_id,
            userlimit:req.body.userlimit,
            location_limit:req.body.location_limit,
            building_limit:req.body. building_limit,
            booking_limit:req.body.booking_limit,
            created_by: req.systemUser.system_user_id,
            created_at:Date.now(),
            status:true
        }
        return await db.crbm_subscription_features.create(insertdata).then(function(data) {
            if (data) {
                return res.status(200).send({ status: true, message: "New Subscription Feature Created Successfully", data });
            } else {
                return logger.error(res, "Error in Subscription Creation");
            }
        });
    } catch (error) {
        console.log('error', error)
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in inserting new Subscription Feature");
    }
}

let editPlanfeatures = async function (req, res, next) {
    try {
        let updatesub = await db.crbm_subscription_features.findOne({
            where: { feature_id: req.body.feature_id,plan_id:req.body.plan_id}
        })
        let subupdate=  await db.crbm_subscription_features.update(
            {
            userlimit:req.body.userlimit,
            location_limit:req.body.location_limit,
            building_limit:req.body.building_limit, 
            booking_limit:req.body.booking_limit ,  
            status: req.body.status,
            updated_at: Date.now(),
            updated_by: req.systemUser.system_user_id
            },
            {
                where: {
                    status:true,
                    feature_id: req.body.feature_id,
                    plan_id:req.body.plan_id,
                    created_by:req.systemUser.system_user_id
                },
            }
        )
        if (updatesub.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (updatesub.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "subscription Plan Feature Updated Successfully", subupdate });
        }
    } catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in subscription Plan Feature update");
    }
}


let deletePlanfeatures = async function(req, res, next) {
    try {
        let subDelete = await db.crbm_subscription_features.findOne({
            where: { feature_id: req.body.feature_id,plan_id:req.body.plan_id }
        })
        const subsFeatures = await db.crbm_subscription_features.update({
            status: false
        }, {
            where: {
                feature_id: req.body.feature_id,
                created_by: req.systemUser.system_user_id
            },
        });
        if (subDelete.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied"});
        } else if (subDelete.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Subscription Plan Feature deleted successfully", subsFeatures });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Subscription Plan Feature delete");
    }

}
let getPlanListfeatures = async function(req, res, next) {
    
    try {
        // db.crbm_subscription_features.belongsTo(db.crbm_subscription_plans, { foreignKey: 'plan_id', as: 'plan' });
        let subscriptionplandata = await db.crbm_subscription_features.findAll({
            attributes: ["feature_id","plan_id", "userlimit","location_limit","building_limit"],
            order: [
                ['feature_id', "ASC"]
            ],
            where: {
                status: true,
                created_by: req.systemUser.system_user_id
            },
            // include: [
            //     { model: db.crbm_subscription_plans, attributes: ['plan_name'], as: 'plan' },
            //   ]
        })
        if (subscriptionplandata.length === 0) {
            return res.status(400).send({ status: false, message: "Subscription Plan Feature not available", subscriptionplandata });
        } else {
            return res.status(200).send({ status: true, message: "Subscription Plan Feature retrived successfully", subscriptionplandata });
        }
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in Subscription Plan Feature");
    }
}

let getsubscriptionfeatures = async function (req,res,next) {  
    try {
        // db.crbm_subscription_features.belongsTo(db.crbm_subscription_plans, { foreignKey: 'plan_id', as: 'plan' });
        let getsubdata = await db.crbm_subscription_features.findOne({
            where: { feature_id:req.query.feature_id}
        })
        let subdata = await db.crbm_subscription_features.findAll({
            attributes: ["feature_id", "userlimit","location_limit","building_limit","booking_limit"],
            where: {
              status:true,
              feature_id: req.query.feature_id,
              created_by:req.systemUser.system_user_id
          },
          include: [
            { model: db.crbm_subscription_plans,
                 attributes: ['plan_name','description','price','tenure'],
                  as: 'crbm_subscription_plans' },
          ]   
        })
        if (getsubdata.created_by !== req.systemUser.system_user_id) {
            return res.status(400).send({ status: false, message: "Perimission Denied" });
        } else if (getsubdata.created_by === req.systemUser.system_user_id) {
            return res.status(200).send({ status: true, message: "Subscription Plan Feature Retrived Successfully", subdata });
        }
    } catch (error) {
        logger.createLog(__filename,error.message,req)
        return logger.error(res,"Exception in Subscription Plan Feature");
    }
  }
let getFeaturesDataTable = async function (req,res,next) {  
    try {
        var draw = req.query.draw;
        var start = req.query.start;
        var length = req.query.length;
        var order_data = req.query.order; 
        let feature = await db.crbm_subscription_features.findOne({
            attributes: [[Sequelize.fn("count", sequelize.col(`feature_id`)), 'feaCount'],
            ],where:{ 
                status:true
            }
        });
        if (typeof order_data == 'undefined') {
            var column_name = 'd.designation_id';
            var column_sort_order = 'desc';
        }
        else {
            var column_index = req.query.order[0]['column'];
            var column_name = req.query.columns[column_index]['data'];
            var column_sort_order = req.query.order[0]['dir'];
        }
    
        var search_value = req.query.search['value'];
        var search_query = '';
        if (search_value != "") {
            search_value = search_value.toLowerCase();
            search_query = ` and (f.feature_id::text = '${search_value}' OR LOWER(p.plan_name)::text LIKE '%${search_value}%' OR f.userlimit::text = '${search_value}' OR f.building_limit::text = '${search_value}' OR f.booking_limit::text = '${search_value}' OR f.status::text LIKE '%${search_value}%' )`;
        }
        const featuresearchdata = await sequelize.query(`select COUNT(f.feature_id) AS Total from crbm_subscription_features f left join crbm_subscription_plans p on p.plan_id=f.plan_id where f.status = 'true' ${search_query}`);
        let query = `select f.feature_id,p.plan_name,f.plan_id,f.userlimit,f.building_limit,f.booking_limit,f.status from crbm_subscription_features f left join crbm_subscription_plans p on p.plan_id=f.plan_id where f.status = 'true' ${search_query} ORDER BY ${column_name} ${column_sort_order} OFFSET ${start} LIMIT ${length}`;
        const feaData = await sequelize.query(query);
        let data = [];
        if (feaData[0].length != 0) {
            for (i = 0; i < feaData[0].length; i++) {
                data.push({
                    feature_id: feaData[0][i].feature_id,
                    plan_name: feaData[0][i].plan_name,
                    userlimit: feaData[0][i].userlimit,
                    building_limit: feaData[0][i].building_limit,
                    booking_limit: feaData[0][i].booking_limit,
                    status: feaData[0][i].status,
                    action: `<div> 
                    <span class='a-edit' catid='${feaData[0][i].feature_id}'><i class="bi bi-pencil-square"></i></span>
                    <span class='a-view' catid='${feaData[0][i].feature_id}'><i class="bi bi-eye-fill"></i></span>
                    <span  class='a-delete' catid='${feaData[0][i].feature_id}'><i class="bi bi-trash-fill"></i></span>
                    </div>`,
                });
            }
        }
        var output = {
            'draw': draw,
            'iTotalRecords': feature.dataValues.feaCount,
            'iTotalDisplayRecords': featuresearchdata[0][0].total,
            'aaData': data
        };
        return res.send(output);
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        var output = {
            'draw': draw,
            'iTotalRecords': 0,
            'iTotalDisplayRecords': 0,
            'aaData': []
        };
        return res.send(output);
    }
  }

module.exports = {
    createPlanfeatures,
    editPlanfeatures,
    deletePlanfeatures,
    getPlanListfeatures,
    getsubscriptionfeatures,
    getFeaturesDataTable
};