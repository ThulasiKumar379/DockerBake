var db = require('../../models/index')
const logger = require('../../../utils/winston')
function detectNumeric(obj) {
    for (var index in obj) {
        if (!isNaN(obj[index])) {
            obj[index] = Number(obj[index]);
        } else if (typeof obj === "object") {
            detectNumeric(obj[index]);
        }
    }
}

const createPlan = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.body.plan_id == 'undefined' || typeof req.body.userlimit == 'undefined' || typeof req.body.location_limit == 'undefined'|| typeof req.body.building_limit == 'undefined'|| typeof req.body.booking_limit == 'undefined') {
            return logger.error(res, "Invalid Parameters");
        }
        if ( /^\s*$/.test(req.body.plan_id) || /^\s*$/.test(req.body.userlimit) || /^\s*$/.test(req.body.location_limit) || /^\s*$/.test(req.body.building_limit) || /^\s*$/.test(req.body.booking_limit)) {
            return logger.error(res, "Parameters cannot be empty");
        } 
        if (!Number(req.body.plan_id || req.body.userlimit|| req.body.location_limit || req.body.building_limit || req.body.booking_limit)) {
            return logger.error(res, "Invalid input");
        }
        
        let feature = await db.crbm_subscription_features.findOne({
            attributes: ["feature_id","plan_id"],
            where: { feature_id: req.body.feature_id,plan_id:req.body.plan_id }
        });
        if (feature) {
                return logger.error(res, "Feature or Plan id already exists"); 
        }
        next();

    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in subcription Plan Feature");
    }
}

const deletePlan = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.body.feature_id == 'undefined' || typeof req.body.plan_id == 'undefined') {
            return logger.error(res, "Invalid Parameters");
        }
        if (/^\s*$/.test(req.body.feature_id)|| /^\s*$/.test(req.body.plan_id) ) {
            return logger.error(res, "Parameters cannot be empty");
        } 
        if (!Number(req.body.feature_id||req.body.plan_id)) {
            return logger.error(res, "Feature or Plan cannot be string");
        }
        let departmentData = await db.crbm_subscription_features.findOne({
            attributes: ["feature_id", "status"],
            where: { feature_id: req.body.feature_id, status: false, created_by: req.systemUser.system_user_id }
        });

        if (departmentData) {
         return logger.error(res, "Subscription Plan Feature is already inactive");
        } 
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req)
        return logger.error(res, "Exception in plan delete");
    }
}

let editPlan = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.body.feature_id == 'undefined' || typeof req.body.plan_id == 'undefined' || typeof req.body.userlimit == 'undefined' || typeof req.body.location_limit == 'undefined'|| typeof req.body.building_limit == 'undefined'|| typeof req.body.booking_limit == 'undefined') {
            return logger.error(res, "Invalid Parameters");
        }
        if (/^\s*$/.test(req.body.feature_id)|| /^\s*$/.test(req.body.plan_id) || /^\s*$/.test(req.body.userlimit) || /^\s*$/.test(req.body.location_limit) || /^\s*$/.test(req.body.building_limit) || /^\s*$/.test(req.body.booking_limit)) {
            return logger.error(res, "Parameters cannot be empty");
        } 
        if (!Number(req.body.feature_id||req.body.plan_id || req.body.userlimit|| req.body.location_limit || req.body.building_limit || req.body.booking_limit)) {
            return logger.error(res, "Invalid input");
        }
        let subedit = await db.crbm_subscription_features.findOne({
            attributes: ['feature_id','plan_id','status'],
            where: { feature_id:req.body.feature_id,plan_id:req.body.plan_id,status:false},
        });
        if (subedit) {
            return logger.error(res, "Subscription Plan Feature is Inactive.");
        }  
        let editsub = await db.crbm_subscription_features.findOne({
            attributes: ['feature_id'],
            where: { feature_id:req.body.feature_id},
        });
        if (!editsub) {
            return logger.error(res, "Subscription Plan Feature not found");
        } 
        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in Subscription Plan Feature update");
    }
};


let getPlanbyid = async function(req, res, next) {
    try {
        await detectNumeric(req.body);
        if (typeof req.query.feature_id == 'undefined' ) {
            return logger.error(res, "Invalid Parameters");
        }
        if (/^\s*$/.test(req.query.feature_id)) {
            return logger.error(res, "Parameters cannot be empty");
        } 
        if (!Number(req.query.feature_id)) {
            return logger.error(res, "Invalid input");
        }
        let locationdata = await db.crbm_subscription_features.findOne({
            attributes: ["feature_id", "status"],
            where: { feature_id: req.query.feature_id, status: false, created_by: req.systemUser.system_user_id }
        })
        if (locationdata) {
            return logger.error(res, "Subscription Plan Feature is inactive");
        }
        let locationget = await db.crbm_subscription_features.findOne({
            attributes: ['feature_id'],
            where: { feature_id: req.query.feature_id },
        });
        if (!locationget) {
            return logger.error(res, "Subscription Plan Feature not found");
        }

        next();
    } catch (error) {
        logger.createLog(__filename, error.message, req);
        return logger.error(res, "Exception in retrieving Subscription Plan Feature.");
    }
};


module.exports = {
    createPlan,
    deletePlan,
    editPlan,
    getPlanbyid
};