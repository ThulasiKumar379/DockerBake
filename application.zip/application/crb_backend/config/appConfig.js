var config = {
    "local": {
        saltRounds: 10,
        expiresIn: '60d',
        apiUrl: 'http://localhost:3001',
        port: 3001,
        host: "localhost",
        dbName: "crb_local",
        dbUserName: "postgres",
        dialect: "postgres",
        dbPassword: "postgres",
        dbPort: "5432",
        pool: {
            max: 5, 
            min: 0,
            acquire: 30000,
            idle: 10000
        },
        smtp: {
            host: 'sandbox.smtp.mailtrap.io',
            username: '89db9796c14e4c',
            password: 'b5af3f266292e6',
            port: 2525
        },
        emailsubject: {
            welcome: "Welcome to CRB(FSS)"
        },
        jwtkey: {
            system_user_pw_decrypt: "9WbcWTEybxshlwertij5vGtBMwyQ6VOu",
            system_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa5aliQ',
            end_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa5aliQ'
        },
        cashfree: {
            appId: "12666350b3ae2e87aa19d5dea3366621", // MM test
            secretKey: "fd8bf11305d405267c37f09a37fcea6e26d64916", // MM test
            currency: "INR",
            mode: "TEST",
            returnUrl: "http://localhost:3000/api/payment/onlinepaymentresponse",
            notifyUrl: "http://localhost:3000/api/payment/onlinepaymentresponse",
            PRODUrl: "https://www.cashfree.com/checkout/post/submit",
            TestUrl: "https://test.cashfree.com/billpay/checkout/post/submit",
            // paymentlanding:"https://dev.magikmat.net/my-subscription/invoice",
            paymentlanding: "https://dev.crb.rezumr.com/",
            ProdPaymentVerify: "https://api.cashfree.com/pg/orders/",
            TestPaymentVerify: "https://sandbox.cashfree.com/pg/orders/",
            API_Version: "2022-09-01"
        },
        s3: {
            accessKeyId: "AKIASUSRTKXTMHOM4BUU",
            secretAccessKey: "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",
            region: "ap-south-1",
            bucketname: 'dev-crb',
            profilepickey: 'profilePictures/'
        },
        rabbitMQConnectionString: 'amqp://localhost:5672',
        emailQueue: 'email_queue'
    },
    "dev": {
        saltRounds: 10,
        expiresIn: '60d',
        apiUrl: 'http://localhost:3053',
        port: 3053,
        host: "postgres",
        dbName: "crb_dev",
        dbUserName: "crb_dev_user",
        dialect: "postgres",
        dbPassword: "2f!G3TkH13NM",
        dbPort: "5432",
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        },
       smtp: {
            host: 'smtp.office365.com',
            username: 'fss.helpdesk@federalsoftsystems.com',
            password: 'FederalSoft@123',
            port: 587
        },
        emailsubject: { 
            welcome: "Welcome to CRB (FSS)"
        },
        jwtkey: {
            system_user_pw_decrypt: "9WbcWTEybxshlwertij5vGtBMwyQ6VOu",
            system_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa5a123',
            end_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa5a123'
        },
        cashfree: {
            appId: "12666350b3ae2e87aa19d5dea3366621", // MM test
            secretKey: "fd8bf11305d405267c37f09a37fcea6e26d64916", // MM test
            currency: "INR",
            mode: "TEST",
            returnUrl: "https://dev.crbapi.rezumr.com/api/payment/onlinepaymentresponse",
            notifyUrl: "https://dev.crbapi.rezumr.com/api/payment/onlinepaymentresponse",
            PRODUrl: "https://www.cashfree.com/checkout/post/submit",
            TestUrl: "https://test.cashfree.com/billpay/checkout/post/submit",
            // paymentlanding:"https://dev.magikmat.net/my-subscription/invoice",
            paymentlanding: "https://dev.crb.rezumr.com/",
            ProdPaymentVerify: "https://api.cashfree.com/pg/orders/",
            TestPaymentVerify: "https://sandbox.cashfree.com/pg/orders/",
            API_Version: "2022-09-01"
        },
        rabbitMQConnectionString: 'amqp://localhost:5672',
        emailQueue: 'email_queue',
        s3: {
            accessKeyId: "AKIASUSRTKXTMHOM4BUU",
            secretAccessKey: "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",
            region: "ap-south-1",
            bucketname: 'dev-crb',
            profilepickey: 'profilePictures/'
        }
    },
    "uat": {
        saltRounds: 10,
        expiresIn: '60d',
        apiUrl: 'https://uat.crbapi.rezumr.com/',
        port: 3054,
        host: "localhost",
        dbName: "crb_uat",
        dbUserName: "crb_uat_user",
        dialect: "postgres",
        dbPassword: "3*jNlvSv58qT",
        dbPort: "5432",
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        },
        smtp: {
            host: 'smtp.office365.com',
            username: 'fss.helpdesk@federalsoftsystems.com',
            password: 'FederalSoft@123',
            port: 587
        },
        emailsubject: {
            welcome: "Welcome to CRB (FSS)"
        },
        jwtkey: {
            system_user_pw_decrypt: "P1OtCvgbhFPbgZT9brDgzhUrjxzpnW2Vq",
            system_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa51234',
            end_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa51234'
        },
        cashfree: {
            appId: "12666350b3ae2e87aa19d5dea3366621", // MM test
            secretKey: "fd8bf11305d405267c37f09a37fcea6e26d64916", // MM test
            currency: "INR",
            mode: "TEST",
            returnUrl: "https://uat.crbapi.rezumr.com/api/payment/onlinepaymentresponse",
            notifyUrl: "https://uat.crbapi.rezumr.com/api/payment/onlinepaymentresponse",
            PRODUrl: "https://www.cashfree.com/checkout/post/submit",
            TestUrl: "https://test.cashfree.com/billpay/checkout/post/submit",
            // paymentlanding:"https://dev.magikmat.net/my-subscription/invoice",
            paymentlanding: "https://uat.crb.rezumr.com",
            ProdPaymentVerify: "https://api.cashfree.com/pg/orders/",
            TestPaymentVerify: "https://sandbox.cashfree.com/pg/orders/",
            API_Version: "2022-09-01"
        },
        rabbitMQConnectionString: 'amqp://localhost:5672',
        emailQueue: 'email_queue',
        s3: {
            accessKeyId: "AKIASUSRTKXTMHOM4BUU",
            secretAccessKey: "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",
            region: "ap-south-1",
            bucketname: 'dev-crb',
            profilepickey: 'profilePictures/'
        },
    },

    "prod": {
        saltRounds: 10,
        expiresIn: '60d',
        apiUrl: 'https://uat.crbapi.rezumr.com/',
        port: 3054,
        host: "localhost",
        dbName: "crb_dev",
        dbUserName: "postgres",
        dialect: "postgres",
        dbPassword: "123456",
        dbPort: "5432",
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        },
        smtp: {
            host: 'smtp.office365.com',
            username: 'fss.helpdesk@federalsoftsystems.com',
            password: 'FederalSoft@123',
            port: 587
        },
        emailsubject: {
            welcome: "Welcome to CRB (FSS)"
        },

        jwtkey: {
            system_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa98078',
            end_user_key: 'ceb21d54e6c700170420ade71f46e99d1722864a11bfbbb89db42e51c139efaw'
        },
        rabbitMQConnectionString: 'amqp://localhost:5672',
        emailQueue: 'email_queue',
        s3: {
            accessKeyId: "AKIASUSRTKXTMHOM4BUU",
            secretAccessKey: "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",
            region: "ap-south-1",
            bucketname: 'dev-crb',
            profilepickey: 'profilePictures/'
        },
    },
    "docker": {
        saltRounds: 10,
        expiresIn: '60d',
        apiUrl: 'https://dev.crbapi.rezumr.com/',
        port: 3053,
        host: "localhost",
        dbName: "crb_dev",
        dbUserName: "venkat",
        dialect: "postgres",
        dbPassword: "yNm9F2z6$&U5",
        dbPort: "5432",
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        },
        smtp: {
            host: 'smtp.office365.com',
            username: 'fss.helpdesk@fssglobal.in',
            password: 'Federal@23',
            port: 587
        },
        emailsubject: {
            welcome: "Welcome to CRB (FSS)"
        },
        jwtkey: {
            system_user_pw_decrypt: "9WbcWTEybxshlwertij5vGtBMwyQ6VOu",
            system_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa5a123',
            end_user_key: 'ceb21d54e6c700170420ade71f46e99e1722864a11bfbbb89db42e51c139efad'
        },
        cashfree: {
            appId: "12666350b3ae2e87aa19d5dea3366621", // MM test
            secretKey: "fd8bf11305d405267c37f09a37fcea6e26d64916", // MM test
            currency: "INR",
            mode: "TEST",
            returnUrl: "https://dev.crbapi.rezumr.com/api/payment/onlinepaymentresponse",
            notifyUrl: "https://dev.crbapi.rezumr.com/api/payment/onlinepaymentresponse",
            PRODUrl: "https://www.cashfree.com/checkout/post/submit",
            TestUrl: "https://test.cashfree.com/billpay/checkout/post/submit",
            // paymentlanding:"https://dev.magikmat.net/my-subscription/invoice",
            paymentlanding: "https://dev.crb.rezumr.com/",
            ProdPaymentVerify: "https://api.cashfree.com/pg/orders/",
            TestPaymentVerify: "https://sandbox.cashfree.com/pg/orders/",
            API_Version: "2022-09-01"
        },
        rabbitMQConnectionString: 'amqp://localhost:5672',
        emailQueue: 'email_queue',
        s3: {
            accessKeyId: "AKIASUSRTKXTMHOM4BUU",
            secretAccessKey: "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",
            region: "ap-south-1",
            bucketname: 'dev-crb',
            profilepickey: 'profilePictures/'
        }
    }
    // jwtkey: {
    //     system_user_pw_decrypt:"1wJjBU1jIl567C4s4QpKaNjCeq6Uzcisn",
    //     system_user_key: 'RgXyjlcWbQAbMHwCn0CGRED8dYa98078',
    //     end_user_key: 'ceb21d54e6c700170420ade71f46e99d1722864a11bfbbb89db42e51c139efaw'
    // },

}
module.exports = config;
