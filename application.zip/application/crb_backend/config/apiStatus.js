var config={
    "success":{
     status:true,
     message:"",
     data:"",
    },
    "error":{
     status:false,
     errorMessage:"" 
    },
    "tokenError":{
     status:false,
     errorMessage:"Invalid token" 
    }
     
  }
  module.exports =config;