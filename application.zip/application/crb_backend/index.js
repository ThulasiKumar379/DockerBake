const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const hbs = require('hbs')
const path = require('path')
const app = express()
console.log(path.join(__dirname));
const jwt = require('jsonwebtoken');
const secretKey = 'fss_secret_key';
app.set('view engine', 'hbs');
const nodeCron = require('node-cron');
app.use(bodyParser.json())
app.use(
    bodyParser.urlencoded({
        extended: true,
    })
)

var corsOptions = {
    origin: "*",
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
};

app.use(cors(corsOptions));

var env = require('./config/environment');
const port = env.port;

app.get('/', (req, res) => {
    res.send('<center><h1>CRB API Portal</h1><img src="https://i.ytimg.com/vi/T0DmHRdtqY0/maxresdefault.jpg"></center>')
})

let node_env = process.env.NODE_ENV;

var sample = require('./routes/email');
var systemusers = require('./routes/systemusers');
var subcription = require('./routes/subcriptionPlan');
var department = require('./routes/department');
var aminitie = require('./routes/amenties');
var location = require('./routes/location');
var subfeatures = require('./routes/subsctiptionfeatures');
var designations = require('./routes/designation');
var floors = require('./routes/floor');
var building = require('./routes/building');
var roles = require('./routes/roles');
var room = require('./routes/room');
var notification = require('./routes/notification');
var settings = require('./routes/settings');
var taxinfo = require('./routes/taxinfo');
var setting = require('./routes/setting')
var payment = require('./routes/payment');
var companyprofile = require('./routes/company');
var users = require('./routes/users');
var bookings = require('./routes/bookings');
var userprofile = require('./routes/userprofile');
var roomservice = require('./routes/roomservice');
var bookingNotification = require('./src/controllers/booking/bookingController');
var acl=require('./routes/acl')



app.use('/api/payment', payment);
app.use('/api/roles', roles);
app.use('/api/room', room);
app.use('/api/subcription', subcription);
app.use('/api/sample', sample);
app.use('/api/systemusers', systemusers);
app.use('/api/department', department);
app.use('/api/amenities', aminitie);
app.use('/api/location', location);
app.use('/api/building', building);
app.use('/api/floors', floors);
app.use('/api/designations', designations);
app.use('/api/subscriptionfeatures', subfeatures);
app.use('/api/notification', notification);
app.use('/api/settings', settings);
app.use('/api/taxinfo', taxinfo);
app.use('/api/subscriptionfeatures', subfeatures)
app.use('/api/setting', setting)
app.use('/api/companyprofile', companyprofile);
app.use('/api/users', users);
app.use('/api/bookings', bookings);
app.use('/api/userprofile', userprofile);
app.use('/api/roomservice', roomservice);
app.use('/api/acl',acl);

app.use('/loaderio-35c8d96e6c1ab1adbe82ec03d651d844', (req, res, next) => {

    
    return res.end('loaderio-35c8d96e6c1ab1adbe82ec03d651d844')
});

nodeCron.schedule('*/1 * * * *', async() => {
    await bookingNotification.bookingNotification()
    console.log('this is for notification email sending before 15mins and rescheduled mail')
    console.log('running a task every minute'); 
});


app.use("*", (req, res, next) => {
    res.send({ status: 404, 'Message': 'End point not registered' });
})
app.listen(port, () => {
    console.log(`environment set for ${node_env}`)
    console.log(`Example app listening on port ${port}`)
})
