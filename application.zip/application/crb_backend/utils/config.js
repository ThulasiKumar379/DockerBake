module.exports = {
    secretKey: '34db83cbe84dec0f465351a5f34902a34025b22294eb7051b577b1302906ff49',
};