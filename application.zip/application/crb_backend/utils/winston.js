const moment =require("moment")
const winston =require("winston")
const winstonRotate =require("winston-daily-rotate-file")

 async function getLogger(){
    try{
        return winston.createLogger({
            transports:[
                new winston.transports.DailyRotateFile({
                    filename:"CRB_ERROR_LOG_%DATE%.log",
                    frequency:"24h",
                    datePattern:"YYYY-MM-DD",
                    maxSize:"1g",
                    maxFiles:"365", 
                    dirname:"logs/errorLogs"
                })
            ]
        });
    }catch(error){
        console.log("error in getLogger() : ",error.message()) 
    }
}

async function createLog(fname,message,req){ 
    logger=await getLogger();
    let logmessage= {}; 
    logmessage.time     =   moment().format('DD-MM-YYYY h:mm:ss a');
    logmessage.Headers  =   req.rawHeaders; 
    logmessage.Method   =   req.method;
    logmessage.EndPoint =   req.originalUrl
    logmessage.File     =   fname;
    logmessage.errorMessage =message; 
    logmessage.params   =   req.params; 
    logmessage.body     =   req.body; 
    logmessage.query    =   req.query;  
    logger.info(logmessage)
}
let error=(res,message)=>{ 
   return res.status(200).send({ status:false, errorMessage:message  } );
}
let success=(res,message,data=null)=>{
    var rlt = { status:true, message:message}
    if(data!=null){
        rlt.data=data;
    }
    return res.status(200).send(rlt);
}
module.exports={
    getLogger,
    createLog,error,success
}