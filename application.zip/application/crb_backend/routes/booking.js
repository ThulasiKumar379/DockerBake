// var express = require('express');
// var router = express.Router();
// const auth = require('../middleware/auth')

// /*controllers start*/
// var booking = require('../src/controllers/bookings/bookingController');
// var bookingValidator = require('../src/controllers/bookings/bookingValidator'); 


// /*sample start*/
// //router.post('/rolescreation',auth.systemUserAuth, roleValidator.createRoleValidator, sample.createRoles)

// router.get('/getbooking', auth.systemUserAuth, bookings.viewBooking)

// /*sample end*/


// module.exports = router;