var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

const payment = require("../src/controllers/payments/paymentController"); 

router.post('/checkout',payment.payOnline);
router.post('/onlinepaymentresponse',payment.response);
router.get('/paymenthistory',auth.systemUserAuth,payment.getPaymentHistory);
 
module.exports=router;