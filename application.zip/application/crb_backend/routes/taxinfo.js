var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth')

/*controllers start*/
var taxinfo = require('../src/controllers/tax_info/taxinfoController');
var taxinfoValidator = require('../src/controllers/tax_info/taxinfoValidator'); 


/*sample start*/

// router.post('/taxinfocreation',auth.systemUserAuth, taxinfoValidator.createTaxinfoValidator, taxinfo.createTaxInfo)
// router.put('/edittaxinfo',auth.systemUserAuth,taxinfoValidator.updateTaxinfoValidator, taxinfo.updateTaxInfo)
// router.get('/gettaxinfo', auth.systemUserAuth, taxinfo.getTaxInfo)
// router.delete('/deletetaxinfo',auth.systemUserAuth, taxinfoValidator.deleteTaxinfoValidator, taxinfo.deleteTaxInfo)
// router.get('/taxinfoDataTable',auth.systemUserAuth,taxinfo.gettaxinfoDataTable)

/*sample end*/


module.exports = router;