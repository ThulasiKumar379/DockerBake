var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth')

/*controllers start*/
var sample = require('../src/controllers/room/roomController');
var roomValidator = require('../src/controllers/room/roomValidator'); 

/*sample start*/
router.post('/roomcreation', auth.systemUserAuth,roomValidator.createRoomValidator, sample.createRoom)
router.get('/viewRoom', auth.systemUserAuth,sample.viewRoom)
router.put('/updateRoom', auth.systemUserAuth,roomValidator.updateRoomValidator, sample.updateRoom)
router.delete('/deleteRoom',auth.systemUserAuth,roomValidator.deleteRoomValidator , sample.deleteRoom)
router.post('/deactiveroom', auth.systemUserAuth, roomValidator.userDeactivevalidator, sample.roomDeactivate);
router.get('/getRoomById', auth.systemUserAuth, roomValidator.getRoomByIdValidator,sample.getRoomById)
router.get('/fetchrooms', auth.systemUserAuth, sample.fetchrooms)
router.get('/getUserRooms', auth.systemUserAuth, sample.fetchUserrooms)

/*sample end*/


module.exports = router; 