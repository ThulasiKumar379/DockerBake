var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth')
/*controllers start*/
// var notification = require('../src/controllers/notification/emailsend');
var notifValidator = require('../src/controllers/notification/notificationValidator'); 
var notif = require('../src/controllers/notification/notificationController');
/*controllers end*/

/*sample start*/
router.get('/getNotifications',auth.userAuth,notif.getNotifications,notifValidator.getNotificationsValidator);
// router.get('/sendEmail',notification.emailsend)
/*sample end*/


module.exports=router;