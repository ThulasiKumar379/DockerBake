var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');
var userAuth = require('../middleware/auth');
var env = require('../config/environment');


var userController = require('../src/controllers/userprofile/userprofilecontroller');
var userValidator = require('../src/controllers/userprofile/userprofilevalidator');
var img = require('../src/controllers/imagecontroller');


router.get('/getuserprofile', auth.systemUserAuth,userValidator.userprofile, userController.getuserprofile);
router.post('/profilepicupload',userAuth.userAuth,userController.uploadtoS3,userController.uploadprofile) ;
router.delete('/profilepicdelete',userAuth.userAuth,userController.deleteProfilePicture) ;
router.post('/updatepassword',userAuth.userAuth,userController.changepassword);
router.get('/profilepic/:token',img.getprofilepic) 

 


module.exports = router;