var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

var roomservice = require('../src/controllers/roomservice/roomservicecontroller');
var roomservicevalidator = require('../src/controllers/roomservice/roomservicevalidator');
var icon = require('../src/controllers/roomservice/iconcontroller');

router.post('/createroomservice',auth.systemUserAuth,roomservice.uploadicon,roomservicevalidator.createroomservice,roomservice.createroomservice);
router.get('/getroomservice', auth.systemUserAuth,roomservice.getroomservicelist);
router.get('/getroomservicebyid',auth.systemUserAuth,roomservicevalidator.getroomservice,roomservice.getroomservice);
router.delete('/deleteroomservice',auth.systemUserAuth,roomservicevalidator.deleteroomservice, roomservice.deleteroomservice);
router.put('/updateroomservice',auth.systemUserAuth,roomservice.uploadicon,roomservicevalidator.editroomservice,roomservice.editroomservice);
router.get('/fetchroomservice',auth.systemUserAuth,roomservicevalidator.getroomservicefetch,roomservice.getroomservicefetch);
router.get('/geticon',roomservicevalidator.serviceicon,icon.geticon);
router.post('/deactivateservice',auth.systemUserAuth,roomservicevalidator.servicedeactivate,roomservice.Roomservicedeactivate);

module.exports=router;  