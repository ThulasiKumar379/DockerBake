var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');

/*controllers start*/
var settings = require('../src/controllers/settings/companytimingsController');
var settingsValidator = require('../src/controllers/settings/companytimingsValidator');
/*controllers end*/

/*sample start*/

router.put('/edittimings',auth.systemUserAuth,settingsValidator.updateCompanyTimingsValidator, settings.updateCompanyTimings)
router.get('/gettimings', auth.systemUserAuth, settings.getCompanyTimings)
router.get('/getCompanyTimings', auth.systemUserAuth, settings.fetchCompanyTimings)
/*sample end*/


module.exports = router;