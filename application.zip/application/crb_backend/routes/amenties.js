var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

var amenitie = require('../src/controllers/aminties/amintiesController');
var amenitievalidator = require('../src/controllers/aminties/amintiesValidations');
var thumbnail = require('../src/controllers/aminties/thumbnailController');

router.post('/createamenitie',auth.systemUserAuth,amenitie.uploadAminities,amenitievalidator.createAminity,amenitie.createaminities);
router.get('/getamenitie', auth.systemUserAuth,amenitie.getamenitie);
router.get('/getamenitybyid',auth.systemUserAuth,amenitievalidator.getAminitybyid,amenitie.getamenitiebyid);
router.delete('/deleteamenitie',auth.systemUserAuth,amenitievalidator.deleteAminity, amenitie.deleteamenity);
router.put('/updateaminities',auth.systemUserAuth,amenitie.uploadAminities,amenitievalidator.editAminity,amenitie.updateaminities);
router.get('/amenitiesDataTable',amenitie.getAmenitiesDataTable);
router.get('/thumbnail',thumbnail.getthumbnail);
router.get('/fetchAmenities',auth.systemUserAuth,amenitie.fetchAmenities);
router.post('/deactivateamenity',auth.systemUserAuth,amenitievalidator.amenitydeactivate,amenitie.Amenitydeactivate)
router.get('/getRoomThumbnails' ,thumbnail.getRoomThumbnails);

module.exports=router;