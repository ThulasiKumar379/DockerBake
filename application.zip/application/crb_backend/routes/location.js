var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

const location = require("../src/controllers/location/locationcontroller");
const locationvalidator = require('../src/controllers/location/locationValidator');

router.post('/createlocation',auth.systemUserAuth,locationvalidator.locationcreate,location.createLocation);
router.put('/editlocation',auth.systemUserAuth,locationvalidator.locationupdate,location.updatelocation);
router.get('/getlocation',auth.systemUserAuth,locationvalidator.getlocationfetch,location.getlocation);
router.get('/getlocationbyid',auth.systemUserAuth,locationvalidator.getlocationbyid, location.getlocationbyid);
router.delete('/deletelocation',auth.systemUserAuth,locationvalidator.locationdelete, location.deletelocation);
router.get('/locationDataTable',location.getlocationsDataTable);
router.get('/fetchLocations',auth.systemUserAuth,location.fetchLocations);
router.put('/Locationdeactivate',auth.systemUserAuth,locationvalidator.locationdeactivate,location.Locationdeactivate)

module.exports=router;