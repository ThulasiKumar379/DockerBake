var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');

/*controllers start*/
var bookingController = require('../src/controllers/booking/bookingController');
var bookingValidator = require('../src/controllers/booking/bookingValidator');
/*controllers end*/

/*sample start*/
router.post('/createBooking', auth.userAuth,bookingValidator.userBooking, bookingController.userBooking);
router.put('/updateBooking', auth.userAuth, bookingValidator.EdituserBooking, bookingController.EdituserBooking);
router.put('/bookingCancel', auth.userAuth, bookingValidator.bookingCancel, bookingController.bookingCancel);
router.put('/bookingApproveReject', auth.userAuth, bookingValidator.bookingCancel, bookingController.changeBookingStatus);
router.put('/bookingAcceptReject', auth.userAuth, bookingController.bookingAcceptReject)
router.get('/getBookings', auth.systemUserAuth, bookingController.getBookings)
router.get('/getBookingStatus', auth.userAuth, bookingController.fetchStatus)
router.get('/availableRooms', auth.systemUserAuth, bookingValidator.availableRooms, bookingController.availableRooms)
router.get('/fetchRoomDetails',auth.userAuth,bookingController.fetchRoomDetails)

router.get('/availableSlots', auth.systemUserAuth, bookingController.availableSlots)
router.get('/mybookings', auth.userAuth, bookingController.mybookingFetch)
router.get('/myinvitations', auth.userAuth, bookingController.invitedBooking)
router.get('/manageBookings', auth.systemUserAuth, bookingController.manageBooking)
router.get('/bookingListView', auth.systemUserAuth, auth.userAuth, bookingController.booking_list_view)
router.get('/getBookingByID',auth.userAuth,bookingValidator.getbookingbyid,bookingController.getbookingsbyID);
router.get('/getroomcapacityandamenities', auth.systemUserAuth, auth.userAuth, bookingController.getRoomCapacityandAmenities)

/*sample end*/


module.exports = router;