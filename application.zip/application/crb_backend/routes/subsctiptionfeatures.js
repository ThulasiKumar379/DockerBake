var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

const subscriptionfeature = require("../src/controllers/subscription plan features/subscriptionfeaturecontrollers");
const subscriptionvalidator = require('../src/controllers/subscription plan features/subscriptionfeatureValidator');

router.post('/createsubscriptionfeature',auth.systemUserAuth,subscriptionvalidator.createPlan,subscriptionfeature.createPlanfeatures);
router.put('/editsubscriptionfeature',auth.systemUserAuth,subscriptionvalidator.editPlan,subscriptionfeature.editPlanfeatures);
router.get('/getPlanListfeatures',auth.systemUserAuth,subscriptionfeature.getPlanListfeatures);
router.get('/getsubscriptionfeature', auth.systemUserAuth,subscriptionvalidator.getPlanbyid,subscriptionfeature.getsubscriptionfeatures);
router.delete('/deletesubscriptionfeature',auth.systemUserAuth,subscriptionvalidator.deletePlan,subscriptionfeature.deletePlanfeatures);
router.get('/featuresDataTable',subscriptionfeature.getFeaturesDataTable);

module.exports=router;