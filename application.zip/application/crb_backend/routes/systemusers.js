var express = require('express');
var router = express.Router();

const auth = require('../middleware/auth');

/*controllers start*/
 
var system_users = require('../src/controllers/system_users/systemUserController'); 
var system_users_validations = require('../src/controllers/system_users/systemUserValidator'); 

/*controllers end*/

/*sample start*/
router.post('/registerSystemUser',system_users_validations.signUp,system_users.signUp)
router.post('/login',system_users_validations.login,system_users.login)
router.get('/userPermissionById',auth.userAuth,system_users.getPermissionsByUserID)
router.post('/emailVerification',system_users_validations.emailVerification,system_users.emailVerification)

// router.post('/registerSystemUser', register.signUp) /*headers-token -provide jwt token*/
// router.post('/verifyEmail', register.verifyEmail)
router.post('/forgotPassword',system_users.forgotPassword)
router.post('/verify_otp',system_users.verify_otp)
router.put('/changeSysPassword',system_users.changeSysPassword)


/*sample end*/


module.exports = router;