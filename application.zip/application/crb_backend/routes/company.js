var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');


var companyprofileController = require('../src/controllers/Company Profile/companyprofilecontroller');
var compnayprofilevalidator=require('../src/controllers/Company Profile/companyprofilevalidator');
var getorganizationlogo = require('../src/controllers/Company Profile/getcompanypic')




router.get('/getprofile', auth.systemUserAuth, companyprofileController.getcompanyprofile);
router.put('/updatecompanyprofile',auth.systemUserAuth,compnayprofilevalidator.editprofileData,companyprofileController.editcompanyprofile);
router.get('/getcompanyprofileDataTable',auth.systemUserAuth,companyprofileController.getuserDataTable);
router.post('/uploadlogo',auth.systemUserAuth,companyprofileController.uploadtoS3bucket,companyprofileController.uploadlogo); 
router.get('/getlogo/:token',getorganizationlogo.getprofilepic)


module.exports = router;