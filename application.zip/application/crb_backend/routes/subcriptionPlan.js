var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

var subcription = require('../src/controllers/subcription/subcriptionController');
var subcriptionValidator = require('../src/controllers/subcription/subcriptionValidator');
 
router.post('/subcriptionPlan', auth.systemUserAuth, subcriptionValidator.createPlan, subcription.createPlan)
router.put('/editPlan', auth.systemUserAuth, subcriptionValidator.editPlan, subcription.editPlan)
router.get('/getPlanList', auth.systemUserAuth, subcription.getPlanList)
router.get('/getsubcriptionPlanList', auth.systemUserAuth, subcription.getSubcriptionPlanList)
router.get('/getplan', auth.systemUserAuth, subcriptionValidator.getPlan, subcription.getsubscription)
router.delete('/deletePlan', auth.systemUserAuth, subcriptionValidator.deletePlan, subcription.deletePlan)
router.get('/subcriptionDataTable', subcription.getSubcriptionDataTable)


module.exports = router;