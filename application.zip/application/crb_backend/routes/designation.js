var express = require('express');
var router = express.Router();
var auth=require('../middleware/auth')

/*controllers start*/
 
var designations = require('../src/controllers/designation/designationController'); 
var designation_validations = require('../src/controllers/designation/designationValidator'); 

/*controllers end*/

/*sample start*/

router.post('/createDesignation',auth.systemUserAuth,designation_validations.createDesignation,designations.createDesignation)
router.put('/updateDesignation',auth.systemUserAuth,designation_validations.updateDesignation,designations.updateDesignation)
router.delete('/deleteDesignation',auth.systemUserAuth,designation_validations.deleteDesignation,designations.deleteDesignation)
router.get('/getDesignationByID',auth.systemUserAuth,designation_validations.getDesignationByID,designations.getDesignationByID)
router.get('/getDesignations',auth.systemUserAuth,designations.getDesignations)
router.get('/designationsDataTable',designations.getDesignationsDataTable)
router.get('/fetchdesignations',auth.systemUserAuth,designations.fetchDesignations)
router.put('/actionDesignation',auth.systemUserAuth,designation_validations.actionDesignation,designations.actionDesignation)

/*sample end*/


module.exports=router;