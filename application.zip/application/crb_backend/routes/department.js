var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');

/*controllers start*/
var departmentController = require('../src/controllers/department/departmentController');
var departmentValidator = require('../src/controllers/department/departmentValidator');
/*controllers end*/

/*route start*/
router.post('/createDepartment', auth.systemUserAuth, departmentValidator.createDepartment, departmentController.createDepartment)
router.put('/editDepartment', auth.systemUserAuth, departmentValidator.editDepartment, departmentController.editDepartment)
router.get('/getDepartmentList', auth.systemUserAuth, departmentController.getDepartmentList)
router.get('/getDepartmentinfo', auth.systemUserAuth, departmentValidator.getDepartmentfetch, departmentController.getDepartmentfetch)
router.get('/getDepartment', auth.systemUserAuth, departmentValidator.getDepartment, departmentController.getDepartment)
router.delete('/deleteDepartment', auth.systemUserAuth, departmentValidator.deleteDepartment, departmentController.deleteDepartment)
router.get('/departmentDataTable', auth.systemUserAuth, departmentController.getDepartmentDataTable)
router.get('/fetchDepartments', auth.systemUserAuth, departmentController.fetchDepartments)
router.post('/departmentActDec', auth.systemUserAuth, departmentValidator.departmentActDec, departmentController.departmentActDec)
    /*route end*/


module.exports = router;