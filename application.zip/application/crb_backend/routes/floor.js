var express = require('express');
var router = express.Router();
var auth=require('../middleware/auth')

/*controllers start*/
 
var floors = require('../src/controllers/floor/floorController'); 
var floors_validations = require('../src/controllers/floor/floorValidator'); 

/*controllers end*/

/*sample start*/

router.post('/createFloor',auth.systemUserAuth,floors_validations.createFloor,floors.createFloor)
router.put('/updateFloor',auth.systemUserAuth,floors_validations.updateFloor,floors.updateFloor)
router.delete('/deleteFloor',auth.systemUserAuth,floors_validations.deleteFloor,floors.deleteFloor)
router.get('/getFloorByID',auth.systemUserAuth,floors_validations.getFloorByID,floors.getFloorByID)
router.get('/getFloor',auth.systemUserAuth,floors.getFloor)
router.get('/floorsDataTable',floors.getFloorsDataTable)
router.get('/fetchFloors',auth.systemUserAuth,floors.fetchFloors)
router.put('/actionFloor',auth.systemUserAuth,floors_validations.actionFloor,floors.actionFloor)

/*sample end*/


module.exports=router;