var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');


var userController = require('../src/controllers/users/userController');
var userValidator = require('../src/controllers/users/userValidator');

router.post('/createUser', auth.systemUserAuth, userValidator.createUser, userController.createUser);
router.get('/userLogin', userValidator.userlogin, userController.userlogin);
router.post('/deactiveUser', auth.systemUserAuth, userValidator.userDeactive, userController.userDeactivate);
router.get('/getUser', auth.systemUserAuth, userValidator.getUser, userController.getUser);
router.get('/fetchUser', auth.systemUserAuth, userController.fetchUsers);
router.put('/updateUser', auth.systemUserAuth, userValidator.editUser, userController.editUser);
router.get('/getUserData', auth.systemUserAuth, userController.getUserData);



module.exports = router;