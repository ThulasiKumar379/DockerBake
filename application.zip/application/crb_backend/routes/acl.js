var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth');

var acl = require('../src/controllers/acl/aclcontroller');
var aclvalidator = require('../src/controllers/acl/aclvalidator');

router.post('/createacl',auth.systemUserAuth,aclvalidator.aclcreate,acl.aclcreate) 
router.delete('/deleteacl',auth.systemUserAuth,aclvalidator.acldelete,acl.acldelete)
router.get('/getacl',auth.systemUserAuth,acl.getACl)
router.put('/updatepermissions',auth.systemUserAuth,acl.updatePermissions)
router.get('/getRoles',auth.systemUserAuth,acl.getRoles)

module.exports=router;