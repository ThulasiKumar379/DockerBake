var express = require('express');
var router = express.Router();

/*controllers start*/
var sample = require('../src/controllers/email/emailController');
/*controllers end*/

/*sample start*/
router.get('/sendEmail',sample.createSample)
/*sample end*/


module.exports=router;