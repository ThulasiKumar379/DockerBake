var express = require('express');
var router = express.Router();
const path = require('path');
const auth = require('../middleware/auth');

/*controllers start*/
var buildingController = require('../src/controllers/Building/buildingController');
var buildingValidator = require('../src/controllers/Building/buildingValidator');
/*controllers end*/

/*sample start*/
router.post('/createBuilding', auth.systemUserAuth, buildingValidator.createBuilding, buildingController.createBuilding)
router.put('/editBuilding', auth.systemUserAuth, buildingValidator.editBuilding, buildingController.editBuilding)
router.get('/getBuildingList', auth.systemUserAuth, buildingController.getBuildingList)
router.get('/getBuilding', auth.systemUserAuth, buildingValidator.getBuildingbyid, buildingController.getBuildingbyid)
router.get('/getBuildinginfo', auth.systemUserAuth, buildingValidator.getBuildingfetch, buildingController.getBuildingfetch)
router.delete('/deleteBuilding', auth.systemUserAuth, buildingValidator.deleteBuilding, buildingController.deleteBuilding)
router.get('/fetchBuildings', auth.systemUserAuth, buildingController.fetchBuildings)
router.post('/BuildingDecAct', auth.systemUserAuth, buildingController.buildingActDec, buildingValidator.buildingActDec)

/*sample end*/


module.exports = router;