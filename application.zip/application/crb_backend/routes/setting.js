var express = require('express');
var router = express.Router();
var auth=require('../middleware/auth')

/*controllers start*/
 
var settings = require('../src/controllers/setting/settingController'); 
var settings_validations = require('../src/controllers/setting/settingValidator'); 

/*controllers end*/

/*sample start*/
router.get('/getSettings',auth.systemUserAuth,settings.getSettings)
router.post('/createSetting',auth.systemUserAuth,settings_validations.createSetting,settings.createSetting)
router.post('/updateSetting',auth.systemUserAuth,settings_validations.updateSetting,settings.updateSetting)
/*sample end*/

module.exports=router;