var express = require('express');
var router = express.Router();
const auth = require('../middleware/auth')

/*controllers start*/
var role = require('../src/controllers/roles/roleController');
var roleValidator = require('../src/controllers/roles/roleValidator'); 


/*sample start*/
//router.post('/rolescreation',auth.systemUserAuth, roleValidator.createRoleValidator, sample.createRoles)
router.post('/rolescreation',auth.systemUserAuth, roleValidator.createRoleValidator, role.createRoles)
router.put('/editRole',auth.systemUserAuth,roleValidator.updateRoleValidator, role.updateRoles)
router.get('/getRole', auth.systemUserAuth, role.viewRoles)
router.get('/getRoleById', auth.systemUserAuth, roleValidator.getRoleByIdValidator,role.getRoleById)
router.delete('/deleteRole',auth.systemUserAuth, roleValidator.deleteRoleValidator, role.deleteRoles)
router.post('/deactiverole', auth.systemUserAuth, roleValidator.roleDeactivevalidator, role.roleDeactivate);
// router.get('/roleDataTable',auth.systemUserAuth,role.getRoleDataTable)
router.get('/fetchRoles',auth.systemUserAuth,role.fetchRoles)
router.get('/getroleinfo', auth.systemUserAuth, roleValidator.getrolefetchValidator, role.getrolefetch)


/*sample end*/


module.exports = router;
