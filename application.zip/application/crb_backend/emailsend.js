const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "sathvikaeaswara05@gmail.com",
    pass: "itvehxwjnaxeyksy"
  }
});

const mailOptions = {
  from: "sathvikaeaswara05@gmail.com",
  to: "eswarasathvika@gmail.com",
  subject: "Welcome to CRB",
  text: "Sending Gmail notification"
};

transporter.sendMail(mailOptions, function(error, info) {
  if (error) {
    console.log(error);
  } else {
    console.log("Email sent: " + info.response);
  }
});

