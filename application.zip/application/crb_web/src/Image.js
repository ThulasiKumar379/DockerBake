import { Paper } from "@mui/material";
import React from "react";
import './App.css';
import { Avatar, Typography } from "@mui/material";
import { MenuItem } from "@mui/material";
import { Menu } from "@mui/material";


export class Image extends React.Component {
  state = {
    anchorEl: null,
    open: false,
  };
  handleClick = event => {
    this.setState({ open: true, anchorEl: event.currentTarget });
  };
  handleRequestClose = () => {
    this.setState({ open: false });
  };
  render() {
    return (
      <div>
        <div className="photo">
          <Paper style={{ width: "100%", paddingLeft: "20px", paddingTop: "20px", paddingBottom: "16px", paddingRight: "10px" }}>
            < Typography variant="h6"
              id="outlined-read-only-input"
              InputProps={{
                readOnly: true,
              }} style={{ fontWeight: "bold", textAlign: "center" }}> User Name</Typography>
            <Avatar src="/broken-image.jpg"
              aria-owns={this.state.open ? 'simple-menu' : null}
              aria-haspopup="true"
              onClick={this.handleClick}
              onMouseOver={this.handleClick}
              sx={{ height: "120px", width: "120px", align: "center",marginTop:"15px", marginLeft: "15px", marginBottom: "15px" }}
            />
            <Menu
              id="simple-menu"
              anchorEl={this.state.anchorEl}
              open={this.state.open}
              onRequestClose={this.handleRequestClose}
            >
              <MenuItem onClick={this.handleRequestClose}>View Photo</MenuItem>
              <MenuItem onClick={this.handleRequestClose}>Upload Photo</MenuItem>
              <MenuItem onClick={this.handleRequestClose}>Remove Photo</MenuItem>
            </Menu>
          </Paper>
        </div>
      </div>
    )
  }
}