import React from "react";
import { ProfileDetails } from "./ProfileDetails";
import { Typography } from "@mui/material";

export const UserProfilesetting = () => {
  return (
    <div className="direction">
      <div className="dir-heading">
        <Typography variant="h4">Profile</Typography>
        <Typography variant="h5" sx={{ fontWeight: " 400 !important" }}>
          Settings
        </Typography>
      </div>
      <div className="dir-content" style={{}}>
        <ProfileDetails />
      </div>
    </div>
  );
};
