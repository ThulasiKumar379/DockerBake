import React, { useState, useRef } from "react";
import {
  Paper,
  Avatar,
  Typography,
  MenuItem,
  Menu,
  Tooltip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsersData } from "../api/UserProfile/userProfileReducer";
import { uploadProfilePic, deleteProfilePicture } from "../api/UserProfile/userProfileApi"; 
import { checkUserAccess } from "../CheckUserAccess";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}`;
const token = sessionStorage.getItem("userToken");
const profilePicUrl = `${BASE_URL}/userprofile/profilepic/${token}`;

export const ProfileImg = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [viewPhotoOpen, setViewPhotoOpen] = useState(false);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleRemovePhoto = async () => {
    try {
      await deleteProfilePicture();
      window.location.reload();
      toast.success("Profile picture removed successfully");
    } catch (error) {
      console.error("Error deleting profile picture:", error);
      toast.error("Error deleting profile picture");
    }
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleViewPhotoOpen = () => {
    setViewPhotoOpen(true); 
  };
  const handleViewPhotoClose = () => {
    setViewPhotoOpen(false); 
  };
  const hasAccess = checkUserAccess("profile");
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.users);
  // useEffect(() => {
  //   dispatch(fetchUsersData());
  // }, [dispatch]);
  const UsersData = userData?.users?.userData;
  const fileInputRef = useRef(null);
  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      // Check if the file type is either jpg or png
      if (file.type === "image/jpeg" || file.type === "image/png") {
        const formData = new FormData();
        formData.append("mypic", file);
        window.location.reload();
        try {
          const response = await uploadProfilePic(formData);
          console.log("Profile pic uploaded successfully:", response);
          toast.success("Profile picture uploaded successfully");
        } catch (error) {
          console.error("Error uploading profile pic:", error);
          toast.error("Error uploading profile picture");
        }
      } else {
        // If the file is not a jpg or png, display an error message
        console.error("Invalid file type. Only JPG and PNG are allowed.");
        toast.error("Invalid file type. Only JPG and PNG images are allowed.");
      }
    }
  };
  
  const handleUploadPhoto = () => {
    fileInputRef.current.click();
  };
  return (
    <div style={{ flexGrow: 1 }}>
      <div className="Apply" style={{ display: "flex" }}>
        <input
          type="file"
          id="profilePicInput"
          name="mypic"
          style={{ display: "none" }}
          ref={fileInputRef}
          onChange={handleFileChange}
        />
        <ToastContainer
          position="bottom-right"
          autoClose={5000}
          hideProgressBar={false}
          pauseOnHover={false}
          draggable={true}
        />
        <Paper
          style={{
            width: "fitcontent",
            padding: "0px",
            boxShadow: "none",
          }}
        >
         
            <Avatar
              src={profilePicUrl}
              sx={{
                height: "143px",
                width: "120px",
                display: "flex",
                justifyContent: "center",
                marginBottom: "15px",
              }}
            />
          <Tooltip title="click here to Edit Profile pic" align="center">
          {hasAccess.exists && (
            <Button
              fullWidth
              onClick={handleClick}
              variant="contained"
              sx={{
                background: "#3E0BA1 !important",
                border: "1px solid #707070",
                borderRadius: "7px",
                font: "normal normal 600 11px/15px Montserrat",
                letterSpacing: "0px",
                color: "#FFF7F7",
                marginBottom: "10px",
              }}
            >
              Edit picture
            </Button>
          )}
          </Tooltip>
          <Typography
            variant="h6"
            id="outlined-read-only-input"
            name="first_name"
            InputProps={{
              readOnly: true,
            }}
            style={{ fontWeight: "bold", textAlign: "center" }}
          >
            {UsersData?.first_name || ""} {UsersData?.last_name || ""}
          </Typography>
          <Typography
            variant="h6"
            id="outlined-read-only-input"
            InputProps={{
              readOnly: true,
            }}
            style={{
              fontWeight: "normal",
              textAlign: "center",
              fontSize: "14px",
              marginBottom: "20px",
            }}
          >
            {UsersData?.crbt_designations?.designation_name || ""}
          </Typography>
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            align="right"
            onClose={handleClose}
            MenuListProps={{
              "aria-labelledby": "basic-button",
            }}
          >
            <MenuItem onClick={handleViewPhotoOpen}>View Photo</MenuItem>
            <MenuItem onClick={handleUploadPhoto}>Upload Photo</MenuItem>
            <MenuItem onClick={handleRemovePhoto}>Remove Photo</MenuItem>
          </Menu>
        </Paper>
      </div>
      <Dialog open={viewPhotoOpen} onClose={handleViewPhotoClose}>
      <DialogTitle>View Photo</DialogTitle>
        <DialogContent style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
          <img src={profilePicUrl} alt="Profile" style={{ maxWidth: "50%" }} />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleViewPhotoClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};
