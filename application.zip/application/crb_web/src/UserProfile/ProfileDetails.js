import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  FormControlLabel,
  TextField,
  Button,
  Switch,
  Paper,
  Box,
  Grid,
} from "@mui/material";
import { styled } from "@mui/system";
import Password from "./Password";
import { ProfileImg } from "./ProfileImage";
import { useEffect } from "react";
import { fetchUsersData } from "../api/UserProfile/userProfileReducer";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { checkUserAccess } from "../CheckUserAccess";
import { useSelector, useDispatch } from "react-redux";

export const ProfileDetails = () => {
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.users.users);
  const hasAccess=checkUserAccess("profile")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
      navigate("/");
  }
  // console.log('User Data:', userData);
  // console.log('Redux State:', userData);
 
  const UsersData = userData?.userData; 
  
  useEffect(() => {
    // console.log(userData);
    dispatch(fetchUsersData());
  }, [dispatch]);
  

  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClickClose = () => {
    setOpen(false);
  };
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 60,
    height: 30,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 25,
      height: 25,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    <>
      <div className="user-profile">
        <div className="Pro1">
          <Paper
            elevation={4}
            sx={{
              padding: "50px 75px",
              border: "2px solid #CFCFCF",
              borderRadius: "25px",
              boxShadow: " 12px 23px 57px #0000001A",
              marginBottom: "20px",
            }}
          >
            <div className="profile-settings">
              <ProfileImg />
              <Box sx={{ flexGrow: 1 }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          User ID
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="user_id"
                      name="user_id"
                      value={UsersData?.user_id || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          First Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="first_name"
                      value={UsersData?.first_name || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Last Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="last_name"
                      value={UsersData?.last_name || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Email
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="email"
                      value={UsersData?.email || ""}
                      InputProps={{
                        shrink: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Phone Number
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="mobile_number"
                      value={UsersData?.mobile_number || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Default Location
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="location_id"
                      value={UsersData?.crbt_locations?.location_name || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Default Building
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="department_id"
                      value={UsersData?.crbt_buildings?.building_name || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Department
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="department_id"
                      value={UsersData?.crbt_departments?.department_name || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      label={
                        <span>
                          Role
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      id="outlined-read-only-input"
                      name="role_id"
                      value={UsersData?.crbt_roles?.role_name || ""}
                      InputProps={{
                        readOnly: true,
                      }}
                    ></TextField>
                  </Grid>
                  <Grid item xs={12} sm={6} md={6}>
                    <FormControlLabel
                      control={<IOSSwitch defaultChecked />}
                      label="Notification"
                      labelPlacement="top"
                    />
                  </Grid>
                  <Grid item xs={12} sm={12} md={4}>
                    {hasAccess.exists&&(
                    <Button
                      variant="contained"
                      style={{
                        background: "#3E0BA1 0% 0% no-repeat padding-box",
                        border: "1px solid #707070",
                        borderRadius: "30px",
                        font: "normal normal 600 12px/15px Montserrat",
                        letterSpacing: "0px",
                        color: "#FFF7F7",
                        padding: "20px 34px",
                      }}
                      onClick={handleClickOpen}
                    >
                      Change password
                    </Button>
                    )}
                  </Grid>
                </Grid>
              </Box>
            </div>
          </Paper>
        </div>
      </div>
      <Dialog open={open} fullWidth={true} maxWidth={"xs"}>
        <DialogContent>
          <Password onClose={handleClickClose} />
        </DialogContent>
      </Dialog>
    </>
  );
};
