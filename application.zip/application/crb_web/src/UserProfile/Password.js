import React, { useState } from "react";
import {
  Button,
  TextField,
  InputAdornment,
  IconButton,
  Typography,
} from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { updatePassword } from "../api/UserProfile/userProfileReducer";

const Password = ({ onClose }) => {
  const dispatch = useDispatch();
  const [passwordVisibility, setPasswordVisibility] = useState({
    currentPassword: false,
    newPassword: false,
    confirmPassword: false,
  });

  const [passwords, setPasswords] = useState({
    Currentpassword: "",
    Newpassword: "",
    Confirmpassword: "",
  });

  const handlePasswordVisibility = (field) => {
    setPasswordVisibility((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  const handleChange = (prop) => (event) => {
    setPasswords({ ...passwords, [prop]: event.target.value });
  };
const handleClose = () => {
    onClose();
  };
  const handleUpdate = async () => {
    dispatch(updatePassword({
      Currentpassword: passwords.Currentpassword,
      Newpassword: passwords.Newpassword,
      Confirmpassword: passwords.Confirmpassword,
    }))
      .unwrap()
      .then((response) => {
        console.log(response)
        if (response.status === true) {
          toast.success("User Password Updated successfully", { autoClose: 5000 });
          if (onClose) onClose();
        }else{
          toast.error(response.errorMessage, { autoClose: 5000 });
        }
      })
      .catch((error) => {
        let errorMessage = error?.response?.data?.errorMessage || "An unexpected error occurred";
        toast.error(errorMessage, { autoClose: 5000 });
      });
  };


  return (
    <div>
      <ToastContainer position="bottom-right" autoClose={5000} hideProgressBar={false} pauseOnHover draggable />
      <Typography variant="h6" component="h2" sx={{ mb: 2 }}>
        Change Password
      </Typography>
      {/* Current Password Input */}
      <TextField
        label="Current Password"
        type={passwordVisibility.currentPassword ? "text" : "password"}
        value={passwords.Currentpassword}
        onChange={handleChange('Currentpassword')}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton onClick={() => handlePasswordVisibility('currentPassword')}>
                {passwordVisibility.currentPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </InputAdornment>
          ),
        }}
        fullWidth
        margin="normal"
      />
      {/* New Password Input */}
      <TextField
        label="New Password"
        type={passwordVisibility.newPassword ? "text" : "password"}
        value={passwords.Newpassword}
        onChange={handleChange('Newpassword')}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton onClick={() => handlePasswordVisibility('newPassword')}>
                {passwordVisibility.newPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </InputAdornment>
          ),
        }}
        fullWidth
        margin="normal"
      />
      {/* Confirm New Password Input */}
      <TextField
        label="Confirm New Password"
        type={passwordVisibility.confirmPassword ? "text" : "password"}
        value={passwords.Confirmpassword}
        onChange={handleChange('Confirmpassword')}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton onClick={() => handlePasswordVisibility('confirmPassword')}>
                {passwordVisibility.confirmPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </InputAdornment>
          ),
        }}
        fullWidth
        margin="normal"
      />
      <Button
            variant="contained"
            onClick={handleUpdate}
            sx={{
              marginRight: "10px",
              textTransform: "capitalize",
              fontSize: "0.75rem",
              marginTop: "15px",
            }}
            className="bookingbtn"
          >
            Update
          </Button>
        
        <Button
          variant="outlined"
          onClick={handleClose}
          className="bookingbtn1"
          sx={{
            textTransform: "capitalize",
            fontSize: "0.75rem",
            marginTop: "15px",
          }}
        >
          Cancel
        </Button>
    </div>
  );
};

export default Password;