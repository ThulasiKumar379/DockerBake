import React,{useState} from "react"
import { Checkbox} from "@mui/material";
function AclCheckBox({userPermissions,header,params,handleRoleCheckboxChange}){
    let [checkboxValue,setCheckboxValue]=useState(userPermissions.includes(header.id)?true:false)
return ( <Checkbox
    checked={checkboxValue}
    onChange={(e,v) =>{ 
        setCheckboxValue(v)
      handleRoleCheckboxChange(params.row.id,header.id,v)
    }            
    }
  />)
}
export default AclCheckBox;
