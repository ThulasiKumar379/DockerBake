import React from "react";
import { useState } from "react";
import { TextField, Button, Typography } from "@mui/material";
import { IconButton, InputAdornment } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import HttpsOutlinedIcon from "@mui/icons-material/HttpsOutlined";

import './App.css';

export const Reset = () => {
    const navigate = useNavigate();
    const [pass1, setPass1] = useState(false);
    const HandleShowPassword1 = () => {
        setPass1(!pass1)
    }
    const HandleMousePass1 = () => {
        setPass1(!pass1)
    }
    const [pass2, setPass2] = useState(false);
    const HandleShowPassword2 = () => {
        setPass2(!pass2)
    }
    const HandleMousePass2 = () => {
        setPass2(!pass2)
    }

    return (
        <div className="Main">
            <div className="Submain">
                <Typography variant="h4">Reset Password</Typography><br />
                <TextField
                    label='New Password'
                    variant="outlined"
                    required
                    type={pass1 ? "text" : "password"}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <HttpsOutlinedIcon style={{ color: '#002046' }} />
                            </InputAdornment>
                        ),
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    aria-label="toggle password visibility"
                                    onClick={HandleShowPassword1}
                                    onMouseDown={HandleMousePass1}
                                >
                                    {pass1 ? <Visibility /> : <VisibilityOff />}
                                </IconButton>
                            </InputAdornment>
                        )
                    }}
                /><br /> <br />
                <TextField
                    label='Confrim Password'
                    variant="outlined"
                    required
                    type={pass2 ? "text" : "password"}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <HttpsOutlinedIcon style={{ color: '#002046' }} />
                            </InputAdornment>
                        ),
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    aria-label="toggle password visibility"
                                    onClick={HandleShowPassword2}
                                    onMouseDown={HandleMousePass2}>
                                    {pass2 ? <Visibility /> : <VisibilityOff />}
                                </IconButton>
                            </InputAdornment>
                        )
                    }}
                /><br /> <br />
                <Button variant="contained" style={{ background: "#002046" }} onClick={() => navigate("/success")}>Change</Button>
            </div>
        </div>)
}