import React, { useState } from "react";
import { TextField, Button, Typography, Dialog } from "@mui/material";
import Group217 from "./Components/Images/Group217.svg";
import { initiateChangePassword } from "./api/Auth/authReducer";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import {  changeSysPassword } from "../src/api/Auth/authApi";
import "react-toastify/dist/ReactToastify.css";
import { toast, ToastContainer } from "react-toastify";


const ChangePassword = ({ email, onClose }) => {
  const [fullWidth] = React.useState(true);
  const [maxWidth] = React.useState('sm');
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isEmailVerified] = useState(true);
  const [isChanged, setIsChanged] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();

  const handleChangePassword = async () => {
      setIsLoading(true); 
      const response = await changeSysPassword({
        newPassword,
        confirmPassword,
        reset_token:localStorage.getItem('FPT')
      }); 
      console.log("change password:", response);  
      if (response.status) { 
        setIsChanged(true);
        onClose();
        toast.success("password updated successfully")
      }  
  };
  

  
  // const handleChangePassword = async (userEmail) => {
  //   try {
  //     setIsLoading(true);
  
  //     const response = await dispatch(initiateChangePassword({
  //       email: userEmail,
  //     }), {
  //       method: 'PUT',
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: JSON.stringify({
  //         newPassword,
  //         confirmPassword,
  //         email: userEmail,
  //       }),
  //     });
  //     console.log("change Rres",response)
  //     const data = await response.json();
  
  //     console.log("change password:", data);
  
  //     if (response.ok) {
  //       console.log(data.message); // Log success message
  //       setIsChanged(true);

  //       // Store JWT token in local storage
  //       localStorage.setItem('emailtoken', data.token);
  
  //       onClose();
  //     } else {
  //       console.error(data.error); // Log error message
  //     }
  //   } catch (error) {
  //     console.error(error.message); // Log any exceptions
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };
  
  const handleBacktoLogin = () => {
    onClose();
  };

  return (
    
    <Dialog
      fullWidth={fullWidth}
      maxWidth={maxWidth}
      open={true}
      onClose={onClose}
      BackdropProps={{
        style: { backgroundColor: "rgba(98, 14, 182, 0.5)" },
      }}
    >
      <ToastContainer
          position="bottom-right"
          autoClose={3000}
          hideProgressBar={false}
          pauseOnHover={false}
          draggable={true}
        />
      <div
        style={{
          textAlign: "center",
          padding: "1em", 
        }}
      >
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <Button onClick={onClose} sx={{ color: "black", minWidth: "32px" }}>
            X
          </Button>
        </div>
        <div>
          <Typography variant="h4" color="primary">
            <span>
              <img
                src={Group217}
                alt="Key"
                style={{
                  maxWidth: "85px",
                  objectFit: "contain",
                  margin: "0 auto",
                  padding: "0",
                }}
              />
            </span>{" "}
          </Typography>
          <Typography variant="h4" color="primary">
            <h6
              style={{
                color: "#3E0BA1",
                font: "normal normal medium 24px/29px Montserrat",
                letterSpacing: "0px",
                fontSize: "24px",
                textAlign: "center",
                marginTop: "0.5em",
                marginBottom: "0em",
              }}
            >
              Forget password
            </h6>
          </Typography>
          <p style={{ marginBottom: "1em" }}>
            No worries, we'll send you reset instructions
          </p>
        </div>
        {isEmailVerified && (
          <span
            role="img"
            aria-label="verified"
            style={{
              backgroundColor: "#3E0BA1",
              color: "white",
              padding: "5px",
              borderRadius: "5px",
            }}
          >
            ✅ verified
          </span>
        )}
        <div>
          <TextField
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            variant="outlined"
            margin="normal"
            type="password"
            style={{
              background: "#FFFFFF 0% 0% no-repeat padding-box",
              borderRadius: "7px",
              opacity: "1",
              fontSize: "14px",
              width: "100%", // Increase the width of the text field
              height: "57px",
              outline: "none",
              marginBottom: "0.9em",
            }}
            placeholder="New Password"
          />
        </div>
        <div>
          <TextField
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            variant="outlined"
            margin="normal"
            type="password"
            style={{
              background: "#FFFFFF 0% 0% no-repeat padding-box",
              borderRadius: "7px",
              opacity: "1",
              fontSize: "14px",
              width: "100%", // Increase the width of the text field
              height: "57px",
              outline: "none",
              marginBottom: "1em",
              marginTop: "0",
            }}
            placeholder="Confirm Password"
          />
        </div>
        <div>
          <button
            variant="contained"
            style={{
              backgroundColor: "#3E0BA1",
              color: "white",
              width: "200px",
              height: "50px",
              borderRadius: "5px",
              marginBottom: "5px",
            }}
            onClick={handleChangePassword}
            disabled={!newPassword || newPassword !== confirmPassword || isLoading}
          >
            {isLoading ? "Changing..." : isChanged ? "Password Changed!" : "CHANGE"}
          </button>
          <p
            onClick={handleBacktoLogin}
            style={{
              cursor: "pointer",
              color: "#3E0BA1",
              fontSize: "14px",
              marginBottom: "0.2em",
              marginTop: "0",
              textDecoration: "underline",
            }}
          >
            Back to login
          </p>
        </div>
      </div>
    </Dialog>
  );
};
export default ChangePassword;
