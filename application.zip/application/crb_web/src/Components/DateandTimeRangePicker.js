import React, { useState, useEffect } from "react";
import DateTimeRangePicker from "@wojtekmaj/react-datetimerange-picker";
import "@wojtekmaj/react-datetimerange-picker/dist/DateTimeRangePicker.css";
import "react-calendar/dist/Calendar.css";
import "react-clock/dist/Clock.css";
import "./datetimerange.css";

function DateandTimerangePicker({ onChange, value }) {
  // State to manage the selected date and time range
  const [selectedRange, setSelectedRange] = useState(value);

  // Update the state when the prop value changes (e.g., when parent re-renders)
  useEffect(() => {
    setSelectedRange(value);
  }, [value]);

  // Function to handle the change in the picker
  const handlePickerChange = (newRange) => {
    setSelectedRange(newRange);
    onChange(newRange);
  };

  return (
    <>
      <DateTimeRangePicker
        onChange={handlePickerChange}
        format="y-MM-dd HH:mm:ss"
        value={selectedRange}
      />
    </>
  );
}

export default DateandTimerangePicker;
