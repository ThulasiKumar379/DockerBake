import React, { useEffect, useState, useMemo, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { Tooltip } from "@mui/material";
import "react-toastify/dist/ReactToastify.css";
import { red } from "@mui/material/colors";
import {
  getFloorsData,
  createFloorData,
  updateFloorData,
  deleteFloorData,
} from "../../api/Floor/floorReducers";
import {
  CssBaseline,
  Box,
  Typography,
  Button,
  Stack,
  Modal,
  TextField,
  Grid,
  Autocomplete,
  FormControlLabel,
  Switch,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import { styled } from "@mui/material/styles";
import Table from "../Table";
import { EditNote } from "@mui/icons-material";
import DoNotDisturbOnIcon from "@mui/icons-material/DoNotDisturbOn";
import SearchIcon from "@mui/icons-material/Search";
import AddIcon from "@mui/icons-material/Add";
import { fetchBuildings, getBuildings } from "../../api/Building/buildingApi"
import { fetchLocationsData } from "../../api/Location/locationReducer";
import { checkUserAccess } from "../../CheckUserAccess";
import { create } from "@mui/material/styles/createTransitions";
import { getFloorsInfo } from "../../api/Floor/floorApis"
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "calc(100% - 64px)",
  maxWidth: "600px",
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 0,
};
export default function SimpleContainer() {
  const [locationError, setLocationError] = useState(false);
  const [buildingError, setBuildingError] = useState(false);
  const [floorIdError, setFloorIdError] = useState(false);
  const [floorNameError, setFloorNameError] = useState(false);
  const [editLocationError, setEditLocationError] = useState(false);
  const [editBuildingError, setEditBuildingError] = useState(false);
  const [editFloorIdError, setEditFloorIdError] = useState(false);
  const [editFloorNameError, setEditFloorNameError] = useState(false);
  const [open, setOpen] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isActive, setIsActive] = useState(true);
  const [buildingData, setBuildingData] = useState([]);
  const [, setIsActiveEdit] = useState(true);
  const [tableData, setTableData] = useState([]);
  const [rowData, setRowData] = useState({});
  const [createdata, setCreateData] = useState({ building_id: '', building_name: '', ubuilding_id: '' });
  const [keyChange, setKeyChange] = useState("");
  const [isFloorDataRerender, setIsFloorDataRerender] = useState(false);
  const [locationSearch, setLocationSearch] = useState([]);
  const [buldingSearch, setBuldingSearch] = useState([]);
  const [autocompleteKey, setAutocompleteKey] = useState(0);
  const [floorData, setFloorData] = useState([]);
  const [locationInputValue, setLocationInputValue] = useState("");
  const [selectedBuldingFilter, setSelectedBuldingFilter] = useState([]);
  const formRef = useRef();
  const floorIdRef = useRef(null);
  const floorNameRef = useRef(null);
  const floorNameEditRef = useRef(null);
  const hasAccess = checkUserAccess("floors")
  const hasAccessToCreate = checkUserAccess("add_floor")
  const hasAccessToEdit = checkUserAccess("edit_floor")
  const hasAccessToDelete = checkUserAccess("delete_floor")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }
  const handleClose = () => {
    resetAddState()
    setOpen(false);
    setIsActive(true);
    resetAddState();
  };

  const resetAddState = () => {
    setFloorIdError(false);
    setLocationError(false);
    setBuildingError(false);
    setFloorNameError(false);
    setCreateData(prevData => ({
      ...prevData,
      location_id: '',
      location_name: '',
    }));
    setAutocompleteKey(prevKey => prevKey + 1);
  };

  const handleCloseEdit = () => {
    setOpenEdit(false);
    resetEditState();
  };
  const resetEditState = () => {
    setEditFloorIdError(false);
    setEditLocationError(false);
    setEditBuildingError(false);
    setEditFloorNameError(false);
  };
  const handleButton = () => {
    setOpen(true);
    setCreateData({});
    resetAddState();
  };
  const handleEditButton = (currentRow) => {
    setOpenEdit(true);
    setRowData(currentRow);
    resetEditState();
  };

  const handleWindowClick = (e) => {
    if (formRef.current && !formRef.current.contains(e.target)) {
      setOpen(false);
      resetAddState();
    }
  };
  useEffect(() => {
    window.addEventListener('click', handleWindowClick);
    return () => {
      window.removeEventListener('click', handleWindowClick);
    };
  }, []);


  useEffect(() => {
    let fetchdata = async () => {
      let locationId = ''; let building_id = '';
      if (locationSearch.length > 0) {
        locationId = locationSearch.map((l) => l.location_id);
      }
      if (buldingSearch.length > 0) {
        building_id = buldingSearch.map((l) => l.building_id);
      }
      let data = await getFloorsInfo(`location_id=${locationId}&building_id=${building_id}`);
      setFloorData({ floors: data })
    }
    fetchdata();
  }, [isFloorDataRerender]);

  const dispatch = useDispatch();
  useEffect(() => {
    const floorfilter = floorData?.floors?.data ?? [];
    if (floorfilter?.length > 0) {
      const newData = floorfilter.map((d) => {
        const {
          floor_id,
          floor_name,
          building_name,
          location_name,
          location_id,
          building_id,
          ubuilding_id,
          ulocation_id,
          status,
          created_at,
          updated_at,
        } = d;
        const constructData = {
          floor_id,
          floor_name,
          building_name,
          location_name,
          location_id,
          ulocation_id,
          building_id,
          ubuilding_id,
          created_at,
          updated_at,
          status: status ? "Active" : "Inactive",
        };
        return constructData;
      });
      setTableData(newData);
    } else {
      setTableData([]);
    }
  }, [floorData]);

  const handleChangeToggle = (event) => setIsActive(event.target.checked);

  const locationData = useSelector((state) => state.locations);
  const clearBuilding = () => {
    setCreateData((prevData) => ({
      ...prevData,
      ['building_id']: '',
      ['building_name']: '',
      ['ubuilding_id']: ''
    }));
  }
  const getBuildingsData = async (v) => {
    let rlt = await fetchBuildings(v)
    setBuildingData({ buildings: rlt })
  }
  const handleChange = async (e, v, name) => {
    if (name == 'location_id' && v != null) {
      clearBuilding();
      getBuildingsData(v)
    } else if (name == 'location_id') {
      clearBuilding();
      setBuildingData([])
    }
    if (name == 'building_id') {
      if (v != null) {
        setCreateData((prevData) => ({
          ...prevData,
          ['building_id']: v.building_id,
          ['building_name']: v.building_name,
          ['ubuilding_id']: v.ubuilding_id
        }));
      } else {
        clearBuilding();
      }

    } else
      if (Array.isArray(v)) {
        const values = v.map((a) => a[name]);
        setCreateData((prevData) => ({
          ...prevData,
          [name]: values,
        }));
      } else {
        const val = v === null ? e?.target?.value : v[name];
        setCreateData((prevData) => ({
          ...prevData,
          [name]: val,
        }));
      }
  };

  const locationNameHandler = async (e, v) => {
    setSelectedBuldingFilter([])
    setBuildingData([])
    setBuldingSearch([])
    let value = v
      ? v.map((option) => option.location_id)
      : [];
    value = value.length > 0 ? value : [];
    setLocationSearch(v)
    setIsFloorDataRerender(!isFloorDataRerender)
    if (value.length > 0) {
      let rlt = await fetchBuildings(v)
      setBuildingData({ buildings: rlt })
    }
  };
  const buildingNameHandler = (e, v) => {
    setBuldingSearch(v)
    setSelectedBuldingFilter(v)
    setIsFloorDataRerender(!isFloorDataRerender)
  };

  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
  const handleToogleChangeEdit = (event) => {
    setIsActiveEdit(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const handleEdit = (e, v, name) => {
    const val = v === null ? e?.target?.value : v[name];
    setRowData((prevData) => ({
      ...prevData,
      [name]: val,
    }));
    if (name === "status") {
      setIsActive(val);
    }
  };
  const clearEditBuilding = async () => {
    setRowData((prevData) => ({
      ...prevData,
      [`building_id`]: "",
      [`ubuilding_id`]: "",
      [`building_name`]: "",
    }));
  }
  const handleEditChange = async (e, v, name) => {
    if (name === "location" && v != null) {
      clearEditBuilding();
      getBuildingsData(v);
    } if (name === "location" && v == null) {
      clearEditBuilding();
      setBuildingData([]);
    }
    if (name === "building" || name === "location") {
      setRowData((prevData) => ({
        ...prevData,
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setRowData((prevData) => ({
        ...prevData,
        [name]: v,
      }));
    }
  };
  useEffect(() => {
    dispatch(fetchLocationsData());
  }, [dispatch]);


  const onDelete = (data) => {
    setSelectedRow(data);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirmed = async () => {
    const payload = {
      floor_id: selectedRow.floor_id,
      building_id: selectedRow.building_id,
    };

    await dispatch(deleteFloorData(payload))
      .then(() => {
        setIsFloorDataRerender(!isFloorDataRerender)
        setTimeout(() => {
          toast.success("Floor Deactivated successfully");
        }, 500);
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to Deactivate floor");
        }, 500);
      });
    setDeleteDialogOpen(false);
  };
  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };
  const columns = [
    {
      field: "floor_id",
      headerName: "Floor ID",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "floor_name",
      headerName: "Floor Name",
      flex: 1,
      width: 200,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "building_name",
      headerName: "Building Name",
      flex: 1,
      width: 200,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "location_name",
      headerName: "Location Name",
      flex: 1,
      width: 200,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "created_at",
      headerName: "Created Date",
      flex: 1,
      width: 200,
      minWidth: 180,
      headerClassName: "super-app-theme--header",
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "updated_at",
      headerClassName: "super-app-theme--header",
      headerName: "Last Updated Date",
      sortable: false,
      flex: 1,
      width: 200,
      minWidth: 180,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return (
          <span style={{ color: params.value ? "#000000" : "#000000" }}>
            {status}
          </span>
        );
      },
    },
    {
      field: "Operations",
      headerClassName: "super-app-theme--header",
      headerName: "Operations",
      width: 180,
      sortable: false,
      disableClickEventBubbling: true,
      renderCell: (params) => {
        const currentRow = params.row;
        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Edit" sx={{ yIndex: 9999 }}>
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleEditButton(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title="Deactive" sx={{ yIndex: 9999 }}>
                <Button
                  disabled={currentRow?.status !== "Active"}
                  color={currentRow?.status !== "Active" ? "warning" : "error"}
                  variant="text"
                  size="small"
                  sx={{
                    minWidth: "32px",
                    opacity: currentRow?.status ? 1 : 0.5,
                    pointerEvents: currentRow?.status ? "auto" : "none",
                    "&:hover": {
                      backgroundColor: "transparent",
                    },
                  }}
                  id="floor_id"
                  onClick={() => onDelete(currentRow)}
                >
                  <DoNotDisturbOnIcon />
                </Button>
              </Tooltip>
            )}
          </Stack>
        );
      },
    },
  ];
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  const handleAdd = async () => {
    if (
      !createdata.location_id ||
      !createdata.building_id ||
      !createdata.floor_name ||
      !createdata.floor_id
    ) {
       let object=[{
      key:createdata.floor_id,
      ref:floorIdRef.current,
    },
    {
      key:createdata.floor_name,
      ref:floorNameRef.current,
    }
  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }

      setLocationError(!createdata.location_id);
      setBuildingError(!createdata.building_id);
      setFloorIdError(!createdata.floor_id);
      setFloorNameError(!createdata.floor_name);

   
      return;
    }
    setLocationError(false);
    setBuildingError(false);
    setFloorIdError(false);
    setFloorNameError(false);
    
    await dispatch(createFloorData(createdata))
      //  const data = response.payload;
      .then((data) => {
        if (data.payload.status) {
          setIsFloorDataRerender(!isFloorDataRerender)
          setKeyChange(true);
          setCreateData({});
          setOpen(false);
          setIsActive(true);
          setTimeout(() => {
            toast.success("Floor created successfully");
            setKeyChange(false);
          }, 500);
        } else {
          setOpen(true);
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setOpen(false);
        setTimeout(() => {
          toast.error("Failed to create Floor");
        }, 500);
      });
    // setOpen(false);
  };
  const handleEditUpdate = async () => {
    if (
      !rowData.location_id ||
      !rowData.building_id ||
      !rowData.floor_name ||
      !rowData.floor_id ||
      editLocationError ||
      editBuildingError ||
      editFloorIdError ||
      editFloorNameError
    ) {
      if (!rowData.floor_name) {
        floorNameEditRef.current.focus()
      }
      setEditLocationError(!rowData.location_id);
      setEditBuildingError(!rowData.building_id);
      setEditFloorIdError(!rowData.floor_id);
      setEditFloorNameError(!rowData.floor_name);

      return;
    }
    setEditLocationError(false);
    setEditBuildingError(false);
    setEditFloorIdError(false);
    setEditFloorNameError(false);

    await dispatch(updateFloorData(rowData))
      .then((data) => {
        if (data.payload.status) {
          setIsFloorDataRerender(!isFloorDataRerender)
          setTimeout(() => {
            toast.success("Floor updated successfully");
          }, 500);
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update floor");
        }, 500);
      });
    setOpenEdit(false);
    setIsActive(true);
  };
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return '';
    }
  };
  return (
    <React.Fragment>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Modal
        keepMounted
        open={open}
        onClose={handleClose}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            Add Floor
            <div style={{ textAlign: "right", display: "inline" }}>
              <Button onClick={handleClose}>X</Button>
            </div>
          </Typography>
          <Box style={{ padding: "10px 15px 25px" }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      Floor ID <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="fullWidth"
                  inputRef={floorIdRef}
                  onChange={(e) => {
                    handleChange(e, null, "floor_id");
                    setFloorIdError("");
                  }}
                  value={createdata.floor_id || ""}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  error={floorIdError || ((createdata && createdata.floor_id && createdata.floor_id.length < 1) || (createdata && createdata.floor_id && createdata.floor_id.length > 120))}
                  helperText={
                    floorIdError
                      ? "Floor ID is required."
                      : (createdata && createdata.floor_id && createdata.floor_id.length < 1)
                        ? "Minimum 2 characters allowed."
                        : (createdata && createdata.floor_id && createdata.floor_id.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                  name="floor_id"
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  key={autocompleteKey}
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  fullWidth
                  id="checkboxes-tags-demo"
                  options={locationData?.locations?.location || []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdLocation(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  name="location_id"
                  onChange={(e, v) => {
                    handleChange(e, v, "location_id");
                    setLocationError("");
                  }}
                  style={{ width: "100%" }}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Location Id-Name"
                      value={createdata.location_name || ""}
                      error={locationError}
                      helperText={
                        locationError ? "location id-name is required." : ""
                      }

                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete

                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="building_id"
                  onChange={(e, v) => {
                    handleChange(e, v, "building_id");
                    setBuildingError("");
                  }}
                  // value={{ ubuilding_id: createdata.ubuilding_id, building_id: createdata.building_id, building_name: createdata.building_name }}
                  key={keyChange && Math.random()}
                  options={buildingData?.buildings?.BuildingsData || []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdBuilding(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Building ID-Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      value={createdata.building || ""}
                      placeholder="Building Id-Name"
                      error={buildingError}
                      helperText={
                        buildingError ? "building id-name is required." : ""
                      }

                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      Floor Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="fullWidth"
                  inputRef={floorNameRef}
                  onChange={(e) => {
                    handleChange(e, null, "floor_name");
                    setFloorNameError("");
                  }}
                  value={createdata.floor_name || ""}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  error={floorNameError || ((createdata && createdata.floor_name && createdata.floor_name.length < 2) || (createdata && createdata.floor_name && createdata.floor_name.length > 120))}
                  helperText={
                    floorNameError
                      ? "Floor Name is required."
                      : (createdata && createdata.floor_name && createdata.floor_name.length < 2)
                        ? "Minimum 2 characters allowed."
                        : (createdata && createdata.floor_name && createdata.floor_name.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                  name="floor_name"
                />
              </Grid>
              <Grid item xs={12} sm={12} className="text-right">
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={isActive}
                      onChange={handleChangeToggle}
                    />
                  }
                  label={isActive ? "Active" : "Inactive"}
                  sx={{ marginLeft: "0" }}
                  labelPlacement="top"
                />
                <Button
                  variant="contained"
                  sx={{
                    marginRight: "10px",
                    marginTop: "10px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                  className="bookingbtn"
                  onClick={handleAdd}
                >
                  Save
                </Button>
                <Button
                  variant="outlined"
                  onClick={handleClose}
                  className="bookingbtn1"
                  sx={{
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                    marginTop: "10px",
                  }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
      <Modal
        keepMounted
        open={openEdit}
        onClose={handleCloseEdit}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            Edit Floor
            <div style={{ textAlign: "right", display: "inline" }}>
              <Button onClick={handleCloseEdit}>X</Button>
            </div>
          </Typography>
          <Box style={{ padding: "10px 10px 25px" }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={<div>
                    Floor ID <RequiredAsterisk>*</RequiredAsterisk>
                  </div>}
                  id="fullWidth"
                  name="floor_id"
                  value={rowData && rowData.floor_id}
                  InputLabelProps={{ shrink: rowData && rowData.floor_id }}
                  onChange={(e) => handleEdit(e)}
                  error={editFloorIdError}
                  helperText={
                    editFloorIdError ? "Floor ID cannot be empty." : ""
                  }
                  InputProps={{
                    readOnly: true,
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  fullWidth
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  // id="checkboxes-tags-demo"
                  id={"location_id"}
                  name="location_id"
                  key={keyChange && Math.random()}
                  value={{
                    location_name: rowData?.location_name,
                    location_id: rowData?.location_id,
                    ulocation_id: rowData?.ulocation_id,
                  }}
                  onChange={(e, v) => {
                    handleEditChange(e, v, "location");
                    setEditLocationError("");
                  }}
                  options={locationData?.locations?.location ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdLocation(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Location Id-Name"
                      error={editLocationError}
                      helperText={
                        editLocationError
                          ? "location id-name cannot be empty."
                          : ""
                      }
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.location_name),
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="building_id"
                  name="building_id"
                  value={{
                    ubuilding_id: rowData?.ubuilding_id,
                    building_id: rowData?.building_id,
                    building_name: rowData?.building_name,
                  }}
                  onChange={(e, v) => {
                    handleEditChange(e, v, "building");
                    setEditBuildingError("");
                  }}
                  key={keyChange && Math.random()}
                  options={buildingData?.buildings?.BuildingsData || []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdBuilding(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Building ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      error={editBuildingError}
                      helperText={
                        editBuildingError
                          ? "building id-name cannot be empty."
                          : ""
                      }
                      placeholder="Building Id-Name"
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.location_name),
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      Floor Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id={"floor_name"}
                  name="floor_name"
                  value={rowData.floor_name}
                  inputRef={floorNameEditRef}
                  onChange={(e) => {
                    handleEdit(e, null, "floor_name");
                    setEditFloorNameError("");
                  }}
                  InputLabelProps={{ shrink: rowData.floor_name }}
                  error={
                    editFloorNameError ||
                    (!rowData || !rowData.floor_name) ||
                    ((rowData && rowData.floor_name && rowData.floor_name.length < 2) ||
                      (rowData && rowData.floor_name && rowData.floor_name.length > 120))
                  }
                  helperText={
                    editFloorNameError
                      ? "Floor Name cannot be empty."
                      : (rowData && rowData.floor_name && rowData.floor_name.length < 2)
                        ? "Minimum 2 characters allowed."
                        : (rowData && rowData.floor_name && rowData.floor_name.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                /> 
              </Grid>
              <Grid item xs={12} sm={12} className="text-right">
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={(rowData?.status == "Active" || rowData?.status == true) ? true : false}
                      onChange={handleToogleChangeEdit}
                    />
                  }
                  label={(rowData?.status == "Active" || rowData?.status == true) ? "Active" : "Inactive"}
                  sx={{ marginLeft: "0" }}
                  labelPlacement="top"
                />
                <Button
                  variant="contained"
                  sx={{
                    marginRight: "10px",
                    marginTop: "10px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                  className="bookingbtn"
                  onClick={handleEditUpdate}
                >
                  update
                </Button>
                <Button
                  variant="outlined"
                  onClick={handleCloseEdit}
                  className="bookingbtn1"
                  sx={{
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                    marginTop: "10px",
                  }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
      <CssBaseline />
      <Box sx={{ bgcolor: "#fff" }}>
        <Grid container mb={2}>
          <Grid item xs={12} sm={8} md={9} lg={10}>
            <Typography variant="h4" sx={{ fontWeight: "600" }}>
              Floor
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4} md={3} lg={2} className="noPadding">
            {hasAccessToCreate.exists && (
              <Button
                fullWidth
                variant="contained"
                sx={{
                  padding: "10px 0",
                  backgroundColor: "#0B78A1 !important",
                  borderRadius: 0,
                  fontSize: "0.75rem !important",
                  lineHeight: "1.125rem",
                  letterSpacing: 0,
                }}
                onClick={handleButton}
                startIcon={<AddIcon />}
              >
                Add New Floor
              </Button>
            )}
          </Grid>
        </Grid>
        <Accordion
          sx={{
            backgroundColor: "#3E0BA1",
            color: "#fff",
            margin: "0 0 15px !important",
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
            aria-controls="panel1a-content"
            id="panel1a-header"
            sx={{
              minHeight: "48px !important",
              "& .Mui-expanded": {
                margin: "12px 0 !important",
              },
            }}
          >
            <Typography>
              <FilterAltIcon />
              Filter
            </Typography>
          </AccordionSummary>
          <AccordionDetails
            sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
          >
            <Grid container spacing={1} sx={{ marginBottom: "20px" }}>
              <Grid item xs={12} sm={12} md={12} lg={12}>
                <Grid container spacing={1}>
                  <Grid item xs={12} sm={6} md={4} lg={2}>
                    <Autocomplete
                      multiple
                      size="small"
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                        marginBottom: "10px",
                      }}
                      id="checkboxes-tags-demo"
                      name="location_name"
                      onChange={(e, v) =>
                        locationNameHandler(e, v)
                      }
                      key={keyChange && Math.random()}
                      options={locationData?.locations?.location ?? []}
                      getOptionLabel={(option) =>
                        getOptionLabelWithIdLocation(option)
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Location Id-Name"
                          placeholder="Location Id-Name"
                          InputLabelProps={{
                            ...params.InputLabelProps,
                            ...labelClassess.label,
                          }}
                        />
                      )}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={2}>
                    <Autocomplete
                      multiple
                      size="small"
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                        marginBottom: "10px",
                      }}
                      id="checkboxes-tags-demo"
                      name="building_name"
                      value={selectedBuldingFilter}
                      onChange={(e, v) =>
                        buildingNameHandler(e, v)
                      }
                      key={keyChange && Math.random()}
                      options={buildingData?.buildings?.BuildingsData || []}
                      getOptionLabel={(option) =>
                        getOptionLabelWithIdBuilding(option)
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Building Id-Name"
                          placeholder="Building Id-Name"
                          InputLabelProps={{
                            ...params.InputLabelProps,
                            ...labelClassess.label,
                          }}
                        />
                      )}
                    />
                  </Grid>

                </Grid>
                <Grid container sx={{ justifyContent: "end" }}>
                  <Grid item xs={12} sm={4} md={3} lg={2}>
                    <Button
                      fullWidth
                      variant="contained"
                      onClick={() => { }
                      }
                      sx={{
                        padding: "10px 0",
                        backgroundColor: "#3E0BA1 !important",
                        borderRadius: 0,
                        fontSize: "0.75rem !important",
                        lineHeight: "1.125rem",
                        letterSpacing: 0,
                      }}
                      startIcon={<SearchIcon />}
                    >
                      Search
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>
        <Table data={tableData} columns={columns} id="floor_id" />
      </Box>
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle>Deactive Participant</DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={() => setDeleteDialogOpen(false)}>X</Button>
          </div>
        </div>
        <DialogContent>
          Are you sure you want to Deactive this Floor?
        </DialogContent>
        <DialogActions sx={{ paddingBottom: "15px" }}>
          <Button
            onClick={handleDeleteConfirmed}
            className="bookingbtn"
            sx={{
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
          >
            Deactive
          </Button>
          <Button
            onClick={() => setDeleteDialogOpen(false)}
            className="bookingbtn1"
            sx={{
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}
