import React, { useEffect, useState, useMemo } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AddRoom from './popups/AddRoom'
import EditRoom from './popups/EditRoom'
import {
  CssBaseline,
  Box,
  Container,
  Typography,
  Button,
  Stack, 
  TextField, 
  Grid,
  Autocomplete,
  Checkbox, 
  DialogTitle,
  Dialog,
  Tooltip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import Table from "../Table";
import {
  EditNote,
  CheckBox,
  CheckBoxOutlineBlank,
  Add as AddIcon,
  Search as SearchIcon,
  FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
  DoNotDisturbOn as DoNotDisturbOnIcon,
  AddCircle as AddCircleIcon,
} from "@mui/icons-material";
import { 
  updateRoomData, 
  deleteRoomData,
} from "../../api/Rooms/roomReducer"; 
import { fetchAmenitiesData } from "../../api/Amenities/amenitiesReducers"; 
import { fetchLocationsData } from "../../api/Location/locationReducer";
import {getRoomsdata} from "../../api/Rooms/roomApis";
import {fetchBuildings} from "../../api/Building/buildingApi"
import {fetchFloors} from "../../api/Floor/floorApis"
import { checkUserAccess } from "../../CheckUserAccess";

const Capacity = [
  { label: "0-50" },
  { label: "51-100" },
  { label: "101-150" },
  { label: "151-200" },
  { label: "201-250" },
  { label: "251-300" },
];

const icon = <CheckBoxOutlineBlank fontSize="small" />;

const checkedIcon = <CheckBox fontSize="small" />;

export default function SimpleContainer() {
  const [, setIsActive] = useState(true);
  const [modelOpen, setModelOpen] = useState(false);
  const [editModelOpen, setEditModelOpen] = useState(false);  
  const [openEdit, setOpenEdit] = useState(false); 
  const [rowData, setRowData] = useState(null); 
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [deleteRoomId, setDeleteRoomId] = useState(null);
  const [keyChange, setKeyChange] = useState("");  
  const [tableData, setTableData] = useState([]);
  const [roomTabledata, setRoomTabledata] = useState(false);  
  const [currentRow, setCurrentRow] = useState(null); 
  
// search variables 
const [amenitySearch, setAmenitySearch] = useState([]); 
const [locationSearch, setLocationSearch] = useState([]); 
const [buildingSearch, setBuildingSearch] = useState([]);
const [floorSearch, setFloorSearch] = useState([]);
const [capacitySearch, setCapacitySearch] = useState([]);
const [floorData, setFloorData] = useState([]);
const [buildingData, setBuildingData] = useState([]);  
const [selectedBuldingFilter, setSelectedBuldingFilter] = useState([]);
const [selectedAmenityFilter, setselectedAmenityFilter] = useState([]);
const [selectedFloorFilter, setSelectedFloorFilter] = useState([]);
  let roomDatas=[]; 
  const [, setShowAllAmenitiesArray] = useState(
    Array(tableData.length).fill(false)
  );

  const hasAccess=checkUserAccess("rooms")
  const hasAccessToCreate=checkUserAccess("add_room")
  const hasAccessToEdit=checkUserAccess("edit_room")
  const hasAccessToDelete=checkUserAccess("delete_room")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
      navigate("/");
   }
  useEffect(() => { 
    if (tableData.length > 0) {
      setShowAllAmenitiesArray(Array(tableData.length).fill(false));
    }
  }, [tableData]); 
  const dispatch = useDispatch();    
  useEffect(() => { 
    const fetchData = async () => {
      roomDatas = await getRoomsdata(locationSearch, buildingSearch, floorSearch, capacitySearch, amenitySearch);
      roomDatas=roomDatas?.rooms?roomDatas.rooms:[]; 
      if (roomDatas.length > 0) { 
        const newData = roomDatas.map((d) => { 
          const { building_id,ubuilding_id, building_name } = d.crbt_buildings;
          const { floor_id,ufloor_id, floor_name } = d.crbt_floors;
          const { location_id, location_name,ulocation_id } = d.crbt_locations;
          const { amenities, capacity, room_id,roomid, room_name, status } = d; 
          const amenity_id = amenities && amenities.length > 0 ? amenities[0].amenity_id : null;
          const amenity_name = (amenities!=null && amenities.length > 0) ? amenities[0].amenityname : null;
          let datas = {   
            roomid,        
            amenities,
            capacity,            
            building_id,
            ubuilding_id,
            building_name,
            ufloor_id,
            floor_id,
            floor_name,
            location_id,
            ulocation_id,
            location_name,
            room_id,
            room_name,
            status:status?'Active':'Inactive',
            amenity_id,
            amenity_name,
          }; 
          return datas;
        }); 
        setTableData(newData);       
      }else{
        setTableData([])
      }
    }

    fetchData(); 
  }, [roomTabledata]);
   
  const handleButton = () => {setModelOpen(true);}

  const handleEditButton = (currentRow) => {
    setOpenEdit(true);
    const {
      room_id,
      roomid,
      capacity,
      room_name,
      location_id,
      ulocation_id,
      location_name,
      floor_id,
      ufloor_id,
      floor_name,
      building_id,
      ubuilding_id,
      building_name,
      status,
      amenities
    } = currentRow; 
    let data = currentRow;
    data.room_amenities=currentRow.amenities;    
    setRowData(data);
    setEditModelOpen(true)
  }; 
  const locationData = useSelector((state) => state.locations);
  const amenityOptions = useSelector((state) => state.amenities);
  useEffect(() => {  
    dispatch(fetchLocationsData());
    dispatch(fetchAmenitiesData());
  }, [dispatch]); 
// const buildingData = useSelector((state) => state.buildings); 
  let fetchBuildingData=async (v)=>{ 
    setFloorData([])
    if(v!=null){
      let rlt=await fetchBuildings(v) 
      setBuildingData({buildings:rlt}) 
    }else{
      setBuildingData([])
      setFloorData([])
    }
  }

  let fetchFloorData=async (v)=>{ 
    if(v!=null){
      let rlt=await fetchFloors(v)  
       setFloorData({floors:rlt}) 
    }else{
      setFloorData([])
    }
  }  
  const handleAmenityFilter = async (e, v) => {
    const value = v ? v.map((option) => option.amenityid) : [];
    setselectedAmenityFilter(v);
    setAmenitySearch(value);
    setRoomTabledata(!roomTabledata);
  };
  const handleChangeFilter =async  (e, v, name) => { 
    let value=[];
    if(name=="location_name"){
      setSelectedBuldingFilter([])
      setSelectedFloorFilter([])
       value = v? v.map((option) => option.location_id): []; 
        value=value.length>0?value:"";
        if(value.length!=0){ 
          fetchBuildingData(v);
        }else{
          setBuildingData([])
          setFloorData([])
          setBuildingSearch([])
          setFloorSearch([])
        }
        setLocationSearch(value)
    } 
    if(name=="building_name"){    
      setSelectedFloorFilter([])
        value = v? v.map((option) => option.building_id): []; 
        value=value.length>0?value:""; 
       if(v.length>0){
        fetchFloorData(v)
        setSelectedBuldingFilter(v)
       }else{
        setFloorData([])
        setFloorSearch([])
        setSelectedBuldingFilter([])
       }  
      setBuildingSearch(value)
    } 
    if(name=="floor_name"){
      value = v? v.map((option) => option.floor_id): []; 
      value=value.length>0?value:"";
      setFloorSearch(value)
      setSelectedFloorFilter(v)
     
    } 
    if(name=="capacity"){
      if(v!=null){
        setCapacitySearch(v.label)
      }else{
        setCapacitySearch('')
      } 
    } 
    setRoomTabledata(!roomTabledata)    
  }; 
  
  const handleShowDeleteConfirmation = (currentRow) => {
    setDeleteRoomId(currentRow);
    setCurrentRow(currentRow);
    setShowDeleteConfirmation(true);
  };

  const handleHideDeleteConfirmation = () => {
    setShowDeleteConfirmation(false);
    setDeleteRoomId(null);
  };

  const handleDeleteConfirmation = () => {
    setShowDeleteConfirmation(false);
    if (deleteRoomId) {
      onDelete(deleteRoomId);
    }
  }; 
  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };

  const onDelete = async (currentRow) => {
    const payload = {
      room_id: currentRow.room_id.toString(),
      isactive: !(currentRow.status=='Active') ? 1 : 0,
    };
    await dispatch(deleteRoomData(payload))
      .then((data) => { 
        if (data.payload.status) { 
          setTimeout(() => { 
            setRoomTabledata(!roomTabledata)
            toast.success(
              `Room ${
                currentRow?.status=="Inactive" ? "Activate" : "Deactivate"
              } successfully`
            );
          }, 500);
        } else {
          setTimeout(() => {
            toast.error(data.message);
          }, 500);
        }
      })
      .catch(() => {
       setTimeout(() => {
         toast.error(
           `Failed to ${currentRow?.status=="Inactive" ? "Activate" : "Deactivate"} Room`
         );
       }, 500);
      });
  };
  
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };
  const getOptionLabelWithIdFloor = (option) => {
    if (option?.floor_id) {
      return `${option.ufloor_id} - ${option.floor_name}`;
    } else {
      return option?.floor_name;
    }
  };
  const getOptionLabelWithIdAmenity = (option) => {
    if (option?.amenity_id) {
      return `${option.amenity_id} - ${option.amenityname}`;
    } else {
      return option?.amenityname;
    }
  };  
const roomTableDataRerander=()=>{
  setRoomTabledata(!roomTabledata);
}
  const columns = [
    {
      field: "roomid",
      headerName: "Room ID",
      flex: 1,
      width: 100,
      minWidth: 90,
      headerClassName: "super-app-theme--header",
    }, 
    {
    field: "location_name",
    headerName: "Location",
    flex: 1,
    width: 200,
    minWidth: 200,
    headerClassName: "super-app-theme--header"
  },
    {
      field: "building_name",
      headerName: "Building Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header"
    },
    {
      field: "floor_name",
      headerName: "Floor Name",
      flex: 1,
      width: 120,
      minWidth: 120,
      headerClassName: "super-app-theme--header"
    },
    {
      field: "room_name",
      headerName: "Room Name",
      flex: 1,
      width: 150,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "capacity",
      headerName: "Capacity",
      flex: 1,
      width: 100,
      minWidth: 90,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "amenities",
      headerName: "Amenities",
      flex: 1,
      width: 150,
      minWidth: 160,
      overflowX: "scroll !important",
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        return (
          <div
            style={{
              display: "inline-flex",
              height: "60px",
              overflowX: params.value.length > 7 ? "scroll" : "hidden",
            }}
          >
            {params.value.map((amenity) => (
              <Tooltip
                title={` ${amenity.amenityname}`}
                placement="top"
                key={amenity.amenityid} // Using a unique and stable key
              >
                <img
                  src={`${process.env.REACT_APP_BASE_URL}/amenities/getRoomThumbnails?amenityid=${amenity.amenityid}&thumbnail_key=${amenity.thumbnail_key}`}
                  alt={amenity.amenityid}
                  style={{
                    flex: "0 0 auto",
                    width: "20px",
                    padding: "0",
                    objectFit: "contain",
                  }}
                />
              </Tooltip>
            ))}
          </div>
        );
      },
    },

    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 80,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return <span>{status}</span>;
      },
    },
    {
      field: "action",
      headerName: "Operations",
      headerClassName: "super-app-theme--header",
      width: 100,
      sortable: false,
      disableClickEventBubbling: true,
      renderCell: (params) => {
        const currentRow = params.row;

        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleEditButton(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
            <Tooltip title={currentRow.status=="Active" ? "Deactivate" : "Activate"}>
              <Button
                variant="text"
                color={currentRow?.status === "Inactive" ? "success" : "error"}
                size="small"
                onClick={() => handleShowDeleteConfirmation(currentRow)}
                sx={{ minWidth: "32px" }}
              >
                {currentRow?.status === "Inactive" ? (
                  <AddCircleIcon color="disabled" />
                ) : (
                  <DoNotDisturbOnIcon color="error" />
                )}
              </Button>
            </Tooltip>
            )}
          </Stack>
        );
      },
    },
  ];  
  const addRoomClose=()=>{
    setModelOpen(false);
  }
  const editRoomClose=()=>{
    setEditModelOpen(false)
  }
  return (
    <React.Fragment>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      
      <AddRoom modelOpen={modelOpen} roomTable={roomTableDataRerander} close={addRoomClose}/>
      <EditRoom modelOpen={editModelOpen} editData={rowData} roomTable={roomTableDataRerander} close={editRoomClose}/>
      <Dialog open={showDeleteConfirmation} onClose={handleHideDeleteConfirmation}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #e9ecef" }}>
          <DialogTitle>
            {currentRow?.status=="Inactive" ? "Activate" : "Deactivate"}
          </DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleHideDeleteConfirmation}>X</Button>
          </div>
        </div>
        <Typography sx={{ padding: "10px" }}>
          {currentRow?.status=="Inactive"
            ? "Are you sure you want to Activate this room?"
            : "Are you sure you want to Deactivate this room?"}
        </Typography>
        <div style={{ padding: "10px 15px", textAlign: "right" }}>
          <Button
            variant="contained"
            color="error"
            onClick={handleDeleteConfirmation}
            sx={{
              marginLeft: "10px",
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
            className="bookingbtn"
          >
            {currentRow?.status=="Inactive" ? "Activate" : "Deactivate"}
          </Button>
          <Button
            variant="outlined"
            onClick={handleHideDeleteConfirmation}
            sx={{
              marginLeft: "10px",
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
            className="bookingbtn1"
          >
            Cancel
          </Button>
        </div>
      </Dialog>  
      <CssBaseline />
      {/* search filter */}
      <Container maxWidth="xl" sx={{ padding: "0 !important" }}>
        <Box sx={{ bgcolor: "#fff" }}>
          <Grid
            container
            spacing={1}
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "20px",
            }}
          >
            <Grid item xs={12} sm={8} md={9} lg={10}>
              <Typography variant="h4" sx={{ fontWeight: "600" }}>
                Rooms
              </Typography>
            </Grid>
            <Grid
              className="noPadding noPadding600"
              item
              xs={12}
              sm={4}
              md={3}
              lg={2}
            >
              {hasAccessToCreate.exists&&(
              <Button
                size="small"
                fullWidth
                variant="contained"
                sx={{
                  padding: "11px 0",
                  backgroundColor: "#0B78A1 !important",
                  borderRadius: 0,
                  fontSize: "0.75rem !important",
                  lineHeight: "1.125rem",
                  letterSpacing: 0,
                }}
                onClick={handleButton}
                startIcon={<AddIcon />}
              >
                Add New Room
              </Button>
              )}
            </Grid>
          </Grid>

          <Accordion
            sx={{
              backgroundColor: "#3E0BA1",
              color: "#fff",
              margin: "0 0 15px !important",
              borderRadius: "0 !important",
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
              aria-controls="panel1a-content"
              id="panel1a-header"
              sx={{
                minHeight: "48px !important",
                "& .Mui-expanded": {
                  margin: "12px 0 !important",
                },
              }}
            >
              <Typography>
                <FilterAltIcon /> Filter
              </Typography>
            </AccordionSummary>
            <AccordionDetails
              sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
            >
              <Box>
                <Grid container spacing={1}>
                  <Grid item xs={12} sm={12} md={12} lg={12}>
                    <Grid container spacing={1}>
                      
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="location_name"
                          onChange={(e, v) =>
                            handleChangeFilter(e, v, "location_name")
                          }
                          key={keyChange}
                          options={locationData?.locations?.location ?? []}
                          getOptionLabel={(option) =>
                            getOptionLabelWithIdLocation(option)
                          }
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Location Id-Name"
                              placeholder="Location Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                                ...labelClassess.label,
                              }}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="building_name"
                          onChange={(e, v) =>
                            handleChangeFilter(e, v, "building_name")
                          }
                          value={selectedBuldingFilter}
                          key={keyChange}
                          options={buildingData?.buildings?.BuildingsData || []}
                          getOptionLabel={(option) =>
                            getOptionLabelWithIdBuilding(option)
                          }
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Building Id-Name"
                              placeholder="Building Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                                ...labelClassess.label,
                              }}
                            />
                          )}
                        />
                      </Grid> 

                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                              padding: "8px",
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="floor_name"
                          value={selectedFloorFilter}
                          onChange={(e, v) => handleChangeFilter(e, v, "floor_name")}
                          key={keyChange}
                          options={floorData?.floors?.floorsData || []}
                          getOptionLabel={(option) => getOptionLabelWithIdFloor(option)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Floor Id-Name"
                              placeholder="Floor Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                              }}
                            />
                          )}
                        />
                      </Grid>                      
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          size="small"
                          id="checkboxes-tags-demo"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                            },
                            marginBottom: "10px",
                          }}
                          options={Capacity}
                          getOptionLabel={(option) => option.label}
                          name="capacity"
                          onChange={(e, v) =>
                            handleChangeFilter(e, v, "capacity")
                          }
                          renderOption={(props, option, { selected }) => (
                            <li {...props}>
                              <Checkbox
                                icon={icon}
                                checkedIcon={checkedIcon}
                                style={{ marginRight: 8 }}
                                checked={selected}
                              />
                              {option.label}
                            </li>
                          )}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Capacity"
                              placeholder="Capacity"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                                ...labelClassess.label,
                              }}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          size="small"
                          multiple
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          options={amenityOptions?.amenities?.amenitydata || []}
                          getOptionLabel={(option) => getOptionLabelWithIdAmenity(option)}
                          name="room_amenities"
                          value={selectedAmenityFilter}
                          onChange={(e, v) => handleAmenityFilter(e, v)}
                          key={keyChange && Math.random()}
                          renderOption={(props, option, { selected }) => (
                            <li {...props}>
                              <Checkbox
                                icon={icon}
                                checkedIcon={checkedIcon}
                                style={{ marginRight: 8 }}
                                checked={selected}
                              />
                              {getOptionLabelWithIdAmenity(option)}
                            </li>
                          )}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Amenities"
                              placeholder="Amenities"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                                ...labelClassess.label,
                              }}
                            />
                          )}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid
                  container
                  sx={{ justifyContent: "end", marginBottom: "15px" }}
                > 
                </Grid>
              </Box>
            </AccordionDetails>
          </Accordion>
          <Table data={tableData} columns={columns} id="room_id" />
        </Box>
      </Container>
    </React.Fragment>
  );
}