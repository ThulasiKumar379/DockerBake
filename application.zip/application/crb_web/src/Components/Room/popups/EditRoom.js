import React, { useEffect, useState, useMemo, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import { fetchBuildings } from "../../../api/Building/buildingApi"
import { fetchFloors } from "../../../api/Floor/floorApis";
import { styled } from "@mui/material/styles";
import { CheckBox, CheckBoxOutlineBlank } from "@mui/icons-material";
import { updateRoomData } from "../../../api/Rooms/roomReducer";
import {
  Box,
  Typography,
  Button,
  Modal,
  TextField,
  FormControlLabel,
  Grid,
  Autocomplete,
  Checkbox,
  Switch,
} from "@mui/material";

const icon = <CheckBoxOutlineBlank fontSize="small" />;
const checkedIcon = <CheckBox fontSize="small" />;
const RequiredAsterisk = styled("span")({
  color: "red",
});
export default function EditRoom({ modelOpen, editData, roomTable, close }) {
  const [, setIsActive] = useState(true);
  const [rowData, setRowData] = useState(null);
  const [editLocationError, setEditLocationError] = useState(false);
  const [editBuildingError, setEditBuildingError] = useState(false);
  const [editFloorError, setEditFloorError] = useState(false);
  const [editNameError, setEditNameError] = useState(false);
  const [editCapacityError, setEditCapacityError] = useState(false);
  const [editAmenityError, setEditAmenityError] = useState(false);
  const [floorData, setFloorData] = useState([]);
  const [buildingData, setBuildingData] = useState([]);
  const locationData = useSelector((state) => state.locations);
  const amenityOptions = useSelector((state) => state.amenities);
  const [keyChange, setKeyChange] = useState("");
  const roomNameEditRef = useRef(null);
  const capacityEditRef = useRef(null);

  useEffect(() => {
    setRowData(editData);
    fetchBuildingData([editData])
    fetchFloorData([editData]);
  },
    [editData]);
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
  const handleToogleEdit = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };
  const getOptionLabelWithIdFloor = (option) => {
    if (option?.floor_id) {
      return `${option.ufloor_id} - ${option.floor_name}`;
    } else {
      return option?.floor_name;
    }
  };

  let fetchBuildingData = async (v) => {
    if (modelOpen) {
      setFloorData([])
      if (v != null) {
        let rlt = await fetchBuildings(v)
        setBuildingData({ buildings: rlt })
      } else {
        setBuildingData([])
        setFloorData([])
      }
    }

  }

  const handleEditChange = async (e, v, name) => {
    let val = v === null ? e?.target?.value : v[name];
    if (name === "room_amenities") {
      setRowData((prevData) => ({
        ...prevData,
        [name]: v,
      }));
    } else if (name === "building" || name === "location" || name === "floor") {
      setRowData((prevData) => ({
        ...prevData,
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setRowData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }

    if (name === "location") {
      setRowData((prevData) => ({
        ...prevData,
        [`building_id`]: "",
        [`building_name`]: "",
        [`floor_id`]: "",
        [`floor_name`]: "",
      }));
      await fetchBuildingData(v);
    } else if (name === "building") {
      setRowData((prevData) => ({
        ...prevData,
        [`floor_id`]: "",
        [`floor_name`]: "",
      }));
      if (v !== null) {
        await fetchFloorData([v]);
      } else {
        setFloorData([]);
      }
    }
  };
  let fetchFloorData = async (v) => {
    if (modelOpen) {
      if (v != null) {
        let rlt = await fetchFloors(v)
        setFloorData({ floors: rlt })
      } else {
        setFloorData([])
      }
    }

  }
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    maxWidth: "600px",
    width: "calc(100% - 64px)",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 0,
  };
  const dispatch = useDispatch();
  const handleEditUpdate = async () => {
    if (
      !rowData.location_id ||
      !rowData.building_id ||
      !rowData.floor_id ||
      !rowData.room_name ||
      !rowData.capacity ||
      !rowData.room_amenities ||
      editLocationError ||
      editBuildingError ||
      editFloorError ||
      editNameError ||
      editCapacityError ||
      editAmenityError
    ) {
      setEditLocationError(!rowData.location_id);
      setEditBuildingError(!rowData.building_id);
      setEditFloorError(!rowData.floor_id);
      setEditNameError(!rowData.room_name);
      setEditCapacityError(!rowData.capacity);
      setEditAmenityError(!rowData.room_amenities);

      let object=[{
      key:rowData.room_name,
      ref:roomNameEditRef.current,
    },
    {
      key:rowData.capacity,
      ref:capacityEditRef.current,
    },
  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }

      return;
    }
    setEditLocationError(false);
    setEditBuildingError(false);
    setEditFloorError(false);
    setEditNameError(false);
    setEditCapacityError(false);
    setEditAmenityError(false);
    const selectedAmenities = [...rowData.room_amenities];
    const amenityIds = selectedAmenities.map((amenity) => amenity.amenityid);
    if (amenityIds.length === 0) {
      setEditAmenityError(true);
      return;
    }
    const updatedRowData = {
      ...rowData,
      room_amenities: amenityIds,
    };
    await dispatch(updateRoomData(updatedRowData))
      .then((data) => {
        if (data.payload.status) {
          roomTable();
          setTimeout(() => {
            toast.success("Room updated successfully");
          }, 500);
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update Room");
        }, 500);
      });
    close();
  };
  const handleCloseEdit = () => {
    close();
    resetEditState();
  };
  const resetEditState = () => {
    setEditLocationError(false);
    setEditBuildingError(false);
    setEditFloorError(false);
    setEditNameError(false);
    setEditCapacityError(false);
    setEditAmenityError(false);
    setRowData(null);
  };

  return (
    <Modal
      keepMounted
      open={modelOpen}
      onClose={handleCloseEdit}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
    >
      <Box sx={style}>
        <Typography
          id="modal-modal-title"
          variant="h6"
          component="h2"
          sx={{
            borderBottom: "1px solid #e9ecef",
            marginBottom: "20px",
            padding: "10px",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          Edit Room
          <div style={{ textAlign: "right", display: "inline" }}>
            <Button onClick={handleCloseEdit}>X</Button>
          </div>
        </Typography>
        <Box style={{ padding: "10px 15px 25px", textAlign: "left" }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label={<div>
                  Room ID <RequiredAsterisk>*</RequiredAsterisk>
                </div>}
                InputProps={{
                  readOnly: true,
                }}
                id={"room_id"}
                name="room_id"
                value={rowData && rowData.roomid}
                InputLabelProps={{ shrink: rowData && rowData.room_id }}
                sx={{
                  marginBottom: "0px",
                  marginRight: "10px",
                  fieldset: {
                    borderRadius: 0,
                  },
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id={"location_name"}
                name="location_name"
                onChange={(e, v) => {
                  handleEditChange(e, v, "location");
                  setEditLocationError("");
                }}
                options={locationData?.locations?.location || []}
                getOptionLabel={(option) =>
                  getOptionLabelWithIdLocation(option)
                }
                value={{
                  location_name: rowData?.location_name,
                  location_id: rowData?.location_id,
                  ulocation_id: rowData?.ulocation_id,
                }}
                getOptionDisabled={(option) => option.status === false}
                renderInput={(params) => (
                  <TextField
                    fullWidth
                    {...params}
                    label={<div>
                      Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Location Id-Name"
                    error={editLocationError}
                    helperText={
                      editLocationError ? "Location can't be empty." : ""
                    }
                    InputLabelProps={{
                      shrink:
                        Boolean(params.inputProps.value) ||
                        Boolean(rowData?.location_name),
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id={"building_name"}
                name="building_name"
                clearOnEscape
                options={buildingData?.buildings?.BuildingsData || []}
                key={keyChange}
                value={{
                  ubuilding_id: rowData?.ubuilding_id,
                  building_id: rowData?.building_id,
                  building_name: rowData?.building_name,
                }}
                onChange={(e, v) => {
                  handleEditChange(e, v, "building");
                  setEditBuildingError("");
                }}
                getOptionLabel={(option) =>
                  getOptionLabelWithIdBuilding(option)
                }
                getOptionDisabled={(option) => option.status === false}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Building ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Building Id-Name"
                    error={Boolean(editBuildingError)}
                    helperText={
                      editBuildingError ? "Building can't be empty." : ""
                    }
                    InputLabelProps={{
                      shrink:
                        Boolean(params.inputProps.value) ||
                        Boolean(rowData?.building_name),
                    }}
                  />
                )}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id={"floor_name"}
                name="floor_name"
                clearOnEscape
                options={floorData?.floors?.floorsData || []}
                onChange={(e, v) => {
                  handleEditChange(e, v, "floor");
                  setEditFloorError("");
                }}
                key={keyChange}
                value={{
                  ufloor_id: rowData?.ufloor_id,
                  floor_id: rowData?.floor_id,
                  floor_name: rowData?.floor_name,
                }}
                getOptionLabel={(option) =>
                  getOptionLabelWithIdFloor(option)
                }
                getOptionDisabled={(option) => option.status === false}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Floor ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Floor Id-Name"
                    error={Boolean(editFloorError)}
                    helperText={
                      editFloorError ? "Floor can't be empty." : ""
                    }
                    InputLabelProps={{
                      shrink:
                        Boolean(params.inputProps.value) ||
                        Boolean(rowData?.floor_name),
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                open={modelOpen}
                label={
                  <div>
                    Room Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                id={"room_name"}
                name="room_name"
                inputRef={roomNameEditRef}
                error={
                  editNameError ||
                  (!rowData || !rowData.room_name) ||
                  ((rowData && rowData.room_name && rowData.room_name.length < 2) ||
                    (rowData && rowData.room_name && rowData.room_name.length > 120))
                }
                helperText={
                  editNameError
                    ? "Name can't be empty."
                    : (rowData && rowData.room_name && rowData.room_name.length < 2)
                      ? "Minimum 2 characters allowed."
                      : (rowData && rowData.room_name && rowData.room_name.length > 120)
                        ? "Maximum 120 characters allowed."
                        : ""
                }
                value={rowData && rowData.room_name}
                InputLabelProps={{ shrink: rowData && rowData.room_name }}
                sx={{ marginBottom: "0px", marginRight: "10px" }}
                onChange={(e) => {
                  handleEditChange(e, null, "room_name");
                  setEditNameError("");
                }}
              /> 
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label={<div>
                  Capacity <RequiredAsterisk>*</RequiredAsterisk>
                </div>}
                id={"capacity"}
                name="capacity"
                inputRef={capacityEditRef}
                error={editCapacityError}
                helperText={
                  editCapacityError ? "Capacity can't be empty." : ""
                }
                value={rowData && rowData.capacity}
                InputLabelProps={{ shrink: rowData && rowData.capacity }}
                onChange={(e) => {
                  handleEditChange(e, null, "capacity");
                  setEditCapacityError("");
                }}
                sx={{
                  marginBottom: "0px",
                  marginRight: "10px",
                  fieldset: {
                    borderRadius: 0,
                  },
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                multiple
                fullWidth
                size="small"
                id="room_amenities"
                name="room_amenities"
                options={amenityOptions?.amenities?.amenitydata || []}
                getOptionLabel={(option) => option.amenityname}
                value={rowData?.room_amenities || []}
                onChange={(e, v) => {
                  handleEditChange(e, v, "room_amenities");
                  setEditAmenityError("");
                }}
                clearOnEscape
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      icon={icon}
                      checkedIcon={checkedIcon}
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option.amenityname}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Amenities <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Amenities"
                    error={editAmenityError}
                    helperText={
                      editAmenityError ? "Amenity can't be empty." : ""
                    }
                    InputLabelProps={{
                      shrink: Boolean(rowData && rowData.room_amenities),
                    }}
                  />
                )}
              />
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              sx={{
                display: "flex",
                justifyContent: "end",
                alignItems: "end",
              }}
            >
              <FormControlLabel
                control={
                  <IOSSwitch
                    checked={(rowData?.status == true || rowData?.status == 'Active') ? true : false}
                    onChange={handleToogleEdit}
                  />
                }
                label={(rowData?.status === "Active" || rowData?.status === true) ? "Active" : "Inactive"}
                sx={{ marginBottom: "0" }}
                labelPlacement="top"
              />
              <Button
                variant="contained"
                className="bookingbtn"
                sx={{
                  marginRight: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
                onClick={handleEditUpdate}
              >
                Update
              </Button>
              <Button
                variant="contained"
                sx={{ fontSize: "0.75rem", textTransform: "capitalize" }}
                onClick={handleCloseEdit}
                className="bookingbtn1"
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Modal>
  )

}









