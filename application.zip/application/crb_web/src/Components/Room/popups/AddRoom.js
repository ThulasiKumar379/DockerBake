import React, { useEffect, useState, useMemo, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import { fetchBuildings } from "../../../api/Building/buildingApi"
import { fetchFloors } from "../../../api/Floor/floorApis";
import { styled } from "@mui/material/styles";
import { createRoomData } from "../../../api/Rooms/roomReducer";
import { CheckBox, CheckBoxOutlineBlank } from "@mui/icons-material";
import {
  Box,
  Typography,
  Button,
  Stack,
  Modal,
  TextField,
  FormControlLabel,
  Grid,
  Autocomplete,
  Checkbox,
  Switch,
} from "@mui/material";

const icon = <CheckBoxOutlineBlank fontSize="small" />;
const checkedIcon = <CheckBox fontSize="small" />;
export default function AddRoom({ modelOpen, roomTable, close }) {
  const dispatch = useDispatch();
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [createData, setCreateData] = useState({ status: isActiveAdd, ubuilding_id: '', building_id: '', ufloor_id: '', floor_id: '', building_name: '', floor_name: '' });
  let resetCreateData = () => {
    setCreateData({
      status: isActiveAdd,
      location_id: '', ulocation_id: '', location_name: '',
      ubuilding_id: '', building_id: '', building_name: '',
      ufloor_id: '', floor_id: '', floor_name: '', room_amenities: []
    });
  }
  const resetAddState = () => {
    setRoomIdError(false);
    setLocationError(false);
    setBuildingError(false);
    setFloorError(false);
    setNameError(false);
    setCapacityError(false);
    setAmenityError(false);
    setKeyChange(keyChange + 1);
  };
  const [keyChange, setKeyChange] = useState("");
  const [roomIdError, setRoomIdError] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const [buildingError, setBuildingError] = useState(false);
  const [floorError, setFloorError] = useState(false);
  const [nameError, setNameError] = useState(false);
  const [capacityError, setCapacityError] = useState(false);
  const [amenityError, setAmenityError] = useState(false);
  const [, setIsActive] = useState(true);
  const [floorData, setFloorData] = useState([]);
  const [buildingData, setBuildingData] = useState([]);
  const locationData = useSelector((state) => state.locations);
  const amenityOptions = useSelector((state) => state.amenities);
  const roomIdRef = useRef(null);
  const roomNameRef = useRef(null);
  const capacityRef = useRef(null);
  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };
  const getOptionLabelWithIdFloor = (option) => {
    if (option?.floor_id) {
      return `${option.ufloor_id} - ${option.floor_name}`;
    } else {
      return option?.floor_name;
    }
  };
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    maxWidth: "600px",
    width: "calc(100% - 64px)",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 0,
  };
  const handleToogleAdd = (event) => {
    setIsActiveAdd(event.target.checked);
  };
  const handleClose = () => {
    setIsActive(true);
    resetCreateData();
    resetAddState();
    close();
  };
  const addRoomHandleChange = (e, v, name) => {
    const val = v === null ? e?.target?.value : v[name];
    if (Array.isArray(v)) {
      if (name === 'room_amenities') {
        const AmmValues = v.map((a) => a.amenityid);
        setCreateData((prevData) => ({
          ...prevData,
          [name]: AmmValues,
        }));
      }
    } else if (name === "building" || name === "location" || name === "floor") {
      setCreateData((prevData) => ({
        ...prevData,
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setCreateData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }
    let setEmptyCreateData = (name, v) => {
      setCreateData((prevData) => ({
        ...prevData,
        [`${name}_id`]: "",
        [`${name}_name`]: "",
      }));
    }
    let fetchBuildingData = async (v) => {
      setFloorData([])
      if (v != null) {
        let rlt = await fetchBuildings(v)
        setBuildingData({ buildings: rlt })
      } else {
        setBuildingData([])
        setFloorData([])
      }
    }
    if (name == "location") {
      setEmptyCreateData('building', v)
      setEmptyCreateData('floor', v)
      fetchBuildingData(v)
    }
    if (name == "building") {
      setEmptyCreateData('floor', v)
      if (v != null) {
        fetchFloorData([v]);
      } else {
        setFloorData([])
      }
    }
  }
  let fetchFloorData = async (v) => {
    if (v != null) {
      let rlt = await fetchFloors(v)
      setFloorData({ floors: rlt })
    } else {
      setFloorData([])
    }
  }
  const handleAdd = async () => {
    const locationIdAsInt = parseInt(createData.location_id, 10);
    const buildingIdAsInt = parseInt(createData.building_id, 10);
    const floorIdAsInt = parseInt(createData.floor_id, 10);
    const updatedCreateData = {
      ...createData,
      location_id: locationIdAsInt,
      building_id: buildingIdAsInt,
      floor_id: floorIdAsInt,
    };

    if (
      !createData.room_id ||
      !createData.location_id ||
      !createData.building_id ||
      !createData.floor_id ||
      !createData.room_name ||
      !createData.capacity 
      // !createData.room_amenities||createData.room_amenities.length===0
    ) {
      setRoomIdError(!createData.room_id);
      setLocationError(!createData.location_id);
      setBuildingError(!createData.building_id);
      setFloorError(!createData.floor_id);
      setNameError(!createData.room_name);
      setCapacityError(!createData.capacity);
      // setAmenityError(!createData.room_amenities||createData.room_amenities.length===0);

      let object=[{
      key:createData.room_id,
      ref:roomIdRef.current,

    },
    {
      key:createData.room_name,
      ref:roomNameRef.current,
    },
    {
      key:createData.capacity,
      ref:capacityRef.current,
    },
  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }
      return;
    }
    setRoomIdError(false);
    setLocationError(false);
    setBuildingError(false);
    setFloorError(false);
    setNameError(false);
    setCapacityError(false);
    setAmenityError(false);
    await dispatch(createRoomData(updatedCreateData))
      .then((data) => {
        if (data.payload.status) {
          close()
          roomTable()
          resetCreateData()
          setKeyChange(Math.random());
          setTimeout(() => {
            toast.success("Room created successfully");
          }, 500);
          setIsActiveAdd(true);
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to create Room");
        }, 500);
      });
  };
  return (
    <Modal
      keepMounted
      open={modelOpen}
      onClose={handleClose}
      aria-labelledby="keep-mounted-modal-title"
      aria-describedby="keep-mounted-modal-description"
    >
      <Box sx={style}>
        <Typography
          id="modal-modal-title"
          variant="h6"
          component="h2"
          sx={{
            borderBottom: "1px solid #e9ecef",
            marginBottom: "10px",
            padding: "10px",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          Add Room
          <div style={{ textAlign: "right", display: "inline" }}>
            <Button onClick={handleClose}>X</Button>
          </div>
        </Typography>
        <Box style={{ padding: "10px 15px 25px", textAlign: "left" }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                size="small"
                open={modelOpen}
                label={
                  <div>
                    Room ID <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                id={"room_id"}
                value={createData.room_id || ""}
                inputRef={roomIdRef}
                error={
                  roomIdError ||
                  (!createData || !createData.room_id) ||
                  ((createData && createData.room_id && createData.room_id.length < 1) ||
                    (createData && createData.room_id && createData.room_id.length > 120))
                }
                helperText={
                  roomIdError
                    ? "Room ID is required."
                    : (createData && createData.room_id && createData.room_id.length < 1)
                      ? "Minimum 1 character is allowed."
                      : (createData && createData.room_id && createData.room_id.length > 120)
                        ? "Maximum 120 characters allowed."
                        : ""
                }
                name="room_id"
                onChange={(e) => {
                  addRoomHandleChange(e, null, "room_id");
                  setRoomIdError("");
                }}
              />

            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id="checkboxes-tags-demo"
                name="location_id"
                onChange={(e, v) => {
                  addRoomHandleChange(e, v, "location");
                  setLocationError("");
                }}
                key={keyChange}
                options={locationData?.locations?.location ?? []}
                getOptionLabel={(option) =>
                  getOptionLabelWithIdLocation(option)
                }
                getOptionDisabled={(option) => option.status === false}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Location Id-Name"
                    value={createData.location_id || []}
                    error={locationError}
                    helperText={
                      locationError ? "Location name is required." : ""
                    }
                    InputLabelProps={{
                      ...params.InputLabelProps,
                      ...labelClassess.label,
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id="checkboxes-tags-demo"
                name="building_name"
                onChange={(e, v) => {
                  addRoomHandleChange(e, v, "building");
                  setBuildingError("");
                }}
                key={keyChange}
                options={buildingData?.buildings?.BuildingsData || []}
                getOptionLabel={(option) =>
                  getOptionLabelWithIdBuilding(option)
                }
                // value={{ubuilding_id:createData.ubuilding_id,building_id:createData.building_id,building_name:createData.building_name}}
                getOptionDisabled={(option) => option.status === false}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Building ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Building Id-Name"
                    // value={createData.building_id || []}
                    error={buildingError}
                    value={createData.building || []}
                    helperText={
                      buildingError ? "Building name is required." : ""
                    }
                    InputLabelProps={{
                      ...params.InputLabelProps,
                      ...labelClassess.label,
                    }}
                  />
                )}
              />


            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id="checkboxes-tags-demo"
                name="floor_name"
                onChange={(e, v) => {
                  addRoomHandleChange(e, v, "floor");
                  setFloorError("");
                }}
                options={floorData?.floors?.floorsData || []}
                key={keyChange}
                getOptionLabel={(option) => getOptionLabelWithIdFloor(option)}
                getOptionDisabled={(option) => option.status === false}
                // value={{floor_id:createData.floor_id,ufloor_id:createData.ufloor_id,floor_name:createData.floor_name}}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Floor ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Floor Id-Name"
                    // value={createData.floor_id || []}
                    error={floorError}
                    value={createData.floor_id || []}
                    helperText={floorError ? "Floor name is required." : ""}
                    InputLabelProps={{
                      ...params.InputLabelProps,
                      ...labelClassess.label,
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                size="small"
                label={
                  <div>
                    Room Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                id={"room_name"}
                name="room_name"
                inputRef={roomNameRef}
                value={createData.room_name || ""}
                error={
                  nameError ||
                  (!createData || !createData.room_name) ||
                  ((createData && createData.room_name && createData.room_name.length < 2) ||
                    (createData && createData.room_name && createData.room_name.length > 120))
                }
                helperText={
                  nameError
                    ? "Room Name is required."
                    : (createData && createData.room_name && createData.room_name.length < 2)
                      ? "Minimum 2 characters allowed."
                      : (createData && createData.room_name && createData.room_name.length > 120)
                        ? "Maximum 120 characters allowed."
                        : ""
                }
                onChange={(e) => {
                  addRoomHandleChange(e, null, "room_name");
                  setNameError("");
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                size="small"
                open={modelOpen}
                label={
                  <div>
                    Capacity <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                id={"capacity"}
                inputRef={capacityRef}
                value={createData.capacity || ""}
                error={capacityError}
                helperText={capacityError ? "Capacity is required." : ""}
                name="capacity"
                onChange={(e) => {
                  const value = e.target.value;
                  // Only allow numeric values
                  if (!isNaN(value)) {
                    addRoomHandleChange(e, null, "capacity");
                    setCapacityError("");
                  } else {
                    setCapacityError("Only numbers are allowed.");
                  }
                }}
              /> 
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                multiple
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id="checkboxes-tags-demo"
                options={amenityOptions?.amenities?.amenitydata || []}
                getOptionLabel={(option) => option.amenityname}
                getOptionDisabled={(option) => option.status === false}
                name="room_amenities"
                onChange={(e, v) => {
                  addRoomHandleChange(e, v, "room_amenities");
                  setAmenityError("");
                }}
                key={keyChange}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      icon={icon}
                      checkedIcon={checkedIcon}
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option.amenityname}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={<div>
                      Ameneties <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Ameneties"
                    value={createData.room_amenities || []}
                    error={amenityError}
                    helperText={amenityError ? "Amenities are required." : ""}
                    InputLabelProps={{
                      ...params.InputLabelProps,
                      ...labelClassess.label,
                    }}
                  />
                )}
              />
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              sx={{
                display: "flex",
                justifyContent: "end",
                alignItems: "end",
              }}
            >
              <FormControlLabel
                control={
                  <IOSSwitch
                    checked={isActiveAdd}
                    onChange={handleToogleAdd}
                  />
                }
                label={isActiveAdd ? "Active" : "Inactive"}
                sx={{ marginBottom: "0" }}
                labelPlacement="top"
              />
              <Button
                variant="contained"
                sx={{
                  marginRight: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
                className="bookingbtn"
                onClick={handleAdd}
              >
                Save
              </Button>
              <Button
                variant="outlined"
                sx={{
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
                onClick={handleClose}
                className="bookingbtn1"
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Modal>)

}