import React, { useState } from "react";
import Modal from "react-bootstrap/Modal";
import {
  TextField,
  Select,
  MenuItem,
  FormControl,
  Grid,
  Typography,
  Button,
  ButtonGroup,
  Radio,
  RadioGroup,
  FormControlLabel,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { Close } from "@mui/icons-material";

const RecurrenceDetailsModal = ({bookingDate,bookingEndDate,show, onClose, saveRecurrence,days }) => {
  const [startDate, setStartDate] = React.useState(bookingDate);
  const [repeatEvery, setRepeatEvery] = React.useState(1);
  const [repeatUnit, setRepeatUnit] = React.useState("week");
  const [endDate, setEndDate] = React.useState(bookingEndDate);
  const [selectedDays, setSelectedDays] = React.useState(days);
  const [onDayRadioValue, setOnDayRadioValue] = useState("onDay");
  const [onDayTextFieldValue, setOnDayTextFieldValue] = useState("");
  const [selectedOrdinal, setSelectedOrdinal] = useState("first");
  const [selectedDay, setSelectedDay] = useState("");

   
  const handleDayButtonClick = (day) => {
    console.log(selectedDays);
    if (selectedDays.includes(day)) {
      setSelectedDays(
        selectedDays.filter((selectedDay) => selectedDay !== day)
      );
    } else {
      setSelectedDays([...selectedDays, day]);
    }
  };

  const handleRepeatEveryChange = (event) => {
    setRepeatEvery(event.target.value);
  };

  const handleRepeatUnitChange = (event) => {
    setRepeatUnit(event.target.value);
  }; 
  const handleOnDayRadioChange = (event) => {
    setOnDayRadioValue(event.target.value);
  };

  const handleOrdinalChange = (event) => {
    setSelectedOrdinal(event.target.value);
  };

  const handleDayChange = (event) => {
    setSelectedDay(event.target.value);
  };

  const handleOnDayTextFieldChange = (event) => {
    const newValue = event.target.value;

    if (newValue === "" || (newValue >= 1 && newValue <= 31)) {
      setOnDayTextFieldValue(newValue);
    }
  };

  // Function to generate recurrence summary
  const generateRecurrenceSummary = () => {
    const startDateFormatted = startDate;
    const endDateFormatted = endDate;
    let repeatText = "";
    if (repeatUnit === "day") {
      repeatText = `days`;
    } else if (repeatUnit === "week") {
      repeatText = `week on ${selectedDays.join(", ")}`;
    } else if (repeatUnit === "month") {
      if (onDayRadioValue === "onDay") {
        repeatText = `months on day ${onDayTextFieldValue}`;
      } else if (onDayRadioValue === "onThe") {
        const ordinalText =
          selectedOrdinal === "first"
            ? "1st"
            : selectedOrdinal === "second"
            ? "2nd"
            : selectedOrdinal === "third"
            ? "3rd"
            : selectedOrdinal === "fourth"
            ? "4th"
            : "";

        repeatText = `months on the ${ordinalText} ${selectedDay}`;
      }
    }
    let txt=`Occurs every ${repeatText} starting from  ${startDateFormatted}}`; 
     return txt;
  };
  const recurrenceSummary = generateRecurrenceSummary();

  const handleSaveRecurrence = () => {
    const recurrenceDetails =  
      {
        startDate, 
        endDate,
        selectedDays,
        recurrenceSummary
      } 
    saveRecurrence(recurrenceDetails) 
    onClose(); // Close the modal after saving
  };

  return (
    <Modal show={show} onHide={onClose} className="recurrence-detail-modal">
      <Modal.Header>
        <Modal.Title>Set Recurrence</Modal.Title>
        <Close onClick={onClose}></Close>
      </Modal.Header>
      <Modal.Body>
        <Grid container spacing={2} sx={{ flexDirection: "column" }}>
          {/* Start Date */}
          <Grid item xs={12} sm={12}>
            <LocalizationProvider dateAdapter={AdapterMoment}>
              <DatePicker
                label="Start Date"
                value={startDate}
                onChange={(newDate) => setStartDate(newDate)}
                renderInput={(params) => <TextField {...params} />}
              />
            </LocalizationProvider>
          </Grid>

          {/* <Grid
            item
            xs={12}
            sm={12}
            sx={{ display: "flex", flexDirection: "row" }}
          > 
            <FormControl sx={{ marginRight: "10px" }}> 
              <TextField
                value={repeatEvery}
                onChange={handleRepeatEveryChange}
                required
                id="outlined-required"
                label="Repeat Every"
              />
            </FormControl> 
            <FormControl>
              <Select value={repeatUnit} onChange={handleRepeatUnitChange}>
                <MenuItem value="day">Day</MenuItem>
                <MenuItem value="week">Week</MenuItem>
                <MenuItem value="month">Month</MenuItem>
              </Select>
            </FormControl>
          </Grid> */}

          {repeatUnit === "week" && (
            <Grid item xs={12} sm={12}>
              <Typography variant="subtitle1">Select Days:</Typography>
              <FormControl>
                {/* Render clickable buttons for each day */}
                <ButtonGroup>
                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(
                    (day) => (
                      <Button
                        key={day}
                        style={{
                          backgroundColor: selectedDays.includes(day)
                            ? "blue"
                            : "white",
                          color: selectedDays.includes(day) ? "white" : "black",
                        }}
                        onClick={() => handleDayButtonClick(day)}
                      >
                        {day}
                      </Button>
                    )
                  )}
                </ButtonGroup>
              </FormControl>
            </Grid>
          )}

          {/* {repeatUnit === "month" && "Text Fied && radio button"} */}
          {repeatUnit === "month" && (
            <Grid item xs={12} sm={12}>
              <FormControl component="fieldset">
                <RadioGroup
                  aria-label="On Day"
                  name="onDayRadio"
                  value={onDayRadioValue} // You need to manage this state
                  onChange={handleOnDayRadioChange}
                >
                  <FormControlLabel
                    value="onDay"
                    control={<Radio />}
                    label="On Day"
                  />
                  <FormControlLabel
                    value="onThe"
                    control={<Radio />}
                    label="On The"
                  />
                </RadioGroup>
              </FormControl>

              {onDayRadioValue === "onDay" && (
                <TextField
                  sx={{ width: "60px" }}
                  label="Day"
                  value={onDayTextFieldValue}
                  onChange={handleOnDayTextFieldChange}
                  type="text"
                  inputProps={{
                    min: 1,
                    max: 31,
                    maxLength: 2, // Add this line
                  }}
                />
              )}

              {onDayRadioValue === "onThe" && (
                <Grid container spacing={1}>
                  <Grid item>
                    <Select
                      value={selectedOrdinal}
                      onChange={handleOrdinalChange}
                    >
                      <MenuItem value="first">First</MenuItem>
                      <MenuItem value="second">Second</MenuItem>
                      <MenuItem value="third">Third</MenuItem>
                      <MenuItem value="fourth">Fourth</MenuItem>
                    </Select>
                  </Grid>
                  <Grid item>
                    <Select value={selectedDay} onChange={handleDayChange}>
                      <MenuItem value="sun">Sun</MenuItem>
                      <MenuItem value="mon">Mon</MenuItem>
                      <MenuItem value="tue">Tue</MenuItem>
                      <MenuItem value="wed">Wed</MenuItem>
                      <MenuItem value="thu">Thu</MenuItem>
                      <MenuItem value="fri">Fri</MenuItem>
                      <MenuItem value="sat">Sat</MenuItem>
                    </Select>
                  </Grid>
                </Grid>
              )}
            </Grid>
          )}

          {/* End Date */}
          <Grid item xs={12} sm={12}>
            <LocalizationProvider dateAdapter={AdapterMoment}>
              <DatePicker
                label="End Date"
                value={endDate}
                onChange={(newDate) => setEndDate(newDate)}
                renderInput={(params) => <TextField {...params} />}
              />
            </LocalizationProvider>

            <Grid item xs={12} sm={12}>
              <Typography variant="p">{generateRecurrenceSummary()}</Typography>
            </Grid>
          </Grid>
        </Grid>
      </Modal.Body>
      <Modal.Footer>
        <Button
          className="book-now"
          variant="primary"
          onClick={handleSaveRecurrence}
        >
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default RecurrenceDetailsModal;
