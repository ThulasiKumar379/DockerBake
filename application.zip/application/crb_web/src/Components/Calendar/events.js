const now = new Date()

const event = [
  {
    id: 1,
    start: new Date(2023, 7, 14, 9, 0),
    end: new Date(2023, 7, 14, 10, 30),
    title: 'Meeting with Team A',
    room: 'room1',
  },
  {
    id: 2,
    start: new Date(2023, 7, 15, 14, 0),
    end: new Date(2023, 7, 15, 15, 30),
    title: 'Presentation to Client',
    room: 'room2',
  },
  {
    id: 3,
    start: new Date(2023, 7, 16, 10, 0),
    end: new Date(2023, 7, 16, 11, 30),
    title: 'Product Development Discussion',
    room: 'room1',
  },
  {
    id: 4,
    start: new Date(2023, 7, 17, 9, 30),
    end: new Date(2023, 7, 17, 12, 0),
    title: 'Workshop: Time Management',
    room: 'room3',
  },
  {
    id: 5,
    start: new Date(2023, 7, 18, 13, 0),
    end: new Date(2023, 7, 18, 15, 0),
    title: 'Brainstorming Session',
    room: 'room2',
  },
  {
    id: 6,
    start: new Date(2023, 7, 19, 11, 0),
    end: new Date(2023, 7, 19, 12, 30),
    title: 'Team Building Activity',
    room: 'room4',
  },
  {
    id: 7,
    start: new Date(2023, 7, 20, 15, 0),
    end: new Date(2023, 7, 20, 16, 30),
    title: 'Client Meeting',
    room: 'room1',
  },
  {
    id: 8,
    start: new Date(2023, 7, 21, 10, 0),
    end: new Date(2023, 7, 21, 11, 0),
    title: 'Team Standup',
    room: 'room2',
  },
  {
    id: 9,
    start: new Date(2023, 7, 22, 14, 0),
    end: new Date(2023, 7, 22, 15, 30),
    title: 'Project Review',
    room: 'room3',
  },
  {
    id: 10,
    start: new Date(2023, 7, 23, 11, 0),
    end: new Date(2023, 7, 23, 12, 0),
    title: 'Training Session',
    room: 'room4',
  },
 ]

export default event
