import React from 'react';
import './scheduler.css'

const RoomButton = ({ label, selected, onRoomClick }) => {
  return (
    <button
      className={`room-button ${selected ? 'selected' : ''}`}
      onClick={onRoomClick}
    >
      {label}
    </button>
  );
};

export default RoomButton;
