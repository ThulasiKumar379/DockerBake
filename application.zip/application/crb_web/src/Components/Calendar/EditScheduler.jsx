import React, {
  Fragment,
  useState,
  useCallback,
  useMemo,
  useEffect,
} from "react";
import { Checkbox } from "@mui/material";
import { CheckBox, CheckBoxOutlineBlank } from "@mui/icons-material";
import { useSelector, useDispatch } from "react-redux";
import RoomButton from "./RoomButton";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Calendar, Views, momentLocalizer } from "react-big-calendar";
import RecurrenceDetailsModal from "./RecurrenceDetailsModal";
import moment from "moment";
import { getRoomBookingsData } from "../../api/RoomBooking/roombookingReducer";
import "react-big-calendar/lib/css/react-big-calendar.css";
import "./scheduler.css";
import { Modal, Button, Form } from "react-bootstrap";
import { Autocomplete, Box, TextField, Typography } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import Grid from "@mui/material/Grid";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { styled } from "@mui/system";
import { fetchBuildings } from "../../api/Building/buildingApi";
import { fetchFloors } from "../../api/Floor/floorApis";
import { getRoomsList } from "../../api/Rooms/roomApis";
// import { fetchRooms } from "../../api/Rooms/roomApis";
import { fetchLocationsData } from "../../api/Location/locationReducer";
import { fetchBuildingsData } from "../../api/Building/buildingReducers";
import { fetchFloorsData } from "../../api/Floor/floorReducers";
import { fetchRoomsData } from "../../api/Rooms/roomReducer";
import { fetchRoomServiceData } from "../../api/RoomService/roomServiceReducers";
import { fetchAmenitiesData } from "../../api/Amenities/amenitiesReducers";
import { fetchUsersData } from "../../api/UserAccessManagementPage/UserAccessReducers";
import { createBookingData } from "../../api/RoomBooking/roombookingReducer";
const localizer = momentLocalizer(moment);
const roomOptions = [
  { value: "room1", label: "Room 1" },
  { value: "room2", label: "Room 2" },
];
const Capacity = [
  { label: "0-50" },
  { label: "51-100" },
  { label: "101-150" },
  { label: "151-200" },
  { label: "201-250" },
  { label: "251-300" },
];
const icon = <CheckBoxOutlineBlank fontSize="small" />;
const checkedIcon = <CheckBox fontSize="small" />;
export default function Scheduler({ modelOpen, isSearchResultsFound }) {
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState("room1");
  const BookingsData = useSelector((state) => state.roomBooking);
  console.log({ BookingsData });
  const FetchApiBooking = BookingsData?.bookings?.data ?? [];
  const RoomServiceData = useSelector((state) => state.roomService);
  const [roomData, setRoomData] = useState([]);
  const [floorData, setFloorData] = useState([]);
  const [buildingData, setBuildingData] = useState([]);
  // const buildingData = useSelector((state) => state.buildings);
  const locationData = useSelector((state) => state.locations);
  const amenityOptions = useSelector((state) => state.amenities);
  const AmenityData = useSelector((state) => state.amenities);
  const { amenities } = AmenityData;
  const amenitiesData = amenities?.data;
  const [keyChange, setKeyChange] = useState("");
  const [selectedCapacity, setSelectedCapacity] = useState(false);
  // const [capacityError, setCapacityError] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const [buildingError, setBuildingError] = useState(false);
  const [floorError, setFloorError] = useState(false);
  const [roomError, setRoomError] = useState(false);
  const [nameError, setNameError] = useState(false);
  const [dateError, setDateError] = useState(false);
  const [starttimeError, setStartTimeError] = useState(false);
  const [endtimeError, setEndTimeError] = useState(false);
  const [durationError, setDurationError] = useState(false);
  const [capacityError, setCapacityError] = useState(false);
  const [repeatError, setRepeatError] = useState(false);
  const [amenityError, setAmenityError] = useState(false);
  const [servicenameError, setServiceNameError] = useState(false);
  const [addattendiesError, setAddAttendeesError] = useState(false);
  const [descriptionError, setDescriptionError] = useState(false);
  const [createData, setCreateData] = useState({
    status: isActiveAdd,
    building_id: "",
    floor_id: "",
    floor_name: "",
    building_name: "",
    room_id: "",
    room_name: "",
  });
  const [selectedBuldingFilter, setSelectedBuldingFilter] = useState([]);
  const [selectedFloorFilter, setSelectedFloorFilter] = useState([]);
  const [selectedRoomFilter, setSelectedRoomFilter] = useState([]);
  const [capacitySearch, setCapacitySearch] = useState([]);
  const [locationSearch, setLocationSearch] = useState([]);
  const [buildingSearch, setBuildingSearch] = useState([]);
  const [floorSearch, setFloorSearch] = useState([]);
  const [roomSearch, setRoomSearch] = useState([]);
  let resetCreateData = () => {
    setCreateData({
      status: isActiveAdd,
      location_id: "",
      ulocation_id: "",
      location_name: "",
      ubuilding_id: "",
      building_id: "",
      building_name: "",
      ufloor_id: "",
      floor_id: "",
      floor_name: "",
      uroom_id: "",
      room_id: "",
      room_name: "",
      room_capacity: "",
      repeat: "",
      room_service_name: "",
      addattendies: "",
      room_amenities: [],
    });
  };

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getRoomBookingsData());
    dispatch(fetchFloorsData([]));
    dispatch(fetchUsersData([]));
    dispatch(fetchRoomServiceData([]));
    dispatch(fetchRoomsData([]));
    dispatch(fetchLocationsData([]));
    dispatch(fetchBuildingsData([]));
    dispatch(fetchAmenitiesData([]));
  }, [dispatch]);

  const formatEventsForCalendar = (eventsToShow) => {
    return eventsToShow.map((event) => ({
      id: event.booking_id,
      title: event.title_of_meeting,
      start: new Date(`${event.booking_date}T${event.starttime}`),
      end: new Date(`${event.booking_date}T${event.endtime}`),
    }));
  };
  const filteredEvents =
    selectedRoom === "room1"
      ? FetchApiBooking
      : FetchApiBooking.filter((event) => event.room_id === selectedRoom);
  const [modalData, setModalData] = useState({
    title: "",
    description: "",
    start: null,
    end: null,
  });
  const [editingEvent, setEditingEvent] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editModalData, setEditModalData] = useState({
    // title: "",
    description: "",
    // start: null,
    // end: null,
  });
  const [selectedRecurrenceOption, setSelectedRecurrenceOption] =
    useState(null);
  const [showRecurrenceModal, setShowRecurrenceModal] = useState(false);
  const isDateInPast = (date) => {
    const now = new Date();
    return date < now;
  };
  const handleSelectSlot = ({ start, end }) => {
    if (isDateInPast(start)) {
      toast.error("You can't create an event in the past!");
      return;
    }
    const overlap = FetchApiBooking.some(
      (event) => start < event.end && end > event.start
    );
    if (!overlap) {
      setModalData({
        title: "",
        description: "",
        start,
        end,
      });
      setStartValue(start);
      setEndValue(end);
      setShowModal(true);
    } else {
      toast.error("Selected time range overlaps with existing events.");
    }
  };
  const handleModalClose = () => {
    setShowModal(false);
  };
console.log("createData",createData)
  const handleModalSubmit = async () => {
    const {
      location_id,
      building_id,
      floor_id,
      room_id,
      meeting_subject,
      selectdate,
      starttime,
      endtime,
      duration,
      // room_capacity,
      repeat,
      room_amenities,
      room_service_name,
      addattendies,
      description,
    } = createData;
    if (
      !location_id ||
      !building_id ||
      !floor_id ||
      !room_id ||
      !meeting_subject ||
      !selectdate ||
      !starttime ||
      !endtime ||
      !duration ||
      // !room_capacity ||
      !repeat ||
      !room_amenities ||
      !room_service_name ||
      !addattendies ||
      !description
    ) {
      setLocationError(!location_id);
      setBuildingError(!building_id);
      setFloorError(!floor_id);
      setRoomError(!room_id);
      setNameError(!meeting_subject);
      setDateError(!selectdate);
      setStartTimeError(!starttime);
      setEndTimeError(!endtime);
      setDurationError(!duration);
      // setCapacityError(!room_capacity);
      setRepeatError(!repeat);
      setAmenityError(!room_amenities);
      setServiceNameError(!room_service_name);
      setAddAttendeesError(!addattendies);
      setDescriptionError(!description);

      return;
    }
    setLocationError(false);
    setBuildingError(false);
    setFloorError(false);
    setRoomError(false);
    setNameError(false);
    setDateError(false);
    setStartTimeError(false);
    setEndTimeError(false);
    setDurationError(false);
    // setCapacityError(false);
    setRepeatError(false);
    setAmenityError(false);
    setServiceNameError(false);
    setAddAttendeesError(false);
    setDescriptionError(false);

    try {
      const data = await dispatch(createBookingData());

      if (data.payload.status) {
        resetCreateData();
        setKeyChange(Math.random());
        setTimeout(() => {
          toast.success("New Booking created successfully");
        }, 500);
        setIsActiveAdd(true);
      } else {
        setTimeout(() => {
          toast.error(data.payload.errorMessage);
        }, 500);
      }
      if (!createData.room_capacity || createData.room_capacity.length === 0) {
        // If capacity is not provided, set capacityError to true
        setCapacityError(true);
        return; // Exit the function
      }
    } catch (error) {
      setTimeout(() => {
        toast.error("Failed to create NewBooking");
      }, 500);
    }
  };

  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };
  const handleSelectEvent = useCallback((event) => {
    setEditingEvent(event);
    setEditModalData({
      // title: event.title,
      description: event.description,
      // start: event.start,
      // end: event.end,
    });
    setShowEditModal(true);
  }, []);
  const handleEditModalClose = () => {
    setShowEditModal(false);
  };
  const handleEditModalSubmit = () => {
    if (editingEvent) {
      const updatedEvent = {
        ...editingEvent,
        title: editModalData.title,
        description: editModalData.description,
        start: editModalData.start,
        end: editModalData.end,
      };
      setShowEditModal(false);
    }
  };
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };
  const getOptionLabelWithIdFloor = (option) => {
    if (option?.floor_id) {
      return `${option.ufloor_id} - ${option.floor_name}`;
    } else {
      return option?.floor_name;
    }
  };
  const getOptionLabelWithIdRoom = (option) => {
    if (option?.room_id) {
      return `${option.roomid} - ${option.room_name}`;
    } else {
      return option?.room_name;
    }
  };
  const getOptionLabelWithIdRoomService = (option) => {
    if (option?.room_service_id) {
      return `${option.room_service_id} - ${option.room_service_name}`;
    } else {
      return option?.room_service_name;
    }
  };

  const { defaultDate, scrollToTime } = useMemo(
    () => ({
      defaultDate: new Date(),
      scrollToTime: new Date(Date.now() - 3 * 60 * 60 * 1000),
    }),
    []
  );
  const minTime = new Date();
  minTime.setHours(0, 0, 0); // Set the minimum time to 12:00 AM (midnight)
  const maxTime = new Date();
  maxTime.setHours(23, 59, 59); // Set the maximum time to 11:59 PM (end of day)
  const recurrence = [
    { title: "Does Not Repeat" },
    { title: "Mon - Fri" },
    { title: "Weekly" },
    { title: "Monthly" },
  ];
  const attendies = [
    { title: "Sundar M" },
    { title: "Zameer Ahmad" },
    { title: "Darab Karim" },
    { title: "Md Mustafa" },
  ];
  const [selectedTimezone, setSelectedTimezone] = useState(
    Intl.DateTimeFormat().resolvedOptions().timeZone
  );
  const [ishow, setIsshow] = useState(true);
  const [startvalue, setStartValue] = useState(moment(""));
  const [endvalue, setEndValue] = useState(moment(""));
  const handletime = () => {
    setIsshow(false);
  };

  let fetchBuildingData = async (v) => {
    setFloorData([]);
    setRoomData([]);
    if (v != null) {
      let rlt = await fetchBuildings(v);
      setBuildingData({ buildings: rlt });
    } else {
      setBuildingData([]);
      setFloorData([]);
      setRoomData([]);
    }
  };
  let fetchFloorData = async (v) => {
    setRoomData([]);
    if (v != null) {
      let rlt = await fetchFloors(v);
      setFloorData({ floors: rlt });
    } else {
      setFloorData([]);
      setRoomData([]);
    }
  };
  let fetchRoomData = async (v) => {
    if (v != null) {
      let rlt = await getRoomsList(v);
      setRoomData({ rooms: rlt });
    } else {
      setRoomData([]);
    }
  };
  const handleChange = (e, v, name) => {
    console.log("value data", v);
    const val = v === null ? e?.target?.value : v[name];
    if (Array.isArray(v)) {
      if (name === "room_amenities") {
        const AmmValues = v.map((a) => a.amenityid);
        setCreateData((prevData) => ({
          ...prevData,
          [name]: AmmValues,
        }));
      }
    } else if (
      name === "building" ||
      name === "location" ||
      name === "floor" ||
      name === "room"
    ) {
      setCreateData((prevData) => ({
        ...prevData,
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setCreateData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }
    let setEmptyCreateData = (name, v) => {
      setCreateData((prevData) => ({
        ...prevData,
        [`${name}_id`]: "",
        [`${name}_name`]: "",
      }));
    };
    let fetchBuildingData = async (v) => {
      setFloorData([]);
      if (v != null) {
        let rlt = await fetchBuildings(v);
        setBuildingData({ buildings: rlt });
      } else {
        setBuildingData([]);
        setFloorData([]);
      }
    };
    if (name == "location") {
      setEmptyCreateData("building", v);
      setEmptyCreateData("floor", v);
      fetchBuildingData(v);
    }
    if (name == "building") {
      setEmptyCreateData("floor", v);
      if (v != null) {
        fetchFloorData([v]);
      } else {
        setFloorData([]);
      }
    }
    if (name == "floor") {
      setEmptyCreateData("room", v);
      if (v != null) {
        fetchRoomData([v]);
      } else {
        setRoomData([]);
      }
    }
    if (name === "room_capacity") {
      setSelectedCapacity(v);
      setCapacityError(false);
    }

    if (Array.isArray(v)) {
      const AmmValues = v.map((a) => a.amenityid);
      setCreateData((prevData) => ({
        ...prevData,
        [name]: AmmValues,
      }));
    }
    if (!editModalData.description.trim()) {
      setDescriptionError(true);
      return;
    }
    setDescriptionError(false);
  };

  const handleChangeend = (newValue) => {
    setEndValue(newValue);
  };
  const [value, setValue] = useState(null);
  const label = { inputProps: { "aria-label": "Switch demo" } };
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    <Fragment>
      <ToastContainer />
      {isSearchResultsFound && (
        <Box sx={{ margin: "15px 0" }}>
          <Typography variant="h6">Select a Room :</Typography>
          {roomOptions.map((option) => (
            <RoomButton
              key={option.value}
              label={option.label}
              selected={selectedRoom === option.value}
              onRoomClick={() => setSelectedRoom(option.value)}
            />
          ))}
        </Box>
      )}
      <div className="container-fluid p-0">
        <div className="row">
          <div className="col-md-12">
            <Button onClick={handleSelectSlot} className="new-booking">
              New Booking
            </Button>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 height300 my-3">
            <Calendar
              defaultDate={defaultDate}
              defaultView={Views.WEEK}
              views={["week", "day"]}
              events={formatEventsForCalendar(filteredEvents)}
              localizer={localizer}
              onSelectEvent={handleSelectEvent}
              onSelectSlot={handleSelectSlot}
              selectable
              scrollToTime={scrollToTime}
              min={minTime}
              max={maxTime}
              timeslots={2}
              startAccessor="start"
              endAccessor="end"
              dayLayoutAlgorithm="no-overlap"
            />
            <Modal size="xl" show={showModal} onHide={handleModalClose}>
              <Modal.Header style={{ padding: "1rem 3.2rem" }}>
                <Modal.Title>Book Room</Modal.Title>
                <Button
                  variant="link"
                  className="close-modal-btn dismiss-booking"
                  onClick={handleModalClose}
                  aria-label="Close"
                >
                  &times;
                </Button>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  <Grid sx={{ padding: "0 40px" }} container spacing={2}>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        name="location_id"
                        onChange={(e, v) => {
                          handleChange(e, v, "location");
                          setLocationError("");
                        }}
                        key={keyChange}
                        options={locationData?.locations?.location ?? []}
                        getOptionLabel={(option) =>
                          getOptionLabelWithIdLocation(option)
                        }
                        getOptionDisabled={(option) => option.status === false}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Location Id-Name"
                            placeholder="Location Id-Name"
                            value={createData.location_id || []}
                            error={locationError}
                            helperText={
                              locationError ? "Location name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        name="building_name"
                        onChange={(e, v) => {
                          handleChange(e, v, "building");
                          setBuildingError("");
                        }}
                        key={keyChange}
                        options={buildingData?.buildings?.BuildingsData || []}
                        getOptionLabel={(option) =>
                          getOptionLabelWithIdBuilding(option)
                        }
                        value={{
                          ubuilding_id: createData.ubuilding_id,
                          building_id: createData.building_id,
                          building_name: createData.building_name,
                        }}
                        getOptionDisabled={(option) => option.status === false}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Building Id-Name"
                            placeholder="Building Id-Name"
                            // value={createData.building_id || []}
                            error={buildingError}
                            helperText={
                              buildingError ? "Building name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>

                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        name="floor_name"
                        onChange={(e, v) => {
                          handleChange(e, v, "floor");
                          setFloorError("");
                        }}
                        options={floorData?.floors?.floorsData || []}
                        key={keyChange}
                        getOptionLabel={(option) =>
                          getOptionLabelWithIdFloor(option)
                        }
                        getOptionDisabled={(option) => option.status === false}
                        value={{
                          floor_id: createData.floor_id,
                          ufloor_id: createData.ufloor_id,
                          floor_name: createData.floor_name,
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Floor Id-Name"
                            placeholder="Floor Id-Name"
                            // value={createData.floor_id || []}
                            error={floorError}
                            helperText={
                              floorError ? "Floor name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        // multiple
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                            padding: "8px",
                          },
                          marginBottom: "10px",
                        }}
                        id="checkboxes-tags-demo"
                        name="room_name"
                        onChange={(e, v) => handleChange(e, v, "room_id")}
                        key={keyChange}
                        options={roomData?.rooms?.roomData || []}
                        getOptionLabel={(option) =>
                          getOptionLabelWithIdRoom(option)
                        }
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Room Id-Name"
                            placeholder="Room Id-Name"
                            error={roomError}
                            helperText={
                              roomError ? "Room name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <TextField
                        fullWidth
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        size="small"
                        open={modelOpen}
                        label="Meeting Subject"
                        id={"meeting_subject"}
                        value={editModalData.meeting_subject}
                        error={nameError}
                        helperText={
                          nameError ? "Meeting Subject is required." : ""
                        }
                        name="meeting_subject"
                        onChange={(e) => {
                          handleChange(e, null, "meeting_subject");
                          setNameError("");
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <DatePicker
                          size="small"
                          label={
                            <span>
                              Select Date
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          value={value}
                          onChange={(newValue) => {
                            setValue(newValue);
                          }}
                          error={dateError}
                          helperText={
                            dateError ? "select date is required." : ""
                          }
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <TimePicker
                          value={startvalue}
                          label={
                            <span>
                              Start time
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          error={starttimeError}
                          helperText={
                            starttimeError ? "Start time is required." : ""
                          }
                          onChange={handleChange}
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <TimePicker
                          value={endvalue}
                          label={
                            <span>
                              End Time
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          error={endtimeError}
                          helperText={
                            endtimeError ? "End time is required." : ""
                          }
                          onChange={handleChangeend}
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <TextField
                        fullWidth
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        size="small"
                        open={modelOpen}
                        label="Duration"
                        id={"duration"}
                        value={editModalData.duration}
                        error={durationError}
                        helperText={
                          durationError ? "Duration is required." : ""
                        }
                        name="duration"
                        onChange={(e) => {
                          handleChange(e, null, "duration");
                          setDurationError("");
                        }}
                      />
                    </Grid>
                    {/* <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        options={Capacity}
                        getOptionLabel={(option) => option.label}
                        getOptionDisabled={(option) => option.status === false}
                        name="room_capacity"
                        onChange={(e, v) => handleChange(e, v, "room_capacity")}
                        renderOption={(props, option, { selected }) => (
                          <li {...props}>
                            <Checkbox checked={selected} />
                            {option.label}
                          </li>
                        )}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Room Capacity"
                            placeholder="Capacity"
                            value={
                              selectedCapacity ? selectedCapacity.label : ""
                            }
                            error={capacityError}
                            helperText={
                              capacityError ? "Room Capacity is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              // Add your label classes here if needed
                            }}
                          />
                        )}
                      />
                    </Grid> */}
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        id="free-solo-2-demo"
                        disableClearable
                        options={recurrence.map((option) => option.title)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Repeat"
                            InputProps={{
                              ...params.InputProps,
                              type: "search",
                            }}
                            // error={repeatError}
                            // helperText={repeatError ? "Repeat is required." : ""}
                          />
                        )}
                        onChange={(event, newValue) => {
                          if (newValue === "Does Not Repeat") {
                            setSelectedRecurrenceOption(null);
                          } else {
                            setSelectedRecurrenceOption(newValue);
                            setShowRecurrenceModal(true);
                          }
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        multiple
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        options={amenityOptions?.amenities?.amenitydata || []}
                        getOptionLabel={(option) => option.amenityname}
                        getOptionDisabled={(option) => option.status === false}
                        name="room_amenities"
                        onChange={(e, v) => {
                          handleChange(e, v, "room_amenities");
                          setAmenityError("");
                        }}
                        key={keyChange}
                        renderOption={(props, option, { selected }) => (
                          <li {...props}>
                            <Checkbox
                              icon={icon}
                              checkedIcon={checkedIcon}
                              style={{ marginRight: 8 }}
                              checked={selected}
                            />
                            {option.amenityname}
                          </li>
                        )}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Ameneties"
                            placeholder="Ameneties"
                            value={createData.room_amenities || []}
                            error={amenityError}
                            helperText={
                              amenityError ? "Amenities are required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12}>
                      <Autocomplete
                        multiple
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        options={RoomServiceData?.roomservice?.service || []}
                        getOptionDisabled={(option) => option.status === false}
                        getOptionLabel={(option) =>
                          getOptionLabelWithIdRoomService(option)
                        }
                        name="room_service_name"
                        onChange={(e, v) => {
                          handleChange(e, v, "room_service_name");
                          setServiceNameError("");
                        }}
                        key={keyChange}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Room Service-Name"
                            placeholder="Room Service-Name"
                            value={createData.room_service_name || []}
                            error={servicenameError}
                            helperText={
                              servicenameError
                                ? "Room Service is required."
                                : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12}>
                      <Autocomplete
                        size="small"
                        multiple
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        options={attendies.map((option) => option.title)}
                        getOptionDisabled={(option) => option.status === false}
                        name="addattendies"
                        onChange={(e, v) => {
                          handleChange(e, v, "addattendies");
                          setAddAttendeesError("");
                        }}
                        key={keyChange}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Add Attendies"
                            placeholder="Add Attendies"
                            value={createData.addattendies || []}
                            error={addattendiesError}
                            helperText={
                              addattendiesError
                                ? "Add Attendies is required."
                                : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12}>
                      <TextField
                        fullWidth
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        size="small"
                        open={modelOpen}
                        label="Description"
                        id={"description"}
                        variant="outlined"
                        multiline
                        rows={4}
                        value={editModalData.description}
                        error={descriptionError}
                        helperText={
                          descriptionError ? "Description is required." : ""
                        }
                        name="description"
                        onChange={(e) => {
                          handleChange(e, null, "description");
                          //setDescriptionError("");
                          const { value } = e.target;
                          setEditModalData((prevData) => ({
                            ...prevData,
                            description: value,
                          }));
                          //setDescriptionError("");
                        }}
                      />
                    </Grid>
                  </Grid>
                </Form>
              </Modal.Body>
              <Modal.Footer>
                <Button className="book-now" onClick={handleModalSubmit}>
                  Book Room
                </Button>
              </Modal.Footer>
            </Modal>
          </div>
        </div>
      </div>
      {selectedRecurrenceOption && showRecurrenceModal && (
        <RecurrenceDetailsModal
          show={showRecurrenceModal}
          onClose={() => setShowRecurrenceModal(false)}
          recurrenceOption={selectedRecurrenceOption}
        />
      )}
    </Fragment>
  );
}
