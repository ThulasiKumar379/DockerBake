import React, {Fragment,useState,useCallback,useMemo,useEffect} from "react";
import { Box, Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux"; 
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Calendar, Views, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import { getRoomBookingsData,getBookingById } from "../../api/RoomBooking/roombookingReducer";
import { fetchCompanyTimings } from "../../api/Settings/timingReducer";
import { getUserRooms } from "../../api/Rooms/roomReducer";
import "react-big-calendar/lib/css/react-big-calendar.css";
import "./scheduler.css";
import { Modal, Button, Form } from "react-bootstrap";
import { fetchRoomServiceData } from "../../api/RoomService/roomServiceReducers";
import CreateBooking from "./CreateBookingPopUp"
import RoomButton from "./RoomButton";
import { Explore } from "@mui/icons-material";
import { fetchRoomDetailsData } from "../../api/RoomBooking/roombookingReducer";
const localizer = momentLocalizer(moment); 
export default function Scheduler({ isSearchResultsFound,searchParams,calRerender }) {    
  let [officeStartTime,setOfficeStartTime]=useState('00:00:00')
  let [officeEndTime,setOfficeEndTime]=useState('23:59:59')
  const [workingDays, setWorkingDays] = useState([]);
  const [thisWeekEvents, setThisWeekEvents] = useState([]);
  const [editBookingId, setEditBookingId] = useState(null);
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [eventRerender, setEventRerender] = useState(true);  
  const [showModal, setShowModal] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState({}); 
  const [createData, setCreateData] = useState({status: isActiveAdd,duration:"30M",room_capacity:""}); 
  const [startvalue, setStartValue] = useState(moment(""));
  const [endvalue, setEndValue] = useState(moment("")); 
  const [currentStartDate, setCurrentStartDate] = useState(moment(""));
  const [currentEndDate, setCurrentEndDate] = useState(moment(""));  
  const dispatch = useDispatch();
  const BookingDetailsData = useSelector((state) => state?.roomBooking?.bookingDetails);
  const [userRooms,setUserRooms]=useState([])
  const searchRoomData = useSelector((state) => state?.roomBooking?.roomDetails);
  const roomData = useSelector((state) => state?.rooms?.userRooms);
  const BookingsData = useSelector((state) => state.roomBooking);  
  const companyTimings = useSelector((state) => state.timings.CompanyTimings);  
   
  const [bookingData, setBookingData] = useState([]); 
  useEffect(() => {
    setUserRooms([])
    setSelectedRoom([])
    if(roomData?.data?.length>0){ 
      setUserRooms(roomData.data)
      setSelectedRoom(roomData.data[0])
    } 
  },[roomData]); 

  useEffect(() => {
    setUserRooms([])
    setSelectedRoom([])
    if(searchRoomData?.data?.length>0){ 
      setUserRooms(searchRoomData.data)
      setSelectedRoom(searchRoomData.data[0])
    } 
  },[searchRoomData]); 

  useEffect(() => {
    setBookingData(BookingDetailsData)
  },[BookingDetailsData]);

  
  useEffect(() => {
    const startDateOfWeek = moment().startOf('week').format('YYYY-MM-DD');  
    const endDateOfWeek = moment().endOf('week').format('YYYY-MM-DD'); 
    setCurrentStartDate(startDateOfWeek)
    setCurrentEndDate(endDateOfWeek) 
    dispatch(fetchRoomServiceData([]));    
    dispatch(fetchCompanyTimings()); 
    if(!isSearchResultsFound){ 
       dispatch(getUserRooms());   
    } 
  
  }, [dispatch]);
  useEffect(() => { 
    if(isSearchResultsFound){ 
      dispatch(fetchRoomDetailsData(searchParams))
    }  
  },[calRerender]);
  useEffect(() => {   
    if(selectedRoom?.room_id){
      dispatch(getRoomBookingsData({startDate:currentStartDate,endDate:currentEndDate,room_id:selectedRoom?.room_id}));    
    }else{
      setThisWeekEvents([])
    }
    
  }, [currentEndDate,selectedRoom,eventRerender]); 
  const minTime = new Date(); 
  const maxTime = new Date(); 
  minTime.setHours(6,0,0); // Set the minimum time to 12:00 AM (midnight) 
  maxTime.setHours(23,59,59);
 
  // const st = officeEndTime.split(':');
  // const et = officeEndTime.split(':'); 
  // minTime.setHours(st[0],st[1],st[2]); // Set the minimum time to 12:00 AM (midnight) 
  // maxTime.setHours(et[0],et[1],et[2]); // Set the maximum time to 11:59 PM (end of day)   
  // useEffect(()=>{  
  //   const st = officeStartTime.split(':');
  //   const et = officeEndTime.split(':'); 
  //   minTime.setHours(st[0],st[1],st[2]); // Set the minimum time to 12:00 AM (midnight) 
  //   maxTime.setHours(et[0],et[1],et[2]); // Set the maximum time to 11:59 PM (end of day)  
  // },[setOfficeEndTime])

  
  useEffect(() => {  
   if(companyTimings?.data?.start_time){
      setOfficeStartTime(companyTimings?.data?.start_time)
   }
   if(companyTimings?.data?.end_time){
    setOfficeEndTime(companyTimings?.data?.start_time)
   }  
    let Wdays=[];
    if(companyTimings?.data?.sunday){ Wdays.push(0)};
    if(companyTimings?.data?.monday){ Wdays.push(1)};
    if(companyTimings?.data?.tuesday){ Wdays.push(2)};
    if(companyTimings?.data?.wednesday){ Wdays.push(3)};
    if(companyTimings?.data?.thursday){ Wdays.push(4)};
    if(companyTimings?.data?.friday){ Wdays.push(5)};
    if(companyTimings?.data?.saturday){ Wdays.push(6)}; 
    setWorkingDays(Wdays) 

  }, [companyTimings]); 
  let CalanderReload=()=>{
    setBookingData([]);
    setEventRerender(!eventRerender) 
  } 
  let eventCreater=(events,obj)=>{
    events.push({
      id: obj.booking_id,
      title: obj.title_of_meeting,
      start: new Date(`${obj.booking_date}T${obj.starttime}`),
      end: new Date(`${obj.booking_date}T${obj.endtime}`),
    })
    return events;
  } 
  function addLeadingZero(month) {
      return month < 10 ? '0' + month : month;
  }
  function getDatesForDayOfWeek(startDate, endDate, dayOfWeek) {
    let dates = '';
    let currentDate = new Date(startDate);
    let endate1 = new Date(endDate);
    while (currentDate <= endate1) { 
        if (currentDate.getDay() === dayOfWeek) {  
          let day = currentDate.getDate();  
          let month = currentDate.getMonth();  
          let year = currentDate.getFullYear();  
            dates=year+'-'+addLeadingZero(month+1)+'-'+addLeadingZero(day)
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }
    return dates;
}
 
useEffect(()=>{
  const FetchApiBooking = BookingsData?.bookings?.data ?? []; 
    let events=[];
    if(FetchApiBooking.length!=0){
      for(let i=0;i<FetchApiBooking.length;i++){
        if(FetchApiBooking[i].repeat!='Does Not Repeat'){
          let eventObj=FetchApiBooking[i];
          let repeatDays=Object.values(eventObj.days); 
          repeatDays.sort()
          if(repeatDays.length){ 
            let startDate='';
            let endDate='';
            const date1 = new Date(eventObj.booking_date); // First date
            const date2 = new Date(currentStartDate); // Second date 
            // Compare the two dates
            if (date1 <= date2) {
              startDate=currentStartDate
            } else if (date1 > date2) {
              startDate=eventObj.booking_date
            } 
            const date3 = new Date(eventObj.booking_end_date); // First date
            const date4 = new Date(currentEndDate); // Second date 
            // Compare the two dates
            if (date3 <= date4) {
              endDate=eventObj.booking_end_date
            } else if (date3 > date4) {
              endDate=currentEndDate
            }  
            repeatDays.map((l)=>{
             let rdate= getDatesForDayOfWeek(startDate, endDate, l); 
              if(rdate!=''){
                events.push({ 
                  id: FetchApiBooking[i].booking_id,
                  title: FetchApiBooking[i].title_of_meeting,
                  start: new Date(`${rdate}T${FetchApiBooking[i].starttime}`),
                  end: new Date(`${rdate}T${FetchApiBooking[i].endtime}`),
                })
              }
            })  
          }else{
            events= eventCreater(events,FetchApiBooking[i]) 
          }
        }else{
          events= eventCreater(events,FetchApiBooking[i]) 
        } 
      } 
    }   
    setThisWeekEvents(events) 
},[BookingsData]) 
  const [editingEvent, setEditingEvent] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);  
  const isDateInPast = (date) => {
    const now = new Date();
    return date < now;
  }; 
  const handleSelectSlot = ({ start, end }) => {   
    const FetchApiBooking = BookingsData?.bookings?.data ?? [];
    if (isDateInPast(start)) {
      toast.error("You can't create an event in the past!");
      return;
    }
    const overlap = FetchApiBooking.some(
      (event) => start < event.end && end > event.start
    );
    if (!overlap) {      
      handleBookingDate(moment(start));
      handleChangestart(moment(start));
      handleChangeend(moment(end));
      handleBookingEndDate(moment(end));
      setShowModal(true);
    } else {
      toast.error("Selected time range overlaps with existing events.");
    }
  }; 
  const handleSelectEvent = useCallback((event) => { 
    dispatch(getBookingById(event.id));
    setEditBookingId(event.id)
    setEditingEvent(event); 
    setShowEditModal(true);
  }, []); 
  const { defaultDate, scrollToTime } = useMemo(
    () => ({
      defaultDate: new Date(),
      scrollToTime: new Date(Date.now() - 3 * 60 * 60 * 1000),
    }),
    []
  );

  // console.log("maxTime",maxTime)
  const [selectedTimezone, setSelectedTimezone] = useState(
    Intl.DateTimeFormat().resolvedOptions().timeZone
  );
  const [ishow, setIsshow] = useState(true);  
  const handletime = () => {
    setIsshow(false);
  };
 
 
  const handleChangeend = (newValue) => { 
    setEndValue(newValue); 
    setCreateData((prevData) => ({
      ...prevData,
      ["endtime"]: newValue.format('HH:mm:ss'),
    }));
  };
  const handleChangestart = (newValue) => {
    setStartValue(newValue); 
    setCreateData((prevData) => ({
      ...prevData,
      ["starttime"]: newValue.format('HH:mm:ss'),
    }));
  }; 
  const [bookingDate, setBookingDate] = useState(null); 
  const [bookingEndDate, setBookingEndDate] = useState(null); 
  const handleBookingEndDate = (newValue) => {
    setBookingEndDate(newValue); 
    setCreateData((prevData) => ({
      ...prevData,
      ["booking_end_date"]: newValue.format('YYYY-MM-DD'),
    }));
  };
  const handleBookingDate = (newValue) => {
    setBookingDate(newValue); 
    setBookingEndDate(newValue);
    setCreateData((prevData) => ({
      ...prevData,
      ["booking_date"]: newValue.format('YYYY-MM-DD'),
      ["booking_end_date"]: newValue.format('YYYY-MM-DD'),
    }));
  }; 
  const handleNavigate = (newDate, view) => { 
    const startDateOfWeek = moment(newDate).startOf('week').format('YYYY-MM-DD');  
    const endDateOfWeek = moment(newDate).endOf('week').format('YYYY-MM-DD');
    setCurrentStartDate(startDateOfWeek)
    setCurrentEndDate(endDateOfWeek) 
    // console.log('Navigated to:', newDate, 'View:', view);
    // You can perform further actions here based on the new date and view 
  };
  const filterDays = date => {
    const day = moment(date).day();
    return workingDays.includes(day)  
  };
 

  return (
    <Fragment>
      <ToastContainer /> 
      <Box sx={{ margin: "15px 0" }}>
          <Typography variant="h6">Select a Room : {selectedRoom?.room_name}</Typography>
          {userRooms.map((option) => (
            <RoomButton
              key={option.room_id}
              label={option.room_name}
              selected={selectedRoom?.room_id === option?.room_id}
              onRoomClick={() => setSelectedRoom(option)}
            />
          ))}
        </Box>

      <div className="container-fluid p-0">
        <div className="row">
          <div className="col-md-12">
            <Button onClick={handleSelectSlot} className="new-booking">
              New Booking
            </Button>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 height300 my-3">
            <Calendar 
              onNavigate={handleNavigate}
              defaultDate={defaultDate}
              defaultView={Views.WEEK}
              views={["week", "day"]}
              events={thisWeekEvents}
              localizer={localizer}
              onSelectEvent={handleSelectEvent}
              onSelectSlot={handleSelectSlot}
              selectable
              scrollToTime={scrollToTime}
              min={minTime}
              max={maxTime}
              timeslots={2}
              startAccessor="start"
              endAccessor="end"
              dayLayoutAlgorithm="no-overlap"
              dayPropGetter={date => ({
                style: {
                  display: filterDays(date) ? 'block' : 'none', // Hide non-Mon/Tue/Wed days
                },
              })}
            />
           {showModal && <CreateBooking  
             setModal={showModal}
             closeModel={()=>setShowModal(false)}
             bookingStartDate={bookingDate}
             bookingEDate={bookingEndDate}
             cData={createData}
             svalue={startvalue}
             evalue={endvalue}
             booking_id={null}
             type='CREATE'
             componetRerender={CalanderReload}
             selectedRoom={selectedRoom}
             /> }  
             {showEditModal && bookingData.length!=0 &&
            <CreateBooking  
              setModal={showEditModal}
              closeModel={()=>{ setBookingData([]); setShowEditModal(false)}}
              bookingStartDate={null}
              bookingEDate={null}
              cData={createData}
              svalue={null}
              evalue={null}
              booking_id={editBookingId}
              bookingData={bookingData}
              type='UPDATE'
              componetRerender={CalanderReload}
              selectedRoom={null}
            /> }
          </div>
        </div>
      </div>
      
    </Fragment>
  );
}

