import React, { useCallback, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { parseISO, format } from "date-fns";
import moment from "moment";
import { Modal, Button, Form, Card } from "react-bootstrap";
import { Typography, Autocomplete, TextField, Switch } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import Grid from "@mui/material/Grid";
import { LocalizationProvider, MobileTimePicker } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import IOSSwitch from "./Switch.js";
import { styled } from "@mui/system";
import event from "./events";
import "./scheduler.css";
import { Close } from "@mui/icons-material";
import RecurrenceDetailsModal from "./RecurrenceDetailsModal";

const RoomCard = () => {
  const [selectedRecurrenceOption, setSelectedRecurrenceOption] =
    useState(null);
  const [showRecurrenceModal, setShowRecurrenceModal] = useState(false);
  const [events, setEvents] = useState(event);
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState({
    title: "",
    description: "",
    start: null,
    end: null,
  });
  const bookingRoomData = useSelector((state) => state.roomBooking);
  const [editingEvent, setEditingEvent] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [roomAvailability, setRoomAvailability] = useState(
    bookingRoomData.availableRooms
  );
  const [showAvailable, setShowAvailable] = useState(true);
  useEffect(() => {
    if (bookingRoomData.availableRooms.length > 0) {
      setRoomAvailability(bookingRoomData.availableRooms);
    }
  }, [bookingRoomData]);
  const handleToggleDayAvailability = (roomId, dayIndex) => {
    setRoomAvailability((prevRooms) =>
      prevRooms?.map((room) =>
        room.id === roomId
          ? {
              ...room,
              days: room.days.map((day, index) =>
                index === dayIndex
                  ? { ...day, isAvailable: !day.isAvailable }
                  : day
              ),
            }
          : room
      )
    );
  };
  const toggleIosSwitch = () => {
    setShowAvailable(!showAvailable);
  };
  const [editModalData, setEditModalData] = useState({
    title: "",
    description: "",
    start: null,
    end: null,
  });

  const handleSelectSlot = useCallback(({ start, end }) => {
    setModalData({
      title: "",
      description: "",
      start,
      end,
    });
    setShowModal(true);
  }, []);

  const handleModalClose = () => {
    setShowModal(false);
  };
  const handleModalSubmit = () => {
    const { title, description, start, end } = modalData;
    if (title) {
      const newEvent = {
        title,
        description,
        start,
        end,
      };
      setEvents((prevEvents) => [...prevEvents, newEvent]);
      setShowModal(false);
    }
  };

  const handleSelectEvent = useCallback((event) => {
    setEditingEvent(event);
    setEditModalData({
      title: event.title,
      description: event.description,
      start: event.start,
      end: event.end,
    });
    setShowEditModal(true);
  }, []);

  const handleEditModalClose = () => {
    setShowEditModal(false);
  };

  const handleEditModalSubmit = () => {
    if (editingEvent) {
      const updatedEvent = {
        ...editingEvent,
        title: editModalData.title,
        description: editModalData.description,
        start: editModalData.start,
        end: editModalData.end,
      };
      setEvents((prevEvents) => {
        const index = prevEvents.findIndex((event) => event === editingEvent);
        if (index !== -1) {
          const updatedEvents = [...prevEvents];
          updatedEvents.splice(index, 1, updatedEvent);
          return updatedEvents;
        }
        return prevEvents;
      });
      setShowEditModal(false);
    }
  };

  const location = [
    { title: "Bangalore" },
    { title: "Chennai" },
    { title: "Hyderabad" },
    { title: "Tirupati" },
  ];

  const building = [
    { title: "ABC Tower" },
    { title: "XYZ Tower" },
    { title: "PQR Tower" },
    { title: "DEF Tower" },
  ];
  const floor = [
    { title: "1st Floor" },
    { title: "2nd Floor" },
    { title: "3rd Floor" },
    { title: "4th Floor" },
  ];
  const room = [
    { title: "Big Room" },
    { title: "Small Room" },
    { title: "Medium Room" },
    { title: "Conference Room" },
  ];
  const recurrence = [
    { title: "Does Not Repeat" },
    { title: "Mon - Fri" },
    { title: "Weekly" },
    { title: "Monthly" },
  ];
  const amenities = [{ title: "TV" }, { title: "Projector" }, { title: "AC" }];
  const roomService = [
    { title: "No Service" },
    { title: "Only Water" },
    { title: "Coffee & Water" },
  ];
  const attendies = [
    { title: "Sundar M" },
    { title: "Zameer Ahmad" },
    { title: "Darab Karim" },
    { title: "Md Mustafa" },
  ];

  const [startvalue, setStartValue] = useState(moment(""));
  const [endvalue, setEndValue] = useState(moment(""));

  const handleChange = (newValue) => {
    setStartValue(newValue);
  };
  const handleChangeend = (newValue) => {
    setEndValue(newValue);
  };
  const [value, setValue] = useState(null);

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  return (
    <div className="border rounded p-2">
      <div className="availablity-top">
        <h6>
          {new Date().toLocaleDateString("en-US", {
            weekday: "short",
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </h6>
        <div>
          <h6>Available</h6>
          <IOSSwitch
            onChange={toggleIosSwitch}
            defaultChecked={showAvailable}
          />
        </div>
      </div>

      {showAvailable && (
        <div>
          {roomAvailability
            .filter((room) => Object.values(room.range).every((e) => e))
            .map((room) => (
              <Card
                key={room.id}
                className="mb-4"
                onClick={handleSelectSlot}
                style={{
                  backgroundColor: Object.values(room.range).every((e) => e)
                    ? "#0ACE8D"
                    : "#ee2a2a",
                }}
              >
                <Card.Body className="d-flex justify-content-between text-white p-2">
                  <div>
                    <p className="mb-0">{room.room_name}</p>
                  </div>
                  <div>
                    <p className="mb-0">
                      {Object.values(room.range).every((e) => e)
                        ? "Available"
                        : "Not Available"}
                    </p>
                  </div>
                </Card.Body>
                <Card.Footer className="px-0 room_card">
                  <div className="d-flex justify-content-between">
                    {Object.keys(room?.availability)?.map((date, index) => {
                      const dateObject = parseISO(date);
                      const dayOfWeek = format(dateObject, "EEEE");
                      return (
                        <Button
                          key={index}
                          variant="link"
                          size="sm"
                          onClick={() =>
                            handleToggleDayAvailability(room.room_id, index)
                          }
                          disabled={!room?.availability[date]}
                        >
                          {dayOfWeek.substring(0, 3)}{" "}
                        </Button>
                      );
                    })}
                  </div>
                </Card.Footer>
              </Card>
            ))}
        </div>
      )}
      {!showAvailable && (
        <div>
          {roomAvailability.map((room) => (
            <Card
              key={room.id}
              className="mb-4"
              onClick={handleSelectSlot}
              style={{
                backgroundColor: Object.values(room.range).every((e) => e)
                  ? "#0ACE8D"
                  : "#ee2a2a",
              }}
            >
              <Card.Body className="d-flex justify-content-between text-white p-2">
                <div>
                  <p className="mb-0">{room.room_name}</p>
                </div>
                <div>
                  <p className="mb-0">
                    {Object.values(room.range).every((e) => e)
                      ? "Available"
                      : "Not Available"}
                  </p>
                </div>
              </Card.Body>
              <Card.Footer className="px-0 room_card">
                <div className="d-flex justify-content-between">
                  {Object.values(room?.availability)?.map((date, index) => (
                    <Button
                      key={index}
                      variant="link"
                      size="sm"
                      onClick={() =>
                        handleToggleDayAvailability(room.room_id, index)
                      }
                      disabled={!room?.availability[date]}
                    >
                      {date}
                    </Button>
                  ))}
                </div>
              </Card.Footer>
            </Card>
          ))}
        </div>
      )}

      <Modal size="xl" show={showModal} onHide={handleModalClose}>
        <Modal.Header style={{ padding: "1rem 3.2rem" }}>
          <Modal.Title>Book Room</Modal.Title>
          <Close onClick={handleModalClose}>&times;</Close>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Grid sx={{ padding: "0 40px" }} container spacing={2}>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={location.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Location
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={building.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Building
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={floor.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Floor Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={room.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Room
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <TextField
                  size="small"
                  fullWidth
                  id="outlined-basic"
                  label={
                    <span>
                      Meeting Subject
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    size="small"
                    label={
                      <span>
                        Select Date
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    value={value}
                    onChange={(newValue) => {
                      setValue(newValue);
                    }}
                    renderInput={(params) => (
                      <TextField size="small" fullWidth {...params} />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={3}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    value={startvalue}
                    label={
                      <span>
                        Start time
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    onChange={handleChange}
                    renderInput={(params) => (
                      <TextField size="small" fullWidth {...params} />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={3}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    value={endvalue}
                    label={
                      <span>
                        End Time
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    onChange={handleChangeend}
                    renderInput={(params) => (
                      <TextField size="small" fullWidth {...params} />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={3}>
                <TextField
                  size="small"
                  fullWidth
                  id="outlined-basic"
                  label={
                    <span>
                      Duration
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <TextField
                  size="small"
                  fullWidth
                  id="outlined-basic"
                  label={
                    <span>
                      Room Capacity
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={recurrence.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Repeat"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                  onChange={(event, newValue) => {
                    if (newValue === "Does Not Repeat") {
                      setSelectedRecurrenceOption(null);
                    } else {
                      setSelectedRecurrenceOption(newValue);
                      setShowRecurrenceModal(true);
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  multiple
                  id="free-solo-2-demo"
                  disableClearable
                  options={amenities.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Ameneties Type"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={roomService.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Room Service"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <Autocomplete
                  size="small"
                  multiple
                  id="free-solo-2-demo"
                  disableClearable
                  options={attendies.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Add Attendies"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  size="small"
                  fullWidth
                  id="editDescription"
                  label="Description"
                  variant="outlined"
                  multiline
                  rows={4}
                  value={editModalData.description}
                  onChange={(e) =>
                    setEditModalData((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                />
              </Grid>
            </Grid>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button className="book-now" onClick={handleModalSubmit}>
            Book Room
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal size="xl" show={showEditModal} onHide={handleEditModalClose}>
        <Modal.Header style={{ padding: "1rem 3.2rem" }}>
          <Modal.Title>Edit Room Details</Modal.Title>
          <Close onClick={handleEditModalClose}>&times;</Close>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Grid sx={{ padding: "0 40px" }} container spacing={2}>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={location.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Location
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={building.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Building
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={floor.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Floor Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={room.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Room
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <TextField
                  size="small"
                  fullWidth
                  id="outlined-basic"
                  label={
                    <span>
                      Meeting Subject
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    label={
                      <span>
                        Select Date
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    value={value}
                    onChange={(newValue) => {
                      setValue(newValue);
                    }}
                    renderInput={(params) => (
                      <TextField size="small" fullWidth {...params} />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={3}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    value={startvalue}
                    label={
                      <span>
                        Start time
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    onChange={handleChange}
                    renderInput={(params) => (
                      <TextField size="small" fullWidth {...params} />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={3}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    value={endvalue}
                    label={
                      <span>
                        End Time
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    onChange={handleChangeend}
                    renderInput={(params) => (
                      <TextField size="small" fullWidth {...params} />
                    )}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={3}>
                <TextField
                  size="small"
                  fullWidth
                  id="outlined-basic"
                  label={
                    <span>
                      Duration
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <TextField
                  size="small"
                  fullWidth
                  id="outlined-basic"
                  label={
                    <span>
                      Room Capacity
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={recurrence.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Repeat"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                  onChange={(event, newValue) => {
                    if (newValue === "Does Not Repeat") {
                      setSelectedRecurrenceOption(null);
                    } else {
                      setSelectedRecurrenceOption(newValue);
                      setShowRecurrenceModal(true);
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  multiple
                  id="free-solo-2-demo"
                  disableClearable
                  options={amenities.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Ameneties Type"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <Autocomplete
                  size="small"
                  id="free-solo-2-demo"
                  disableClearable
                  options={roomService.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Room Service"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <Autocomplete
                  size="small"
                  multiple
                  id="free-solo-2-demo"
                  disableClearable
                  options={attendies.map((option) => option.title)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Add Attendies"
                      InputProps={{
                        ...params.InputProps,
                        type: "search",
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={12}>
                <TextField
                  size="small"
                  fullWidth
                  id="editDescription"
                  label="Description"
                  variant="outlined"
                  multiline
                  rows={4}
                  value={editModalData.description}
                  onChange={(e) =>
                    setEditModalData((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                />
              </Grid>
            </Grid>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button
            className="book-now"
            variant="primary"
            onClick={handleEditModalSubmit}
          >
            Save
          </Button>
        </Modal.Footer>
      </Modal>

      {selectedRecurrenceOption && showRecurrenceModal && (
        <RecurrenceDetailsModal
          show={showRecurrenceModal}
          onClose={() => setShowRecurrenceModal(false)}
          recurrenceOption={selectedRecurrenceOption}
        />
      )}
    </div>
  );
};

export default RoomCard;
