import React, {Fragment,useState,useCallback,useMemo,useEffect} from "react"; 
import { useSelector, useDispatch } from "react-redux"; 
import { Modal, Button, Form } from "react-bootstrap";
import moment from "moment";
import { fetchBuildings } from "../../api/Building/buildingApi";
import { fetchFloors } from "../../api/Floor/floorApis";
import { getRoomsList } from "../../api/Rooms/roomApis"; 
import { fetchRoomServiceData } from "../../api/RoomService/roomServiceReducers";
import { createBookingData,updateBookingData} from "../../api/RoomBooking/roombookingReducer";
import { toast } from "react-toastify";
import { Autocomplete, Box, TextField, Typography } from "@mui/material";
import { getUserData } from "../../api/UserAccessManagementPage/UserAccessAPi"; 
import Grid from "@mui/material/Grid";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import { styled } from "@mui/system";
import RecurrenceDetailsModal from "./RecurrenceDetailsModal";
import { version } from "react";
function CreateBooking(props){   
    let {setModal,closeModel,bookingStartDate,bookingEDate,cData,
        svalue,evalue,booking_id,type,bookingData=null,componetRerender,selectedRoom}=props;   
    const [days, setDays] = React.useState(["Mon", "Tue", "Wed", "Thu", "Fri"]);
    const [autoBuildingSelect, setAutoBuildingSelect] = useState(true);
    const [autoFloorSelect, setAutoFloorSelect] = useState(true);
    const [autoRoomSelect, setAutoRoomSelect] = useState(true);
    const [locationValue, setLocationValue] = useState(null);
    const [buildingValue, setBuildingValue] = useState(null);
    const [floorValue, setFloorValue] = useState(null); 
    const [roomValue, setRoomValue] = useState(null);
    const [repeatValue, setRepeatValue] = useState(null);
    const [userValue, setAttendiesValue] = useState([]); 
    const [attendies, setAttendies] = useState([]);  
    const [isActiveAdd, setIsActiveAdd] = useState(true);
    const [createData, setCreateData] = useState(cData); 
    const [startvalue, setStartValue] = useState(moment(""));
    const [endvalue, setEndValue] = useState(moment(""));
    const [rSummary, setRsummary] = useState('');
    const [roomData, setRoomData] = useState([]);
    const [floorData, setFloorData] = useState([]);
    const [buildingData, setBuildingData] = useState([]);
    const [locationError, setLocationError] = useState(false);
    const [buildingError, setBuildingError] = useState(false);
    const [floorError, setFloorError] = useState(false);
    const [roomError, setRoomError] = useState(false);
    const [nameError, setNameError] = useState(false);
    const [dateError, setDateError] = useState(false);
    const [endDateError, setEndDateError] = useState(false);
    const [starttimeError, setStartTimeError] = useState(false);
    const [endtimeError, setEndTimeError] = useState(false); 
    const [repeatError, setRepeatError] = useState(false); 
    const [servicenameError, setServiceNameError] = useState(false);
    const [addattendiesError, setAddAttendeesError] = useState(false);
    const [descriptionError, setDescriptionError] = useState(false);
    const [keyChange, setKeyChange] = useState(""); 
    const [bookingDate, setBookingDate] = useState(null); 
    const [bookingEndDate, setBookingEndDate] = useState(null);
    const [selectedRecurrenceOption, setSelectedRecurrenceOption] = useState(null);
    const [showRecurrenceModal, setShowRecurrenceModal] = useState(false);
    const currentDate = moment(); 
    const locationData = useSelector((state) => state.locations); 
    const RoomServiceData = useSelector((state) => state.roomService);
    const BookingDetailsData = bookingData;
    const dispatch = useDispatch();  
    
    useEffect(() => {
      if(selectedRoom?.location_id){

        setCreateData((prevData) => ({
          ...prevData,
          ["location_id"]:  selectedRoom?.location_id,  
          ["building_id"]: selectedRoom?.building_id,
          ["floor_id"]: selectedRoom?.floor_id,
          ["room_id"]: selectedRoom?.room_id,
        }));  
        // setLocationValue
        locationData?.locations?.location?.map((l)=>{
          if(l?.location_id==selectedRoom?.location_id){
            setLocationValue(l) 
            fetchBuildingData([l]);
          }
        })  
      }
    },[selectedRoom])

    useEffect(() => {
      if(autoBuildingSelect){
        if(selectedRoom?.location_id){          
          buildingData?.buildings?.BuildingsData?.map((l)=>{          
            if(l?.building_id==selectedRoom?.building_id){
              setAutoBuildingSelect(false)
              setBuildingValue(l) 
              fetchFloorData([l]);
            }
          })  
        }
      } 
    },[buildingData])
    
    useEffect(() => {
      if(autoFloorSelect){
        if(selectedRoom?.location_id){          
          floorData?.floors?.floorsData?.map((l)=>{          
            if(l?.floor_id==selectedRoom?.floor_id){
              setAutoFloorSelect(false)
              setFloorValue(l) 
              fetchRoomData([l]);
            }
          })  
        }
      } 
    },[floorData])

    useEffect(() => {
      if(autoRoomSelect){
        if(selectedRoom?.location_id){          
          roomData?.rooms?.roomData?.map((l)=>{          
            if(l?.room_id==selectedRoom?.room_id){ 
              setAutoRoomSelect(false)
              setRoomValue(l)  
              setCreateData((prevData) => ({
                ...prevData,
                [`room_capacity`]: l?.capacity
              }));
            }
          })  
        }
      } 
    },[roomData])
    // const [autoRoomSelect, setAutoRoomSelect] = useState(true);
    // const [autoFloorSelect, setAutoFloorSelect] = useState(true);

    useEffect(() => {
      if(type=="UPDATE"){  
        console.log(BookingDetailsData?.participents)
        let participents=BookingDetailsData?.participents?.map((user)=>user.crbt_users) 
        setAttendiesValue(participents);
        participents=participents.map(userid=>userid.user_id)
        console.log('participents ',participents)
        fetchBuildingData([{location_id: BookingDetailsData?.crbt_locations?.location_id}]);
        fetchFloorData([{building_id: BookingDetailsData?.crbt_buildings?.building_id}]);
        fetchRoomData([{floor_id: BookingDetailsData?.crbt_floors?.floor_id}]);   
        setCreateData((prevData) => ({
          ...prevData,
          ["title_of_meeting"]: BookingDetailsData?.title_of_meeting,
          ["description"]: BookingDetailsData?.description,
          ["location_id"]: BookingDetailsData?.crbt_locations?.location_id,  
          ["building_id"]: BookingDetailsData?.crbt_buildings?.building_id,
          ["floor_id"]: BookingDetailsData?.crbt_floors?.floor_id,
          ["room_id"]: BookingDetailsData?.crbt_rooms?.room_id,
          ["booking_date"]: BookingDetailsData?.booking_date,
          ["booking_end_date"]: BookingDetailsData?.booking_end_date,
          ["repeat"]: BookingDetailsData?.repeat,
          ["starttime"]: BookingDetailsData?.starttime,
          ["endtime"]: BookingDetailsData?.endtime,
          ["booking_id"]:booking_id,
          ["participants_id"]:participents,
          ["room_capacity"]:BookingDetailsData?.crbt_rooms?.capacity,
        })); 


      setBookingDate(moment(BookingDetailsData?.booking_date)); 
      setBookingEndDate(moment(BookingDetailsData?.booking_end_date));
 
      setStartValue(moment(BookingDetailsData?.booking_date+'T'+BookingDetailsData?.starttime));
      setEndValue(moment(BookingDetailsData?.booking_end_date+'T'+BookingDetailsData?.endtime)); 
      setLocationValue({
        "location_id": BookingDetailsData?.crbt_locations?.location_id,
        "ulocation_id": BookingDetailsData?.crbt_locations?.ulocation_id,
        "location_name":  BookingDetailsData?.crbt_locations?.location_name
      }) 
      setBuildingValue({
        "building_id": BookingDetailsData?.crbt_buildings?.building_id,
        "ubuilding_id": BookingDetailsData?.crbt_buildings?.ubuilding_id,
        "building_name": BookingDetailsData?.crbt_buildings?.building_name,
        "location_id": BookingDetailsData?.crbt_buildings?.location_id,
      }) 
      setFloorValue({
        "building_id": BookingDetailsData?.crbt_floors?.building_id,
        "floor_id": BookingDetailsData?.crbt_floors?.floor_id,
        "floor_name": BookingDetailsData?.crbt_floors?.floor_name,
        "ufloor_id": BookingDetailsData?.crbt_floors?.ufloor_id,
      })  
      setRoomValue({
        "capacity": BookingDetailsData?.crbt_rooms?.capacity,
        "floor_id": BookingDetailsData?.crbt_rooms?.floor_id,
        "room_id": BookingDetailsData?.crbt_rooms?.room_id,
        "room_name": BookingDetailsData?.crbt_rooms?.room_name,
        "uroom_id": BookingDetailsData?.crbt_rooms?.uroom_id
      })      
      setRepeatValue({
        title: BookingDetailsData?.repeat
      })  
      } 
    }, [dispatch]);
 
    
   
    useEffect(() => {    
      errorreset()   
       if(type=="CREATE"){
          setBookingDate(bookingStartDate);    
          setBookingEndDate(bookingEDate);    
          setStartValue(svalue)
          setEndValue(evalue)  
          setCreateData((prevData) => ({
            ...prevData,
            ["booking_date"]: bookingStartDate?.format('YYYY-MM-DD'),
            ["booking_end_date"]: bookingEDate?.format('YYYY-MM-DD'),
            ["starttime"]: svalue?.format('HH:mm:ss'),
            ["endtime"]: evalue?.format('HH:mm:ss')
          }));
        } 
      },[setModal]);
    const saveRecurrence=(recurrenceData)=>{  
      console.log(recurrenceData.selectedDays)
        handleDays(recurrenceData.selectedDays);    
        handleBookingDate(recurrenceData.startDate); 
        handleBookingEndDate(recurrenceData.endDate);  
        setRsummary(recurrenceData.recurrenceSummary);
      }
    let errorreset=()=>{
        let errorHandle=[setLocationError,setBuildingError,setFloorError,setRoomError,setNameError,setDateError,
          setEndDateError,setStartTimeError,setEndTimeError,setRepeatError,
          setServiceNameError,setAddAttendeesError,setDescriptionError]   
          errorHandle.map((muteErrors)=>{muteErrors(false)}) 
      }
    const getDayNumbes=(l)=>{  
      console.log(l)
      console.log(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(l) )
        return ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(l) 
      } 
    const handleDays=(d)=>{ 
        setDays(d);
        setCreateData((prevData) => ({
          ...prevData,
          ["days"]: d.map((l)=>{
          return getDayNumbes(l)
          }),
        }));
      }
    const recurrence = [
        { title: "Does Not Repeat" },
        { title: "Mon-Fri" },
        { title: "Weekly" },
        // { title: "Monthly" },
      ];
    const RequiredAsterisk = styled("span")({
        color: "red",
      });
      const handleChangestart = (newValue) => {
        setStartValue(newValue); 
        setCreateData((prevData) => ({
          ...prevData,
          ["starttime"]: newValue.format('HH:mm:ss'),
        }));
      }; 
      const handleChangeend = (newValue) => { 
    setEndValue(newValue); 
    setCreateData((prevData) => ({
      ...prevData,
      ["endtime"]: newValue.format('HH:mm:ss'),
    }));
  };
      const handleBookingDate = (newValue) => {
        setBookingDate(newValue); 
        setBookingEndDate(newValue);
        setCreateData((prevData) => ({
          ...prevData,
          ["booking_date"]: newValue.format('YYYY-MM-DD'),
        }));
      };
   
    const labelClassess = {
        label: { style: { color: "#2c2c2c" } },
      };
    
    const handleBookingEndDate = (newValue) => {
        setBookingEndDate(newValue); 
        setCreateData((prevData) => ({
          ...prevData,
          ["booking_end_date"]: newValue.format('YYYY-MM-DD'),
        }));
      };
    let  attendiesInputChange=async (event, newInputValue) => {
        try {
          if(newInputValue!=""){
            let data=await getUserData(newInputValue);  
            if(data.status){
              setAttendies(data.data)
            }else{
              setAttendies([])
            }     
          }else{
            setAttendies([])
          } 
        } catch (error) {
          console.error('Error fetching options:', error);
          setAttendies([])
        }
      }; 
    let resetCreateData = () => {
        setCreateData({
          status: isActiveAdd,
          duration:"30M",
          room_capacity:''
        });
      }; 
    let fetchRoomData = async (v) => {
        if (v != null) {
          let rlt = await getRoomsList(v);
          setRoomData({ rooms: rlt });
        } else {
          setRoomData([]);
        }
      };
    let fetchFloorData = async (v) => {
        setRoomData([]);
        if (v != null) {
          let rlt = await fetchFloors(v);
          setFloorData({ floors: rlt });
        } else {
          setFloorData([]);
          setRoomData([]);
        }
      };
      let fetchBuildingData = async (v) => {
        setFloorData([]);
        if (v != null) {
          let rlt = await fetchBuildings(v);
          setBuildingData({ buildings: rlt });
        } else {
          setBuildingData([]);
          setFloorData([]);
        }
      };
    const handleModalClose = () => {
        closeModel();
      }; 
      const handleChange = (e, v, name) => { 
        const val = v === null ? e?.target?.value : v[name];
        if (Array.isArray(v)) { 
          if (name === "room_service_name") { 
            const servicids = v.map((a) => a.room_service_id);
            setCreateData((prevData) => ({
              ...prevData,
              [name]: v,
            }));
            setCreateData((prevData) => ({
              ...prevData,
              ['room_service_id']: servicids,
            }));
          }
          if (name === "participants_id") { 
            const attendiesValue = v.map((a) => a.user_id); 
            setCreateData((prevData) => ({
              ...prevData,
              [name]: attendiesValue,
            }));
          }
        } else if (
          name === "building" ||
          name === "location" ||
          name === "floor" ||
          name === "room"
        ) {
    
          if(name === "room"){ 
            setCreateData((prevData) => ({
              ...prevData,
              [`room_capacity`]: v?.capacity
            }));
          }
          setCreateData((prevData) => ({
            ...prevData,
            [`u${name}_id`]: v ? v[`u${name}_id`] : "",
            [`${name}_id`]: v ? v[`${name}_id`] : "",
            [`${name}_name`]: v ? v[`${name}_name`] : "",
          }));
        }else if( name === "repeat" ){
          setRsummary("")
          setCreateData((prevData) => ({
            ...prevData,
            [name]:  v === null?'':v.title,
          }));
        } else { 
          const val = v === null ? e?.target?.value :  "";
          setCreateData((prevData) => ({
            ...prevData,
            [name]: val,
          }));
        }
        let setEmptyCreateData = (name, v) => {
          setCreateData((prevData) => ({
            ...prevData,
            [`${name}_id`]: "",
            [`${name}_name`]: "",
          }));
          if(name=="room"){
            setCreateData((prevData) => ({
              ...prevData,
              ['room_capacity']: ""
            }));
          } 
        }; 
        if (name == "location") {
          setEmptyCreateData("building", v);
          setEmptyCreateData("floor", v);
          fetchBuildingData(v);
        }
        if (name == "building") {
          setEmptyCreateData("floor", v);
          if (v != null) {
            fetchFloorData([v]);
          } else {
            setFloorData([]);
          }
        }
        if (name == "floor") {
          setEmptyCreateData("room", v);
          if (v != null) {
            fetchRoomData([v]);
          } else {
            setRoomData([]);
          }
        }  
      };     
    const handleModalSubmit = async () => {     
        if (
          !createData.location_id || !createData.building_id 
          || !createData.floor_id || !createData.room_id 
          || !createData.title_of_meeting || !createData.booking_date 
          || !createData.starttime || !createData.endtime 
          || !createData.repeat 
          || !createData.room_service_id 
          || !createData.participants_id || !createData.description
          // || !createData.duration
        ) { 
          setLocationError(!createData.location_id);
          setBuildingError(!createData.building_id);
          setFloorError(!createData.floor_id);
          setRoomError(!createData.room_id);
          setNameError(!createData.title_of_meeting);
          setDateError(!createData.booking_date);
          setStartTimeError(!createData.starttime);
          setEndTimeError(!createData.endtime);        
          setRepeatError(!createData.repeat); 
          setServiceNameError(!createData.room_service_id);
          setAddAttendeesError(!createData.participants_id);
          setDescriptionError(!createData.description); 
          return;
        }   
        
        try {
          let data=''
          if(type=="UPDATE"){ 
              data = await dispatch(updateBookingData(createData));          
           }else{
              data = await dispatch(createBookingData(createData)); 
          }  
          if (data.payload.status) {
            resetCreateData();
            setKeyChange(Math.random());
            handleModalClose(); 
            componetRerender();
            setTimeout(() => {
              toast.success(type=="UPDATE"?"Booking updated successfully":"New Booking created successfully");
            }, 500);
            setIsActiveAdd(true);
          } else { 
            setTimeout(() => {
              toast.error(data.payload.errorMessage);
            }, 500); 
          } 
        } catch (error) {
          setTimeout(() => {
            toast.error("Failed to create NewBooking");
          }, 500);
        }
      };
    return(
        <> 
        <Modal size="xl" show={setModal} onHide={handleModalClose}>
              <Modal.Header style={{ padding: "1rem 3.2rem" }}>
                {type=='UPDATE' &&  <Modal.Title>Update Booking </Modal.Title>}
                {type=='CREATE' &&  <Modal.Title>Book Room</Modal.Title>}
                
                <Button
                  variant="link"
                  className="close-modal-btn dismiss-booking"
                  onClick={handleModalClose}
                  aria-label="Close"
                >
                  &times;
                </Button>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  <Grid sx={{ padding: "0 40px" }} container spacing={2}>
                  <Grid item xs={12} sm={12}>
                      <TextField
                        fullWidth
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        size="small"
                        open={true}
                        label="Meeting Subject"
                        id={"title_of_meeting"}
                        value={createData?.title_of_meeting}
                        error={nameError}
                        helperText={
                          nameError ? "Meeting Subject is required." : ""
                        }
                        name="title_of_meeting"
                        onChange={(e) => {
                          handleChange(e, null, "title_of_meeting");
                          setNameError("");
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12}>
                      <Autocomplete
                        size="small"
                        multiple
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        options={attendies.map((option) => option)}
                        getOptionLabel={(option) =>{
                          if (option?.full_name) {
                            return `${option.employee_code} - ${option.full_name}`;
                          } 
                        }                          
                        }
                        value={userValue}
                        getOptionDisabled={(option) => option.status === false}
                        name="participants_id"
                        onInputChange={attendiesInputChange}
                        onChange={(e, v) => {  
                          setAttendiesValue(v)
                          handleChange(e, v, "participants_id");
                          setAddAttendeesError("");
                          
                        }}
                        key={keyChange}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Add Attendies"
                            placeholder="Add Attendies"
                            // value={createData.participants_id || []}
                            error={addattendiesError}
                            helperText={
                              addattendiesError
                                ? "Add Attendies is required."
                                : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <DatePicker
                          size="small"
                          label={
                            <span>
                              start Date
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          value={bookingDate}
                          minDate={currentDate}
                          onChange={(e) => {
                            handleBookingDate(e)  
                          }} 
                          error={dateError}
                          helperText={
                            dateError ? "Start date is required." : ""
                          }
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <TimePicker
                          value={startvalue} 
                          label={
                            <span>
                              Start time
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          error={starttimeError}
                          helperText={
                            starttimeError ? "Start time is required." : ""
                          }
                          onChange={handleChangestart}
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <DatePicker
                          size="small"
                          label={
                            <span>
                              End Date
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          minDate={bookingDate}
                          value={bookingEndDate}
                          onChange={(e) => {
                            handleBookingEndDate(e)  
                          }} 
                          error={endDateError}
                          helperText={
                            endDateError ? "end date is required." : ""
                          }
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <LocalizationProvider dateAdapter={AdapterMoment}>
                        <TimePicker
                          value={endvalue}
                          minTime={startvalue}
                          label={
                            <span>
                              End Time
                              <RequiredAsterisk>*</RequiredAsterisk>
                            </span>
                          }
                          error={endtimeError}
                          helperText={
                            endtimeError ? "End time is required." : ""
                          }
                          onChange={handleChangeend}
                          renderInput={(params) => (
                            <TextField size="small" fullWidth {...params} />
                          )}
                        />
                      </LocalizationProvider>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        name="location_id"
                        value={locationValue}
                        onChange={(e, v) => {
                          handleChange(e, v, "location");
                          setLocationError(""); 
                          setLocationValue(v) 
                        }}
                        key={keyChange}
                        options={locationData?.locations?.location ?? []}
                        getOptionLabel={(option) =>{
                          if (option?.location_id) {
                            return `${option.ulocation_id} - ${option.location_name}`;
                          }
                        }}
                        getOptionDisabled={(option) => option.status === false}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Location Id-Name"
                            placeholder="Location Id-Name"
                            value={createData.location_id || []}
                            error={locationError}
                            helperText={
                              locationError ? "Location name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        value={buildingValue}
                        id="checkboxes-tags-demo"
                        name="building_name"
                        onChange={(e, v) => {
                          console.log("buildingValue : ",console.log(buildingValue))
                          console.log('v',v)
                          handleChange(e, v, "building");
                          setBuildingError("");
                          setBuildingValue(v)
                        }}
                        key={keyChange}
                        options={buildingData?.buildings?.BuildingsData || []}
                        getOptionLabel={(option) =>
                          { 
                            if (option?.building_id) {
                            return `${option.ubuilding_id} - ${option.building_name}`;
                          } else {
                            return "";
                          }
                        }
                        } 
                        getOptionDisabled={(option) => option.status === false}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Building Id-Name"
                            placeholder="Building Id-Name"
                            // value={createData.building_id || []}
                            error={buildingError}
                            helperText={
                              buildingError ? "Building name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid> 
                    <Grid item xs={12} sm={3}>
                      <Autocomplete
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        name="floor_name"
                        onChange={(e, v) => { 
                          setFloorValue(v)
                          handleChange(e, v, "floor");
                          setFloorError("");
                        }}
                        options={floorData?.floors?.floorsData || []}
                        key={keyChange}
                        getOptionLabel={(option) =>{
                          if (option?.floor_id) {
                            return `${option?.ufloor_id} - ${option?.floor_name}`;
                          }else{ return '' }
                        }}
                        getOptionDisabled={(option) => option.status === false}
                        value={floorValue}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Floor Id-Name"
                            placeholder="Floor Id-Name"
                            // value={createData.floor_id || []}
                            error={floorError}
                            helperText={
                              floorError ? "Floor name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Autocomplete 
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                            padding: "8px",
                          },
                          marginBottom: "10px",
                        }}
                        id="checkboxes-tags-demo"
                        name="room_name"
                        onChange={(e, v) => { 
                          setRoomValue(v)
                          handleChange(e, v, "room");
                          setRoomError("");
                        }}
                        value={roomValue}
                        key={keyChange}
                        options={roomData?.rooms?.roomData || []}
                        getOptionLabel={(option) =>{
                          if (option?.room_id) {
                            return `${option.uroom_id} - ${option.room_name}`;
                          } 
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Room Id-Name"
                            placeholder="Room Id-Name"
                            error={roomError}
                            helperText={
                              roomError ? "Room name is required." : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                            }}
                          />
                        )}
                      />
                    </Grid>   
                    <Grid item xs={12} sm={3}>
                      <Autocomplete 
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                            padding: "8px",
                          },
                          marginBottom: "10px",
                        }}
                        id="repeat"
                        name="repeat" 
                        key={keyChange}
                        options={recurrence.map((op) => op)}
                        getOptionLabel={(option) =>{
                          if (option?.title) {
                            return `${option.title}`;
                          }else{
                            return '';
                          }
                        }} 
                        value={repeatValue}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Repeat"
                            placeholder="Repeat"
                            error={repeatError}
                            helperText={repeatError ? "Repeat is required." : ""}
                            InputLabelProps={{
                              ...params.InputLabelProps,
                            }}
                          />
                        )}
                        onChange={(event, newValue) => {  
                          setRepeatValue(newValue)
                          setRepeatError("")
                          handleChange(event, newValue, "repeat");
                          if(newValue!=null){
                            if (newValue.title === "Does Not Repeat" || newValue.title === "Mon-Fri") {
                              setSelectedRecurrenceOption(null);
                            } else {
                              setSelectedRecurrenceOption(newValue.title);
                              setShowRecurrenceModal(true);
                              handleDays([]) 
                            }
                          }
                         
                        }}
                      />  
                    </Grid> 
                    <Grid item xs={12} sm={12}>
                    <Typography variant="p" onClick={()=>{ setShowRecurrenceModal(true)}} ><a>{rSummary}</a></Typography>
                  </Grid>
                    
                    <Grid item xs={12} sm={12}>
                      <Autocomplete
                        multiple
                        size="small"
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        id="checkboxes-tags-demo"
                        options={RoomServiceData?.roomservice?.service || []}
                        getOptionDisabled={(option) => option.status === false}
                          getOptionLabel={(option) =>{ 
                            if (option?.room_service_id) {
                              return `${option.room_service_id} - ${option.room_service_name}`;
                            }
                          } 
                        }
                        name="room_service_name"
                        onChange={(e, v) => {
                          handleChange(e, v, "room_service_name");
                          setServiceNameError("");
                        }}
                        key={keyChange}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Room Service-Name"
                            placeholder="Room Service-Name"
                            value={createData.room_service_name || []}
                            error={servicenameError}
                            helperText={
                              servicenameError
                                ? "Room Service is required."
                                : ""
                            }
                            InputLabelProps={{
                              ...params.InputLabelProps,
                              ...labelClassess.label,
                            }}
                          />
                        )}
                      />
                    </Grid>                    
                    <Grid item xs={12} sm={12}>
                      <TextField
                        fullWidth
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                        }}
                        size="small"
                        open={true}
                        label="Description"
                        id={"description"}
                        variant="outlined"
                        multiline
                        rows={4}
                        value={createData?.description}
                        error={descriptionError}
                        helperText={
                          descriptionError ? "Description is required." : ""
                        }
                        name="description"
                        onChange={(e) => {
                          handleChange(e, null, "description");
                          setDescriptionError(""); 
                        }}
                      />
                    </Grid>
                  </Grid>
                </Form>
              </Modal.Body>
              <Modal.Footer>
              <Button className="book-now" onClick={handleModalSubmit} >
                 {type=='UPDATE'?"Update Booking":"Book Room"}
              </Button> 
               
              </Modal.Footer>
            </Modal>
            {selectedRecurrenceOption && showRecurrenceModal && (
        <RecurrenceDetailsModal
          bookingDate={bookingDate}
          bookingEndDate={bookingEndDate}
          show={showRecurrenceModal}
          onClose={() => setShowRecurrenceModal(false)}
          recurrenceOption={selectedRecurrenceOption}
          saveRecurrence={saveRecurrence}
          days={days}
        />
      )}
        </>
    )
}
export default CreateBooking;