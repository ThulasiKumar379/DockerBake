import React from "react";
import {useDispatch } from "react-redux";
import { useState,useEffect } from "react";
import {
  TextField,
  MenuItem,
  Checkbox,
  Button,
  Box,
  Grid,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
// import { Tooltip } from 'react-tooltip';
import Tooltip from '@mui/material/Tooltip';
import FilterDatePicker from "../FilterDatePicker";
import { styled } from "@mui/system";
import SearchIcon from "@mui/icons-material/Search";
import moment from "moment";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import TimezoneSelect from "react-timezone-select";
import DateRangePickerValue from "../FilterDatePicker";
import { ExpandMore as ExpandMoreIcon } from "@mui/icons-material";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import Autocomplete from "@mui/material/Autocomplete";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { Calendar, Views, momentLocalizer } from "react-big-calendar";
import FilterTimeRangePicker from "../FilterTimeRangePicker";
// import FilterDatePicker from "../FilterDatePicker";
import { useSelector } from 'react-redux';  
import { fetchLocationsData } from "../../api/Location/locationReducer"; 
import {fetchBuildings} from "../../api/Building/buildingApi"
import {fetchFloors} from "../../api/Floor/floorApis"
import { getRoomsList } from "../../api/Rooms/roomApis";
export default function ManageBooking({filterdata}) {
  const [showfilter, setShowfilter] = React.useState(false); 
  const [isFilter, setIsFilter] = useState(false);  
  const [isActiveAdd, setIsActiveAdd] = useState(true); 
  const [keyChange, setKeyChange] = useState("");  
  const [floorData, setFloorData] = useState([]);
  const [buildingData, setBuildingData] = useState([]); 
  const [roomData, setRoomData] = useState([]); 
  const locationData = useSelector((state) => state?.locations); 
  const [createData, setCreateData] = useState({});
  const handleFilter = () => { 
    let queryparameter="";
    if(createData.location_id!=undefined){
       let locationId = createData.location_id.map((l) => l);
        queryparameter+=`&location_id=${locationId}`
    }
    if(createData.building_id!=undefined){
       let building_id = createData.building_id.map((l) => l);
        queryparameter+=`&building_id=${building_id}`
    }
    if(createData.floor_id!=undefined){
      let floor_id = createData.floor_id.map((l) => l);
       queryparameter+=`&floor_id=${floor_id}`
   }
   if(createData.room_id!=undefined){
    let room_id = createData.room_id.map((l) => l);
     queryparameter+=`&room_id=${room_id}`
 }
  if(createData.startdate!=undefined){  
    queryparameter+=`&startdate=${createData.startdate}`
  }
  if(createData.enddate!=undefined){ 
    queryparameter+=`&enddate=${createData.enddate}`
  } 
  filterdata(queryparameter.substring(1))
    setIsFilter(!isFilter);
  };
  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };
  const UserData = useSelector((state) => state.users);
  const dispatch = useDispatch(); 
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.ubuilding_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };
  const getOptionLabelWithIdFloor = (option) => {
    if (option?.floor_id) {
      return `${option.ufloor_id} - ${option.floor_name}`;
    } else {
      return option?.floor_name;
    }
  };
  const getOptionLabelWithIdRoom = (option) => {
    if (option?.room_id) {
      return `${option.uroom_id} - ${option.room_name}`;
    } else {
      return option?.room_name;
    }
  };

  useEffect(() => { 
    dispatch(fetchLocationsData()); 
  }, [dispatch]);
  
  const columns = [  
    {
    field: "location_name",
    headerName: "Location",
    flex: 1,
    width: 200,
    minWidth: 200,
    headerClassName: "super-app-theme--header",
    renderCell: (params) => {
      const locationName = locationData?.crbt_locations?.location_name || "";
      return locationName;
    },
  },
    {
      field: "building_name",
      headerName: "Building Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const buildingName = buildingData?.crbt_buildings?.building_name || "";
        return buildingName;
      },
    },
    {
      field: "floor_name",
      headerName: "Floor Name",
      flex: 1,
      width: 120,
      minWidth: 120,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const floorName = floorData?.crbt_floors?.floor_name || "";
        return floorName;
      },
    },
    {
      field: "room_name",
      headerName: "Room Name",
      flex: 1,
      width: 150,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const roomName = roomData?.crbt_rooms?.room_name || "";
        return roomName;
      },
    },
    {
      field: "amenities",
      headerName: "Amenities",
      flex: 1,
      width: 150,
      minWidth: 160,
      overflowX: "scroll !important",
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        return (
          <div
            style={{
              display: "inline-flex",
              height: "60px",
              overflowX: params.value.length > 7 ? "scroll" : "hidden",
            }}
          >
            {params.value.map((amenity) => (
              <Tooltip
                title={` ${amenity.amenityname}`}
                placement="top"
                key={amenity.amenityid} // Using a unique and stable key
              >
                <img
                  src={`${process.env.REACT_APP_BASE_URL}/amenities/thumbnail?amenityid=${amenity.amenityid}&thumbnail_key=${amenity.thumbnail_key}`}
                  alt={amenity.amenityid}
                  style={{
                    flex: "0 0 auto",
                    width: "20px",
                    padding: "0",
                    objectFit: "contain",
                  }}
                />
              </Tooltip>
            ))}
          </div>
        );
      },
    },

    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 80,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return <span>{status}</span>;
      },
    },
  ]

  let fetchBuildingData=async (v)=>{ 
    setBuildingData([])
    setFloorData([])
    setRoomData([])
    if(v.length!=0){
      let rlt=await fetchBuildings(v) 
      if(rlt.status){
        setBuildingData({buildings:rlt}) 
      } 
    } 
  }
  let fetchFloorData=async (v)=>{ 
    setFloorData([])
    setRoomData([])
    if(v.length!=0){
      let rlt=await fetchFloors(v)  
       setFloorData({floors:rlt}) 
    } 
  } 
  let fetchRoomData=async (v)=>{  
    setRoomData([])
    if(v.length!=0){
      let rlt=await getRoomsList(v)  
       setRoomData({rooms:rlt}) 
    } 
  }
  const DateFilter = (name,value) => { 
    setCreateData((prevData) => ({ 
      ...prevData,
      [name]: value,
    }));
  }
  const handleChangeFilter = (e, v, name) => { 
    let value =[];
   if(name=="location_id"){  
      fetchBuildingData(v)  
      value = v.map((a) => a.location_id);
    } 
    if(name=="building_id"){
      fetchFloorData(v); 
      value = v.map((a) => a.building_id);
    }
    if(name=="floor_id"){
      fetchRoomData(v); 
      value = v.map((a) => a.floor_id);
    }
    if(name=="room_id"){ 
      if(v.length!=0){
        value = v.map((a) => a.room_id);
      }      
    }
    if (Array.isArray(v)) { 
      setCreateData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    <>
      {!showfilter && (
        <Box>
          <Typography
            variant="h4"
            sx={{ fontWeight: "600", marginBottom: "20px" }}
          >
            Manage Booking
          </Typography>
          <Accordion
            sx={{
              backgroundColor: "#3E0BA1",
              color: "#fff",
              margin: "0 0 15px !important",
              borderRadius: "0 !important",
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
              aria-controls="panel1a-content"
              id="panel1a-header"
              sx={{
                minHeight: "48px !important",
                "& .Mui-expanded": {
                  margin: "12px 0 !important",
                },
              }}
            >
              <Typography>
                <FilterAltIcon /> Filter
              </Typography>
            </AccordionSummary>
            <AccordionDetails
              sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
            >
              <Box>
                <Grid container spacing={1}>
                  <Grid item xs={12} sm={12} md={12} lg={12}>
                    <Grid container spacing={1}>
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="location_name"
                          onChange={(e, v) =>
                            handleChangeFilter(e, v, "location_id")
                          }
                          key={keyChange}
                          options={locationData?.locations?.location ?? []}
                          getOptionLabel={(option) =>
                            getOptionLabelWithIdLocation(option)
                          }
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Location Id-Name"
                              placeholder="Location Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                                ...labelClassess.label,
                              }}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="building_name"
                          onChange={(e, v) =>
                            handleChangeFilter(e, v, "building_id")
                          }
                          key={keyChange}
                          options={buildingData?.buildings?.BuildingsData || []}
                          getOptionLabel={(option) =>
                            getOptionLabelWithIdBuilding(option)
                          }
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Building Id-Name"
                              placeholder="Building Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                                ...labelClassess.label,
                              }}
                            />
                          )}
                        />
                      </Grid>

                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                              padding: "8px",
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="floor_name"
                          onChange={(e, v) => handleChangeFilter(e, v, "floor_id")}
                          key={keyChange}
                          options={floorData?.floors?.floorsData || []}
                          getOptionLabel={(option) => getOptionLabelWithIdFloor(option)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Floor Id-Name"
                              placeholder="Floor Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                              }}
                            />
                          )}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={4} lg={2}>
                        <Autocomplete
                          multiple
                          size="small"
                          sx={{
                            fieldset: {
                              borderColor: "#3E0BA1 !important",
                              borderRadius: 0,
                              padding: "8px",
                            },
                            marginBottom: "10px",
                          }}
                          id="checkboxes-tags-demo"
                          name="room_name"
                          onInputChange={(e, v) => handleChangeFilter(e, v, "room_id")}
                          key={keyChange}
                          options={roomData?.rooms?.roomData || []}
                          getOptionLabel={(option) => getOptionLabelWithIdRoom(option)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Room Id-Name"
                              placeholder="Room Id-Name"
                              InputLabelProps={{
                                ...params.InputLabelProps,
                              }}
                            />
                          )}
                        />
                      </Grid>                                       
                      <Grid item xs={12} sm={12} md={8} lg={4}>
                      <DateRangePickerValue DateFilter={DateFilter}/>
                    </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                
                <Grid container justifyContent="flex-end">
                  <Grid item xs={12} sm={6} md={3} lg={3}>
                    <Button
                      fullWidth
                      variant="contained"
                      onClick={handleFilter}
                      sx={{
                        padding: "10px 0",
                        backgroundColor: "#3E0BA1 !important",
                        borderRadius: 0,
                        fontSize: "0.875rem !important",
                        lineHeight: "1.125rem",
                        letterSpacing: 0,
                        width: "fitcontent",
                        paddingLeft: "60px",
                        paddingRight: "60px",
                      }}
                      startIcon={<SearchIcon />}
                    >
                      Search
                    </Button>
                  </Grid>
                </Grid>
              </Box>
            </AccordionDetails>
          </Accordion>
        </Box>
      )}
    </>
  );
}
