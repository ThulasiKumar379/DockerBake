import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  TableBody,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  TableCell,
  tableCellClasses,
} from "@mui/material";

import { visuallyHidden } from "@mui/utils";
import {
  alpha,
  Box,
  Table,
  Button,
  styled,
  Paper,
  Tooltip,
  Typography,
  Toolbar,
  IconButton,
} from "@mui/material/styles";
import {
  Delete as DeleteIcon,
  FilterList as FilterListIcon,
} from "@mui/icons-material";

// const data = [
//   {
//     value: 1,
//     icon: (
//       <Tooltip title="coffee">
//         <CoffeeIcon />
//       </Tooltip>
//     ),
//   },
//   {
//     value: 2,
//     icon: (
//       <Tooltip title="Projector">
//         <ComputerIcon />
//       </Tooltip>
//     ),
//   },

//   {
//     value: 3,

//     icon: (
//       <Tooltip title="Book">
//         <BookIcon />
//       </Tooltip>
//     ),
//   },
// ];
const YourComponent = () => {
  return (
    <div style={{ display: "fluid" }}>
      {data.map((item) => (
        <div key={item.value} style={{ marginRight: "10px" }}>
          {item.icon}
        </div>
      ))}
    </div>
  );
};

//   const data = [
//     {
//       value: 1,
//       icon: <CoffeeIcon />,
//       title: "Coffee",
//     },
//     {
//       value: 2,
//       icon: <ComputerIcon />,
//       title: "Projector",
//     },
//     {
//       value: 3,
//       icon: (
//         <img
//           src="https://th.bing.com/th?id=OIP.cy85Fffo6Ra_8VBK4nGaUAHaHY&w=250&h=249&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2"
//           alt="White Board"
//           width="20px"
//         />
//       ),
//       title: "White Board",
//     },
//     {
//       value: 4,
//       icon: (
//         <img
//           src="https://th.bing.com/th?id=OIP.kmupAxyuYipKQoA3CMENCgHaHZ&w=250&h=249&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2"
//           alt="Water Bottle"
//           width="20px"
//         />
//       ),
//       title: "Water Bottle",
//     },
//   ];

//   const YourComponent = () => {
//   return (
//     <div style={{ display: "flex" }}>
//       {data.map((item) => (
//         <Card key={item.value} style={{ marginRight: "10px" }}>
//           <CardContent>
//             {item.icon}
//             <Typography variant="body2" component="p">
//               {item.title}
//             </Typography>
//           </CardContent>
//         </Card>
//       ))}
//     </div>
//   );
// }

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "dodgerBlue",
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));


const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));
function createData(
  Location,
  Building,
  Floor,
  Room,
  Title,
  Date,
  Time,
  Organizer,
  Action
) {
  return {
    Location,
    Building,
    Floor,
    Room,
    Title,
    Date,
    Time,
    Organizer,
    Action,
  };
}

const rows = [
  createData(
    "Bangalore",
    "Building 1",
    "Floor 1",
    "Room 1",
    "Title 1",
    "01-06-2023",
    "10:00-11:00",
    "Megna",
    "xx"
  ),
  createData(
    "Hyderabad",
    "Building 2",
    "Floor 2",
    "Room 1",
    "Title 2",
    "02-06-2023",
    "10:00-11:00",
    "Monika",
    "yy"
  ),
  createData(
    "Chennai",
    "Building 3",
    "Floor 3",
    "Room 1",
    "Title 3",
    "03-06-2023",
    "10:00-11:00",
    "Asrita",
    "yy"
  ),
  createData(
    "Tirupathi",
    "Building 4",
    "Floor 4",
    "Room 1",
    "Title 4",
    "04-06-2023",
    "10:00-11:00",
    "Satvika",
    "yy"
  ),
];

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// Since 2020 all major browsers ensure sort stability with Array.prototype.sort().
// stableSort() brings sort stability to non-modern browsers (notably IE11). If you
// only support modern browsers you can replace stableSort(exampleArray, exampleComparator)
// with exampleArray.slice().sort(exampleComparator)
function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

const headCells = [
  {
    id: "name",
    numeric: false,
    disablePadding: true,
    label: "Location",
  },
  {
    id: "calories",
    numeric: false,
    disablePadding: true,
    label: "Building",
  },
  {
    id: "fat",
    numeric: false,
    disablePadding: true,
    label: "Floor",
  },
  {
    id: "carbs",
    numeric: false,
    disablePadding: true,
    label: "Rooms",
  },
  {
    id: "protein",
    numeric: false,
    disablePadding: true,
    label: "Title",
  },
  {
    id: "protein",
    numeric: false,
    disablePadding: true,
    label: "Date",
  },
  {
    id: "protein",
    numeric: false,
    disablePadding: true,
    label: "Time",
  },
  {
    id: "protein",
    numeric: false,
    disablePadding: true,
    label: "Organizer",
  },
  {
    id: "calories",
    numeric: false,
    disablePadding: true,
    label: "Amenities",
  },
  {
    id: "protein",
    numeric: false,
    disablePadding: true,
    label: "Action",
  },
];

function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <StyledTableRow sx={{ height: "60px" }}></StyledTableRow>
      <StyledTableRow>
        {headCells.map((headCell) => (
          <StyledTableCell
            key={headCell.id}
            align="center"
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </StyledTableCell>
        ))}
      </StyledTableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(["asc", "desc"]).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

function EnhancedTableToolbar(props) {
  const { numSelected } = props;

  return (
    <Toolbar
      sx={{
        pl: { sm: 2 },
        pr: { xs: 1, sm: 1 },
        ...(numSelected > 0 && {
          bgcolor: (theme) =>
            alpha(
              theme.palette.primary.main,
              theme.palette.action.activatedOpacity
            ),
        }),
      }}
    >
      {numSelected > 0 ? (
        <Typography
          sx={{ flex: "1 1 100%" }}
          color="inherit"
          variant="subtitle1"
          component="div"
        >
          {numSelected} selected
        </Typography>
      ) : (
        <Typography
          sx={{ flex: "1 1 100%" }}
          variant="h6"
          id="tableTitle"
          component="div"
        >
          Manage Booking
        </Typography>
      )}
      <div>
        <Button variant="contained">Export</Button>
      </div>

      {numSelected > 0 ? (
        <Tooltip title="Delete">
          <IconButton>
            <DeleteIcon />
          </IconButton>
        </Tooltip>
      ) : (
        <Tooltip title="Filter list">
          <IconButton>
            <FilterListIcon />
          </IconButton>
        </Tooltip>
      )}
    </Toolbar>
  );
}

EnhancedTableToolbar.propTypes = {
  numSelected: PropTypes.number.isRequired,
};

export default function ManageBookingTable() {
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [dense, setDense] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [selectedAmenity, setSelectedAmenity] = useState(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const [anchorEl, setAnchorEl] = React.useState(null);
  const [selectedOption, setSelectedOption] = useState(data[0]); // handle onChange event of the dropdown
  const handleChange = (e) => {
    setSelectedOption(e);
  };
  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelected = rows.map((n) => n.name);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleChangeDense = (event) => {
    setDense(event.target.checked);
  };

  const isSelected = (name) => selected.indexOf(name) !== -1;

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const visibleRows = React.useMemo(
    () =>
      stableSort(rows, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage
      ),
    [order, orderBy, page, rowsPerPage]
  );

  return (
    <Box
      sx={{
        width: "100%",
        marginTop: "5%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <Paper sx={{ width: "100%", mb: 2 }}>
        <EnhancedTableToolbar numSelected={selected.length} />
        <TableContainer sx={{ maxHeight: "750px" }}>
          <Table
            sx={{ minWidth: 750 }}
            aria-labelledby="tableTitle"
            size={dense ? "small" : "medium"}
          >
            <EnhancedTableHead
              numSelected={selected.length}
              order={order}
              orderBy={orderBy}
              onSelectAllClick={handleSelectAllClick}
              onRequestSort={handleRequestSort}
              rowCount={rows.length}
            />
            <TableBody>
              {visibleRows.map((row, index) => {
                const isItemSelected = isSelected(row.name);
                const labelId = `enhanced-table-checkbox-${index}`;

                return (
                  <StyledTableRow
                    hover
                    onClick={(event) => handleClick(event, row.name)}
                    role="checkbox"
                    aria-checked={isItemSelected}
                    tabIndex={-1}
                    key={row.name}
                    selected={isItemSelected}
                    sx={{ cursor: "pointer", height: "50px" }}
                  >
                    <StyledTableCell
                      component="th"
                      id={labelId}
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {row.Location}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {row.Building}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {" "}
                      {row.Floor}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {row.Room}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {row.Title}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {row.Date}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      {row.Time}
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      <Tooltip title="meghanamuppal34@gmail.com" arrow>
                        <Button>Meghana</Button>
                      </Tooltip>
                    </StyledTableCell>

                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      <div>
                        <Button>
                          <Select
                            placeholder=""
                            value={selectedOption}
                            options={data}
                            onChange={handleChange}
                            sx={{ width: "100%" }}
                            getOptionLabel={(e) => (
                              <div style={{ alignItems: "center" }}>
                                {e.icon}

                                <span style={{ marginLeft: 10 }}>{e.text}</span>
                              </div>
                            )}
                          />
                        </Button>

                        {selectedOption && (
                          <div
                            style={{ lineHeight: "150px", width: "20%" }}
                          ></div>
                        )}
                      </div>
                    </StyledTableCell>
                    <StyledTableCell
                      scope="row"
                      padding="none"
                      sx={{ textAlign: "center" }}
                    >
                      <Button
                        variant="contained"
                        sx={{ backgroundColor: "red" }}
                        size="small"
                      >
                        Cancel
                      </Button>
                    </StyledTableCell>
                  </StyledTableRow>
                );
              })}
              {emptyRows > 0 && (
                <TableRow
                  style={{
                    height: (dense ? 33 : 53) * emptyRows,
                  }}
                >
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
    </Box>
  );
}
