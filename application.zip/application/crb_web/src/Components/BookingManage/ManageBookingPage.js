import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ManagebookingTable } from "./Managetable";
import ManageBooking from "./Form";
import { getManageBookingAPI } from "../../api/BookingManage/bookingManageApi"; 
const ManageBookingPage = () => {
  const dispatch = useDispatch();
  const [queryParams, setQueryParams] = useState('');
  const [reRander, setReRander] = useState(true);
  
  const [tableData, setTableData] = useState([]);
  const [manageData, setManageData] = useState([]); 
  let filterdata=(params)=>{
    setQueryParams(params); 
    setReRander(!reRander);
  }
  const fetchData = async () => {
    try {
      let data = await getManageBookingAPI(queryParams);
      if(data.status){
        setManageData(data.results);
      } else {
        setManageData([]);
      } 
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => { 
    fetchData();
  }, [reRander]);  
  useEffect(() => {
    if (manageData?.length > 0) {
      console.log(manageData)
      const tableData = manageData.map((data) => {
        const {
          crbt_locations_location_name,
          crbt_buildings_building_name,
          crbt_floors_floor_name,
          crbt_rooms_room_name,
          title_of_meeting,
          booking_date,
          start_endtime,
          crbt_users_first_name,
          crbt_users_email,
          crbt_users_mobile_number,
          amenities_data,
          booking_id,
          booking_status,
          bookingStatus_status
        } = data;
        const constructData = {
          crbt_locations_location_name,
          crbt_buildings_building_name,
          crbt_floors_floor_name,
          crbt_rooms_room_name,
          title_of_meeting,
          booking_date,
          start_endtime,
          crbt_users_first_name,
          crbt_users_email,
          crbt_users_mobile_number,
          amenities_data,
          booking_id,
          booking_status,
          bookingStatus_status
        };
        return constructData;
      });
      setTableData(tableData);
    }else{
      setTableData([]);
    }
  }, [manageData,reRander]);
  return (
    <div style={{ marginTop: "1%" }}>
      <ManageBooking filterdata={filterdata}/>
      <ManagebookingTable tableData={tableData} fetchData={fetchData}/>
    </div>
  );
};
export default ManageBookingPage;
