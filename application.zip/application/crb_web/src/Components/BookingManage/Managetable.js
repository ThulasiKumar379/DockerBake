import React, { useEffect, useState } from "react";
import Table from "../Table";
import {
Button,
  Grid,
  Box,
  Dialog,
  Tooltip,
  DialogTitle,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";  
import EditNote from "@mui/icons-material/EditNote";
import  {ThumbUp, ThumbDown } from '@mui/icons-material'
import CancelIcon from "@mui/icons-material/Cancel";
import { CancelBookingAPI,ChangeBookingStatusAPI } from "../../api/BookingManage/bookingManageApi";
export const ManagebookingTable = ({tableData, fetchData}) => {
  const [opendelete, setOpenDelete] = React.useState(false); 
  const [cancelBookingID, setCancelBookingID] = useState(true);
  const handleEditButton = (rowData) => {

  };
  const handleApproveButton =async (booking_id) => {
      const responseWithApproveStatus = {
          ...booking_id, 
          approveStatus: 2
      }
     await ChangeBookingStatusAPI(responseWithApproveStatus);
      fetchData(); 
  };
  const handleRejectButton =async (booking_id) => {
      const responseWithApproveStatus = {
         ...booking_id, 
        approveStatus: 3
    }
    await ChangeBookingStatusAPI(responseWithApproveStatus)
    fetchData(); 
  };
  const handleClickOpen = (booking_id) => {
    setCancelBookingID(booking_id)
    setOpenDelete(true);
  };
  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const handleCancelBooking =async () => {
  await  CancelBookingAPI(cancelBookingID)
    fetchData(); 
    setOpenDelete(false);
  };
  const handleClose = () => {
    setOpenDelete(false);
  };
  
  const columns = [
    {
      field: "crbt_locations_location_name",
      headerName: "Location",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "crbt_buildings_building_name",
      headerName: "Building",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "crbt_floors_floor_name",
      headerName: "Floor",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "crbt_rooms_room_name",
      headerName: "Room",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "title_of_meeting",
      headerName: "Title",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "booking_date",
      headerName: "Date",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "start_endtime",
      headerName: "Time",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "crbt_users_first_name",
      headerName: "Organiser",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
      renderCell: (params) => {
        return (
          <Tooltip
            title={
              <span>
                {params.row.crbt_users_email}
                <br />
                {params.row.crbt_users_mobile_number}
              </span>
            }
            arrow
          >
            <Button>{params.row.crbt_users_first_name}</Button>
          </Tooltip>
        );
      },
    },
    {
      field: "bookingStatus_status",
      headerName: "Status",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
      // renderCell: (params) => {
      //   let status;
      //   switch(params.value) {
      //     case 1:
      //       status = 'Requested';
      //       break;
      //     case 2:
      //       status = 'Approved';
      //       break;
      //     case 3:
      //       status = 'Rejected';
      //       break;
      //     case 4:
      //       status = 'Cancelled';
      //       break;
      //     default:
      //       status = '';
      //   }
      //   return (
      //     <span>{status}</span>
      //   );
      // },
    },
    {
      field: "amenities",
      headerName: "Amenities",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
      renderCell: (params) => {
        return (
          <div
            style={{
              display: "inline-flex",
              height: "60px",
              overflowX:
                params.row.amenities_data.length > 7 ? "scroll" : "hidden",
            }}
          >
            {params.row.amenities_data?.map((amenity) => (
              <Tooltip
                title={` ${amenity.amenityname}`}
                placement="top"
                key={amenity.amenityid} // Using a unique and stable key
              >
                <img
                  src={`${process.env.REACT_APP_BASE_URL}/amenities/thumbnail?amenityid=${amenity.amenityid}&thumbnail_key=${amenity.amenityname}`}
                  alt={amenity.amenityname}
                  style={{
                    flex: "0 0 auto",
                    width: "20px",
                    padding: "0",
                    objectFit: "contain",
                  }}
                />
              </Tooltip>
            ))}
          </div>
        );
      },
    },
    {
      field: "Actions",
      headerName: "Actions",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        const isBookingCanceled = currentRow.booking_status === 4;
        const isBookingRejected = currentRow.booking_status === 3;
        const isBookingApproved = currentRow.booking_status === 2;

        return (
          <Box display="flex" alignItems="center" sx={{ overflowX: "auto" }}>
            <Tooltip title="Edit Booking">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                onClick={() => handleEditButton(currentRow)}
                disabled={isBookingCanceled||isBookingRejected||isBookingApproved}
              >
                <EditNote />
              </Button>
            </Tooltip>
            <Tooltip title="Approve Booking">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                onClick={() => handleApproveButton(currentRow)}
                disabled={isBookingCanceled||isBookingRejected||isBookingApproved}
              >
                <ThumbUp style={{ color: 'green' }}/>
              </Button>
            </Tooltip>
            <Tooltip title="Reject Booking">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                onClick={() => handleRejectButton(currentRow)}
                disabled={isBookingCanceled||isBookingApproved||isBookingRejected}
              >
                <ThumbDown style={{ color: 'red' }}/>
              </Button>
            </Tooltip>
           
           <Tooltip title="Cancel Booking">
              <Button
                variant="text"
                color="error"
                size="small"
                onClick={() => handleClickOpen(currentRow)}
                disabled={isBookingCanceled||isBookingRejected}
                sx={{ minWidth: "32px" }}
              >
                  <CancelIcon  />
              </Button>
            </Tooltip>
          </Box>
        );
      },
    },
  ]; 

  return (
    <>
      <Dialog
        open={opendelete}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
                    <div style={{ textAlign: "right" }}>
                      </div>
          <DialogTitle sx={{ paddingRight: "-15px" }}>
            Cancel Booking
          </DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleClose} sx={{ color: "black" }}>
              X
            </Button>
          </div>
        </div>
        {"Are you sure, you want to cancel the booking ?"}
        <DialogActions style={{ justifyContent: 'center' }}>
          <Button onClick={handleCancelBooking} className="bookingbtn">
            Yes
          </Button>
          <Button onClick={handleClose} className="bookingbtn1">
            No
          </Button>
        </DialogActions>
      </Dialog>
      <div style={{ marginTop: "2%" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-evenly",
            marginBottom: "20px",
            marginTop: "20px",
            marginLeft: "revert",
          }}
        >
          <Box sx={{ flexGrow: 1 }}>
            <Grid container spacing={2}>
              <Grid
                item
                xs={12}
                sm={6}
                sx={{
                  display: "flex",
                  justifyContent: "space-evenly",
                  marginLeft: "auto",
                }}
              ></Grid>
            </Grid>
          </Box>
        </div>
        <Table data={tableData} columns={columns} id="booking_id" />
      </div>
    </>
  );
};
