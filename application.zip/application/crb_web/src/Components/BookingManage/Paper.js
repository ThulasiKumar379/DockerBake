import React from "react";
import { Paper,Typography } from "@mui/material";
export const NewPaper= () =>{
  return (
    <>
      <Paper>
        <div>
          <Typography variant="h4">Manage Booking</Typography>
          
        </div>
      </Paper>
    </>
  );
}