import { DateRangePicker } from "rsuite";
import "./dateRange.css";
import { Box } from "@mui/material";

const FilterTimeRangePicker = () => (
  <Box>
    <DateRangePicker
      style={{ display: "block", marginBottom: "10px" }}
      placeholder="Time Range"
      size="lg"
      format="HH:mm:ss"
      ranges={[]}
      defaultCalendarValue={[new Date(), new Date()]}
    />
  </Box>
);

export default FilterTimeRangePicker;
