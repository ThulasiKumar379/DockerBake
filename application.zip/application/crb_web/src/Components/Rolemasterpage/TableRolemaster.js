import React, { useState, useEffect, useRef } from "react";
import Table from "../Table";
import { useSelector, useDispatch } from "react-redux";
import {
  Button,
  Grid,
  Box,
  TextField,
  Dialog,
  DialogContent,
  Tooltip,
  DialogTitle,
  DialogActions,
  FormControlLabel,
  DialogContentText,
} from "@mui/material";
import { Switch } from "@mui/material";
import { checkUserAccess } from "../../CheckUserAccess";
import {
  getRolesData,
  updateRoleData,
  deleteRoleData,
} from "../../api/Rolemaster/RoleReducer";
import { styled } from "@mui/system";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  DoNotDisturbOn as DoNotDisturbOnIcon,
  EditNote, AddCircle as AddCircleIcon
} from "@mui/icons-material";
import RMasterpage from "./Masterpage";

const IOSSwitch = styled((props) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 55,
  height: 25,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(30px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 21,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#ffff",
      border: "6px solid #fff",
    },
    "&.Mui-disabled .MuiSwitch-thumb": {},
    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 21,
    height: 21,
  },
  "& .MuiSwitch-track": {
    borderRadius: 34 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
  },
}));
export const TableRolemaster = () => {
  const [openedit, setOpenEdit] = React.useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [deleteRoleId, setDeleteRoleId] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});
  const [tableData, setTableData] = useState([]);
  const [roleIdSearch, setRoleIdSearch] = useState("");
  const [roleNameSearch, setRoleNameSearch] = useState("");
  const [filteroptions, setFilterOption] = useState(false);
  const [, setIsActive] = useState(false);
  const [currentRow, setCurrentRow] = useState(null);
  const roleRef = useRef(null);

  const dispatch = useDispatch();

  const RoleData = useSelector((state) => state.roles);
  const { roles } = RoleData;
  const rolesData = roles?.data;
  const FilteredData = (role_id, role_name) => {
    const filteredRoles = rolesData.filter(
      (role) =>
        role.role_id.toString().includes(role_id) &&
        role.role_name.toLowerCase().includes(role_name.toLowerCase())
    );
    return filteredRoles;
  };

  const hasAccessToEdit = checkUserAccess("edit_role")
  const hasAccessToDelete = checkUserAccess("delete_role")
  useEffect(() => {
    dispatch(getRolesData());
  }, [dispatch]);

  useEffect(() => {
    if (rolesData?.length > 0) {
      const newData = rolesData.map((d) => {
        const { role_id, role_name, status, created_at, updated_at } = d;
        const constructData = {
          role_id,
          role_name,
          status: status ? "Active" : "Inactive",
          created_at,
          updated_at,
        };
        return constructData;
      });
      setTableData(newData);
    }
  }, [rolesData]);

  useEffect(() => {
    if (roleIdSearch === "" && roleNameSearch === "" && filteroptions) {
      dispatch(getRolesData());
    }
  }, [roleIdSearch, roleNameSearch, dispatch, filteroptions]);
  const filterIdHandler = (e) => {
    const value = e.target.value;
    setRoleIdSearch(value);

    if (value === "" && roleNameSearch !== "") {
      setTableData(FilteredData(value, roleNameSearch));
    } else {
      setTableData(FilteredData(value, roleNameSearch, true));
    }
    setFilterOption(true);
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const filterNameHandler = (e) => {
    const value = e.target.value;
    setRoleNameSearch(value);

    if (value === "" && roleIdSearch !== "") {
      setTableData(FilteredData(roleIdSearch, value));
    } else {
      setTableData(FilteredData(roleIdSearch, value, true));
    }
    setFilterOption(true);
  };

  const handleSearchClick = (roleIdSearch, roleNameSearch) => {
    if (roleIdSearch === "" && roleNameSearch === "") {
      setFilterOption(true);
    } else {
      setTableData(FilteredData(roleIdSearch, roleNameSearch));
    }
  };
  const handleClickOpen = (roleId) => {
    setDeleteRoleId(roleId);
    setCurrentRow(currentRow);
    setOpenDelete(true);
  };

  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const handleClickEdit = (currentRow) => {
    setRowData(currentRow);
    setOpenEdit(true);
  };
  const handleCloseedit = () => {
    setOpenEdit(false);
    setIsActive(false);
    resetEditState();
  };
  const resetEditState = () => {
    setValidationErrors(false);
    setRowData(null);
  };
  const [rowData, setRowData] = useState(null);

  const handleEdit = (e) => {
    const { name, value } = e.target;
    setValidationErrors((prevState) => ({ ...prevState, [name]: "" }));
    setRowData({
      ...rowData,
      [name]: value,
    });
  };
  const validateForm = () => {
    const errors = {};
    if (!rowData.role_name || rowData.role_name.trim() === "") {
      errors.role_name = "Role Name can't be empty";
      roleRef.current.focus()
    }
    return errors;
  };

  const handleEditUpdate = () => {
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }
    dispatch(updateRoleData(rowData))
      .then((data) => {
        if (data.payload.status) {
          setTimeout(() => {
            toast.success("Role updated successfully");
          }, 500);
          dispatch(getRolesData());
          setIsActive(false);
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update Role");
        }, 500);
      });

    setOpenEdit(false);
  };
  const onDelete = async (currentRow) => {
    const payload = {
      role_id: currentRow.role_id.toString(),
      isactive: !currentRow.status ? 1 : 0,
    };

    await dispatch(deleteRoleData(payload))
      .then((data) => {
        if (data.payload.status) {
          setTimeout(() => {
            toast.success(
              `Role ${currentRow.status ? "Deactivated" : "Activated"
              } successfully`
            );
          }, 500);
          dispatch(getRolesData());
        } else {
          setTimeout(() => {
            toast.error(data.message);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error(
            `Failed to ${currentRow.status ? "Deactivate" : "Activate"} Role`
          );
        }, 500);
      });
  };


  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const handleDeleteConfirmation = () => {
    setOpenDelete(false);
    if (deleteRoleId) {
      onDelete(deleteRoleId);
    }
  };
  const getIsInactive = (row) => row.status === "Inactive";
  const columns = [
    {
      field: "role_id",
      headerName: "ID",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "role_name",
      headerName: "Role Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "created_at",
      headerName: "Created Date",
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      flex: 1,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "updated_at",
      headerClassName: "super-app-theme--header",
      headerName: "Last Updated Date",
      sortable: false,
      flex: 1,
      width: 200,
      minWidth: 200,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "status",
      headerName: "Status",
      sortable: false,
      headerClassName: "super-app-theme--header",
      flex: 1,
      width: 100,
      minWidth: 100,
      renderCell: (params) => {
        const currentRow = params.row;;
        const isInactive = currentRow.status === "Inactive";
      },
    },
    {
      field: "Operations",
      headerName: "Operations",
      headerClassName: "super-app-theme--header",
      sortable: false,
      flex: 1,
      width: 150,
      minWidth: 150,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        const isInactive = getIsInactive(currentRow);
        return (
          <Box display="flex" alignItems="center" sx={{ overflowX: "auto" }}>
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleClickEdit(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title={isInactive ? "Activate" : "Deactivate"}>
                <Button
                  variant="text"
                  color="error"
                  size="small"
                  onClick={() => handleClickOpen(currentRow)}
                  sx={{ minWidth: "32px" }}
                  disabled={isInactive}
                >
                  {isInactive ? (
                    <DoNotDisturbOnIcon color="error" />
                  ) : (
                    <DoNotDisturbOnIcon color="error" />
                  )}
                </Button>
              </Tooltip>
            )}
          </Box>
        );
      },
    },
  ];
  return (
    <>
      <Dialog open={openedit} fullWidth maxWidth="sm">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle>Edit Role</DialogTitle>
          <Button onClick={handleCloseedit}>X</Button>
        </div>

        <DialogContent>
          <Grid container spacing={1}>
            {/* <Grid item xs={12} sm={6} marginTop={2}>
              <TextField
                fullWidth
                autoFocus
                id="role_id"
                name="role_id"
                label="roleid"
                size="small"
                value={rowData && rowData.role_id}
                onChange={(e) => handleEdit(e)}
                InputProps={{
                  readOnly: true,
                }}
              />
            </Grid> */}
            <Grid item xs={12} sm={6} marginTop={2}>
              <TextField
                fullWidth
                id="role_name"
                name="role_name"
                label={
                  <div>
                    Role Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                inputRef={roleRef}
                value={rowData && rowData.role_name}
                onChange={(e) => handleEdit(e)}
                error={Boolean(validationErrors.role_name) || (rowData && rowData.role_name && (rowData.role_name.length < 2 || rowData.role_name.length > 120))}
                helperText={
                  validationErrors.role_name
                    ? <span style={{ color: 'red' }}>{validationErrors.role_name}</span>
                    : ((rowData && rowData.role_name && rowData.role_name.length < 2)
                      ? <span style={{ color: 'red' }}>Minimum 2 characters required.</span>
                      : (rowData && rowData.role_name && rowData.role_name.length > 120)
                        ? <span style={{ color: 'red' }}>Maximum 120 characters allowed.</span>
                        : "")
                }
              /> 
            </Grid>
            <Grid item xs={12} sm={12} className="text-right">
              <FormControlLabel
                control={
                  <IOSSwitch
                    checked={(rowData?.status == true || rowData?.status == 'Active') ? true : false}
                    onChange={handleToogleChange}
                  />
                }
                label={(rowData?.status == 'Active' || rowData?.status == true) ? "Active" : "Inactive"}
                sx={{ marginLeft: "0" }}
                labelPlacement="top"
              />
              <Button
                className="bookingbtn"
                sx={{
                  marginRight: "10px",
                  marginTop: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
                onClick={handleEditUpdate}
              >
                Save
              </Button>
              <Button
                className="bookingbtn1"
                onClick={handleCloseedit}
                sx={{
                  fontSize: "0.75rem",
                  marginTop: "10px",
                  textTransform: "capitalize",
                }}
              >
                Cancel
              </Button>
            </Grid>
            {/* </DialogActions> */}
          </Grid>
        </DialogContent>
      </Dialog>
      <Dialog open={opendelete} onClose={handleCloseDelete}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle>
            {currentRow?.isactive
              ? "Activate"
              : "Deactivate"}
          </DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleCloseDelete}>X</Button>
          </div>
        </div>
        <DialogContent>
          <DialogContentText>
            {currentRow?.isactive
              ? "Are you sure you want to activate this User?"
              : "Are you sure you want to Deactivate this User?"}
          </DialogContentText>
        </DialogContent>

        <DialogActions sx={{ paddingBottom: "15px" }}>
          <Button
            variant="contained"
            style={{
              marginRight: "10px",
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
            className="bookingbtn"
            onClick={handleDeleteConfirmation}
          >
            {currentRow?.isactive ? "Dctivate" : "Dectivate"}
          </Button>
          <Button
            variant="outlined"
            onClick={handleCloseDelete}
            className="bookingbtn1"
            sx={{ fontSize: "0.75rem", textTransform: "capitalize" }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      <div>
        <div style={{ marginBottom: "3%" }}>
          <RMasterpage
            roleIdSearch={roleIdSearch}
            roleNameSearch={roleNameSearch}
            onSearch={handleSearchClick}
            filterIdHandler={filterIdHandler}
            filterNameHandler={filterNameHandler}
          />
        </div>
        <Table data={tableData} columns={columns} id="role_id" />
      </div>
    </>
  );
};
