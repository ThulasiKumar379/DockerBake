import { TableRolemaster } from './TableRolemaster';
import RMasterpage from './Masterpage';
 export const Rolemaster=()=> {
    return (
      <>
        <div> 
          <TableRolemaster/>
        </div>
      </>
    );
  }
  