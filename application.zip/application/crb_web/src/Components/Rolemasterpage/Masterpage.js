import React, { useEffect, useState,useRef } from "react";
import {
  Box,
  Grid,
  TextField,
  Button,
  Typography,
  Dialog,
  DialogContent,
  DialogTitle,
  Switch,
  styled,
  FormControlLabel,
  AccordionDetails,
  AccordionSummary,
  Accordion,
} from "@mui/material";
import {
  Add as AddIcon,
  Search as SearchIcon,
  // FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { checkUserAccess } from "../../CheckUserAccess";
import {
  createRoleData,
  getRolesData,
} from "../../api/Rolemaster/RoleReducer";
import { Link, useNavigate, useLocation } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import { toast, ToastContainer } from "react-toastify";
const IOSSwitch = styled((props) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 55,
  height: 25,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(30px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 21,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#ffff",
      border: "6px solid #fff",
    },
    "&.Mui-disabled .MuiSwitch-thumb": {},
    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 21,
    height: 21,
  },
  "& .MuiSwitch-track": {
    borderRadius: 34 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
  },
}));
export default function RMasterpage({
  onSearch,
  filterIdHandler,
  filterNameHandler,
  roleIdSearch,
  roleNameSearch,
}) {
  const [openeadd, setOpenAdd] = React.useState(false);
  const [roleName, setRoleName] = useState("");
  const [roleId, setRoleId] = useState("");
  const [, setRoleData] = useState({});
  const [, setKeyChange] = useState("");
  const [errors, setErrors] = useState({});
  const [isActive, setIsActive] = useState(true);
  const roleRef = useRef(null);

  const validateInputs = () => {
    const newErrors = {};

    // if (!roleId || roleId.trim() === "") {
    //   newErrors.roleId = "Role Id is required";
    // }

    if (!roleName || roleName.trim() === "") {
      newErrors.roleName = "Role Name is required";
      roleRef.current.focus()
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSearch = () => {
    onSearch(roleIdSearch, roleNameSearch);
  };

  const handleClickadd = () => {
    setOpenAdd(true);
  };
  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const hasAccess = checkUserAccess("role_master")
  const hasAccessToCreate = checkUserAccess("add_role")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getRolesData());
  }, [dispatch]);

  const handleCloseadd = () => {
    setOpenAdd(false);
    setIsActive(true);
    setRoleName("");
    resetAddState();
  };
  const resetAddState = () => {
    setErrors(false);
    setRoleName(null);
    setRoleId(null);
  };
  const handleSave = async () => {
    const isValid = validateInputs();
    if (isValid) {
      const addDetails = {
        role_id: roleId,
        role_name: roleName,
        status: isActive,
      };
      await dispatch(createRoleData(addDetails))
        .then((data) => {
          if (data.payload.status) {
            setRoleData({});
            setKeyChange(Math.random());
            setTimeout(() => {
              toast.success("Role created successfully");
            }, 500);
            setIsActive(true);
            setRoleName("");
            setRoleId("");
            dispatch(getRolesData());
          } else {
            setTimeout(() => {
              toast.error(data.payload.errorMessage);
            }, 500)
          }
        })
        .catch((error) => {
          setTimeout(() => {
            toast.error("Failed to create Role");
          }, 500);
        });

      setOpenAdd(false);
    }
  };
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
  };

  return (
    <>
      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Dialog open={openeadd} fullWidth maxWidth="sm">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle>Add Role</DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleCloseadd}>X</Button>
          </div>
        </div>
        <DialogContent>
          <Grid container spacing={1}>
            {/* <Grid item xs={12} sm={6} sx={{ marginTop: "2%" }}>
              <TextField
                fullWidth
                label="Id"
                size="small"
                id="role_id"
                name="role_id"
                value={roleId}
                onChange={(e) => {
                  setRoleId(e.target.value);
                  setErrors((prevErrors) => ({ ...prevErrors, roleId: "" }));
                }}
                sx={{ marginBottom: "10px" }}
                error={!!errors.roleId}
                helperText={errors.roleId}
              />
            </Grid> */}
            <Grid item xs={12} sm={6} sx={{ marginTop: "2%" }}>
              <TextField
                fullWidth
                autoFocus
                label={
                  <div>
                    Role Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                id="role_name"
                name="role_name"
                value={roleName}
                inputRef={roleRef}
                onChange={(e) => {
                  setRoleName(e.target.value);
                  setErrors((prevErrors) => ({ ...prevErrors, roleName: "" }));
                }}
                error={!!errors.roleName || (roleName && (roleName.length < 2 || roleName.length > 120))}
                helperText={
                  errors.roleName
                    ? <span style={{ color: 'red' }}>{errors.roleName}</span>
                    : ((roleName && roleName.length < 2)
                      ? <span style={{ color: 'red' }}>Minimum 2 characters required.</span>
                      : (roleName && roleName.length > 120)
                        ? <span style={{ color: 'red' }}>Maximum 120 characters allowed.</span>
                        : "")
                }
                sx={{ marginBottom: "10px" }}
              />

            </Grid>

            <Grid item xs={12} sm={12} className="text-right">
              <FormControlLabel
                control={
                  <IOSSwitch checked={isActive} onChange={handleToogleChange} />
                }
                label={isActive ? "Active" : "Inactive"}
                sx={{ marginTop: "0" }}
                labelPlacement="top"
              />
              <Button
                className="bookingbtn"
                onClick={handleSave}
                sx={{
                  marginRight: "10px",
                  marginTop: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
              >
                Save
              </Button>
              <Button
                onClick={handleCloseadd}
                color="error"
                className="bookingbtn1"
                sx={{
                  fontSize: "0.75rem",
                  marginTop: "10px",
                  textTransform: "capitalize",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
      <Box mb={2}>
        <div>
          <Grid container spacing={1}>
            <Grid item xs={12} sm={8} md={9} lg={10}>
              <Typography
                Manage
                Roles
                variant="h4"
                sx={{ marginBottom: "20px", fontWeight: 600 }}
              >
                Roles Master
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4} md={3} lg={2} className="noPadding">
              {hasAccessToCreate.exists && (
                <Button
                  fullWidth
                  variant="contained"
                  onClick={handleClickadd}
                  sx={{
                    padding: "10px 0",
                    backgroundColor: "#0B78A1 !important",
                    borderRadius: 0,
                    fontSize: "0.75rem !important",
                    lineHeight: "1.125rem",
                    letterSpacing: 0,
                    marginBottom: "15px",
                  }}
                  startIcon={<AddIcon />}
                >
                  Add New Role
                </Button>
              )}
            </Grid>
          </Grid>
        </div>
      </Box>
      {/* <Accordion
        sx={{
          backgroundColor: "#3E0BA1",
          color: "#fff",
          margin: "0 0 15px !important",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          sx={{
            minHeight: "48px !important",
            "& .Mui-expanded": {
              margin: "12px 0 !important",
            },
          }}
        >
          <Typography>
            <FilterAltIcon /> Filter
          </Typography>
        </AccordionSummary>
        <AccordionDetails
          sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
        >
          <Box>
            <Grid container spacing={1}>
              <Grid item xs={12} sm={6} md={4} lg={3}>
                <TextField
                  label="Role Id"
                  fullWidth
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                    marginBottom: "10px",
                  }}
                  value={roleIdSearch}
                  onChange={(e) => filterIdHandler(e)}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4} lg={3}>
                <TextField
                  label="Role Name"
                  fullWidth
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                    marginBottom: "15px",
                  }}
                  value={roleNameSearch}
                  onChange={(e) => filterNameHandler(e)}
                />
              </Grid>
            </Grid>
            <Grid container spacing={1} sx={{ justifyContent: "end" }}>
              <Grid item xs={12} sm={4} md={3} lg={2}>
                <Button
                  variant="contained"
                  fullWidth
                  size="small"
                  onClick={handleSearch}
                  sx={{
                    padding: "10px 0",
                    backgroundColor: "#3E0BA1 !important",
                    borderRadius: 0,
                    fontSize: "0.75rem !important",
                    lineHeight: "1.125rem",
                    letterSpacing: 0,
                  }}
                  startIcon={<SearchIcon />}
                >
                  search
                </Button>
              </Grid>
            </Grid>
          </Box>
        </AccordionDetails>
      </Accordion> */}
    </>
  );
}
