import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Grid,
  Box,
  Autocomplete,
  Checkbox,
} from "@mui/material";
import { Typography } from '@mui/material';
import { fetchBuildings } from "../../src/api/Building/buildingApi";
import { fetchFloors } from "../../src/api/Floor/floorApis";
import { getRoomsList } from "../../src/api/Rooms/roomApis";
import { useSelector, useDispatch } from "react-redux";
import { fetchLocationsData } from "../api/Location/locationReducer"; 
import { fetchAvailableRoomsData } from "../api/RoomBooking/roombookingReducer";


import SearchIcon from "@mui/icons-material/Search";
import { CheckBoxOutlineBlank, CheckBox } from "@mui/icons-material";
import DateandTimerangePicker from "./DateandTimeRangePicker";
export default function SearchFilter({ handleSearchCheck }) {
  const [, setLocationData] = React.useState([]);
  const [keyChange] = useState("");
  const [amenity] = useState("");
  const [capacity] = useState("");
  const locationData = useSelector((state) => state.locations);
  const [buildingData, setBuildingData] = useState([]);
  const [floorData, setFloorData] = useState([]);
  const [roomData, setRoomData] = useState([]);
  const [value, onSearchChange] = useState([new Date(), new Date()]);  
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [searchClicked, setSearchClicked] = useState(false);
  const [createData, setCreateData] = useState({
    status: isActiveAdd,
    building_id: "",
    floor_id: "",
    floor_name: "",
    building_name: "",
    room_id: "",
    room_name: "",
  });
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchLocationsData()); 
    dispatch(fetchAvailableRoomsData());
  }, [dispatch]);
  const icon = <CheckBoxOutlineBlank fontSize="small" />;
  const checkedIcon = <CheckBox fontSize="small" />;
  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };
  let fetchBuildingData = async (v) => {
    setFloorData([]);
    setRoomData([]);
    if (v != null) {
      let rlt = await fetchBuildings(v);
      setBuildingData({ buildings: rlt });
    } else {
      setBuildingData([]);
      setFloorData([]);
      setRoomData([]);
    }
  };
  let fetchFloorData = async (v) => {
    setRoomData([]);
    if (v != null) {
      let rlt = await fetchFloors(v);
      setFloorData({ floors: rlt });
    } else {
      setFloorData([]);
      setRoomData([]);
    }
  };
  let fetchRoomData = async (v) => {
    if (v != null) {
      let rlt = await getRoomsList(v);
      setRoomData({ rooms: rlt });
    } else {
      setRoomData([]);
    }
  };
  const handleChange = (e, v, name) => { 
    const val = v === null ? e?.target?.value : v;
    if (Array.isArray(v)) {
      if (name === "room_amenities") {
        const AmmValues = v.map((a) => a.amenityid);
        setCreateData((prevData) => ({
          ...prevData,
          [name]: AmmValues,
        }));
      }
    } else if (
      name === "building" ||
      name === "location" ||
      name === "floor" ||
      name === "room"
    ) {
      setCreateData((prevData) => ({
        ...prevData,
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setCreateData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }
    let setEmptyCreateData = (name, v) => {
      setCreateData((prevData) => ({
        ...prevData,
        [`${name}_id`]: "",
        [`${name}_name`]: "",
      }));
    };
    let fetchBuildingData = async (v) => {
      setFloorData([]);
      if (v != null) {
        let rlt = await fetchBuildings(v);
        setBuildingData({ buildings: rlt });
      } else {
        setBuildingData([]);
        setFloorData([]);
      }
    };
    if (name == "location") {
      setEmptyCreateData("building", v);
      setEmptyCreateData("floor", v);
      fetchBuildingData(v);
    }
    if (name == "building") {
      setEmptyCreateData("floor", v);
      if (v != null) {
        fetchFloorData([v]);
      } else {
        setFloorData([]);
      }
    }
    if (name == "floor") {
      setEmptyCreateData("room", v);
      if (v != null) {
        fetchRoomData([v]);
      } else {
        setRoomData([]);
      }
    }
  };
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };
  const getOptionLabelWithIdFloor = (option) => {
    if (option?.floor_id) {
      return `${option.ufloor_id} - ${option.floor_name}`;
    } else {
      return option?.floor_name;
    }
  };
  const getOptionLabelWithIdRoom = (option) => {
    if (option?.room_id) {
      return `${option.uroom_id} - ${option.room_name}`;
    } else {
      return option?.room_name;
    }
  };

  const handleSearch = () => {
     if (!createData.location_id || !createData.building_id) {
      setSearchClicked(true);
      return;
    }
    handleSearchCheck({
      building_id: createData?.building_id,
      location_id: createData?.location_id,
      floor_id: createData?.floor_id,
      room_id: createData?.room_id
    });
  };

  const capacityOptions = [
    { label: "0-50" },
    { label: "50-100" },
    { label: "100-150" },
    { label: "150-200" },
    { label: "200-500" },
  ];
  return (
    <div>
      <h4 style={{ marginTop: "15px" }}>Book Your Confroom</h4>

      <p style={{ marginBottom: "40px" }}>Dashboard</p>

      <Box
        sx={{
          display: "flex",

          marginBottom: "20px",
        }}
      >
        <Grid container sx={{ alignItems: "end" }}>
          {/* <Grid item xs={12} sm={6} md={6} lg={6} sx={{ marginBottom: "15px" }}>
            <DateandTimerangePicker onChange={onSearchChange} value={value} />
          </Grid> */}
          <Grid item xs={12} sm={6} md={4} lg={2} sx={{ marginBottom: "15px" }}>
            <Autocomplete
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                width: "100%",
                height: "100%"
              }}
              id="checkboxes-tags-demo"
              name="location_id"
              onChange={(e, v) => {
                handleChange(e, v, "location"); 
              }}
              key={keyChange}
              options={locationData?.locations?.location ?? []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdLocation(option)
              }
              getOptionDisabled={(option) => option.status === false}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Location Name"
                  placeholder="Location Name"
                  value={createData.location_id || []}
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={2} sx={{ marginBottom: "15px" }}>
            <Autocomplete
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                width: "100%"
              }}
              id="checkboxes-tags-demo"
              name="building_name"
              onChange={(e, v) => {
                handleChange(e, v, "building");
              }}
              key={keyChange}
              options={buildingData?.buildings?.BuildingsData || []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdBuilding(option)
              }
              value={{
                ubuilding_id: createData.ubuilding_id,
                building_id: createData.building_id,
                building_name: createData.building_name,
              }}
              getOptionDisabled={(option) => option.status === false}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Building Name"
                  placeholder="Building Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={2} sx={{ marginBottom: "15px" }}>
            <Autocomplete
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                width: "100%"
              }}
              id="checkboxes-tags-demo"
              name="floor_name"
              onChange={(e, v) => {
                handleChange(e, v, "floor"); 
              }}
              options={floorData?.floors?.floorsData || []}
              key={keyChange}
              getOptionLabel={(option) =>
                getOptionLabelWithIdFloor(option)
              }
              getOptionDisabled={(option) => option.status === false}
              value={{
                floor_id: createData.floor_id,
                ufloor_id: createData.ufloor_id,
                floor_name: createData.floor_name,
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Floor Name"
                  placeholder="Floor Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={2} sx={{ marginBottom: "15px" }}>
            <Autocomplete
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                width: "100%"
              }}
              id="checkboxes-tags-demo"
              name="room_name"
              onChange={(e, v) => handleChange(e, v, "room_id")}
              key={keyChange}
              options={roomData?.rooms?.roomData || []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdRoom(option)
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Room Name"
                  placeholder="Room Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={2} sx={{ marginBottom: "15px" }}>
            <Button
              fullWidth
              variant="contained"
              onClick={handleSearch}
              sx={{
                padding: "16px 0",
                backgroundColor: "#3E0BA1 !important",
                borderRadius: 0,
              }}
              startIcon={<SearchIcon />}
            >
              Search Room
            </Button>
          </Grid>
          {/* Error message */}
          {searchClicked && (!createData.location_id || !createData.building_id) && (
            <Typography sx={{ color: "red" }}>
              Location and Building are mandatory
            </Typography>
          )}
        </Grid>
      </Box>
    </div>
  );
}
