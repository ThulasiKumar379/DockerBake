import * as React from "react";
import {
  DataGrid,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
} from "@mui/x-data-grid";
import { Box, IconButton, TextField } from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";
import SearchIcon from "@mui/icons-material/Search";
import { createTheme } from "@mui/material/styles";
//import { createStyles, makeStyles } from "@mui/styles";

const defaultTheme = createTheme();
// const useStyles = makeStyles(
//   (theme) =>
//     createStyles({
//       root: {
//         padding: theme.spacing(0.5, 0.5, 0),
//         justifyContent: "space-between",
//         display: "flex",
//         alignItems: "flex-start",
//         flexWrap: "wrap",
//       },
//       textField: {
//         [theme.breakpoints.down("xs")]: {
//           width: "100%",
//         },
//         margin: theme.spacing(1, 0.5, 1.5),
//         "& .MuiSvgIcon-root": {
//           marginRight: theme.spacing(0.5),
//         },
//         "& .MuiInput-underline:before": {
//           borderBottom: `1px solid ${theme.palette.divider}`,
//         },
//       },
//     }),
//   { defaultTheme }
// );

function escapeRegExp(value) {
  return value.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
}

const QuickSearchToolbar = (props) => {
  // const classes = useStyles();

  return (
    <div style={{ textAlign: "right" }}>
      <TextField
        variant="standard"
        value={props.value}
        onChange={props.onChange}
        placeholder="Search…"
        sx={{
          border: "1px solid #3E0BA1",
          padding: "5px 10px",
          borderRadius: "4px",
          marginBottom: "10px",
          "& .MuiInputBase-input.MuiInput-input": {
            paddingLeft: "10px",
          },
          "& .MuiInput-underline:before": {
            borderBottom: `0px solid !important`,
          },
          "& .MuiSvgIcon-root": {
            marginRight: "1px",
          },
          "& .Mui-focused:after": {
            border: "none !important",
          },
        }}
        InputProps={{
          startAdornment: <SearchIcon fontSize="small" />,
          endAdornment: (
            <IconButton
              title="Clear"
              aria-label="Clear"
              size="small"
              style={{ visibility: props.value ? "visible" : "hidden" }}
              onClick={props.clearSearch}
            >
              <ClearIcon fontSize="small" />
            </IconButton>
          ),
        }}
      />
    </div>
  );
};
export default function Table({ data, columns, id }) {
  const [searchText, setSearchText] = React.useState("");
  const [rows, setRows] = React.useState(data);
   const [pageSize, setPageSize] = React.useState(5);
   const handlePageSizeChange = (params) => {
     setPageSize(params);
   };

  const requestSearch = (searchValue) => {
    setSearchText(searchValue);
    const searchRegex = new RegExp(escapeRegExp(searchValue), "i");
    const filteredRows = data.filter((row) => {
      return Object.keys(row).some((field) => {
        // console.log({ row, searchRegex,field }, searchRegex.test(row[field]));
        if(field!='thumbnail_key'){
          return searchRegex.test(row[field]);
        } 
        
      });
    });
    setRows(filteredRows);
  };

  React.useEffect(() => {
    setRows(data);
  }, [data]);
  return (
    <Box
      sx={{
        height: "450px",
        width: "100%",
        "& .super-app-theme--header": {
          backgroundColor: "#3E0BA1",
          color: "#fff",
          borderRight: "5px solid #fff",
          "&:last-child": {
            borderRight: "0px",
          },
        },
      }}
    >
      <DataGrid
        components={{ Toolbar: QuickSearchToolbar }}
        rows={rows}
        columns={columns}
        componentsProps={{
          toolbar: {
            value: searchText,
            onChange: (event) => requestSearch(event.target.value),
            clearSearch: () => requestSearch(""),
          },
        }}
        responsive={true}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
        sx={{
          boxShadow: 0,
          border: 0,
          "& .MuiDataGrid-columnHeaders": {
            borderRadius: 0,
            border: 0,
          },
          "& .MuiDataGrid-cell": {
            border: 0,
            fontWeight: 600,
          },
          "& .MuiDataGrid-row:hover": {
            backgroundColor: "#f2f2f2",
          },
        }}
        getRowId={(row) => row[id]}
        disableRowSelectionOnClick
        pageSize={pageSize}
        rowsPerPageOptions={[5, 10, 20, 30, 50, 100]}
        onPageSizeChange={handlePageSizeChange}
        disableColumnMenu
      />
    </Box>
  );
}
