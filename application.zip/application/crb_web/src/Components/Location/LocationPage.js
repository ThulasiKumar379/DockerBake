import React, { useState, useEffect, useMemo, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { red } from "@mui/material/colors";
import DoNotDisturbOnIcon from "@mui/icons-material/DoNotDisturbOn";
import { checkUserAccess } from "../../CheckUserAccess";
import "react-toastify/dist/ReactToastify.css";
import {
  CssBaseline,
  Box,
  Container,
  Typography,
  Tooltip,
  Button,
  Stack,
  Modal,
  TextField,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  FormControlLabel,
  Switch,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import Table from "../Table";
import {
  EditNote,
  Add as AddIcon,
  Search as SearchIcon,
  // FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import {
  getLocationsData,
  createLocationData,
  updateLocationData,
  deleteLocationData,
} from "../../api/Location/locationReducer";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  maxWidth: "600px",
  width: "calc(100% - 64px)",
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 0,
};
export default function SimpleContainer() {
  const [open, setOpen] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [, setIsActive] = useState(true);
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [CreateData, setCreateData] = useState({});
  const [, setKeyChange] = useState("");
  const [rowData, setRowData] = useState(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [, setSelectedLocationData] = useState(null);
  const [deleteLocationId, setDeleteLocationId] = useState(null);
  const [locationIdError, setLocationIdError] = useState(false);
  const [locationNameError, setLocationNameError] = useState(false);
  const [cityError, setCityError] = useState(false);
  const [stateError, setStateError] = useState(false);
  const [countryError, setCountryError] = useState(false);
  const [editLocationNameError, setEditLocationNameError] = useState(false);
  const [editCityError, setEditCityError] = useState(false);
  const [editStateError, setEditStateError] = useState(false);
  const [editCountryError, setEditCountryError] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [filteroptions, setFilterOption] = useState(false);
  const [locationIdSearch, setLocationIdSearch] = useState("");
  const [locationNameSearch, setLocationNameSearch] = useState("");
  const [statusSearch, setStatusSearch] = useState("");
  const dispatch = useDispatch();
  const locationsData = useSelector((state) => state.locations);
  const locationIdRef = useRef(null);
  const locationcreateNameRef = useRef(null);
  const cityCreateRef = useRef(null);
  const stateCreateRef = useRef(null);
  const countryCreateRef = useRef(null);
  const locationNameRef = useRef(null);
  const cityRef = useRef(null);
  const stateRef = useRef(null);
  const countryRef = useRef(null);

  const locData = useMemo(() => {
    const data = locationsData?.locations?.data ?? [];
    return data;
  }, [locationsData?.locations?.data]);
  // const FilteredData = (location_id, location_name) => {
  //   const filteredLocations = locData.filter(
  //     (location) =>
  //       location.location_id.toString().includes(location_id) &&
  //       location.location_name
  //         .toLowerCase()
  //         .includes(location_name.toLowerCase())
  //   );
  //   return filteredLocations;
  // };
  const FilteredData = (location_id, location_name, status) => {
    const filteredLocations = locData.filter((location) => {
      const idMatch = location.location_id.toString().includes(location_id);
      const nameMatch = location.location_name.toLowerCase().includes(location_name.toLowerCase());
      const statusMatch = status === "" || location.status.toString().includes(status.toString());

      return idMatch && nameMatch && statusMatch;
    });

    return filteredLocations;
  };
  const hasAccess = checkUserAccess("locations")
  const hasAccessToCreate = checkUserAccess("add_location")
  const hasAccessToEdit = checkUserAccess("edit_location")
  const hasAccessToDelete = checkUserAccess("delete_location")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }
  useEffect(() => {
    dispatch(getLocationsData());
    handleToogleAdd({ target: { checked: isActiveAdd }});
  }, [dispatch]);

  useEffect(() => {
    if (locData?.length > 0) {
      const newData = locData.map((d) => {
        const {
          location_id,
          location_name,
          city,
          state,
          country,
          status,
          created_at,
          updated_at,
        } = d;
        const constructData = {
          location_id,
          location_name,
          city,
          state,
          country,
          created_at,
          updated_at,
          status: status ? "Active" : "Inactive",
        };
        return constructData;
      });
      setTableData(newData);
    }
  }, [locData]);

  useEffect(() => {
    if (locationIdSearch === "" && locationNameSearch === "" && statusSearch === "" && filteroptions) {
      dispatch(getLocationsData());
    }
  }, [dispatch, filteroptions, locationIdSearch, locationNameSearch, statusSearch]);

  const filterIdHandler = (e) => {
    const value = e.target.value;
    setLocationIdSearch(value);
    if (value === "" && locationNameSearch !== "") {
      setTableData(FilteredData(value, locationNameSearch));
    } else {
      setTableData(FilteredData(value, locationNameSearch, true));
    }
    setFilterOption(true);
  };

  const filterNameHandler = (e) => {
    const value = e.target.value;
    setLocationNameSearch(value);
    if (value === "" && locationIdSearch !== "") {
      setTableData(FilteredData(locationIdSearch, value, statusSearch));
    } else {
      setTableData(FilteredData(locationIdSearch, value, statusSearch, true));
    }
    setFilterOption(true);
  };

  const filterStatusHandler = (e) => {
    const value = e.target.value;
    setStatusSearch(value);

    if (value === "" && statusSearch !== "") {
      setTableData(FilteredData(locationIdSearch, locationNameSearch, statusSearch));
    } else {
      setTableData(FilteredData(locationIdSearch, locationNameSearch, value));
    }

    setFilterOption(true);
  };


  const handleSearchClick = (locationIdSearch, locationNameSearch, statusSearch) => {
    if (locationIdSearch === "" && locationNameSearch === "" && statusSearch === "") {
      setFilterOption(true);
    } else {
      setTableData(FilteredData(locationIdSearch, locationNameSearch, statusSearch));
    }
  };


  const handleClose = () => {
    setOpen(false);
    setIsActive(true);
    setCreateData({});
    resetAddState();
  };
  const resetAddState = () => {
    setLocationIdError(false);
    setLocationNameError(false);
    setStateError(false);
    setCityError(false);
    setCountryError(false);
  };
  const handleCloseEdit = () => {
    setOpenEdit(false);
    resetEditState();
  };
  const resetEditState = () => {
    setEditLocationNameError(false);
    setEditStateError(false);
    setEditCityError(false);
    setEditCountryError(false);
  };
  const handleButton = () => setOpen(true);
  const handleEditButton = (currentRow) => {
    setOpenEdit(true);
    setRowData(currentRow);
  };
  const handleDeleteConfirmationClose = () => {
    setShowDeleteConfirmation(false);
    setSelectedLocationData(null);
  };
  const onDelete = (currentRow) => {
    dispatch(deleteLocationData(currentRow))
      .then((data) => {
        if (data.payload.status) {
          toast.success("Location deactivated successfully");
          dispatch(getLocationsData());
        } else {
          toast.error(data.message);
        }
      })
      .catch(() => {
        toast.error("Failed to deactivate location");
      });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCreateData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
    const toggleStatusCreate = (status) => {
    setCreateData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
  const handleToogleAdd = (event) => {
    setIsActiveAdd(event.target.checked);
    toggleStatusCreate(event.target.checked);
  };
  const handleToogleEdit = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const handleUpdate = (e) => {
    const { name, value } = e.target;
    setRowData({
      ...rowData,
      [name]: value,
    });
  };

  const saveHandler = async () => {
  if (
    !CreateData.location_id ||
    !CreateData.location_name ||
    !CreateData.city ||
    !CreateData.state ||
    !CreateData.country
  ) {
      
    setLocationIdError(!CreateData.location_id);
    setLocationNameError(!CreateData.location_name);
    setCityError(!CreateData.city);
    setStateError(!CreateData.state);
    setCountryError(!CreateData.country);

    let object=[{
      key:CreateData.location_id,
      ref:locationIdRef.current,

    },
    {
      key:CreateData.location_name,
      ref:locationcreateNameRef.current,
    },
    {
      key:CreateData.city,
      ref:cityCreateRef.current,
    },
    {
      key:CreateData.state,
      ref:stateCreateRef.current,
    },
    {
      key:CreateData.country,
      ref:countryCreateRef.current,
    },

  ]
  for(let i=0;i<=object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }
    return;
  }

  // Reset error states if all fields are filled
  setLocationIdError(false);
  setLocationNameError(false);
  setCityError(false);
  setStateError(false);
  setCountryError(false);

  try {
    const data = await dispatch(createLocationData(CreateData));
    if (data.payload.status) {
      dispatch(getLocationsData());
      setOpen(false);
      setCreateData({ status: true });
      setKeyChange(Math.random());
      setTimeout(() => {
        toast.success("Location created successfully");
      }, 500);
      setIsActiveAdd(true);
      dispatch(getLocationsData());
    } else {
      toast.error(data.payload.errorMessage);
    }
  } catch (error) {
    console.error(error);
    toast.error("Failed to create Location");
  }
};

  const editHandler = () => {
    if (
      !rowData.location_name ||
      !rowData.city ||
      !rowData.state ||
      !rowData.country
    ) {
      if (!rowData.location_name) {
      setEditLocationNameError(!rowData.location_name);
      setEditCityError(!rowData.city);
      setEditStateError(!rowData.state);
      setEditCountryError(!rowData.country);
      locationNameRef.current.focus();
    } else if (!rowData.city) {
      setEditCityError(!rowData.city);
      cityRef.current.focus();
    } else if (!rowData.state) {
      setEditStateError(!rowData.state);
      stateRef.current.focus();
    } else if (!rowData.country) {
      setEditCountryError(!rowData.country);
      countryRef.current.focus();
    } 
      return;
    }
    setEditLocationNameError(false);
    setEditCityError(false);
    setEditStateError(false);
    setEditCountryError(false);
    dispatch(updateLocationData(rowData))
      .then((data) => {
        if (data.payload.status) {
          dispatch(getLocationsData());
          setTimeout(() => {
            toast.success("Location updated successfully");
          }, 500);
        } else {
          toast.error(data.payload.errorMessage);
        }
      })
      .catch(() => {
        toast.error("Failed to update Location");
      });
    setOpenEdit(false);
  };
  const handleShowDeleteConfirmation = (locationId) => {
    setDeleteLocationId(locationId);
    setShowDeleteConfirmation(true);
  };
  const handleHideDeleteConfirmation = () => {
    setShowDeleteConfirmation(false);
    setDeleteLocationId(null);
  };
  const handleDeleteConfirmation = () => {
    setShowDeleteConfirmation(false);
    if (deleteLocationId) {
      onDelete(deleteLocationId);
    }
  };

  const columns = [
    {
      field: "location_id",
      headerName: "Location ID",
      flex: 1,
      width: 200,
      minWidth: 120,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "location_name",
      headerName: "Location Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "created_at",
      headerName: "Created Date",
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      flex: 1,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "updated_at",
      headerClassName: "super-app-theme--header",
      headerName: "Last Updated Date",
      sortable: false,
      flex: 1,
      width: 200,
      minWidth: 200,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return <span>{status}</span>;
      },
    },
    {
      field: "Operations",
      headerName: "Operations",
      headerClassName: "super-app-theme--header",
      width: 180,
      sortable: false,
      disableClickEventBubbling: true,
      renderCell: (params) => {
        const currentRow = params.row;
        let buttonColor;
        let isDisabled = false;
        if (currentRow.status) {
          // Active state
          buttonColor = red[700];
        } else {
          // Inactive state
          buttonColor = red[700];
          isDisabled = true;
        }
        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleEditButton(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title="Deactivate" >
                <DoNotDisturbOnIcon
                  variant="contained"
                  size="small"
                  sx={{
                    minWidth: "32px",
                    color: currentRow?.status === "Inactive" ? "success" : buttonColor,
                    pointerEvents: currentRow?.status === "Inactive" ? "none" : "auto",
                    opacity: currentRow?.status === "Inactive" ? 0.2 : 1,
                  }}
                  disabled={currentRow?.status === "Inactive"}
                  onClick={() =>
                    handleShowDeleteConfirmation(currentRow.location_id)
                  }
                />
              </Tooltip>
            )}
          </Stack>
        );
      },
    },
  ];
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    <React.Fragment>
      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Modal
        keepMounted
        open={open}
        onClose={handleClose}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            Add Locations
            <div style={{ textAlign: "right", display: "inline" }}>
              <Button onClick={handleClose}>X</Button>
            </div>
          </Typography>
          <Box style={{ padding: "10px 15px 25px", textAlign: "left" }}>
            <Grid container spacing={1}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Location ID <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  id="location_id"
                  name="location_id"
                  value={CreateData.location_id || ""}
                  error={
                    locationIdError ||
                    (CreateData.location_id && (CreateData.location_id.length < 1 || CreateData.location_id.length > 120))
                  }
                  helperText={
                    locationIdError
                      ? "Location ID is required."
                      : (CreateData.location_id && CreateData.location_id.length < 1)
                        ? "Minimun 1 character is Required"
                        : (CreateData.location_id && CreateData.location_id.length > 120)
                          ? "Location ID should not exceed 120 characters."
                          : ""
                  }
                  inputProps={{
                    minLength: 1,
                    maxLength: 120,
                  }}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  inputRef={locationIdRef}
                  onChange={(e) => {
                    const { value } = e.target;
                    setCreateData((prevData) => ({
                      ...prevData,
                      location_id: value,
                    }));
                    if (value.length < 1 || value.length > 120) {
                      setLocationIdError(true);
                    } else {
                      setLocationIdError(false);
                    }
                  }}
                />

              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Location Name <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  id="location_name"
                  name="location_name"
                  value={CreateData.location_name || ""}
                  error={
                    locationNameError ||
                    (CreateData.location_name && (CreateData.location_name.length < 2 || CreateData.location_name.length > 120))
                  }
                  helperText={
                    locationNameError
                      ? "Minimum 2 characters Required."
                      : (CreateData.location_name && CreateData.location_name.length < 2)
                        ? "Minimum 2 characters Required."
                        : (CreateData.location_name && CreateData.location_name.length > 120)
                          ? "Should not exceed 120 characters."
                          : ""
                  }
                  inputRef={locationcreateNameRef}
                  inputProps={{
                    minLength: 2,
                    maxLength: 120,
                  }}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const { value } = e.target;
                    setCreateData((prevData) => ({
                      ...prevData,
                      location_name: value,
                    }));
                    if (value.length < 2 || value.length > 120) {
                      setLocationNameError(true);
                    } else {
                      setLocationNameError(false);
                    }
                  }}
                /> 
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      City
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  id="city"
                  name="city"
                  value={CreateData.city || ""}
                  error={cityError}
                  helperText={cityError ? "Must be between 2 and 120 characters." : ""}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const { value } = e.target;
                    setCreateData((prevData) => ({
                      ...prevData,
                      city: value,
                    }));
                    if (value.length < 2 || value.length > 120) {
                      setCityError("Must be between 2 and 120 characters.");
                    } else {
                      setCityError("");
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      State
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  id="state"
                  name="state"
                  value={CreateData.state || ""}
                  error={stateError}
                  helperText={stateError ? "Must be between 2 and 120 characters." : ""}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const { value } = e.target;
                    setCreateData((prevData) => ({
                      ...prevData,
                      state: value,
                    }));
                    if (value.length < 2 || value.length > 120) {
                      setStateError("Must be between 2 and 120 characters.");
                    } else {
                      setStateError("");
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Country
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  id="country"
                  name="country"
                  value={CreateData.country || ""}
                  error={countryError}
                  helperText={countryError ? "Must be between 2 and 120 characters." : ""}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  inputRef={countryCreateRef}
                  onChange={(e) => {
                    const { value } = e.target;
                    setCreateData((prevData) => ({
                      ...prevData,
                      country: value,
                    }));
                    if (value.length < 2 || value.length > 120) {
                      setCountryError("Must be between 2 and 120 characters.");
                    } else {
                      setCountryError("");
                    }
                  }}
                />
              </Grid>
              <Grid item
                xs={12}
                sm={6}
                sx={{
                  display: "flex",
                  justifyContent: "end",
                  alignItems: "end",
                }}>
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={isActiveAdd}
                      onChange={handleToogleAdd}
                    />
                  }
                  label={isActiveAdd ? "Active" : "Inactive"}
                  sx={{ marginLeft: "0" }}
                  labelPlacement="top"
                />
                <Button
                  variant="contained"
                  sx={{
                    marginRight: "10px",
                    marginTop: "15px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                  className="bookingbtn"
                  onClick={saveHandler}
                >
                  Save
                </Button>
                <Button
                  variant="outlined"
                  onClick={handleClose}
                  sx={{
                    marginRight: "10px",
                    marginTop: "15px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                  className="bookingbtn1"
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
      <Modal
        keepMounted
        open={openEdit}
        onClose={handleCloseEdit}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            Edit Location
            <div style={{ textAlign: "right", display: "inline" }}>
              <Button onClick={handleCloseEdit}>X</Button>
            </div>
          </Typography>
          <Box style={{ padding: "10px 15px 25px", textAlign: "left" }}>
            <Grid container spacing={1}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Location ID
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  InputProps={{
                    readOnly: true,
                  }}
                  id="location_id"
                  name="location_id"
                  value={rowData && rowData.location_id}
                  InputLabelProps={{ shrink: rowData && rowData.location_id }}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => handleUpdate(e)}
                  error={locationIdError}
                  helperText={
                    locationIdError
                      ? "Location Id should be between 1 and 120 characters."
                      : ""
                  }
                  inputProps={{
                    minLength: 1,
                    maxLength: 120,
                  }}
                />

              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Location Name
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  id="location_name"
                  name="location_name"
                  value={rowData && rowData.location_name}
                  error={editLocationNameError}
                  helperText={
                    editLocationNameError ? "Location Name is Required and Minimum 2 characters and maximum 120 characters allowed." : ""
                  }
                  inputRef={locationNameRef}
                  InputLabelProps={{ shrink: rowData && rowData.location_name }}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const value = e.target.value;
                    handleUpdate(e);
                    if (value.length < 2 || value.length > 120) {
                      setEditLocationNameError(true);
                    } else {
                      setEditLocationNameError(false);
                    }
                  }}
                />

              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      City <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="city"
                  name="city"
                  value={rowData && rowData.city}
                  error={editCityError || (rowData && (rowData.city.length < 2 || rowData.city.length > 120))}
                  helperText={
                    editCityError ? "City can't be empty and Minimum 2 characters and maximum 120 characters allowed." : ""
                  }
                  InputLabelProps={{ shrink: rowData && rowData.city }}
                  inputRef={cityRef}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const value = e.target.value;
                    handleUpdate(e);
                    if (value.length < 2 || value.length > 120) {
                      setEditCityError("Invalid length");
                    } else {
                      setEditCityError("");
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      State <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="state"
                  name="state"
                  value={rowData && rowData.state}
                  error={editStateError || (rowData && (rowData.state.length < 2 || rowData.state.length > 120))}
                  helperText={
                    editStateError ? "State can't be empty and Minimum 2 characters and maximum 120 characters allowed." : ""
                  }
                  InputLabelProps={{ shrink: rowData && rowData.state }}
                  inputRef={stateRef}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const value = e.target.value;
                    handleUpdate(e);
                    if (value.length < 2 || value.length > 120) {
                      setEditStateError("Invalid length");
                    } else {
                      setEditStateError("");
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      Country <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="country"
                  name="country"
                  error={editCountryError || (rowData && (rowData.country.length < 2 || rowData.country.length > 120))}
                  helperText={
                    editCountryError ? "Country can't be empty and Minimum 2 characters and maximum 120 characters allowed." : ""
                  }
                  value={rowData && rowData.country}
                  inputRef={countryRef}
                  InputLabelProps={{ shrink: rowData && rowData.country }}
                  sx={{ marginBottom: "10px", marginRight: "10px" }}
                  onChange={(e) => {
                    const value = e.target.value;
                    handleUpdate(e);
                    if (value.length < 2 || value.length > 120) {
                      setEditCountryError("Invalid length");
                    } else {
                      setEditCountryError("");
                    }
                  }}
                />
              </Grid>
              <Grid item
                xs={12}
                sm={6}
                sx={{
                  display: "flex",
                  justifyContent: "end",
                  alignItems: "end",
                }}>
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={(rowData?.status == "Active" || rowData?.status == true) ? true : false}
                      onChange={handleToogleEdit}
                    />
                  }
                  label={(rowData?.status == "Active" || rowData?.status == true) ? "Active" : "Inactive"}
                  sx={{ marginLeft: "0", marginBottom: "0" }}
                  labelPlacement="top"
                />

                <Button
                  variant="contained"
                  onClick={editHandler}
                  sx={{
                    marginRight: "10px",
                    textTransform: "capitalize",
                    fontSize: "0.75rem",
                    marginTop: "15px",
                  }}
                  className="bookingbtn"
                >
                  Update
                </Button>
                <Button
                  variant="outlined"
                  onClick={handleCloseEdit}
                  className="bookingbtn1"
                  sx={{
                    textTransform: "capitalize",
                    fontSize: "0.75rem",
                    marginTop: "15px",
                  }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
      <Modal
        open={showDeleteConfirmation}
        onClose={handleHideDeleteConfirmation}
        aria-labelledby="delete-confirmation-modal-title"
        aria-describedby="delete-confirmation-modal-description"
      >
        <Dialog
          open={showDeleteConfirmation}
          onClose={handleHideDeleteConfirmation}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              borderBottom: "1px solid #e9ecef",
            }}
          >
            <DialogTitle sx={{ fontSize: "1rem" }}>
              Deactivate Location
            </DialogTitle>
            <div style={{ textAlign: "right" }}>
              <Button onClick={handleDeleteConfirmationClose}>X</Button>
            </div>
          </div>
          <DialogContent>
            <DialogContentText>
              Are you sure you want to deactivate this Location?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={handleDeleteConfirmation}
              className="bookingbtn"
              sx={{ textTransform: "capitalize", fontSize: "0.75rem" }}
            >
              Deactivate
            </Button>
            <Button
              onClick={handleDeleteConfirmationClose}
              className="bookingbtn1"
              sx={{ textTransform: "capitalize", fontSize: "0.75rem" }}
            >
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </Modal>
      <CssBaseline />
      <Container maxWidth="xl">
        <Box sx={{ bgcolor: "#fff" }}>
          <Grid container spacing={1}>
            <Grid item xs={12} sm={8} md={9} lg={10}>
              <Typography variant="h4" sx={{ fontWeight: "600" }}>
                Locations
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4} md={3} lg={2} className="noPadding">
              {hasAccessToCreate.exists && (
                <Button
                  fullWidth
                  variant="contained"
                  sx={{
                    alignSelf: "center",
                    padding: "10px",
                    backgroundColor: "#0B78A1 !important",
                    borderRadius: 0,
                    fontSize: "0.75rem !important",
                    lineHeight: "1.125rem",
                    letterSpacing: 0,
                    marginBottom: "15px",
                  }}
                  onClick={handleButton}
                  startIcon={<AddIcon />}
                >
                  Add New Location
                </Button>
              )}
            </Grid>
          </Grid>

          {/* <Accordion
            sx={{
              backgroundColor: "#3E0BA1",
              color: "#fff",
              margin: "0 0 15px !important",
              borderRadius: "0 !important",
            }}
          > */}
          {/* <AccordionSummary
              expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
              aria-controls="panel1a-content"
              id="panel1a-header"
              sx={{
                minHeight: "48px !important",
                "& .Mui-expanded": {
                  margin: "12px 0 !important",
                },
              }}
            > */}
          {/* <Typography>
                <FilterAltIcon /> Filter
              </Typography> */}
          {/* </AccordionSummary> */}
          {/* <AccordionDetails
              sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
            > */}
          {/* <Box>
                <Grid container spacing={1}> */}
          {/* <Grid item xs={12} sm={6} md={4} lg={3}>
                    <TextField
                      size="small"
                      fullWidth
                      label="Location ID"
                      id="fullWidth"
                      value={locationIdSearch}
                      onChange={(e) => filterIdHandler(e)}
                      sx={{
                        marginBottom: "15px",
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={3}>
                    <TextField
                      fullWidth
                      size="small"
                      label="Location Name"
                      id="fullWidth"
                      value={locationNameSearch}
                      onChange={(e) => filterNameHandler(e)}
                      sx={{
                        marginBottom: "15px",
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                      }}
                    />
                  </Grid> */}
          {/* </Grid> */}

          {/* <Grid container spacing={1} sx={{ justifyContent: "end" }}>
                  <Grid item xs={12} sm={4} md={3} lg={2}>
                    <Button
                      fullWidth
                      variant="contained"
                      sx={{
                        alignSelf: "center",
                        padding: "10px 0",
                        backgroundColor: "#3E0BA1 !important",
                        borderRadius: 0,
                        fontSize: "0.75rem !important",
                        lineHeight: "1.125rem",
                        letterSpacing: 0,
                      }}
                      onClick={() =>
                        handleSearchClick(locationIdSearch, locationNameSearch,statusSearch)
                      }
                      startIcon={<SearchIcon />}
                    >
                      Search
                    </Button>
                  </Grid>
                </Grid> */}
          {/* </Box> */}
          {/* </AccordionDetails> */}
          {/* </Accordion> */}
        </Box>
        <Table data={tableData} columns={columns} id="location_id" />
      </Container>
    </React.Fragment>
  );
}
