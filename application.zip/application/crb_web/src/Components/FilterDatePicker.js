import React, { useState } from "react";
import "./dateRange.css";
import { DatePicker } from "rsuite";
import { Grid } from "@mui/material";

const DateRangePicker = ({DateFilter}) => {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const handleStartDateChange = (date) => {
    setStartDate(date);
    DateFilter("startdate",date)
  };

  const handleEndDateChange = (date) => {
    setEndDate(date);
    DateFilter("enddate",date)
  };

  return (
    <>
      <Grid container>
        <Grid item xs={12} sm={12} md={6} lg={6}>
          <DatePicker
            size="lg"
            style={{ display: "block", marginBottom: "10px" }}
            value={startDate}
            onChange={handleStartDateChange}
            placeholder="Start Date"
          />
        </Grid>
        <Grid item xs={12} sm={12} md={6} lg={6}>
          <DatePicker
            size="lg"
            style={{ display: "block", marginBottom: "10px" }}
            value={endDate}
            onChange={handleEndDateChange}
            placeholder="End Date"
          />
        </Grid>
      </Grid>
    </>
  );
};

export default DateRangePicker;
