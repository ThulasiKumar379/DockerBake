import React, { useState } from "react";
import SearchFilter from "../SearchFilter";
import Scheduler from "../Calendar/Scheduler";
import RoomCard from "../Calendar/RoomCard";
import ArrowBackRoundedIcon from "@mui/icons-material/ArrowBackRounded";

const Dashboard = ({ handleBack, handleSearchCheck, isSearchResultsFound }) => {
  return (
    <div className="container-fluid">
      <ArrowBackRoundedIcon onClick={() => handleBack()}></ArrowBackRoundedIcon>
      <div className="row">
        <div className="col-md-12">
          <SearchFilter handleSearchCheck={handleSearchCheck} />
        </div>
      </div>
      <div className="row">
        <div className="col-md-9">
          <Scheduler isSearchResultsFound={isSearchResultsFound} />
        </div>
        {/* <div className="col-md-3 p-0">
          <RoomCard />
        </div> */}
      </div>
    </div>
  );
};

export default Dashboard;
