import React from 'react';
import BookingListView from './BookingListView';
import { BookinglistviewTable } from './DataTable';

const BookingListPage = ()=> {
  return (
    <div style={{marginTop:'1%'}}>
        <BookingListView />
        <BookinglistviewTable/>
    </div>
  )
}
export default BookingListPage
