import React, { useState } from "react";
import {
  Box,
  Grid,
  TextField,
  Button,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Autocomplete,
} from "@mui/material";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import FilterDatePicker from "../FilterDatePicker"
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import SearchIcon from "@mui/icons-material/Search";
import dayjs, { Dayjs } from "dayjs";
import { ExpandMore as ExpandMoreIcon } from "@mui/icons-material";
import FilterTimeRangePicker from "../FilterTimeRangePicker";
const Location = ["Location1", "Location2", "Location3"];
const Floor = ["Floor 1", "Floor 2", "Floor 3"];
const Building = ["Building 1", "Building 2", "Building 3"];
const Amenities = [" 1", " 2", " 3"];
const renderInput = (params) => (
  <TextField
    {...params}
    label={params.inputProps.label}
    helperText={params.inputProps.helperText}
    sx={{ width: "100%" }}
    size="medium"
  />
);
export default function ResponsiveGrid() {
  const [showfilter, setShowfilter] = React.useState(false);
  const [ishow, setIsshow] = useState(true);
  const [startvalue, setStartValue] = useState(dayjs("2014-08-18T21:11:54"));
  const [endvalue, setEndValue] = useState(dayjs("2014-08-18T21:11:54"));
  const handletime = () => {
    setIsshow(false);
  };
  const handleChange = (newValue) => {
    setStartValue(newValue);
  };
  const handleChangeend = (newValue) => {
    setEndValue(newValue);
  };
  const customRenderInput = (params) => (
    <TextField
      {...params}
      label={params?.inputProps?.label}
      helperText={params?.inputProps?.helperText}
      sx={{ width: "100%" }}
      size="small"
    />
  );

  return (
    <>
      <div sx={{ paddingLeft: "5%", marginTop: "5px" }}>
        {!showfilter && (
          <div>
            <Typography
              variant="h5"
              sx={{ color: "#000", marginBottom: "10px" }}
            >
              Booking list filter
            </Typography>
            <Accordion
              sx={{
                backgroundColor: "#3E0BA1",
                color: "#fff",
                margin: "0 0 15px !important",
                borderRadius: "0 !important",
              }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
                aria-controls="panel1a-content"
                id="panel1a-header"
                sx={{
                  minHeight: "48px !important",
                  "& .Mui-expanded": {
                    margin: "12px 0 !important",
                  },
                }}
              >
                <Typography>
                  <FilterAltIcon /> Filter
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
              >
                <Box sx={{ flexGrow: 1 }}>
                  <Grid container>
                    <Grid item xs={12} md={4} lg={2}>
                      <Autocomplete
                        options={Location}
                        renderInput={(params) =>
                          customRenderInput({
                            ...params,
                            inputProps: {
                              ...params.inputProps,
                              label: "Location",
                            },
                          })
                        }
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                          marginBottom: "10px",
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} md={4} lg={2}>
                      <Autocomplete
                        options={Building}
                        renderInput={(params) =>
                          customRenderInput({
                            ...params,
                            inputProps: {
                              ...params.inputProps,
                              label: "Building",
                            },
                          })
                        }
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                          marginBottom: "10px",
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} md={4} lg={2}>
                      <Autocomplete
                        options={Floor}
                        renderInput={(params) =>
                          customRenderInput({
                            ...params,
                            inputProps: {
                              ...params.inputProps,
                              label: "Floor",
                            },
                            marginBottom: "10px",
                          })
                        }
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                          marginBottom: "10px",
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} md={4} lg={2}>
                      <Autocomplete
                        multiple
                        options={Amenities}
                        renderInput={(params) =>
                          customRenderInput({
                            ...params,
                            inputProps: {
                              ...params.inputProps,
                              label: "Amenities",
                            },
                          })
                        }
                        sx={{
                          fieldset: {
                            borderColor: "#3E0BA1 !important",
                            borderRadius: 0,
                          },
                          marginBottom: "10px",
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12} md={8} lg={4}>
                      <FilterDatePicker />
                    </Grid>
                    <Grid item xs={12} md={4} lg={2}>
                      <FilterTimeRangePicker />
                    </Grid>
                  </Grid>
                  <Grid container justifyContent="end">
                    <Grid item xs={12} sm={4} md={4} lg={2}>
                      <Button
                        variant="contained"
                        fullWidth
                        // onClick={filterHandler}
                        sx={{
                          padding: "10px 0",
                          backgroundColor: "#3E0BA1 !important",
                          borderRadius: 0,
                          fontSize: "0.75rem !important",
                          lineHeight: "1.125rem",
                          letterSpacing: 0,
                        }}
                        startIcon={<SearchIcon />}
                      >
                        search
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              </AccordionDetails>
            </Accordion>
          </div>
        )}
      </div>
    </>
  );
}
