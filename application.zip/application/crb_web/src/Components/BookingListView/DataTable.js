import React, { useState } from "react";
import { FormControlLabel, Switch } from "@mui/material";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Box,
  Button,
} from "@mui/material";
import { styled } from "@mui/system";
import VideoCall from "@mui/icons-material/VideoCall";
import Tv from "@mui/icons-material/Tv";
import WifiIcon from "@mui/icons-material/Wifi";
import Call from "@mui/icons-material/Call";
import Print from "@mui/icons-material/Print";
import Avatar from "@mui/material/Avatar";
import AvatarGroup from "@mui/material/AvatarGroup";
import { Tooltip } from "@mui/material";
const ColoredTableCell = styled(TableCell)({
  backgroundColor: "#3E0BA1",
  color: "#FFFFFF",
  width: "118px",
  height: "30px",
  borderLeft: "3px solid",
});
const ColoredTableHeadCell = styled(ColoredTableCell)({
  marginRight: "2px",
});
const StyledTableContainer = styled(TableContainer)({
  width: "100%",
  height: "auto",
});
const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: "#F5F5F7",
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const IconWithTooltip = ({ icon, tooltipText }) => (
  <Tooltip title={tooltipText} placement="top">
    <span>{icon}</span>
  </Tooltip>
);

export const BookinglistviewTable = () => {
  const [meetingDetails, setMeetingDetails] = useState({
    attendes: [
      {
        building: "building1",
        floor: "floor1",
        room: "room1",
        title: "CRB",
        date: "28th-31st Jul",
        time: "3:00,4:00pm",
        organizer: {
          name: "John Doe",
          email: "john.doe@example.com",
          phone: "123-456-7890",
        },
        attendes: [
          { avatar: "R" },
          { avatar: "O" },
          { avatar: "C" },
          { avatar: "K" },
        ],
        capacity: "7",
        amenities: [
          {
            icon: (
              <VideoCall
                className={"iconBackground"}
                sx={{ fontSize: "15px" }}
              />
            ),
            tooltipText: "Video Call",
          },
          {
            icon: <Tv className={"iconBackground"} sx={{ fontSize: "15px" }} />,
            tooltipText: "TV",
          },
          {
            icon: (
              <WifiIcon
                className={"iconBackground"}
                sx={{ fontSize: "15px" }}
              />
            ),
            tooltipText: "Wi-Fi",
          },
          {
            icon: (
              <Call className={"iconBackground"} sx={{ fontSize: "15px" }} />
            ),
            tooltipText: "Call",
          },
          {
            icon: (
              <Print className={"iconBackground"} sx={{ fontSize: "15px" }} />
            ),
            tooltipText: "Print",
          },
        ],
        status: "Pending",
      },
      // Add more attendees data here if needed...
    ],
  });

  return (
    <div>
      <Box sx={{ overflow: "auto", marginTop: "15px" }}>
        <Box sx={{ width: "100%", display: "table", tableLayout: "fixed" }}>
          <TableContainer sx={{ marginBottom: "10px" }}>
            <Typography variant="h5" sx={{ marginBottom: "20px" }}>
              Booking list view
            </Typography>
            <Table>
              <TableHead>
                <TableRow>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Building
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Floor
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Room
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Title
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Date
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Time
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Organizer
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Attendes
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Capacity
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Amenities
                  </ColoredTableHeadCell>
                  <ColoredTableHeadCell sx={{ padding: "10px" }}>
                    Status
                  </ColoredTableHeadCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {meetingDetails.attendes.map((attendes, index) => (
                  <StyledTableRow key={index}>
                    <TableCell>{attendes.building}</TableCell>
                    <TableCell>{attendes.floor}</TableCell>
                    <TableCell>{attendes.room}</TableCell>
                    <TableCell>{attendes.title}</TableCell>
                    <TableCell>{attendes.date}</TableCell>
                    <TableCell>{attendes.time}</TableCell>
                    <TableCell>
                      <Tooltip
                        title={
                          <Typography>
                            <strong>Email:</strong> {attendes.organizer.email}
                            <br />
                            <strong>Phone:</strong> {attendes.organizer.phone}
                          </Typography>
                        }
                        arrow
                      >
                        <Button>person</Button>
                      </Tooltip>
                    </TableCell>
                    <TableCell>
                      <AvatarGroup total={attendes.attendes.length}>
                        {attendes.attendes.map((attendee, index) => (
                          <Avatar
                            key={index}
                            alt={attendee.avatar}
                            src="/static/images/avatar/"
                            sx={{ width: 24, height: 24 }}
                          />
                        ))}
                      </AvatarGroup>
                    </TableCell>
                    <TableCell>{attendes.capacity}</TableCell>
                    <TableCell>
                      {attendes.amenities.map((amenity, index) => (
                        <IconWithTooltip
                          key={index}
                          icon={amenity.icon}
                          tooltipText={amenity.tooltipText}
                        />
                      ))}
                    </TableCell>
                    <TableCell>{attendes.status}</TableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Box>
    </div>
  );
};

export default BookinglistviewTable;
