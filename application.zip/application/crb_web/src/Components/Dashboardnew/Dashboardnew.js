import React, { useState } from "react";
import { ToggleButtonGroup, ToggleButton, Tooltip } from "@mui/material";
import { List, CalendarToday } from "@mui/icons-material";
import SearchFilter from "../SearchFilter";
import Scheduler from "../Calendar/Scheduler";
import ListView from "../Dashboardnew/ListView";
import DashboardCalendar from "../Dashboard/DashboardCalendar";
import { useSelector, useDispatch } from "react-redux";
const Dashboard = () => {
  const dispatch = useDispatch();
  const [view, setView] = React.useState("calendar");
  const handleViewChange = (event, newView) => {
    if (newView) {
      setView(newView);
    }
  };
  const [calRerender,setCalRerender]=useState(true);
  const [isSearchResultsFound, setIsSearchResultsFound] = useState(false);
  const [searchParams, setSearchParams] = useState({});
  const handleSearch = (data) => {  
    setSearchParams(data) 
    setIsSearchResultsFound(true);
    setCalRerender(!calRerender)
  };

  const handleBack = (data) => {
   
    setIsSearchResultsFound(false);
  };

  return (
    <div>
     (
        <>
          <SearchFilter handleSearchCheck={handleSearch} />
          <ToggleButtonGroup
            value={view}
            exclusive
            onChange={handleViewChange}
            aria-label="view toggle"
            sx={{ my: 2 }}
          >
            <ToggleButton value="calendar" aria-label="calendar view">
              <Tooltip title="Calendar View" placement="top">
                <CalendarToday />
              </Tooltip>
            </ToggleButton>
            <ToggleButton value="list" aria-label="list view">
              <Tooltip title="List View" placement="top">
                <List />
              </Tooltip>
            </ToggleButton>
          </ToggleButtonGroup>
          
          {view === "calendar" ? <Scheduler
          isSearchResultsFound={isSearchResultsFound}
          searchParams={searchParams}
          calRerender={calRerender}
          /> : <ListView />}
        </>
      )
      {/* {isSearchResultsFound && (
        <DashboardCalendar
          isSearchResultsFound={isSearchResultsFound}
          handleBack={() => handleBack()}
          handleSearchCheck={() => handleSearch()}
        />
      )} */}
    </div>
  );
};

export default Dashboard;
