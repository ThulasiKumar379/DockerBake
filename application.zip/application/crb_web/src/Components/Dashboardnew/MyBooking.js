import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { red } from "@mui/material/colors";
import { FormControlLabel, Switch } from "@mui/material";

import {
  DialogActions,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Button,
  Stack,
  DialogContentText,
  Box,
} from "@mui/material";
import {bookingCancelData,getBookingById} from "../../api/RoomBooking/roombookingReducer";
import { CancelBookingAPI } from "../../api/BookingManage/bookingManageApi";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Table from "../Table";
import { getMyBookingsData } from "../../api/RoomBooking/mybookingReducers";
import { styled } from "@mui/system";
import EditScheduler from "../Calendar/EditScheduler";
// import Dialog from '@mui/material/Dialog';
import { EditNote, Cancel as CancelIcon } from "@mui/icons-material";
import { Tooltip } from "@mui/material";
import { Grid } from "@mui/material";
import CreateBooking from "../Calendar/CreateBookingPopUp"
const IOSSwitch = styled((props) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 42,
  height: 26,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(16px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 21,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#ffff",
      border: "6px solid #fff",
    },
    "&.Mui-disabled .MuiSwitch-thumb": {
      //   color:
      //     theme.palette.mode === "light"
      //       ? theme.palette.grey[600]
      //       : theme.palette.grey[600],
    },
    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 22,
    height: 22,
  },
  "& .MuiSwitch-track": {
    borderRadius: 26 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
    // // transition: theme.transitions.create(["background-color"], {
    // //   duration: 500,
    // }),
  },
}));

const MyBookings = () => {
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [createData, setCreateData] = useState({status: isActiveAdd,duration:"",room_capacity:""}); 
  const [showModal, setShowModal] = useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [open, setOpen] = useState(false);
  const [deleteBookingId, setDeleteBookingId] = useState(null);
  const [editBookingId, setEditBookingId] = useState(null);
  const handleClickOpen = (booking_id) => { 
    setDeleteBookingId(booking_id);
    setOpenDelete(true);
  };
  const handleClickEdit = (bookingId) => {  
    dispatch(getBookingById(bookingId));
    setEditBookingId(bookingId)
    setShowModal(true)
  }; 
  const handleClose = () => {
    setOpen(false);
  };
  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const MyBookings = useSelector((state) => state.myBooking);  
  const BookingsData = MyBookings?.myBookings?.results ?? []; 
  const dispatch = useDispatch();
  const BookingDetailsData = useSelector((state) => state?.roomBooking?.bookingDetails); 
  const [editBookingData, setEditBookingData] = useState([]);  
  useEffect(() => {
    setEditBookingData(BookingDetailsData)
  },[BookingDetailsData]);

  useEffect(() => {
    dispatch(getMyBookingsData());
  }, [dispatch]);
 
  const onDelete = async (currentRow) => {
    try { 
      const data = await dispatch(bookingCancelData(currentRow)); 
      if (data.payload.status) {
        dispatch(getMyBookingsData());
        setTimeout(() => {
          toast.success(" Booking canceled  successfully");
        }, 500);
      } else {
        setTimeout(() => {
          toast.error(data.message);
        }, 500);
      }
    } catch (error) {
      setTimeout(() => {
        toast.error("Failed to cancel Booking");
      }, 500);
    }
  };
  const handleDeleteConfirmation = () => {
    CancelBookingAPI(deleteBookingId)
    setOpenDelete(false);
    if (deleteBookingId) {
      onDelete(deleteBookingId);
    }
  };
  const columns = [
    {
      field: "room_id",
      headerName: "Room No",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },

    {
      field: "crbt_locations_location_name",
      headerName: "Location",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },

    {
      field: "crbt_buildings_building_name",
      headerName: "Building",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "crbt_floors_floor_name",
      headerName: "Floor",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "duration",
      headerName: "Duration",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "starttime",
      headerName: " StartTime",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "endtime",
      headerName: " EndTime",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "booking_date",
      headerName: "Date",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },

    {
      field: "crbt_users.first_name",
      headerName: "Organizer",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "title_of_meeting",
      headerName: "Meeting Name",
      flex: 1,
      width: 200,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
    },

    {
      field: "amenities_data",
      headerName: "Amenities",
      flex: 1,
      width: 100,
      minWidth: 100,
      overflowX: "scroll !important",
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        return (
          <div
            style={{
              display: "inline-flex",
              height: "60px",
              overflowX: params.value.length > 5 ? "scroll" : "hidden",
            }}
          >
            {params.value.map((amenity) => (
              <Tooltip
                title={` ${amenity.amenityname}`}
                placement="top"
                key={amenity.amenityid} // Using a unique and stable key
              >
                <img
                  src={`${process.env.REACT_APP_BASE_URL}/amenities/getRoomThumbnails?amenityid=${amenity.amenityid}&thumbnail_key=${amenity.thumbnail_key}`}
                  alt={amenity.amenityid}
                  style={{flex: "0 0 auto",width: "20px",padding: "0",objectFit: "contain",}}
                />
              </Tooltip>
            ))}
          </div>
        );
      },
    },

    {
      field: "participants",
      headerName: "Participants",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params, index) => {
        const isScrollable = index !== 0 && params.value.length > 0;
        return (
          <div
            style={{
              display: "inline-flex",height: "60px",overflowX: isScrollable ? "scroll" : "hidden",}}
          >
            {params.value.map((participant, index) => (
              <span key={participant.user_id}>
                {participant.first_name}
                {index < params.value.length - 1 && ", "}
              </span>
            ))}
          </div>
        );
      },
    },

    {
      field: "Actions",
      headerClassName: "super-app-theme--header",
      headerName: "Operations",
      width: 180,
      sortable: false,
      disableClickEventBubbling: true,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        const isBookingCanceled = currentRow.booking_status === 4;
        return (
          <Stack direction="row" spacing={2}>
             <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                onClick={() => handleClickEdit(currentRow.booking_id)}
                disabled={isBookingCanceled}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {/* <Dialog open={open} onClose={handleClose}>
              
            </Dialog> */}

            <Tooltip title="Deactivate">
              <CancelIcon
                variant="contained"
                size="small"
                sx={{
                  minWidth: "32px",
                  color: "red",
                }}
                onClick={() => handleClickOpen(currentRow)}
              />
            </Tooltip>
          </Stack>
        );
      },
    },
  ];

  return (
    <React.Fragment>
      <ToastContainer /> 
      <Dialog open={opendelete} onClose={handleCloseDelete}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",
            paddingBottom: "10px",
            marginBottom: "14px",
            fontSize: "1rem",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <>Cancel Booking</>
            <Button onClick={handleCloseDelete}>X</Button>
          </div>
        </DialogTitle>
        <DialogContent sx={{ color: "black" }}>
          Are you sure you want to Cancel this Booking?
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            className="bookingbtn"
            onClick={handleDeleteConfirmation}
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
              marginRight: "10px",
            }}
          >
            Cancel Booking
          </Button>
          <Button
            variant="outlined"
            className="bookingbtn1"
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
            }}
            onClick={handleCloseDelete}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      <Table data={BookingsData} columns={columns} id={"booking_id"} />
      {showModal && editBookingData.length!=0 &&
            <CreateBooking 
              modelOpen={true} 
              setModal={showModal}
              closeModel={()=>{ setEditBookingData([]);setShowModal(false);}}
              bookingStartDate={null}
              bookingEDate={null}
              cData={createData}
              svalue={null}
              evalue={null}
              booking_id={editBookingId}
              bookingData={editBookingData}
              type='UPDATE'
            /> }
    </React.Fragment>
  );
};
export default MyBookings;
