import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  TableCell,
  DialogActions,
  TableContainer,
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Button,
  DialogContentText,
  Tooltip,
  Stack,
} from "@mui/material";
import { styled } from "@mui/system";
import { Grid } from "@mui/material";
import EditNoteIcon from "@mui/icons-material/EditNote";
import Table from "../Table";
import DoNotDisturbOnIcon from "@mui/icons-material/DoNotDisturbOn";
import { getMyInvitationsData } from "../../api/RoomBooking/MyInvitationsReducers";
import { FormControlLabel, Switch } from "@mui/material";
import {Cancel} from "@mui/icons-material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
const ColoredTableCell = styled(TableCell)({
  backgroundColor: "#0BA197",
  color: "#FFFFFF",
  width: "118px",
  height: "30px",
  borderLeft: "3px solid",
});
const ColoredTableHeadCell = styled(ColoredTableCell)({
  marginRight: "2px",
});
const StyledTableContainer = styled(TableContainer)({
  width: "100%",
  height: "auto",
});
const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: "#F5F5F7",
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));
const InvitedMeeting = () => {
  const [openPopup, setOpenPopup] = useState(false);
  const [input1Value, setInput1Value] = useState("");
  const [input2Value, setInput2Value] = useState("");
  const [input3Value, setInput3Value] = useState("");
  const [input4Value, setInput4Value] = useState("");
  const [deleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);
  const [rowToEdit, setRowToEdit] = useState(null);
  const MyinvitationsData = useSelector((state) => state.myinvitations);
  const tableData = MyinvitationsData?.myInvitations?.results ?? [];
  console.log({ MyinvitationsData });
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getMyInvitationsData());
  }, [dispatch]);
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(16px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {
        //   color:
        //     theme.palette.mode === "light"
        //       ? theme.palette.grey[600]
        //       : theme.palette.grey[600],
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 22,
      height: 22,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
      // // transition: theme.transitions.create(["background-color"], {
      // //   duration: 500,
      // }),
    },
  }));
  const handleOpenPopup = (index) => {
    setRowToEdit(index);
    setOpenPopup(true);
  };
  const handleClosePopup = () => {
    setOpenPopup(false);
    setRowToEdit(null);
  };
  const handleDeleteConfirmationOpen = (rowIndex) => {
    setRowToEdit(rowIndex);
    setDeleteConfirmationOpen(true);
  };
  const handleDeleteConfirmationClose = () => {
    setRowToEdit(null);
    setDeleteConfirmationOpen(false);
  };
  const columns = [
    {
      field: "room_id",
      headerName: "Room No",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "crbt_locations_location_name",
      headerName: "Location",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "crbt_buildings_building_name",
      headerName: "Building",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "crbt_floors_floor_name",
      headerName: "Floor",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "duration",
      headerName: "Duration",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "starttime",
      headerName: "Time",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "booking_date",
      headerName: "Date",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "crbt_users.first_name",
      headerName: "Organizer",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "title_of_meeting",
      headerName: "Meeting Name",
      flex: 1,
      width: 200,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "amenities",
      headerName: "Amenities",
      flex: 1,
      width: 100,
      minWidth: 100,
      overflowX: "scroll !important",
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        return (
          <div
            style={{
              display: "inline-flex",
              height: "60px",
              overflowX: params.value.length > 5 ? "scroll" : "hidden",
            }}
          >
            {params.value.map((amenity) => (
              <Tooltip
                title={` ${amenity.amenityname}`}
                placement="top"
                key={amenity.amenityid} 
              >
                <img
                  src={`${process.env.REACT_APP_BASE_URL}/amenities/getRoomThumbnails?amenityid=${amenity.amenityid}&thumbnail_key=${amenity.thumbnail_key}`}
                  alt={amenity.amenityid}
                  style={{
                    flex: "0 0 auto",
                    width: "20px",
                    padding: "0",
                    objectFit: "contain",
                  }}
                />
              </Tooltip>
            ))}
          </div>
        );
      },
    },
    {
      field: "participants",
      headerName: "Participants",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params, index) => {
        const isScrollable = index !== 0 && params.value.length > 0;
        return (
          <div
            style={{
              display: "inline-flex",
              height: "60px",
              overflowX: isScrollable ? "scroll" : "hidden",
            }}
          >
            {params.value.map((participant, index) => (
              <span key={participant.user_id}>
                {participant.first_name}
                {index < params.value.length - 1 && ", "}
              </span>
            ))}
          </div>
        );
      },
    },
    {
      field: "Actions",
      headerClassName: "super-app-theme--header",
      headerName: "Operations",
      width: 180,
      sortable: false,
      disableClickEventBubbling: true,
      renderCell: (params) => {
        const currentRow = params.row;
        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Decline" sx={{ yIndex: 9999 }}>
              <Button
                variant="text"
                color="error"
                size="small"
                sx={{ minWidth: "32px" }}
                 onClick={() => handleDeleteConfirmationOpen(currentRow)}
              >
                <Cancel />
              </Button>
            </Tooltip>
            <Tooltip title="Accept" sx={{ yIndex: 9999 }}>
              <Button
                variant="text"
                size="small"
                color="secondary"
                sx={{
                  minWidth: "32px",
                }}
                id="booking_date"
                // onClick={() => onDelete(currentRow)}
              >
                <CheckCircleIcon />
              </Button>
            </Tooltip>
          </Stack>
        );
      },
    },
  ];
  return (
    <div>
      <Table data={tableData} columns={columns} id={"booking_id"} />
      <Dialog
        open={openPopup}
        onClose={handleClosePopup}
        fullWidth
        maxWidth="md"
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <DialogTitle sx={{ paddingRight: "-23px" }}>
            Edit Meeting Details
          </DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleClosePopup}>X</Button>
          </div>
        </div>
        <DialogContent>
          <Grid container spacing={1}>
            <Grid item xs={12} sm={8} md={4}>
              <TextField
                fullWidth
                margin="dense"
                label="Room No"
                size="small"
                value={input1Value}
                // sx={{width:"100%"}}
                onChange={(e) => setInput1Value(e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                margin="dense"
                label="Location"
                size="small"
                value={input2Value}
                onChange={(e) => setInput2Value(e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                margin="dense"
                label="Building"
                size="small"
                value={input2Value}
                onChange={(e) => setInput3Value(e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                margin="dense"
                label="Floor"
                size="small"
                value={input2Value}
                onChange={(e) => setInput4Value(e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                margin="dense"
                label="Duration"
                size="small"
                value={input2Value}
                onChange={(e) => setInput4Value(e.target.value)}
              />
            </Grid>
            <div className="toggle">
              <FormControlLabel
                control={<IOSSwitch />}
                label="active"
                sx={{ marginTop: "12px" }}
                labelPlacement="top"
              />
            </div>
            <DialogActions sx={{ marginTop: "12px" }}>
              <Button
                // onClick={() => handleSubmit(rowToEdit)}
                className="Invitedbtn"
              >
                Update
              </Button>
              <Button
                onClick={handleClosePopup}
                color="error"
                variant="contained"
              >
                Cancel
              </Button>
            </DialogActions>
          </Grid>
        </DialogContent>
      </Dialog>
      <Dialog
        open={deleteConfirmationOpen}
        onClose={handleDeleteConfirmationClose}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <DialogTitle sx={{ paddingRight: "-23px" }}>
            Reject Meeting
          </DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleDeleteConfirmationClose}>X</Button>
          </div>
        </div>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to reject this Meeting?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            //onClick={handleDelete}
            className="bookingbtn"
          >
            Delete
          </Button>
          <Button
            onClick={handleDeleteConfirmationClose}
            className="bookingbtn1"
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};
export default InvitedMeeting;
