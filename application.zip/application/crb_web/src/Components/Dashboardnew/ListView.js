import React from "react";
import MyBooking from "./MyBooking";
import InvitedMeeting from "./InvitedMeeting";

const ListView = () => {
  return (
    <div>
      <MyBooking />
      <InvitedMeeting />
    </div>
  );
};

export default ListView;
