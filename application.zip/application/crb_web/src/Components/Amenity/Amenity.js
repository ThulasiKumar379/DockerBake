import React from 'react';
import { AmenityTable } from './AmenityTable';
export const Amenity =()=> {
    return(
        <div>
            <AmenityTable/>
        </div>
    
    )
}