import React, { useState } from "react";
import {
  TextField,
  FormControl,
  FormControlLabel,
  Switch,
  Button,
  Grid,
  DialogActions,
  Input,
  swi,
} from "@mui/material";

import { styled } from "@mui/system";
import { useSelector, useDispatch } from "react-redux";
import {
  createAmenityData,
  fetchAmenitiesData,
} from "../../api/Amenities/amenitiesReducers";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { CommentsDisabledOutlined } from "@mui/icons-material";
export const AddAmenity = ({ onClose }) => {
  const [amenityid, setamenityid] = useState("");
  const [amenityName, setAmenityName] = useState("");
  const [amenitydata, setAmenityData] = useState({});
  const [keyChange, setKeyChange] = useState("");
  const [AmenityDataError, setAmenityDataError] = useState({
    amenityname: "",
  });
  const [amenityNameError, setAmenityNameError] = useState("");
  const [iconError, setIconError] = useState("");
  const [generalError, setGeneralError] = useState("");
  const handleClose = () => {
    onClose();
  };
  const dispatch = useDispatch();
  const handleSave = async () => {
    setAmenityNameError("");
    setIconError("");
    setGeneralError("");

    if (!amenityName.trim()) {
      setAmenityNameError("Amenity Name is required");
      setGeneralError("Please fill in all required fields"); // Set general error for both fields
      return;
    }
    if (!selectedFile) {
      setIconError("Icon is required");
      setGeneralError("Please fill in all required fields"); // Set general error for both fields
      return;
    }
    const fd = new FormData();
    console.log("fd",fd);
    fd.append("thumbnail", selectedFile);
    fd.append("amenityName", amenityName);
    fd.append("amenityid",amenityid)
    await dispatch(createAmenityData(fd))
      .then((data) => {
        console.log(data);
        if (data.payload.status) {
          dispatch(fetchAmenitiesData());
          setAmenityData({});
          setKeyChange(Math.random());
          toast.success("Amenity Created Successfully");
        } else {
          toast.error(data.payload.errorMessage);
        }
      })
      .catch((error) => {
        toast.error("Failed to create Amenity");
      });
    onClose();
  };
  const [labelStatus, setlabelStatus] = useState(false);
  const labelName = labelStatus ? "Active" : "Inactive";

  const handleChange = () => {
    setlabelStatus(!labelStatus);
  };
  const [selectedFile, setSelectedFile] = useState(null);
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const allowedFormats = ['image/jpeg', 'image/jpg', 'image/png'];
      if (!allowedFormats.includes(file.type)) {
        setIconError('Please upload only JPG or JPEG or PNG');
        setSelectedFile(null);
      } else {
        setSelectedFile(file);
        setIconError('');
      }
    }
  };
  
  const ToggleSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(16px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },

      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },

      "&.Mui-disabled .MuiSwitch-thumb": {
        //   color:
        //     theme.palette.mode === "light"
        //       ? theme.palette.grey[600]
        //       : theme.palette.grey[600],
      },

      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },

    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,

      // // transition: theme.transitions.create(["background-color"], {

      // //   duration: 500,

      // }),
    },
  }));
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    // <FormControl fullWidth={true} maxWidth={""} textalign="left"><
    <>
      {generalError && (
        <Grid item xs={12}>
          <span style={{ color: "red", textTransform: "capitalize" }}>
            {generalError}
          </span>
        </Grid>
      )}
      <Grid
        container
        spacing={1}
        //columns={{ xs: 3, sm: 2, md: 8 }}
      >
        {/* <Grid item xs={12} sm={4} md={3}>
          <TextField
            autoFocus
            margin="dense"
            label={
              <span>
                amenityid
                <RequiredAsterisk>*</RequiredAsterisk>
              </span>
            }
            size="small"
          />
        </Grid> */}
        <Grid item xs={12} sm={6}>
          <label className="thumbnail">Amenity ID</label>
          <TextField
            fullWidth
            label={
              <span>
                Amenity ID
                <RequiredAsterisk>*</RequiredAsterisk>
              </span>
            }
            // size="small"
            // onChange={(e) => setamenityid(e.target.value)}
            // error={Boolean(amenityidError)}
            // helperText={amenityidError}

            size="small"
            onChange={(e) => setamenityid(e.target.value)}
            // error={Boolean(amenityidError)}
            // helperText={amenityidError}
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <label className="thumbnail">Amenity Name</label>
          <TextField
            fullWidth
            label={
              <span>
                Amenity Name
                <RequiredAsterisk>*</RequiredAsterisk>
              </span>
            }

            size="small"
            onChange={(e) => setAmenityName(e.target.value)}
            error={Boolean(amenityNameError)}
            helperText={amenityNameError}
          />
        </Grid>

        {/* <Grid item xs={12} sm={6} md={6}>
          <label className="thumbnail">Description</label>
          <TextField
            fullWidth
            id="outlined-multiline-static"
            multiline
            rows={4}
            sx={{
              height: "78px",

              paddingTop: "10px",

              marginBottom: "80px",

              width: "100%",
            }}
          />
        </Grid> */}
        <Grid item xs={12} sm={6}>
          <label className="thumbnail">
            Icon<RequiredAsterisk>*</RequiredAsterisk>
          </label>
          <div>
            <Input
              type="file"
              onChange={handleFileChange}
              inputProps={{ accept: ".jpg,.png,.jpeg" }} // Specify accepted file types
              error={Boolean(iconError)}
            />
            {iconError && <span style={{ color: "red" }}>{iconError}</span>} 
            {/* {selectedFile && <p>Selected file: {selectedFile.name}</p>} */}
          </div>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControlLabel
            control={<ToggleSwitch checked={labelStatus} />}
            sx={{ marginLeft: "0", marginBottom: "16px" }}
            labelPlacement="top"
            label={labelName}
            onClick={handleChange}
          />
          <Button
            className="bookingbtn"
            onClick={handleSave}
            style={{ marginRight: "5px" }}
          >
            Save
          </Button>
          <Button className="bookingbtn1" onClick={handleClose}>
            Cancel
          </Button>
        </Grid>
      </Grid>
    </>
  );
};
