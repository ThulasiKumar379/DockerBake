import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { checkUserAccess } from "../../CheckUserAccess";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  EditNote,
  DoNotDisturbOn as DoNotDisturbOnIcon,
} from "@mui/icons-material";
import { red } from "@mui/material/colors";
import Table from "../Table";
import {
  Button,
  Grid,
  Box,
  TextField,
  Dialog,
  DialogContent,
  Tooltip,
  DialogTitle,
  DialogActions,
  FormControlLabel,
  Switch,
} from "@mui/material";
import AmenityForm from "./AmenityForm";
import {
  getAmenitiesData,
  updateAmenityData,
  deleteAmenityData,
} from "../../api/Amenities/amenitiesReducers";
import { styled } from "@mui/system";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
export const AmenityTable = () => {
  const [openedit, setOpenEdit] = React.useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [deleteamenityId, setDeleteamenityId] = useState(null);
  const handleClickOpen = (amenityid) => {
    setDeleteamenityId(amenityid);
    setOpenDelete(true);
  };
  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const [, setIsActive] = useState(false);
  const [amenityIdSearch, setamenityIdSearch] = useState("");
  const [amenityNameSearch, setAmenityNameSearch] = useState("");
  const [amenitystatusSearch, setAmenityStatusSearch] = useState("");
  const [filteroptions, setFilterOption] = useState(false);
  const amenityNameRef = useRef(null);


  const ImageCell = ({ row }) => {
    const { amenityid, amenityname, thumbnail_key } = row;
    return (
      <Tooltip title={amenityname}>
        <img
          src={`${process.env.REACT_APP_BASE_URL}/amenities/thumbnail?amenityid=${amenityid}&thumbnail_key=${thumbnail_key}`}
          style={{ width: "50px" }}
          alt="Icon"
        />
      </Tooltip>
    );
  };
  const [selectedFile, setSelectedFile] = useState(null);
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };
  const [rowData, setRowData] = useState(null);
  const dispatch = useDispatch();
  const AmenityData = useSelector((state) => state.amenities);
  const { amenities } = AmenityData;
  const [tableData, setTableData] = useState([]);
  const amenitiesData = amenities?.data;
  const FilteredData = (amenityid, amenityname) => {
    const filteredAmenities = amenitiesData.filter(
      (amenity) =>
        amenity.amenityid.toString().includes(amenityid) &&
        amenity.amenityname.toLowerCase().includes(amenityname.toLowerCase())
      // amenity.status.toString().includes(status)  
      // amenity.status.toLowerCase().includes(status.toLowerCase())
    );
    return filteredAmenities;
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const hasAccess = checkUserAccess("amenity")
  const hasAccessToEdit = checkUserAccess("edit_amenity")
  const hasAccessToDelete = checkUserAccess("delete_amenity")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
    window.location.reload();
  }

  useEffect(() => {
    dispatch(getAmenitiesData());
  }, [dispatch]);
  useEffect(() => {
    if (amenitiesData?.length > 0) {
      const newData = amenitiesData.map((d) => {
        const { amenityid, amenityname, status, thumbnail_key } = d;
        const constructData = {
          amenityid,
          amenityname,
          thumbnail_key,
          status: status ? "Active" : "Inactive",
        };
        return constructData;
      });
      setTableData(newData);
    }
  }, [amenitiesData]);
  useEffect(() => {
    if (amenityIdSearch === "" && amenityNameSearch === "" && filteroptions) {
      dispatch(getAmenitiesData());
    }
  }, [amenityIdSearch, amenityNameSearch, dispatch, filteroptions]);
  const filterIdHandler = (e) => {
    const value = e.target.value;
    setamenityIdSearch(value);
    if (value === "" && amenityNameSearch !== "") {
      setTableData(FilteredData(value, amenityNameSearch));
    } else {
      setTableData(FilteredData(value, amenityNameSearch, true));
      // setTableData(FilteredData(amenityidSearch, amenityNameSearch, amenitystatusSearch));
    }
    setFilterOption(true);
  };
  const filterNameHandler = (e) => {
    const value = e.target.value;
    setAmenityNameSearch(value);
    if (value === "" && amenityIdSearch !== "") {
      setTableData(FilteredData(amenityIdSearch, value));
    } else {
      setTableData(FilteredData(amenityIdSearch, value, true));
      // setTableData(FilteredData(amenityIdSearch, amenityNameSearch, amenitystatusSearch));
    }
    setFilterOption(true);
  };
  const filterStatusHandler = (e) => {
    const value = e.target.value;
    setAmenityStatusSearch(value);
    if (value === "" && amenityIdSearch !== "" && amenityNameSearch !== "") {
      setTableData(FilteredData(amenityIdSearch, amenityNameSearch, value));
    } else {
      // setTableData(FilteredData(amenityidSearch, amenityNameSearch, value, true));
      setTableData(FilteredData(amenityIdSearch, amenityNameSearch,));
    }
    setFilterOption(true);
  };
  const handleSearchClick = (amenityIdSearch, amenityNameSearch) => {
    if (amenityIdSearch === "" && amenityNameSearch === "") {
      setFilterOption(true);
    } else {
      setTableData(FilteredData(amenityIdSearch, amenityNameSearch));
    }
  };
  const handleClickEdit = (currentRow) => {
    setRowData(currentRow);
    setSelectedFile(null);

    setErrors({});
    setOpenEdit(true);
  };
  const [errors, setErrors] = useState({});
  const validateInputs = () => {
    const newErrors = {};
    if (!rowData || rowData.amenityname.trim() === "") {
      newErrors.amenityName = "Amenity Name should not be empty";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCloseedit = () => {
    setOpenEdit(false);
  };
  const handleEdit = (e) => {
    const { name, value } = e.target;
    setRowData({
      ...rowData,
      [name]: value,
    });
  };
  const handleEditUpdate = () => {
    const isValid = validateInputs();
     if(!rowData.amenityname){
      amenityNameRef.current.focus()
    }

    if (isValid) {
      const fd = new FormData();
      fd.append("thumbnail_key", selectedFile);
      fd.append("amenityname", rowData.amenityname);
      fd.append("amenityid", rowData.amenityid);
      // fd.append("status", rowData.status);
      fd.append("status", rowData.status ? 1 : 0);
      dispatch(updateAmenityData(fd))
        .then((data) => {
          if (data.payload.status) {
            dispatch(getAmenitiesData());
            setOpenEdit(false);
            setTimeout(() => {
              toast.success("Amenity updated successfully");
            }, 500);
          } else {
            setTimeout(() => {
              toast.error(data.payload.errorMessage);
            }, 500);
          }
        })
        .catch(() => {
          setTimeout(() => {
            toast.error("Failed to update amenity");
          }, 500);
        });
      setOpenEdit(false);
    }
  };

  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const onDelete = async (currentRow) => {
    try {
      const data = await dispatch(deleteAmenityData(currentRow));
      if (data.payload.status) {
        dispatch(getAmenitiesData());
        setTimeout(() => {
          toast.success("Amenity deactivated  successfully");
        }, 500);
      } else {
        setTimeout(() => {
          toast.error(data.message);
        }, 500);
      }
    } catch (error) {
      setTimeout(() => {
        toast.error("Failed to deactivate Amenity");
      }, 500);
    }
  };
  const handleDeleteConfirmation = () => {
    setOpenDelete(false);
    if (deleteamenityId) {
      onDelete(deleteamenityId);
    }
  };
  const ToggleSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const columns = [
    {
      field: "amenityid",
      headerName: "ID",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "amenityname",
      headerName: "Amenity Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "thumbnail",
      headerName: "Icons",
      sortable: false,
      headerClassName: "super-app-theme--header",
      flex: 1,
      width: 200,
      minWidth: 200,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => <ImageCell row={params.row} />,
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return <span>{status}</span>;
      },
    },
    {
      field: "Operations",
      headerName: "Operations",
      headerClassName: "super-app-theme--header",
      sortable: false,
      flex: 1,
      width: 150,
      minWidth: 150,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        let buttonColor;
        let isDisabled = false;
        if (currentRow.status) {
          buttonColor = red[700];
        } else {
          buttonColor = red[700];
          isDisabled = true;
        }
        return (
          <Box display="flex" alignItems="center"
            sx={{ overflowX: "auto", color: isDisabled ? "lightgray" : "inherit" }}>
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleClickEdit(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title="Deactivate">
                <DoNotDisturbOnIcon
                  variant="contained"
                  size="small"
                  sx={{
                    minWidth: "32px",
                    color: currentRow?.status === "Inactive" ? "success" : buttonColor,
                    pointerEvents: currentRow?.status === "Inactive" ? "none" : "auto",
                    opacity: currentRow?.status === "Inactive" ? 0.2 : 1,
                  }}
                  disabled={currentRow?.status === "Inactive"}
                  onClick={() =>
                    handleClickOpen(currentRow.amenityid)
                  }
                />
              </Tooltip>
            )}
          </Box>
        );
      },
    },
  ];
  return (
    <>
      <Dialog open={openedit}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",
            paddingBottom: "10px",
            marginBottom: "14px",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <>Edit Amenity</>
            <Button onClick={handleCloseedit} sx={{ color: "black" }}>
              X
            </Button>
          </div>
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ marginTop: "0" }}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                autoFocus
                label={<div>
                  Amenity ID <RequiredAsterisk>*</RequiredAsterisk>
                </div>}
                name="amenityid"
                size="small"
                InputProps={{
                  readOnly: true,
                }}
                value={rowData && rowData.amenityid}
                onChange={(e) => handleEdit(e)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                name="amenityname"
                label={
                  <div>
                    Amenity Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                value={rowData && rowData.amenityname}
                inputRef={amenityNameRef}
                onChange={(e) => {
                  handleEdit(e);
                  setErrors((prevErrors) => ({
                    ...prevErrors,
                    amenityName: "",
                  }));
                  if (e.target.value.length < 2) {
                    setErrors((prevErrors) => ({
                      ...prevErrors,
                      amenityName: "Min 2 characters required.",
                    }));
                  } else if (e.target.value.length > 120) {
                    setErrors((prevErrors) => ({
                      ...prevErrors,
                      amenityName: "Max 120 characters allowed.",
                    }));
                  }
                }}
                error={!!errors.amenityName}
                helperText={errors.amenityName}
              />

            </Grid>
            <Grid item xs={12} sm={6}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <label
                  className="thumbnail"
                  style={{ marginRight: "4px", marginTop: "24px" }}
                >
                  Icon:
                  <RequiredAsterisk>*</RequiredAsterisk>
                  {!selectedFile && rowData && (
                    <Tooltip>
                      <img
                        src={`${process.env.REACT_APP_BASE_URL}/amenities/thumbnail?amenityid=${rowData.amenityid}&thumbnail_key=${rowData.thumbnail_key}`}
                        style={{
                          width: "50px",
                          marginLeft: "10px",
                          padding: "0px",
                          marginBottom: "0px",
                        }}
                        alt="Existing Icon"
                      />
                    </Tooltip>
                  )}
                  {selectedFile && (
                    <img
                      src={URL.createObjectURL(selectedFile)}
                      style={{
                        width: "50px",
                        marginLeft: "10px",
                        padding: "0px",
                        marginBottom: "0px",
                      }}
                      alt="Selected Icon"
                    />
                  )}
                </label>
                <Button
                  variant="outlined"
                  component="label"
                  style={{ marginTop: "24px" }}
                  sx={{ textTransform: "none" }}
                >
                  Choose Icon
                  <input
                    type="file"
                    onChange={handleFileChange}
                    style={{ display: "none" }}
                    accept=".jpg,.png,.jpeg"
                  />
                </Button>
              </div>
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              sx={{
                display: "flex",
                justifyContent: "end",
                alignItems: "end",
              }}
            >
              <FormControlLabel
                control={
                  <ToggleSwitch
                    checked={(rowData?.status == true || rowData?.status == 'Active') ? true : false}
                    onChange={handleToogleChange}
                  />
                }
                label={(rowData?.status == true || rowData?.status == 'Active') ? "Active" : "Inactive"}
                sx={{
                  marginLeft: "0px",
                  marginBottom: "0",
                  marginRight: "10px",
                }}
                labelPlacement="top"
              />
              <Button
                className="bookingbtn"
                onClick={handleEditUpdate}
                style={{
                  marginRight: "5px",
                  marginTop: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
              >
                Update
              </Button>
              <Button
                className="bookingbtn1"
                onClick={handleCloseedit}
                sx={{
                  fontSize: "0.75rem",
                  marginTop: "10px",
                  textTransform: "capitalize",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
      <Dialog open={opendelete} onClose={handleCloseDelete}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",
            paddingBottom: "10px",
            marginBottom: "14px",
            fontSize: "1rem",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <>Deactivate Amenity</>
            <Button onClick={handleCloseDelete}>X</Button>
          </div>
        </DialogTitle>
        <DialogContent sx={{ color: "black" }}>
          Are you sure you want to deactivate this Amenity?
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            className="bookingbtn"
            onClick={handleDeleteConfirmation}
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
              marginRight: "10px",
            }}
          >
            Deactivate
          </Button>
          <Button
            variant="outlined"
            className="bookingbtn1"
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
            }}
            onClick={handleCloseDelete}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      <div>
        <div style={{ marginBottom: "3%" }}>
          <AmenityForm
            amenityIdSearch={amenityIdSearch}
            amenityNameSearch={amenityNameSearch}
            amenitystatusSearch={amenitystatusSearch}
            onSearch={handleSearchClick}
            filterIdHandler={filterIdHandler}
            filterNameHandler={filterNameHandler}
            filterStatusHandler={filterStatusHandler}
          />
        </div>
        <Table
          data={tableData}
          columns={columns}
          id="amenityid"
          handleClickOpen={handleClickOpen}
        />
      </div>
    </>
  );
};
