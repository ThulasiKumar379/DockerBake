import React, { useState, useEffect, useRef } from "react";
import { checkUserAccess } from "../../CheckUserAccess";
import {
  Box,
  Grid,
  TextField,
  Button,
  Typography,
  Dialog,
  DialogContent,
  DialogTitle,
  Tooltip,
  FormControlLabel,
  Switch,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import { useDispatch } from "react-redux";
import {
  Add as AddIcon,
  Search as SearchIcon,
  //FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import { styled } from "@mui/system";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  createAmenityData,
  getAmenitiesData,
} from "../../api/Amenities/amenitiesReducers";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
export default function AmenitiesMasterForm({
  onSearch,
  filterIdHandler,
  filterNameHandler,
  // filterStatusHandler,
  amenityIdSearch,
  amenityNameSearch,
  // amenitystatusSearch,
  // handleClicksearch,
}) {
  const [openadd, setOpenAdd] = React.useState(false);
  const [fullWidth] = React.useState(true);
  const [maxWidth] = React.useState("sm");
  const amenityIdRef = useRef(null);
  const amenityNameRef = useRef(null);
  const [amenityId, setamenityId] = useState("");
  const [amenityName, setAmenityName] = useState("");
  // const [amenitystatusSearch, setamenitystatusSearch] = useState("");
  const [iconError, setIconError] = useState("");

  const [errors, setErrors] = useState({});
  const validateInputs = () => {
    const newErrors = {};
    if (amenityId.trim() === "") {
      newErrors.amenityId = "Amenity ID is required";
    }
    if (amenityName.trim() === "") {
      newErrors.amenityName = "Amenity Name is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const hasAccess = checkUserAccess("amenity")
  const hasAccessToCreate = checkUserAccess("add_amenity")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getAmenitiesData());
  }, [dispatch]);

  const resetForm = () => {
    setAmenityName("");
    setamenityId("")
    // setamenitystatusSearch("");
    setIconError("");
    setSelectedFile(null);
    setlabelStatus(false);
    setErrors({});
  };
  const handleSave = async () => {
    setIconError("");
    const isValid = validateInputs();

    if (!amenityId) {
      amenityIdRef.current.focus()
    }else if(!amenityName){
      amenityNameRef.current.focus()
    }


    if (!selectedFile) {
      setIconError("Icon is required");
      return;
    }

    const allowedFormats = ["image/jpeg", "image/jpg", "image/png"];
    if (!allowedFormats.includes(selectedFile.type)) {
      setIconError("Only JPG, JPEG, or PNG formats allowed");
      return;
    }

    if (isValid) {
      const fd = new FormData();
      fd.append("thumbnail_key", selectedFile);
      fd.append("amenityname", amenityName);
      fd.append("amenityid", amenityId);
      fd.append("status", labelStatus);

      await dispatch(createAmenityData(fd))
        .then((data) => {
          console.log(data);
          if (data.payload.status) {
            dispatch(getAmenitiesData());
            setTimeout(() => {
              toast.success("Amenity Created Successfully");
            }, 500);
          } else {
            setTimeout(() => {
              toast.error(data.payload.errorMessage);
            }, 500);
          }
        })
        .catch((error) => {
          setTimeout(() => {
            toast.error("Failed to Create Amenity");
          }, 500);
        });

      setOpenAdd(false);
      resetForm();
      setlabelStatus(true);
    }
  };

  const [labelStatus, setlabelStatus] = useState(true);
  const labelName = labelStatus ? "Active" : "Inactive";
  const changeHandle = () => {
    setlabelStatus(!labelStatus);
  };
  const [selectedFile, setSelectedFile] = useState(null);
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    setIconError("");
  };

  const handleClickadd = () => {
    setOpenAdd(true);
  };
  const handleCloseadd = () => {
    setOpenAdd(false);
    resetForm();
    setlabelStatus(true);
  };
  const handleClicksearch = () => {
    onSearch(amenityIdSearch, amenityNameSearch);
  };

  const ToggleSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    <>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={true}
        draggable={true}
      />
      <Dialog open={openadd} fullWidth={fullWidth} maxWidth={maxWidth}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",
            paddingBottom: "10px",
            marginBottom: "14px",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <>Add Amenity</>
            <Button onClick={handleCloseadd} sx={{ color: "black" }}>
              X
            </Button>
          </div>
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ marginTop: "0" }}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                autoFocus
                id="amenityid"
                name="amenity_id"
                value={amenityId}
                label={
                  <span>
                    Amenity ID <RequiredAsterisk>*</RequiredAsterisk>
                  </span>
                }
                size="small"
                inputRef={amenityIdRef}
                onChange={(e) => {
                  setamenityId(e.target.value);

                  setErrors((prevErrors) => ({
                    ...prevErrors,
                    amenityId: "",
                  }));

                  if (e.target.value.length < 1 || e.target.value.length > 120) {
                    setErrors((prevErrors) => ({
                      ...prevErrors,
                      amenityId: "Amenity ID must be between 1 and 120 characters.",
                    }));
                  }
                }}
                error={!!errors.amenityId}
                helperText={errors.amenityId}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="amenityname"
                name="amenityname"
                value={amenityName}
                label={
                  <span>
                    Amenity Name <RequiredAsterisk>*</RequiredAsterisk>
                  </span>
                }
                size="small"
                inputRef={amenityNameRef}
                onChange={(e) => {
                  setAmenityName(e.target.value);

                  setErrors((prevErrors) => ({
                    ...prevErrors,
                    amenityName: "",
                  }));

                  if (e.target.value.length < 2 || e.target.value.length > 120) {
                    setErrors((prevErrors) => ({
                      ...prevErrors,
                      amenityName: "Amenity Name must be between 2 and 120 characters.",
                    }));
                  }
                }}
                error={!!errors.amenityName}
                helperText={errors.amenityName || ""}
              /> 
            </Grid>

            <Grid item xs={12} sm={6}>
              <div style={{ display: "flex", alignItems: "center" }}>
                <label
                  className="thumbnail"
                  style={{ marginRight: "10px", marginTop: "25px" }}
                >
                  Icon:<RequiredAsterisk>*</RequiredAsterisk>
                  {selectedFile && (
                    <Tooltip>
                      <img
                        src={URL.createObjectURL(selectedFile)}
                        style={{
                          width: "50px",
                          padding: "0px",
                          marginLeft: "10px",
                          marginBottom: "0px",
                        }}
                        alt="Selected Icon"
                      />
                    </Tooltip>
                  )}
                </label>
                <Button
                  variant="outlined"
                  component="label"
                  error={Boolean(iconError)}
                  style={{ marginTop: "25px" }}
                  sx={{ textTransform: "none" }}
                >
                  Choose Icon
                  <input
                    type="file"
                    onChange={handleFileChange}
                    style={{ display: "none" }}
                    accept=".jpg,.png,.jpeg"
                  />
                </Button>
              </div>
              {iconError && (
                <span
                  style={{
                    color: "red",
                    fontSize: "13px",
                    textTransform: "capitalize",
                    marginLeft: "0px",
                  }}
                >
                  {iconError}
                </span>
              )}
            </Grid>

            <Grid item
              xs={12}
              sm={6}
              sx={{
                display: "flex",
                justifyContent: "end",
                alignItems: "end",
              }}>
              <FormControlLabel
                control={<ToggleSwitch checked={labelStatus} />}
                sx={{ marginLeft: "0", marginBottom: "0", marginRight: "10px" }}
                labelPlacement="top"
                label={labelName}
                onClick={changeHandle}
              />
              <Button
                className="bookingbtn"
                onClick={handleSave}
                style={{
                  marginTop: "10px",
                  marginRight: "5px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
              >
                Save
              </Button>
              <Button
                className="bookingbtn1"
                onClick={handleCloseadd}
                sx={{
                  fontSize: "0.75rem",
                  marginTop: "10px",
                  textTransform: "capitalize",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
      <Box mt={2} ml={2}>
        <div>
          <Grid container spacing={1}>
            <Grid item xs={12} sm={8} md={9} lg={10}>
              <Typography
                variant="h4"
                sx={{ marginBottom: "20px", fontWeight: "600" }}
              >
                Amenities
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4} md={3} lg={2} className="noPadding">
              {hasAccessToCreate.exists && (
                <Button
                  fullWidth
                  variant="contained"
                  onClick={handleClickadd}
                  sx={{
                    padding: "10px 0",
                    backgroundColor: "#0B78A1 !important",
                    borderRadius: 0,
                    fontSize: "0.75rem !important",
                    lineHeight: "1.125rem",
                    letterSpacing: 0,
                    marginBottom: "15px",
                  }}
                  startIcon={<AddIcon />}
                >
                  Add New Amenity
                </Button>
              )}
            </Grid>
          </Grid>
          {/* <Accordion
            sx={{
              backgroundColor: "#3E0BA1",
              color: "#fff",
              margin: "0 0 15px !important",
              borderRadius: "0 !important",
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
              aria-controls="panel1a-content"
              id="panel1a-header"
              sx={{
                minHeight: "48px !important",
                "& .Mui-expanded": {
                  margin: "12px 0 !important",
                },
              }}
            >
              <Typography>
                <FilterAltIcon /> Filter
              </Typography>
            </AccordionSummary>
            <AccordionDetails
              sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
            > */}
          {/* <Box> */}
          {/* <Grid container spacing={1}>
                  <Grid item xs={12} sm={6} md={4} lg={2}>
                    <TextField
                      label="Amenity Id"
                      value={amenityIdSearch}
                      onChange={(e) => filterIdHandler(e)}
                      name="amenityid"
                      fullWidth
                      size="small"
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                        marginBottom: "10px",
                      }}
                      InputLabelProps={{
                        sx: {
                          color: "#2c2c2c",
                          "&.Mui-focused": { color: "#2c2c2c" },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={2}>
                    <TextField
                      label="Amenity Name"
                      fullWidth
                      size="small"
                      value={amenityNameSearch}
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                        marginBottom: "10px",
                      }}
                      name="amenity name "
                      onChange={(e) => filterNameHandler(e)}
                    />
                  </Grid>
                </Grid> */}
          {/* <Grid container spacing={1} sx={{ justifyContent: "end" }}>
                  <Grid item xs={12} sm={4} md={3} lg={2}>
                    <Button
                      variant="contained"
                      fullWidth
                      onClick={handleClicksearch}
                      sx={{
                        padding: "10px 0",
                        backgroundColor: "#3E0BA1 !important",
                        borderRadius: 0,
                        fontSize: "0.75rem !important",
                        lineHeight: "1.125rem",
                        letterSpacing: 0,
                      }}
                      startIcon={<SearchIcon />}
                    >
                      search
                    </Button>
                  </Grid>
                </Grid>
              {/* </Box> */}
          {/* </AccordionDetails>
          </Accordion> */}
        </div>
      </Box>
    </>
  );
}
