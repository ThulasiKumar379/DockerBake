import React, { Fragment, useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { checkUserAccess } from "../../CheckUserAccess";
import {
  Typography,
  Autocomplete,
  Box,
  Grid,
  Tooltip,
  TextField,
  Button,
  Container,
  Switch,
  Dialog,
  DialogTitle,
  DialogContent,
  FormControlLabel,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import {
  Add as AddIcon,
  Search as SearchIcon,
  // FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import {
  createRoomServiceData,
  fetchRoomServiceData,
} from "../../api/RoomService/roomServiceReducers";

const ToggleSwitch = styled((props) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 55,
  height: 25,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(30px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 21,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#ffff",
      border: "6px solid #fff",
    },
    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 21,
    height: 21,
  },
  "& .MuiSwitch-track": {
    borderRadius: 34 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
  },
}));

const RoomService = ({
  onSearch,
  filterIdHandler,
  filterNameHandler,
  serviceIdSearch,
  serviceNameSearch,
}) => {
  const [openAdd, setOpenAdd] = React.useState(false);
  const [fullWidth] = React.useState(true);
  const [maxWidth] = React.useState("sm");
  const [serviceId, setServiceId] = useState("");
  const [serviceName, setServiceName] = useState("");
  const [errors, setErrors] = useState({});
  const [iconError, setIconError] = useState("");
  const serviceIdRef = useRef(null);
  const serviceNameRef = useRef(null);


  const validateInputs = () => {
    const newErrors = {};
    if (serviceId.trim() === "") {
      newErrors.serviceId = "Minimum 1 Character is Required";
    }
    if (serviceName.trim() === "") {
      newErrors.serviceName = "Service Name is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const [selectedFile, setSelectedFile] = useState(null);

  const [labelStatus, setlabelStatus] = useState(true);

  const labelName = labelStatus ? "Active" : "Inactive";

  const changeHandle = () => {
    setlabelStatus(!labelStatus);
  };
  const handleSearch = () => {
    console.log("Search Clicked!");
    onSearch(serviceIdSearch, serviceNameSearch);
  };
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    setIconError("");
  };

  const hasAccess = checkUserAccess("room_service")
  const hasAccessToCreate = checkUserAccess("add_room_service")
  const hasAccessToEdit = checkUserAccess("edit_room_service")
  const hasAccessToDelete = checkUserAccess("delete_room_service")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }
  const dispatch = useDispatch();

  const handleSave = async () => {
    setIconError("");
    const isValid = validateInputs();
     if (!serviceId) {
      serviceIdRef.current.focus()
    }else if(!serviceName){
      serviceNameRef.current.focus()
    }
    if (!selectedFile) {
      setIconError("Icon is required");
      return;
    }

    const allowedFormats = ["image/jpeg", "image/jpg", "image/png"];
    if (!allowedFormats.includes(selectedFile.type)) {
      setIconError("Only JPG, JPEG, or PNG formats allowed");
      return;
    }

    if (isValid) {
      const fd = new FormData();
      fd.append("room_service_id", serviceId);
      fd.append("service_icon", selectedFile);
      fd.append("room_service_name", serviceName);
      fd.append("status", labelStatus);

      await dispatch(createRoomServiceData(fd))
        .then((data) => {
          console.log(data);

          if (data.payload.status) {
            dispatch(fetchRoomServiceData());
            setTimeout(() => {
              toast.success("Room Service Created Successfully");
            }, 500);
          } else {
            setTimeout(() => {
              toast.error(data.payload.errorMessage);
            }, 500);
          }
        })
        .catch((error) => {
          setTimeout(() => {
            toast.error("Failed to create service");
          }, 500);
        });

      setOpenAdd(false);
      setServiceId("");
      setServiceName("");
      setSelectedFile(null);
      setlabelStatus(true);
    }
  };


  // const handleSave = async () => {
  //   setIconError("");

  //   const isValid = validateInputs();

  //   if (!selectedFile) {
  //     setIconError("Icon is required");
  //     return;
  //   }

  //   if (isValid) {
  //     const fd = new FormData();
  //     fd.append("room_service_id", serviceId); 
  //     fd.append("service_icon", selectedFile);
  //     fd.append("room_service_name", serviceName);
  //     fd.append("status", labelStatus ? "Active" : "Inactive");

  //     try {
  //       const data = await dispatch(createRoomServiceData(fd));

  //       if (data.payload.status) {
  //         dispatch(fetchRoomServiceData());
  //         setTimeout(() => {
  //           toast.success("Room service created successfully");
  //         }, 500);
  //       } else {
  //         setTimeout(() => {
  //           toast.error(data.payload.errorMessage);
  //         }, 500);
  //       }
  //     } catch (error) {
  //       setTimeout(() => {
  //         toast.error("Failed to create service");
  //       }, 500);
  //     }

  //     setOpenAdd(false);
  //     setServiceId("");
  //     setServiceName("");
  //     setSelectedFile(null);
  //     setlabelStatus(true);
  //   }
  // };

  useEffect(() => {
    if (!openAdd) {
      setErrors({});
      setIconError("");
    }
  }, [openAdd]);

  const handleClickadd = () => {
    setOpenAdd(true);
  };

  const handleCloseadd = () => {
    setOpenAdd(false);
    setServiceId("");
    setServiceName("");
    setSelectedFile(null);
    setlabelStatus(true);
  };
  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const RoomServiceData = useSelector((state) => state.roomService);
  console.log("darab", { RoomServiceData });

  return (
    <Fragment>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Container maxWidth="xl" sx={{ padding: "0 !important" }}>
        <Box sx={{ bgcolor: "#fff" }}>
          <Grid container spacing={1} sx={{ marginBottom: "20px" }}>
            <Grid item xs={12} sm={8} md={9} lg={10}>
              <Typography variant="h4" sx={{ fontWeight: "600" }}>
                Room Service
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4} md={3} lg={2} className="noPadding">
              {hasAccessToCreate.exists && (
                <Button
                  fullWidth
                  variant="contained"
                  sx={{
                    padding: "10px 0",
                    backgroundColor: "#0B78A1 !important",
                    borderRadius: 0,
                    fontSize: "0.75rem !important",
                    lineHeight: "1.125rem",
                    letterSpacing: 0,
                  }}
                  onClick={handleClickadd}
                  startIcon={<AddIcon />}
                >
                  Add New Service
                </Button>
              )}
            </Grid>
          </Grid>
          {/* <Box sx={{ marginBottom: "20px", borderRadius: "0 !important" }}>
            <Accordion
              sx={{
                backgroundColor: "#3E0BA1",
                color: "#fff",
                margin: "0 0 15px !important",
                borderRadius: "0 !important",
              }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
                aria-controls="panel1a-content"
                id="panel1a-header"
                sx={{
                  minHeight: "48px !important",
                  "& .Mui-expanded": {
                    margin: "12px 0 !important",
                  },
                }}
              >
                <Typography>
                  <FilterAltIcon /> Filter
                </Typography>
              </AccordionSummary>
              <AccordionDetails
                sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
              >
                <Grid container spacing={1}>
                  <Grid item xs={12} sm={6} md={4} lg={2}>
                    <Autocomplete
                      size="small"
                      fullWidth
                      disablePortal
                      id="combo-box-demo"
                      onChange={(e, v) =>
                        filterIdHandler(e, v, "room_service_id")
                      }
                      options={RoomServiceData?.roomservice?.service ?? []}
                      getOptionLabel={(option) => option.room_service_id}
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",

                          borderRadius: 0,
                        },

                        marginBottom: "10px",
                      }}
                      renderInput={(params) => (
                        <TextField {...params} label="ID" />
                      )}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={2}>
                    <Autocomplete
                      size="small"
                      fullWidth
                      disablePortal
                      id="combo-box-demo"
                      onChange={(e, v) =>
                        filterNameHandler(e, v, "room_service_name")
                      }
                      options={RoomServiceData?.roomservice?.service ?? []}
                      getOptionLabel={(option) => option.room_service_name}
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                        marginBottom: "15px",
                      }}
                      renderInput={(params) => (
                        <TextField {...params} label="Services" />
                      )}
                    />
                  </Grid>
                </Grid>
                <Grid container spacing={1} sx={{ justifyContent: "end" }}>
                  <Grid item xs={12} sm={4} md={3} lg={2}>
                    <Button
                      fullWidth
                      variant="contained"
                      onClick={handleSearch}
                      sx={{
                        padding: "10px 0",
                        backgroundColor: "#3E0BA1 !important",
                        borderRadius: 0,
                        fontSize: "0.75rem !important",
                        lineHeight: "1.125rem",
                        letterSpacing: 0,
                      }}
                      startIcon={<SearchIcon />}
                    >
                      Search
                    </Button>
                  </Grid>
                </Grid>
              </AccordionDetails>
            </Accordion>
          </Box> */}
        </Box>

        <Box>
          <Dialog open={openAdd} fullWidth={fullWidth} maxWidth={maxWidth}>
            <DialogTitle
              sx={{
                borderBottom: "1px solid #e9ecef",
                paddingBottom: "10px",
                marginBottom: "14px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <>Add Room Services</>

                <CloseIcon onClick={handleCloseadd} />
              </div>
            </DialogTitle>

            <DialogContent>
              <Grid container spacing={2} sx={{ alignItems: "flex-end" }}>
                <Grid item xs={12} sm={6}>
                <TextField
                    fullWidth
                    autoFocus
                    id="room_service_id"
                    name="room_service_id"
                    value={serviceId}
                    label={
                      <span>
                        Service ID
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    size="small"
                    inputRef={serviceIdRef}
                    onChange={(e) => {
                      setServiceId(e.target.value);
    
                      setErrors((prevErrors) => ({
                        ...prevErrors,
                        serviceId: "",
                      }));
                    }}
                    error={!!errors.serviceId}
                    helperText={errors.serviceId}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <label style={{ visibility: "hidden" }}>Service Name</label>
                  <TextField
                    fullWidth
                    id="service_name"
                    name="service_name"
                    value={serviceName}
                    label={
                      <span>
                        Service Name <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    size="small"
                    inputRef={serviceNameRef}
                    onChange={(e) => {
                      setServiceName(e.target.value);

                      setErrors((prevErrors) => ({
                        ...prevErrors,
                        serviceName: "",
                      }));

                      if (e.target.value.length < 2) {
                        setErrors((prevErrors) => ({
                          ...prevErrors,
                          serviceName: "Min 2 characters required.",
                        }));
                      } else if (e.target.value.length > 120) {
                        setErrors((prevErrors) => ({
                          ...prevErrors,
                          serviceName: "Max 120 characters allowed.",
                        }));
                      }
                    }}
                    error={!!errors.serviceName}
                    helperText={errors.serviceName || ""}
                  /> 
                </Grid>

                <Grid item xs={12} sm={6}>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <label
                      className="thumbnail"
                      style={{ marginRight: "15px", marginBottom: "14px" }}
                    >
                      Icon:<RequiredAsterisk>*</RequiredAsterisk>
                      {selectedFile && (
                        <Tooltip>
                          <img
                            src={URL.createObjectURL(selectedFile)}
                            style={{
                              width: "50px",
                              padding: "0px",
                              marginLeft: "10px",
                              marginBottom: "0px",
                            }}
                            alt="Selected Icon"
                          />
                        </Tooltip>
                      )}
                    </label>
                    <Button
                      variant="outlined"
                      component="label"
                      error={Boolean(iconError)}
                      style={{ marginBottom: "14px" }}
                      sx={{ textTransform: "none" }}
                    >
                      Choose Icon
                      <input
                        type="file"
                        onChange={handleFileChange}
                        style={{ display: "none" }}
                        accept=".jpg,.png,.jpeg"
                      />
                    </Button>
                  </div>
                  {iconError && (
                    <span
                      style={{
                        color: "red",
                        fontSize: "13px",
                        textTransform: "capitalize",
                        marginLeft: "0px",
                      }}
                    >
                      {iconError}
                    </span>
                  )}
                </Grid>

                <Grid item
                  xs={12}
                  sm={6}
                  sx={{
                    display: "flex",
                    justifyContent: "end",
                    alignItems: "end",
                  }}>
                  <FormControlLabel
                    control={<ToggleSwitch checked={labelStatus} />}
                    sx={{
                      marginLeft: "0",

                      marginTop: "15px",

                      marginBottom: "3px",

                      width: "50px",
                    }}
                    label={labelName}
                    onClick={changeHandle}
                    labelPlacement="top"
                  />

                  <Button
                    className="bookingbtn"
                    onClick={handleSave}
                    style={{
                      marginTop: "10px",
                      marginRight: "5px",
                      fontSize: "0.75rem",

                      textTransform: "capitalize",
                    }}
                  >
                    Save
                  </Button>

                  <Button
                    className="bookingbtn1"
                    onClick={handleCloseadd}
                    sx={{
                      fontSize: "0.75rem",
                      marginTop: "10px",
                      textTransform: "capitalize",
                    }}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </DialogContent>
          </Dialog>
        </Box>
      </Container>

      <Container maxWidth="xl" sx={{ padding: "0 !important" }}></Container>
    </Fragment>
  );
};

export default RoomService;
