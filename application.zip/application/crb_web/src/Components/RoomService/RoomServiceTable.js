import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import RoomService from "./RoomService";
import { red } from "@mui/material/colors";
import Table from "../Table";
import {
  Button,
  Grid,
  Box,
  TextField,
  Dialog,
  DialogContent,
  Tooltip,
  DialogTitle,
  DialogActions,
  FormControlLabel,
  Switch,
} from "@mui/material";
import {
  fetchRoomServiceData,
  updateRoomServiceData,
  deleteRoomServiceData,
} from "../../api/RoomService/roomServiceReducers";
import { styled } from "@mui/system";
import {
  EditNote,
  Close as CloseIcon,
  DoNotDisturbOn as DoNotDisturbOnIcon,
} from "@mui/icons-material";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const RoomServiceTable = () => {
  const [openedit, setOpenEdit] = React.useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [filteroptions, setFilterOption] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [serviceIdSearch, setserviceIdSearch] = useState("");
  const [serviceNameSearch, setserviceNameSearch] = useState("");
  const [deleteServiceId, setDeleteServiceId] = useState(null);
  const RoomServiceData = useSelector((state) => state.roomService);
  const [, setIsActive] = useState(false);
  const serviceNameRef = useRef(null);
  const dispatch = useDispatch();
  const RoomFilterData = RoomServiceData?.roomservice?.service;
  const FilteredData = (room_service_id, room_service_name) => {
    const filteredServices = RoomFilterData.filter(
      (roomsfilter) =>
        roomsfilter?.room_service_id.toString().includes(room_service_id) &&
        roomsfilter?.room_service_name
          ?.toLowerCase()
          .includes(room_service_name?.toLowerCase())
    );
    return filteredServices;
  };
  useEffect(() => {
    dispatch(fetchRoomServiceData());
  }, [dispatch]);

  useEffect(() => {
    if (RoomFilterData?.length > 0) {
      const newData = RoomFilterData.map((d) => {
        const { room_service_id, room_service_name, status, service_icon } = d;
        const constructData = {
          room_service_id,
          room_service_name,
          service_icon,
          status: status ? "Active" : "Inactive",
        };
        return constructData;
      });
      setTableData(newData);
    }
  }, [RoomFilterData]);

  const handleClickOpen = (room_service_id) => {
    setDeleteServiceId(room_service_id);
    setOpenDelete(true);
  };
  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const [serviceName, setServiceName] = useState("");

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const ImageCell = ({ row }) => {
    const { room_service_id, room_service_name, service_icon } = row;

    return (
      <Tooltip title={room_service_name}>
        <img
          src={`${process.env.REACT_APP_BASE_URL}/roomservice/geticon?room_service_id=${room_service_id}&service_icon=${service_icon}`}
          style={{ width: "50px" }}
          alt="icon"
        />
      </Tooltip>
    );
  };

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const [rowData, setRowData] = useState("");

  console.log({ RoomServiceData });

  useEffect(() => {
    if (serviceIdSearch === "" && serviceNameSearch === "" && filteroptions) {
      dispatch(fetchRoomServiceData());
    }
  }, [serviceIdSearch, serviceNameSearch, dispatch, filteroptions]);
  const filterIdHandler = (e, v) => {
    const val = v === null ? e?.target?.value : v.room_service_id;
    setserviceIdSearch(val);

    if (val === "" && serviceNameSearch !== "") {
      setTableData(FilteredData(val, serviceNameSearch));
    } else {
      setTableData(FilteredData(val, serviceNameSearch, true));
    }
  };

  const filterNameHandler = (e, v) => {
    const val = v === null ? e?.target?.value : v.room_service_name;
    setserviceNameSearch(val);

    if (val === "" && serviceIdSearch !== "") {
      setTableData(FilteredData(serviceIdSearch, val));
    } else {
      setTableData(FilteredData(serviceIdSearch, val, true));
    }
  };

  const handleSearchClick = (serviceIdSearch, serviceNameSearch) => {
    // if (serviceIdSearch === [] && serviceNameSearch === []) {
    //   setFilterOption(true);
    // } else {
    //   setTableData(FilteredData(serviceIdSearch, serviceNameSearch));
    // }
  };

  const handleClickEdit = (currentRow) => {
    setRowData(currentRow);

    setServiceName(currentRow.room_service_name);
    setSelectedFile(null);
    setErrors({});
    setOpenEdit(true);
  };

  const [errors, setErrors] = useState({});
  const handleCloseedit = () => {
    setIsActive(false);
    setOpenEdit(false);
  };

  const handleEdit = (e) => {
    const { name, value } = e.target;

    setRowData({
      ...rowData,

      [name]: value,
    });
  };
const validateInputs = () => {
  const newErrors = {};
  if (!rowData || !rowData.room_service_name.trim()) {
    newErrors.serviceName = "Service Name is required";
  }
  setErrors(newErrors);
  return Object.keys(newErrors).length === 0;
};

  const handleEditUpdate = () => {
    const isValid = validateInputs();
    if(!rowData.room_service_name){
      serviceNameRef.current.focus()
    }
    if (!isValid) {
    return;
  }

    const fd = new FormData();

    fd.append("service_icon", selectedFile);

    fd.append("room_service_name", rowData.room_service_name);

    fd.append("room_service_id", rowData.room_service_id);

    fd.append("status", rowData.status);

    dispatch(updateRoomServiceData(fd))
      .then((data) => {
        console.log({ data });

        if (data.payload.status) {
          dispatch(fetchRoomServiceData());
          setIsActive(false);
          setOpenEdit(false);
          setTimeout(() => {
            toast.success("service updated successfully");
          }, 500);
        } else {
          setOpenEdit(true);
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })

      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update servcie");
        }, 500);
      });

    setOpenEdit(false);
  };

  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status,
    }));
  };
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const onDelete = async (currentRow) => {
    try {
      console.log({ currentRow });

      const data = await dispatch(deleteRoomServiceData(currentRow));

      console.log({ data });

      if (data.payload.status) {
        dispatch(fetchRoomServiceData());

        setTimeout(() => {
          toast.success("Service deactivated successfully");
        }, 500);
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error("Failed to deactivate Servcie");
    }
  };

  const handleDeleteConfirmation = () => {
    setOpenDelete(false);

    if (deleteServiceId) {
      onDelete(deleteServiceId);
    }
  };

  const ToggleSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 42,

    height: 26,

    padding: 0,

    "& .MuiSwitch-switchBase": {
      padding: 0,

      margin: 2,

      transitionDuration: "300ms",

      "&.Mui-checked": {
        transform: "translateX(16px)",

        color: "#fff",

        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",

          opacity: 1,

          border: 21,
        },

        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },

      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",

        border: "6px solid #fff",
      },

      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },

    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",

      width: 22,

      height: 22,
    },

    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,

      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",

      opacity: 1,
    },
  }));

  const columns = [
    {
      field: "room_service_id",

      headerName: "ID",

      flex: 1,

      headerClassName: "super-app-theme--header",
      width: 120,
      minWidth: 120,
    },

    {
      field: "room_service_name",

      headerName: "Services",

      flex: 1,

      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "service_icon",

      headerName: "Icons",

      sortable: false,

      headerClassName: "super-app-theme--header",

      flex: 1,
      width: 150,
      minWidth: 150,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,

      renderCell: (params) => <ImageCell row={params.row} />,
    },

    {
      field: "status",

      headerName: "Status",

      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",

      renderCell: (params) => {
        const status = params.value;
        return <span>{status}</span>;
      },
    },

    {
      field: "Operations",

      headerName: "Operations",

      headerClassName: "super-app-theme--header",

      sortable: false,

      flex: 1,
      width: 150,
      minWidth: 150,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,

      renderCell: (params) => {
        const currentRow = params.row;
        let buttonColor;
        let isDisabled = false;
        if (currentRow.status) {
          buttonColor = red[700];
        } else {
          buttonColor = red[700];
          isDisabled = true;
        }

        return (
          <Box display="flex" alignItems="center">
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{
                  minWidth: "32px",
                }}
                onClick={() => handleClickEdit(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            <Tooltip title={currentRow?.status === "Inactive" ? "Activate" : "Deactivate"}>
              <DoNotDisturbOnIcon
                variant="contained"
                size="small"
                sx={{
                  minWidth: "32px",
                  color: currentRow?.status === "Inactive" ? "success" : buttonColor,
                  pointerEvents: currentRow?.status === "Inactive" ? "none" : "auto",
                  opacity: currentRow?.status === "Inactive" ? 0.2 : 1,
                }}
                disabled={currentRow?.status === "Inactive"}
                onClick={() =>
                  handleClickOpen(currentRow.room_service_id)
                }
              />
            </Tooltip>
          </Box>
        );
      },
    },
  ];

  return (
    <>
      <Dialog open={openedit}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",

            paddingBottom: "10px",

            marginBottom: "14px",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <>Edit Room Services</>
            <CloseIcon onClick={handleCloseedit} />
          </div>
        </DialogTitle>

        <DialogContent>
          <Grid container spacing={2} sx={{ marginTop: "0" }}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                autoFocus
                id="room_service_id"
                label={<div>
                  Service ID <RequiredAsterisk>*</RequiredAsterisk>
                </div>}
                name="room_service_id"
                size="small"
                InputProps={{
                  readOnly: true,
                }}
                value={rowData && rowData.room_service_id}
                onChange={(e) => handleEdit(e)}
              />
            </Grid> 
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="room_service_name"
                name="room_service_name"
                label={
                  <div>
                    Service Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                value={rowData && rowData.room_service_name}
                 inputRef={serviceNameRef}
                onChange={(e) => {
                  handleEdit(e);
                  setErrors((prevErrors) => ({
                    ...prevErrors,
                    serviceName: (e.target.value.length < 2 || e.target.value.length > 120) ? "Service Name must be between 2 and 120 characters." : "",
                  }));
                }}
                error={!!errors.serviceName}
                helperText={errors.serviceName || ""}
              /> 
            </Grid>

            <Grid item xs={12} sm={6}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <label
                  className="thumbnail"
                  style={{ marginRight: "4px", marginTop: "12px" }}
                >
                  Icon:
                  <RequiredAsterisk>*</RequiredAsterisk>
                  {!selectedFile && rowData && (
                    <Tooltip>
                      <img
                        src={`${process.env.REACT_APP_BASE_URL}/roomservice/geticon?room_service_id=${rowData.room_service_id}&service_icon=${rowData.service_icon}`}
                        style={{
                          width: "50px",
                          marginLeft: "10px",
                          padding: "0px",
                          marginBottom: "0px",
                        }}
                        alt="icon"
                      />
                    </Tooltip>
                  )}
                  {selectedFile && (
                    <img
                      src={URL.createObjectURL(selectedFile)}
                      style={{
                        width: "50px",
                        marginLeft: "10px",
                        padding: "0px",
                        marginBottom: "0px",
                      }}
                      alt="Selected Icon"
                    />
                  )}
                </label>

                <Button
                  variant="outlined"
                  component="label"
                  style={{ marginTop: "11px" }}
                  sx={{ textTransform: "none" }}
                >
                  Choose Icon
                  <input
                    type="file"
                    onChange={handleFileChange}
                    style={{ display: "none" }}
                    accept=".jpg,.png,.jpeg"
                  />
                </Button>
              </div>
            </Grid>

            <Grid
              item
              xs={12}
              sm={6}
              sx={{
                display: "flex",
                justifyContent: "end",
                alignItems: "end",
              }}
            >
              <FormControlLabel
                control={<ToggleSwitch checked={(rowData?.status == true || rowData?.status == 'Active') ? true : false} />}
                sx={{
                  marginLeft: "12px",
                  marginTop: "10px",
                  marginbottom: "4px",
                  width: "50px",
                }}
                labelPlacement="top"
                label={(rowData?.status == true || rowData?.status == 'Active') ? "Active" : "Inactive"}
                onChange={handleToogleChange}
              />

              <Button
                className="bookingbtn"
                onClick={handleEditUpdate}
                style={{
                  marginRight: "5px",
                  marginTop: "15px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
              >
                Update
              </Button>

              <Button
                className="bookingbtn1"
                onClick={handleCloseedit}
                sx={{
                  fontSize: "0.75rem",
                  marginTop: "15px",
                  textTransform: "capitalize",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>

      <Dialog open={opendelete} onClose={handleCloseDelete}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",
            paddingBottom: "10px",
            marginBottom: "14px",
            fontSize: "1rem",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <>Deactivate Service</>
            <Button onClick={handleCloseDelete}>X</Button>
          </div>
        </DialogTitle>

        <DialogContent sx={{ color: "black" }}>
          Are you sure you want to deactivate this Service?
        </DialogContent>

        <DialogActions>
          <Button
            variant="contained"
            className="bookingbtn"
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
              marginRight: "10px",
            }}
            onClick={handleDeleteConfirmation}
          >
            Deactivate
          </Button>

          <Button
            variant="outlined"
            className="bookingbtn1"
            onClick={handleCloseDelete}
            sx={{ textTransform: "capitalize", fontSize: "0.75rem" }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      <div>
        <RoomService
          onSearch={handleSearchClick}
          filterIdHandler={filterIdHandler}
          filterNameHandler={filterNameHandler}
          serviceIdSearch={serviceIdSearch}
          serviceNameSearch={serviceNameSearch}
        />
        <Table
          data={tableData}
          columns={columns}
          id="room_service_id"
          handleClickOpen={handleClickOpen}
        />
      </div>
    </>
  );
};

export default RoomServiceTable;
