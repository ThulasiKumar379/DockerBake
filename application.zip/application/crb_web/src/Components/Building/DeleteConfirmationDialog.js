import React from "react";

import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";
import DoNotDisturbOnIcon from "@mui/icons-material/DoNotDisturbOn";
const DeleteConfirmationDialog = ({ open, handleClose, handleConfirm }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          borderBottom: "1px solid #e9ecef",
        }}
      >
        <DialogTitle>Deactivate</DialogTitle>
        <div style={{ textAlign: "right" }}>
          <Button onClick={handleClose}>X</Button>
        </div>
      </div>

      <DialogContent>
        <DialogContentText>
          Are you sure you want to Deactivate this building?
        </DialogContentText>
      </DialogContent>

      <DialogActions sx={{ paddingBottom: "15px" }}>
        <Button
          onClick={handleConfirm}
          className="bookingbtn"
          sx={{
            marginRight: "10px",
            marginTop: "10px",
            fontSize: "0.75rem",
            textTransform: "capitalize",
            color:"#d32f2f"
          }}
        >
          Deactivate

        </Button>
        <Button
          onClick={handleClose}
          className="bookingbtn1"
          sx={{
            marginTop: "10px",
            fontSize: "0.75rem",
            textTransform: "capitalize",
          }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteConfirmationDialog;
