import React, { useState, useEffect, useRef } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useSelector, useDispatch } from "react-redux";
import DeleteConfirmationDialog from "./DeleteConfirmationDialog";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { checkUserAccess } from "../../CheckUserAccess";
import {
  PersonAddAltOutlined as PersonAddAltOutlinedIcon,
  PersonRemoveOutlined as PersonRemoveOutlinedIcon,
} from "@mui/icons-material";
import { Tooltip } from "@mui/material";
import {
  CssBaseline,
  Box,
  Typography,
  Button,
  Stack,
  Modal,
  TextField,
  Grid,
  Autocomplete,
  Switch,
  FormControlLabel,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import {
  EditNote,
  Add as AddIcon,
  Search as SearchIcon,
  FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
  DoNotDisturbOn as DoNotDisturbOnIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import Table from "../Table";
import {
  getBuildingsData,
  updateBuildingData,
  createBuildingData,
  deleteBuildingData,
  fetchBuildingsData
} from "../../api/Building/buildingReducers";
import { fetchLocationsData } from "../../api/Location/locationReducer";
const labelClassess = {
  label: { style: { color: "#2c2c2c" } },
};
export default function SimpleContainer() {
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [selectedBuildingData, setSelectedBuildingData] = useState(true);
  const [open, setOpen] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [buildingIDError, setBuildingIDError] = useState(false);
  const [buildingError, setBuildingError] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const [pincodeError, setpincodeError] = useState(false);
  const [addressError, setAddressError] = useState(false);
  const [editLocationError, setEditLocationError] = useState(false);
  const [editBuildingError, setEditBuildingError] = useState(false);
  const [editPincodeError, setEditPincodeError] = useState(false);
  const [editAddressError, setEditAddressError] = useState(false);
  const [buildingIDSearch, setbuildingIDSearch] = useState("");
  const [buildingNameSearch, setbuildingNameSearch] = useState("");
  const [locationIDSearch, setlocationIDSearch] = useState("");
  const [touched, setTouched] = useState(false);
  // const [statusSearch, setstatusSearch ] = useState("");
  const [filteroptions, setFilterOption] = useState(false);
  const [tableData, setTableData] = useState([]);
  const buildingDatas = useSelector((state) => state.buildings);
  const locationData = useSelector((state) => state.locations);
  const [rowData, setRowData] = useState(null);
  const buildingIdRef = useRef(null);
  const buildingNameRef = useRef(null);
  const pincodeRef = useRef(null);
  const addressRef = useRef(null);
  const buildingNameEditRef = useRef(null);
  const pincodeEditRef = useRef(null);
  const addressEditRef = useRef(null);
  const [buildingData, setBuildingData] = useState({
    location_id: "",
    ulocation_id: "",
    building_name: "",
    pincode: "",
    address: "",
    status: isActiveAdd,
  });
  const handleBlur = () => {
    setTouched(true);
  };
  const [filterData] = useState({});
  const [keyChange, setKeyChange] = useState(0);
  const handleClose = () => {
    setOpen(false);
    setBuildingData({ status: isActiveAdd });
    resetAddState();
  };
  const resetAddState = () => {
    setBuildingIDError(false);
    setLocationError(false);
    setBuildingError(false);
    setpincodeError(false);
    setAddressError(false);
    setKeyChange(keyChange + 1);
  };
  const handleCloseEdit = () => {
    setOpenEdit(false);
    resetEditState();
  };
  const resetEditState = () => {
    setBuildingIDError(false);
    setEditLocationError(false);
    setEditBuildingError(false);
    setEditPincodeError(false);
    setEditAddressError(false);
    setRowData(null);
  };
  const handleButton = () => setOpen(true);
  const dispatch = useDispatch();

  const hasAccess = checkUserAccess("buildings")
  const hasAccessToCreate = checkUserAccess("add_building")
  const hasAccessToEdit = checkUserAccess("edit_building")
  const hasAccessToDelete = checkUserAccess("delete_building")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }
  useEffect(() => {
    dispatch(getBuildingsData(filterData));
    dispatch(fetchLocationsData());
  }, [dispatch, filterData]);
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const handleEditButton = (currentRow) => {
    setOpenEdit(true);
    setRowData(currentRow);
  };
  const handleChangeFilter = (e, v, name) => {
    const val = v === null ? e?.target?.value : v[name];
    setBuildingData((prevData) => ({
      ...prevData,
      [name]: val,
    }));
  };
  const handleChange = (e, v, name) => {
    const val = v === null ? e?.target?.value : v[name];
    setBuildingData((prevData) => ({
      ...prevData,
      [name]: val,
    }));
    if (name === 'pincode') {
      const isValidPincode = /^\d*$/.test(val);
      setpincodeError(isValidPincode ? "" : "Pincode should be in numbers only.");
    }
  };

  const handleEdit = (e, v, name) => {
    if (name === "location" && v) {
      // Assuming `v` has `location_id` and `location_name` properties
      const { location_id, location_name } = v;
      setRowData((prevData) => ({
        ...prevData,
        location_id: location_id || "",
        location_name: location_name || "",
      }));
    } else {
      setRowData((prevData) => ({
        ...prevData,
        [name]: v,
      }));
    }
  };
  const handleEditChange = (e, v, name) => {
    const val = v === null ? e?.target?.value : v[name];
    if ( name === "location") {
      setRowData((prevData) => ({
        ...prevData,
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    }else{
    setRowData((prevData) => ({
      ...prevData,
      [name]: val,
    }));
  }
    if (name === 'pincode') {
      const isValidPincode = /^\d*$/.test(val);
      setEditPincodeError(isValidPincode ? "" : "Pincode should be in numbers only.");
    }
  };
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    maxWidth: "600px",
    width: "calc(100% - 64px)",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 0,
  };
  const handleAdd = async () => {
    if (
      !buildingData.building_id ||
      !buildingData.location_id ||
      !buildingData.building_name ||
      !buildingData.pincode ||
      !buildingData.address
    ) {
      setBuildingIDError(!buildingData.building_id);
      setLocationError(!buildingData.location_id);
      setBuildingError(!buildingData.building_name);
      setpincodeError(!buildingData.pincode);
      setAddressError(!buildingData.address);

    let object=[{
      key:buildingData.building_id,
      ref:buildingIdRef.current,

    },
    {
      key:buildingData.building_name,
      ref:buildingNameRef.current,
    },
    {
      key:buildingData.pincode,
      ref:pincodeRef.current,
    },
    {
      key:buildingData.address,
      ref:addressRef.current,
    },

  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }
      return;
    }
    setBuildingIDError(false);
    setLocationError(false);
    setBuildingError(false);
    setpincodeError(false);
    setAddressError(false);
    await dispatch(createBuildingData(buildingData))
      .then((data) => {
        if (data.payload.status) {
          dispatch(getBuildingsData());
          setOpen(false);
          setBuildingData({ status: true });
          //  setBuildingData({});
          setKeyChange(Math.random());
          setTimeout(() => {
            toast.success("Building created successfully");
          }, 500);
          setIsActiveAdd(true);
        } else {
          setOpen(true);
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to create Building");
        }, 500);
        setOpen(true);
      });
  };
  const buildingfilter = buildingDatas?.buildings?.data;

  useEffect(() => {
    if (buildingfilter?.length > 0) {
      const newData = buildingfilter.map((d) => {
        const {
          building_id,
          building_name,
          location_id,
          ulocation_id,
          location_name,
          pincode,
          address,
          status,
          created_at,
          updated_at,
        } = d;
        const constructData = {
          building_id,
          building_name,
          location_id,
          ulocation_id,
          location_name,
          pincode,
          address,
          created_at,
          updated_at,
          status,
          // status:status?"Active":"Inactive",
        };
        return constructData;
      });
      setTableData(newData);
    }
  }, [buildingfilter]);

  const FilteredData = (location_name) => {
    const filteredbuildings = buildingfilter.filter(
      (building) => (!location_name || (building?.location_id && location_name.includes(building.location_id)))
    );
    return filteredbuildings;
  };
  const handleEditUpdate = () => {
    if (
      !rowData.location_id ||
      !rowData.building_name ||
      !rowData.pincode ||
      !rowData.address ||
      editLocationError ||
      editBuildingError ||
      editPincodeError ||
      editAddressError
    ) {
      setEditLocationError(!rowData.location_id);
      setEditBuildingError(!rowData.building_name);
      setEditPincodeError(!rowData.pincode);
      setEditAddressError(!rowData.address);

    let object=[
    {
      key:rowData.building_name,
      ref:buildingNameEditRef.current,
    },
    {
      key:rowData.pincode,
      ref:pincodeEditRef.current,
    },
    {
      key:rowData.address,
      ref:addressEditRef.current,
    },

  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }
      return;
    }
    setEditLocationError(false);
    setEditBuildingError(false);
    setEditPincodeError(false);
    setEditAddressError(false);
    dispatch(updateBuildingData(rowData))
      .then((data) => {
        if (data.payload.status) {
          setOpenEdit(false);
          dispatch(getBuildingsData());
          setTimeout(() => {
            toast.success("Building updated successfully");
          }, 500);
        } else {
          setOpenEdit(true);
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setOpenEdit(true)
        setTimeout(() => {
          toast.error("Failed to update building");
        }, 500);
      });
  };
  const handleToogleChange = (event) => {
    setIsActiveAdd(event.target.checked);
  };
  const toggleEditStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status, // Toggle the status
    }));
  };
  const handleEditToogleChange = (event) => {
    setIsActive(event.target.checked);
    toggleEditStatus(event.target.checked);
  };
  const handleDeleteConfirmationClose = () => {
    setShowDeleteConfirmation(false);
    setSelectedBuildingData(true);
  };
  const onDelete = (currentRow) => {
    setSelectedBuildingData(currentRow.building_id);
    setShowDeleteConfirmation(true);
  };
  const handleDeleteConfirm = () => {
    if (selectedBuildingData) {
      dispatch(deleteBuildingData(selectedBuildingData))
        .then((data) => {
          if (data.payload.status) {
            setTimeout(() => {
              toast.success("Building deactivated successfully");
            }, 500);
            dispatch(getBuildingsData());
          } else {
            setTimeout(() => {
              toast.error(data.message);
            }, 500);
          }
        })
        .catch(() => {
          setTimeout(() => {
            toast.error("Failed to deactivate building");
          }, 500);
        });
    }
    handleDeleteConfirmationClose();
  };
  useEffect(() => {
    if (
      locationIDSearch === "" &&
      filteroptions
    ) {
      dispatch(getBuildingsData());
    }
  }, [
    dispatch,
    filteroptions,
    locationIDSearch,
    // statusSearch,
  ]);

  const locationIDHandler = (e, v) => {
    // const value = e.target.value;

    let value = v
      ? v.map((option) => option.location_id)
      : [];
    value = value.length > 0 ? value : "";
    setlocationIDSearch(value);
    setTableData(
      FilteredData(
        value
      )
    );
    // setFilterOption(true);    
  };

  const columns = [
    {
      field: "building_id",
      headerName: "Building ID",
      flex: 1,
      headerClassName: "super-app-theme--header",
      width: 150,
      minWidth: 150,
    },
    {
      field: "building_name",
      headerName: "Building Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "location_name",
      headerName: "Location Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "created_at",
      headerName: "Created Date",
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      flex: 1,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "updated_at",
      headerClassName: "super-app-theme--header",
      headerName: "Last Updated Date",
      sortable: false,
      flex: 1,
      width: 200,
      minWidth: 200,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return (
          <span style={{ color: params.value ? "#000000" : "#000000" }}>
            {status ? "Active" : "Inactive"}
          </span>
        );
      },
    },
    {
      field: "action",
      headerName: "Operations",
      headerClassName: "super-app-theme--header",
      width: 180,
      sortable: false,
      disableClickEventBubbling: true,
      renderCell: (params) => {
        const currentRow = params.row;
        const isInactive = !currentRow.status;
        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Edit" sx={{ yIndex: 9999 }}>
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleEditButton(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title="Deactivate" sx={{ yIndex: 9999 }}>
                <Button
                  disabled={currentRow?.status === "Inactive"}
                  color={currentRow?.status === "Inactive" ? "success" : "error"}
                  variant="text"
                  warning
                  size="small"
                  sx={{
                    minWidth: "32px",
                    opacity: currentRow?.status ? 1 : 0.5,
                    pointerEvents: currentRow?.status ? "auto" : "none",
                    "&:hover": {
                      backgroundColor: "transparent",
                    },
                  }}
                  id="building_id"
                  onClick={() => onDelete(currentRow)}
                >
                  <DoNotDisturbOnIcon />
                </Button>
              </Tooltip>
            )}
          </Stack>
        );
      },
    },
  ];
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  return (
    <React.Fragment>
      <DeleteConfirmationDialog
        open={showDeleteConfirmation}
        handleClose={handleDeleteConfirmationClose}
        handleConfirm={handleDeleteConfirm}
      />
      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Modal
        keepMounted
        open={open}
        onClose={handleClose}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            Add Building
            <div style={{ textAlign: "right", display: "inline" }}>
              <Button onClick={handleClose}>X</Button>
            </div>
          </Typography>
          <Box style={{ padding: "10px 15px 25px", textAlign: "left" }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  fullWidth
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="location_id"
                  onChange={(e, v) => {
                    handleChange(e, v, "location_id");
                    setLocationError("");
                  }}
                  key={keyChange}
                  options={locationData?.locations?.location ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdLocation(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Location Id-Name"
                      error={locationError}
                      helperText={
                        locationError ? "location id-name is required." : ""
                      }
                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Building ID <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  name="building_id"
                  value={buildingData?.building_id || ""}
                  error={
                    buildingIDError ||
                    ((buildingData && buildingData.building_id && buildingData.building_id.length < 1) ||
                      (buildingData && buildingData.building_id && buildingData.building_id.length > 120))
                  }
                  helperText={
                    buildingIDError
                      ? "Building ID is required."
                      : (buildingData && buildingData.building_id && buildingData.building_id.length < 1)
                        ? "Minimum 1 characters allowed."
                        : (buildingData && buildingData.building_id && buildingData.building_id.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                  inputRef={buildingIdRef}
                  onChange={(e) => {
                    handleChange(e, null, "building_id");
                    setBuildingIDError("");
                  }}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                />

              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Building Name <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  name="building_name"
                  value={buildingData?.building_name || ""}
                  inputRef={buildingNameRef}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  onChange={(e) => {
                    handleChange(e, null, "building_name");
                    setBuildingError("");
                  }}
                  error={
                    buildingError ||
                    ((buildingData && buildingData.building_name && buildingData.building_name.length < 2) ||
                      (buildingData && buildingData.building_name && buildingData.building_name.length > 120))
                  }
                  helperText={
                    buildingError
                      ? "Building Name is required."
                      : (buildingData && buildingData.building_name && buildingData.building_name.length < 2)
                        ? "Minimum 2 characters allowed."
                        : (buildingData && buildingData.building_name && buildingData.building_name.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={<span>Pincode
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>}
                  name="pincode"
                  value={buildingData?.pincode || ""}
                  sx={{ marginBottom: "20px", marginRight: "10px" }}
                  inputRef={pincodeRef}
                  onChange={(e) => {
                    handleChange(e, null, "pincode");
                    // setpincodeError("");
                  }}
                  error={pincodeError}
                  helperText={
                    pincodeError
                      ? pincodeError === "Pincode should be in numbers only."
                        ? "Pincode should have only numbers."
                        : "Pincode is required."
                      : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <span>
                      Address <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  placeholder="Address"
                  name="address"
                  multiline
                  value={buildingData?.address || ""}
                  inputRef={addressRef}
                  onChange={(e) => {
                    handleChange(e, null, "address");
                    setAddressError("");
                  }}
                  error={
                    addressError ||
                    ((buildingData && buildingData.address && buildingData.address.length < 2) ||
                      (buildingData && buildingData.address && buildingData.address.length > 120))
                  }
                  helperText={
                    addressError
                      ? "Address name is required."
                      : (buildingData && buildingData.address && buildingData.address.length < 2)
                        ? "Minimum 2 characters allowed."
                        : (buildingData && buildingData.address && buildingData.address.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                  rows={3}
                />

              </Grid>
              <Grid item xs={12} sm={12} className="text-right">
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={isActiveAdd}
                      onChange={handleToogleChange}
                    />
                  }
                  label={isActiveAdd ? "Active" : "Inactive"}
                  sx={{ marginLeft: "0" }}
                  labelPlacement="top"
                />
                <Button
                  variant="contained"
                  className="bookingbtn"
                  sx={{
                    marginRight: "10px",
                    marginTop: "10px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                  onClick={handleAdd}
                >
                  Save
                </Button>
                <Button
                  variant="outlined"
                  onClick={handleClose}
                  className="bookingbtn1"
                  sx={{
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                    marginTop: "10px",
                  }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
      <Modal
        keepMounted
        open={openEdit}
        onClose={handleCloseEdit}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            Edit Building
            <div style={{ textAlign: "right", display: "inline" }}>
              <Button onClick={handleCloseEdit}>X</Button>
            </div>
          </Typography>
          <Box style={{ padding: "10px 15px 25px", textAlign: "left" }}>
            <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
                <Autocomplete
                  fullWidth
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  // id="checkboxes-tags-demo"
                  id={"location_id"}
                  name="location_id"
                  key={keyChange && Math.random()}
                  value={{
                    location_name: rowData?.location_name,
                    location_id: rowData?.location_id,
                    ulocation_id: rowData?.ulocation_id,
                  }}
                  onChange={(e, v) => {
                    handleEditChange(e, v, "location");
                    setEditLocationError("");
                  }}
                  options={locationData?.locations?.location ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdLocation(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Location Id-Name"
                      error={editLocationError}
                      helperText={
                        editLocationError
                          ? "location id-name cannot be empty."
                          : ""
                      }
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.location_name),
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
              <TextField
                  fullWidth
                  size="small"
                  label="BuildingID"
                  id={"building_id"}
                  name="building_id"
                  value={(rowData && rowData?.building_id) || ""}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  InputProps={{
                    readOnly: true,
                  }}
                  onChange={(e) => {
                    handleEditChange(e, null, "building_id");
                  }}
                  InputLabelProps={{ shrink: rowData && rowData.building_id }}
                  // error={editBuildingError} 
                  // helperText={
                  //   editBuildingError ? "Building id can't be empty." : ""
                  // }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      Building Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="building_name"
                  name="building_name"
                  value={(rowData && rowData.building_name) || ""}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  inputRef={buildingNameEditRef}
                  onChange={(e) => {
                    handleEditChange(e, null, "building_name");
                    setEditBuildingError("");
                  }}
                  InputLabelProps={{ shrink: Boolean(rowData && rowData.building_name) }}
                  error={
                    editBuildingError ||
                    ((rowData && rowData.building_name?.length < 2) ||
                      (rowData && rowData.building_name?.length > 120))
                  }
                  helperText={
                    editBuildingError
                      ? "Building name can't be empty."
                      : (rowData && rowData.building_name?.length < 2)
                        ? "Minimum 2 characters allowed."
                        : (rowData && rowData.building_name?.length > 120)
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={<div>
                    Pincode <RequiredAsterisk>*</RequiredAsterisk>
                  </div>}
                  id="pincode"
                  name="pincode"
                  value={(rowData && rowData?.pincode) || ""}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  inputRef={pincodeEditRef}
                  onChange={(e) => {
                    handleEditChange(e, null, "pincode");
                    // setEditPincodeError("");
                  }}
                  InputLabelProps={{ shrink: rowData && rowData.pincode }}
                  error={editPincodeError}
                  helperText={
                    editPincodeError
                      ? editPincodeError === "Pincode should be in numbers only."
                        ? "Pincode should have only numbers."
                        : "Pincode is required."
                      : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={
                    <div>
                      Address <RequiredAsterisk>*</RequiredAsterisk>
                    </div>
                  }
                  id="address"
                  name="address"
                  multiline
                  value={(rowData && rowData?.address) || ""}
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  inputRef={addressEditRef}
                  onChange={(e) => {
                    handleEditChange(e, null, "address");
                    setEditAddressError("");
                  }}
                  InputLabelProps={{ shrink: Boolean(rowData && rowData.address) }}
                  error={
                    editAddressError ||
                    ((rowData && rowData.address?.length < 2) ||
                      (rowData && rowData.address?.length > 120))
                  }
                  helperText={
                    editAddressError
                      ? "Address can't be empty."
                      : rowData && rowData.address?.length < 2
                        ? "Minimum 2 characters required."
                        : rowData && rowData.address?.length > 120
                          ? "Maximum 120 characters allowed."
                          : ""
                  }
                  rows={3}
                />
              </Grid>
              <Grid item xs={12} sm={12} className="text-right">
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={(rowData?.status == "Active" || rowData?.status == true) ? true : false}
                      onChange={handleEditToogleChange}
                    />
                  }
                  label={(rowData?.status == "Active" || rowData?.status == true) ? "Active" : "Inactive"}
                  sx={{
                    marginLeft: "0px",
                    marginBottom: "0",
                    marginRight: "10px",
                  }}
                  labelPlacement="top"
                />
                <Button
                  variant="contained"
                  className="bookingbtn"
                  onClick={handleEditUpdate}
                  sx={{
                    marginRight: "10px",
                    marginTop: "10px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                >
                  Update
                </Button>
                <Button
                  variant="outlined"
                  onClick={handleCloseEdit}
                  className="bookingbtn1"
                  sx={{
                    marginTop: "10px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
      <CssBaseline />
      <Box sx={{ bgcolor: "#fff" }}>
        <Grid container spacing={1} mb={2}>
          <Grid item xs={12} sm={8} md={8} lg={10}>
            <Typography variant="h4" sx={{ fontWeight: "600" }}>
              Buildings
            </Typography>
          </Grid>
          <Grid
            item
            xs={12}
            sm={4}
            md={4}
            lg={2}
            className="noPadding noPadding600"
          >
            {hasAccessToCreate.exists && (
              <Button
                fullWidth
                variant="contained"
                sx={{
                  alignSelf: "center",
                  padding: "10px 0",
                  backgroundColor: "#0B78A1 !important",
                  borderRadius: 0,
                  fontSize: "0.75rem !important",
                  lineHeight: "1.125rem",
                  letterSpacing: 0,
                }}
                onClick={handleButton}
                startIcon={<AddIcon />}
              >
                Add New Building
              </Button>
            )}
          </Grid>
        </Grid>
        <Accordion
          sx={{
            backgroundColor: "#3E0BA1",
            color: "#fff",
            margin: "0 0 15px !important",
            borderRadius: "0 !important",
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
            aria-controls="panel1a-content"
            id="panel1a-header"
            sx={{
              minHeight: "48px !important",
              "& .Mui-expanded": {
                margin: "12px 0 !important",
              },
            }}
          >
            <Typography>
              <FilterAltIcon /> Filter
            </Typography>
          </AccordionSummary>
          <AccordionDetails
            sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
          >
            <Box>
              <Grid container spacing={1}>
                <Grid item xs={12} sm={6} md={4} lg={2}>
                  <Autocomplete
                    size="small"
                    fullWidth
                    multiple
                    sx={{
                      fieldset: {
                        borderColor: "#3E0BA1 !important",
                        borderRadius: 0,
                      },
                    }}
                    id="checkboxes-tags-demo"
                    name="location_id"
                    onChange={(e, v) => {
                      locationIDHandler(e, v);
                    }}
                    key={keyChange}
                    options={locationData?.locations?.location ?? []}
                    getOptionLabel={(option) =>
                      getOptionLabelWithIdLocation(option)
                    }
                    getOptionDisabled={(option) => option.status === false}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Location Id-Name"
                        placeholder="Location Id-Name"
                        InputLabelProps={{
                          ...params.InputLabelProps,
                          ...labelClassess.label,
                        }}
                      />
                    )}
                  />
                </Grid>
              </Grid>
            </Box>
          </AccordionDetails>
        </Accordion>
        <Table data={tableData} columns={columns} id="building_id" />
      </Box>
    </React.Fragment>
  );
}