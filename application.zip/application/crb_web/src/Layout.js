import React, { useState, useEffect } from "react";
import { styled } from "@mui/material/styles";
import { Box, CssBaseline } from "@mui/material";
import { Link, useNavigate, useLocation } from "react-router-dom";
import "../src/MiniSideBar.css";
import MainLogo from "../src/Components/Images/ConfroomLogo.png";
import ListBox from "../src/Components/Images/Icon-ionic-md-list-box.png";
import MasterSetting from "../src/Components/Images/MasterSetting.svg";
import DashboardIcon from "../src/Components/Images/Dashboard.svg";
import LogoutIcon from "../src/Components/Images/Icon-open-account-logout.png";
import SettingIcon from "../src/Components/Images/Icon-ionic-ios-settings.png";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import MenuIcon from "@mui/icons-material/Menu";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { ArrowRight } from "@mui/icons-material";
import { useSelector, useDispatch } from "react-redux";
import { fetchUsersData, fetchProfileImg } from "./api/UserProfile/userProfileReducer";
import { checkUserAccess } from "./CheckUserAccess";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}`;

const drawerWidth = 180;
const masterUrls = [
  "locations",
  "buildings",
  "floors",
  "rooms",
  "amenity",
  "roomservice",
  "designation",
  "rolemaster",
  "department",
  "useraccess",
];
const bookingMainUrls = ["bookinglist", "managebooking"];
const dashUrl = "/";
const bookinglistUrls = [
  "settings",
  "configurationpage",
  "acl",
];

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `-${drawerWidth}px`,
    ...(open && {
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    }),
  })
);

export default function Layout({ children }) {

  const dispatch = useDispatch();
  const userName = localStorage.getItem('userName');

  useEffect(() => {
    dispatch(fetchUsersData());
  }, [dispatch]);

  const [mini, setMini] = useState(true);
  const location = useLocation();
  const navWidth = mini ? "100%" : "calc(100% - 200px)";

  const urlChekcing = (urls) => {
    const currentPath = location.pathname;
    if (urls === "/") {
      return currentPath === "/" || currentPath === "";
    } else {
      const lastPathPart = currentPath.split("/").pop();
      return urls.includes(lastPathPart);
    }
  };
  const [isMasterSubmenuOpen, setMasterIsSubmenuOpen] = useState(true);
  const [isImageSubmenuOpen, setImageSubmenuOpen] = useState(true);
  const [isBookingSubmenuOpen, setBookingSubmenuOpen] = useState(true);
  const toggleSubmenu = () => {
    if (!isImageSubmenuOpen) {
      setImageSubmenuOpen(true);
    }
    setMasterIsSubmenuOpen((prevState) => !prevState);
  };

  const toggleImageSubmenu = () => {
    if (!isMasterSubmenuOpen) {
      setMasterIsSubmenuOpen(true);
    }
    setImageSubmenuOpen((prevState) => !prevState);
  };

  const toggleBookingSubmenu = () => {
    if (!isBookingSubmenuOpen) {
      setImageSubmenuOpen(true);
    }
    setBookingSubmenuOpen((prevState) => !prevState);
  };

  const closeSubmenu = () => {
    setMasterIsSubmenuOpen(false);
  };
  const closeSubmenuImage = () => {
    setImageSubmenuOpen(false);
  };
  const navigate = useNavigate();

  let hasAccessMaster = checkUserAccess("all_master");
  let hasAccess = checkUserAccess("locations");
  let hasAccessBuldings = checkUserAccess("buildings");
  let hasAccessFloors = checkUserAccess("floors");
  let hasAccessRooms = checkUserAccess("rooms");
  let hasAccessAmenities = checkUserAccess("amenity");
  let hasAccessRoomServices = checkUserAccess("room_service");
  let hasAccessDepartments = checkUserAccess("department");
  let hasAccessDesignations = checkUserAccess("designation");
  let hasAccessRoles = checkUserAccess("role_master");
  let hasAccessUserAccess = checkUserAccess("user_access_management");
  let hasAccessConfiguration = checkUserAccess("configuration");
  let hasAccessSettings = checkUserAccess("profile");
  let hasAccessAllSettings = checkUserAccess("all_settings");
  let hasAccessAcl = checkUserAccess("acl");




  const handleLogout = () => {
    console.log("logout");
    cleanupLocalStorage();
    navigate("/login");
    window.location.reload();
  };
  const cleanupLocalStorage = () => {
    console.log("Cleaning up local storage");
    sessionStorage.removeItem("userToken");
    localStorage.removeItem("userName");
    localStorage.removeItem("permissions");
  };
    useEffect(() => {
      if (location.pathname === '/login') {
        localStorage.clear();
      }
      if (!token) {
        localStorage.clear();
      }
    }, [location]);   

  const token = sessionStorage.getItem("userToken");
  const profilePicUrl = `${BASE_URL}/userprofile/profilepic/${token}`;

  if (!token) {
    return <>{children}</>;
  }

  const toggleSidebar = () => {
    setMini((prevMini) => !prevMini);
    if (!mini) {
      setMasterIsSubmenuOpen(true);
      setImageSubmenuOpen(true);
    }
  };
  //console.log(location.pathname.split("/").pop());

  //const test = urlChekcing(masterUrls);
  //console.log(test);
  return (
    <Box>
      <CssBaseline />
      <div data-component="sidebar" className={"TgSideBar"}>
        <div
          className="sidebar"
          id="mySidebar"
          style={{
            marginLeft: mini ? "-208px" : "0",
            transition:
              "transform .3s ease-in-out 0ms, margin .3s ease-in-out 0ms",
          }}
        //onMouseEnter={toggleSidebar}
        //onMouseLeave={toggleSidebar}
        >
          <ul className="list-group flex-column first-menu">
            <li
              className="list-group-item"
              style={{ marginBottom: "50px", padding: "0" }}
            >
              <Link to="/" className="p-3 text-center">
                <img
                  src={MainLogo}
                  style={{ width: "52px", padding: "0" }}
                  alt=""
                />
              </Link>
            </li>
            <li
              className={`list-group-item  ${urlChekcing(dashUrl) && "active"
                } p-0`}
            >
              <Link to="/" className="p-3 lgi1" onClick={toggleSidebar}>
                <i>
                  <img
                    src={DashboardIcon}
                    alt=""
                    style={{
                      width: "33px",
                      height: "25px",
                      padding: "0",
                      objectFit: "contain",
                    }}
                  />
                  <span className="ml-2 align-middle font-weight-normal">
                    Dashboard
                  </span>
                </i>
              </Link>
            </li>
            {hasAccessMaster.exists ? (
              <li
                className={`list-group-item  ${urlChekcing(masterUrls) && "active"
                  } p-0`}
                onClick={toggleSubmenu}
              >
                <Link className="p-3 lgi1">
                  <i>
                    <img
                      src={MasterSetting}
                      alt=""
                      style={{
                        width: "33px",
                        height: "30px",
                        padding: "0",
                        objectFit: "contain",
                      }}
                    />
                    <span className="ml-2 align-middle">Master</span>
                    {!isMasterSubmenuOpen ? (
                      <ArrowDropDownIcon
                        sx={{ marginLeft: "40px", fontWeight: "bold" }}
                      />
                    ) : (
                      <ArrowRight
                        sx={{ marginLeft: "40px", fontWeight: "bold" }}
                      />
                    )}
                  </i>
                </Link>
                <ul
                  className={`list-group rounded-0 hide-scroll submenu ${!isMasterSubmenuOpen ? "show" : ""
                    }`}
                >
                  {hasAccess.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/locations"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Locations
                      </Link>
                    </li>
                  ) : null}
                  {hasAccessBuldings.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/buildings"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Buildings
                      </Link>
                    </li>) : null}
                  {hasAccessFloors.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/floors"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Floors
                      </Link>
                    </li>) : null}
                  {hasAccessRooms.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/rooms"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Rooms
                      </Link>
                    </li>) : null}
                  {hasAccessAmenities.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/amenity"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Amenities
                      </Link>
                    </li>) : null}
                  {hasAccessRoomServices.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/roomservice"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Room Service
                      </Link>
                    </li>) : null}
                  {hasAccessDepartments.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/department"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Department Master
                      </Link>
                    </li>) : null}
                  {hasAccessDesignations.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/designation"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Designation Master
                      </Link>
                    </li>) : null}
                  {hasAccessRoles.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/rolemaster"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        Roles Master
                      </Link>
                    </li>) : null}
                  {hasAccessUserAccess.exists ? (
                    <li className="list-group-item">
                      <Link
                        to="/useraccess"
                        className="p-2 pl-4"
                        onClick={() => {
                          toggleSidebar();
                          closeSubmenu();
                        }}
                      >
                        User Access Management
                      </Link>
                    </li>) : null}
                </ul>
              </li>) : null}
            <li
              className={`list-group-item ${urlChekcing(bookingMainUrls) && "active"
                } p-0`}
              onClick={toggleBookingSubmenu}
            >
              <Link className="p-3 lgi1">
                <i>
                  <img
                    src={SettingIcon}
                    style={{
                      width: "33px",
                      height: "25px",
                      padding: "0",
                      objectFit: "contain",
                    }}
                    alt=""
                  />
                  <span className="ml-2 align-middle">Booking</span>
                  {!isBookingSubmenuOpen ? (
                    <ArrowDropDownIcon
                      sx={{ marginLeft: "40px", fontWeight: "bold" }}
                    />
                  ) : (
                    <ArrowRight
                      sx={{ marginLeft: "40px", fontWeight: "bold" }}
                    />
                  )}
                </i>
              </Link>
              <ul
                className={`list-group rounded-0 hide-scroll submenu ${!isBookingSubmenuOpen ? "show-80" : ""
                  }`}
              >
                <li className="list-group-item pl-4">
                  <Link
                    to="/bookinglist"
                    className="p-2 pl-4"
                    onClick={() => {
                      toggleSidebar();
                      closeSubmenuImage();
                    }}
                  >
                    Bookings List
                  </Link>
                </li>
                <li className="list-group-item pl-4">
                  <Link
                    to="/managebooking"
                    className="p-2 pl-4"
                    onClick={() => {
                      toggleSidebar();
                      closeSubmenuImage();
                    }}
                  >
                    Manage Booking
                  </Link>
                </li>
              </ul>
            </li>
            <li
              className={`list-group-item ${urlChekcing(bookinglistUrls) && "active"
                } p-0`}
              onClick={toggleImageSubmenu}
            >
              {hasAccessAllSettings.exists&&
              <Link className="p-3 lgi1">
                <i>
                  <img
                    src={SettingIcon}
                    style={{
                      width: "33px",
                      height: "25px",
                      padding: "0",
                      objectFit: "contain",
                    }}
                    alt=""
                  />
                  <span className="ml-2 align-middle">Settings</span>
                  {!isImageSubmenuOpen ? (
                    <ArrowDropDownIcon
                      sx={{ marginLeft: "40px", fontWeight: "bold" }}
                    />
                  ) : (
                    <ArrowRight
                      sx={{ marginLeft: "40px", fontWeight: "bold" }}
                    />
                  )}
                </i>
              </Link>}
              <ul
                className={`list-group rounded-0 hide-scroll submenu ${!isImageSubmenuOpen ? "show" : ""
                  }`}
              >
                {hasAccessSettings.exists&&
                <li className="list-group-item pl-4">
                  <Link
                    to="/settings"
                    className="p-2 pl-4"
                    onClick={() => {
                      toggleSidebar();
                      closeSubmenuImage();
                    }}
                  >
                    Settings
                  </Link>
                </li>}
                {hasAccessConfiguration.exists&&
                <li className="list-group-item pl-4">
                  <Link
                    to="/configurationpage"
                    className="p-2 pl-4"
                    onClick={() => {
                      toggleSidebar();
                      closeSubmenuImage();
                    }}
                  >
                    Configuration
                  </Link>
                </li>}
                {hasAccessAcl.exists&&
                <li className="list-group-item pl-4">
                  <Link
                    to="/acl"
                    className="p-2 pl-4"
                    onClick={() => {
                      toggleSidebar();
                      closeSubmenuImage();
                    }}
                  >
                    ACL
                  </Link>
                </li>}
              </ul>
            </li>
          </ul>
          <ul className="list-group flex-column justify-content-end mb-3 first-menu">
            <li className="list-group-item py-2">
              <i
                className=""
                aria-hidden="true"
                onClick={() => handleLogout()}
                style={{
                  whiteSpace: "nowrap",
                  color: "#fff",
                  cursor: "pointer",
                }}
              >
                <img
                  src={LogoutIcon}
                  alt="logout"
                  style={{
                    width: "35px",
                    height: "25px",
                    padding: "0",
                    objectFit: "contain",
                  }}
                />
                <span className="ml-2 align-middle">Logout</span>
              </i>
            </li>
          </ul>
        </div>
      </div>
      <div
        className="navbar shadow-sm bg-white mb-3"
        style={{
          marginLeft: mini ? "0" : "200px",
          transition: "width .3s ease-in-out 0ms, margin .3s ease-in-out 0ms",
          width: navWidth,
          position: "fixed",
          zIndex: "999",
          top: "0",
        }}
      >
        <ul className="navbar-nav menu-icon">
          <li className="nav-item">
            <Link to="#" onClick={() => toggleSidebar()}>
              <MenuIcon />
            </Link>
          </li>
        </ul>
        <ul className="navbar-nav flex-row ml-auto align-items-center">
          <li className="nav-item">
            <Link
              to="#"
              className="nav-link px-3"
              style={{ color: "#3E0BA1", position: "relative" }}
            >
              <NotificationsNoneIcon />
              <span
                className="position-absolute p-1 bg-danger border border-light rounded-circle"
                style={{ top: "11px", right: "17px" }}
              ></span>
            </Link>
          </li>
          <li className="nav-item">
            <Link
              to="#"
              //data-toggle="dropdown"
              className="nav-link px-3 text-dark"
            >
              <img
                src={profilePicUrl}
                className="img-fluid"
                alt="Avatar"
                style={{
                  width: "30px",
                  padding: "0",
                  borderRadius: "20px",
                  marginRight: "10px",
                }}
              ></img>
              {`${userName}`}
            </Link>
          </li>
        </ul>
      </div>
      <Main
        id="main"
        style={{
          marginLeft: mini ? "0" : "200px",
          transition: "margin-left .4s ease-in",
          paddingTop: "70px",
        }}
      >
        {children}
      </Main>
    </Box>
  );
}