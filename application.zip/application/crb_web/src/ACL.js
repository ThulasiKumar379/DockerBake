import { DataGrid } from "@mui/x-data-grid";
import React, { useEffect, useState } from "react";

import { useDispatch, useSelector } from "react-redux";
import { createTheme } from "@mui/material/styles";
import "./acl.css"
import { Link, useNavigate, useLocation } from "react-router-dom";
import { checkUserAccess } from "./CheckUserAccess";
import AclCheckBox from "./AclCheckBox"
import {
  getRoleData,
  getACLData,
  createACLData,
  deleteACLData,
} from "./api/Acl/aclReducer";
const theme = createTheme({
  components: {
    MuiDataGrid: {
      styleOverrides: {
        columnHeader: {
          backgroundColor: "#3E0BA1", 
          color: "white",
        },
      },
    },
  },
});

const Access = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getRoleData());
    dispatch(getACLData());
  }, [dispatch]);
  const [roleHeaders, setRoleHeaders] = useState([]);
  const roleData = useSelector((state) => state.acl);
  const [rowData, setRowData] = useState([]);
  const [pageSize, setPageSize] = React.useState(5);
  const handlePageSizeChange = (params) => {
    setPageSize(params);
  };
  const columns = [
    {
      field: "headerName",
      headerName: "PAGES",
      flex: 1,
      width: 150,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => (
        <div class="custom-div">
          {params.value}
        </div>
      ),
    },
    ...roleHeaders.map((header,idx) => ({
      field: header.field+idx,
      id: header.id,
      headerName: header.headerName,
      flex: 1,
      width: 150,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => { 
        let userPermissions=params.row.userPermissions
        return (  
          <AclCheckBox 
          userPermissions={userPermissions}
          header={header} 
          params={params}
          handleRoleCheckboxChange={handleRoleCheckboxChange}
          />
          
        )
      }
    })),
  ];

  const handleCheck = () => {
    if (roleData?.acl?.data?.length > 0) {
      const rows = roleData?.acl?.data.map((name) => {
        const val = name.userpermissions.map((nm) => nm.role_id);
        return {
          id: name.id,
          headerName: name.name,
          userPermissions:val
        };
      }); 
      setRowData(rows);
    }
  };

  const hasAccess=checkUserAccess("acl")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
      navigate("/"); 
   }

  useEffect(() => {
    if (roleData?.roles?.RoleData?.length > 0) {
      const headers = roleData?.roles?.RoleData.map((role) => ({
        field:role.role_name.toLowerCase(),
        headerName: role.role_name,
        id: role.role_id,
        flex: 1,
        width: 100,
        minWidth: 100,
        headerClassName: "super-app-theme--header",
      }));
      setRoleHeaders(headers);
    }
    handleCheck();
  }, [roleData]);

  const handleRoleCheckboxChange = (permissionId,roleId,v) => {

    const payload = {
      permission_id: permissionId,
      role_id: roleId,
    };
    if(v){
      dispatch(createACLData(payload));
    }else{
      dispatch(deleteACLData(payload));
    }

    // setTimeout(() => {
    //   dispatch(getACLData());
    // }, 200);

    // const updatedRowData = [...rowData];
    // updatedRowData[rowId].checkboxes[field] =
    //   !updatedRowData[rowId].checkboxes[field];
    // const payload = {
    //   permission_id: rowId + 1,
    //   role_id: field,
    // };
    // setRowData(updatedRowData);
    // if (updatedRowData[rowId].checkboxes[field]) {
    //   dispatch(createACLData(payload));
    // } else {
    //   dispatch(deleteACLData(payload));
    // }
    // setTimeout(() => {
    //   dispatch(getACLData());
    // }, 200);
    // handleCheck();
  };
  return (
    <div className="custom-container">
      <DataGrid
        rows={rowData}
        columns={columns}
        pageSize={pageSize}
        disableSelectionOnClick
        rowsPerPageOptions={[5, 10, 20, 30, 50, 100]}
        onPageSizeChange={handlePageSizeChange}
        classes={{
          columnHeader: "custom-header", // Apply the custom class to the header
        }}
      />
    </div>
  );
};
export default Access;
