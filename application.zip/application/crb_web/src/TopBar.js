import React from "react";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import { useSelector } from "react-redux";
import MenuIcon from "@mui/icons-material/Menu";

export default function TopBar() {
    const { loading, error, userInfo } = useSelector((state) => state.auth);
  return (
    <div className="navbar fixed-top bg-dark">
      <ul className="navbar-nav menu-icon">
        <li className="nav-item">
          <a href="#">
            <MenuIcon />
          </a>
        </li>
      </ul>
      <ul className="navbar-nav flex-row ml-auto align-items-center">
        <li class="nav-item">
          <a
            href="#"
            className="nav-link px-3"
            style={{ color: "#3E0BA1", position: "relative" }}
          >
            <NotificationsNoneIcon />
            <span
              className="position-absolute p-1 bg-danger border border-light rounded-circle"
              style={{ top: "11px", right: "17px" }}
            >
              {/* <span class="d-none">New alerts</span> */}
            </span>
          </a>
        </li>
        <li>mustafa</li>
        <li className="nav-item">
          <a
            href="#"
            //data-toggle="dropdown"
            className="nav-link px-3 text-dark"
          >
            <img
              src="https://www.tutorialrepublic.com/examples/images/avatar/3.jpg"
              className="img-fluid"
              alt="Avatar"
              style={{
                width: "30px",
                padding: "0",
                borderRadius: "20px",
                marginRight: "10px",
              }}
            ></img>
            Kishore
          </a>
          {/* <div className="dropdown-menu">
                <a href="#" className="dropdown-item">
                  <i className="fa fa-user-o"></i> Profile
                </a>
                <a href="#" className="dropdown-item">
                  <i className="fa fa-calendar-o"></i> Calendar
                </a>
                <a href="#" className="dropdown-item">
                  <i className="fa fa-sliders"></i> Settings
                </a>
                <div className="divider dropdown-divider"></div>
                <a href="#" className="dropdown-item">
                  <i className="material-icons">&#xE8AC;</i> Logout
                </a>
              </div> */}
        </li>
      </ul>
    </div>
  );
}
