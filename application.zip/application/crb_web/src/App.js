import "./App.css";
import Home from "./pages/Home";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import LoginPage from "./LoginPage.js";
import ForgotPassword from "./ForgotPaasword";
import { Reset } from "./Reset";
import { New } from "./New";
import Otpone from "./MuiOtpIput";
import ChangePassword from "./ChangePassword";
import Layout from "./Layout";
import BookingListPage from "./Components/BookingListView/BookingListPage";
import { Amenity } from "./Components/Amenity/Amenity";
import { UserProfilesetting } from "./UserProfile/UserProfileSetting";
import { UserAccess } from "./Useraccesspage/UserAccess";
import LocationPage from "./Components/Location/LocationPage";
import FloorPage from "./Components/Floor/FloorPage";
import Access from "./ACL"; // Update the path if necessary
import BuildingPage from "./Components/Building/BuildingPage";
import RoomPage from "./Components/Room/RoomPage";
//import RoomServiceTable from "./Components/RoomServiceTable/RoomServiceTable";
import RoomServiceTable from "./Components/RoomService/RoomServiceTable";
import { RoomConfiguration } from "./RoomConfigurationPage/RoomConfiguration";
import ManageBooking from "./Components/BookingManage/Form";
import ResponsiveGrid from "./Components/BookingListView/BookingListView";
import ManageBookingPage from "./Components/BookingManage/ManageBookingPage";
import { Department } from "./Departmentpage/Department";
import { Designation } from "./Designation/Designation";
import { Rolemaster } from "./Components/Rolemasterpage/Rolemaster";
import TabPanel from "./configurationmasterpage/Components/configpage";
// import { RoomConfiguration } from './RoomConfigurationPage/RoomConfiguration';
import Dashboardnew from "./Components/Dashboardnew/Dashboardnew";
import Error from "./Error";


const RequireAuth = ({ children }) => {
  const token = sessionStorage.getItem("userToken");

  if (!token) {
    return <LoginPage />;
  }
  return children;
};
const App = () => {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route
            path="/"
            element={
              <RequireAuth>
                <Dashboardnew />
              </RequireAuth>
            }
          />
          <Route
            path="/*"
            element={
              <RequireAuth>
                <Error />
              </RequireAuth>
            }
          />
          <Route
            path="/login"
            element={
              <RequireAuth>
                <LoginPage />
              </RequireAuth>
            }
          />
          <Route
            path="/forgotpassword"
            element={
              <RequireAuth>
                <ForgotPassword />
              </RequireAuth>
            }
          />
          <Route
            path="/otp"
            element={
              <RequireAuth>
                <Otpone />
              </RequireAuth>
            }
          />
          <Route
            path="/password"
            element={
              <RequireAuth>
                <ChangePassword />
              </RequireAuth>
            }
          />
          <Route
            path="/reset"
            element={
              <RequireAuth>
                <Reset />
              </RequireAuth>
            }
          />
          <Route
            path="/success"
            element={
              <RequireAuth>
                <New />
              </RequireAuth>
            }
          />
          <Route
            path="/bookinglist"
            element={
              <RequireAuth>
                {/* <BookingListPage /> */}
                <ManageBookingPage />
              </RequireAuth>
            }
          />
          <Route
            path="/amenity"
            element={
              <RequireAuth>
                <Amenity />
              </RequireAuth>
            }
          />
          <Route
            path="/settings"
            element={
              <RequireAuth>
                <UserProfilesetting />
              </RequireAuth>
            }
          />
          <Route
            path="/useraccess"
            element={
              <RequireAuth>
                <UserAccess />
              </RequireAuth>
            }
          />
          <Route
            path="/buildings"
            element={
              <RequireAuth>
                <BuildingPage />
              </RequireAuth>
            }
          />
          <Route
            path="/locations"
            element={
              <RequireAuth>
                <LocationPage />
              </RequireAuth>
            }
          />
          <Route
            path="/floors"
            element={
              <RequireAuth>
                <FloorPage />
              </RequireAuth>
            }
          />
          <Route
            path="/rooms"
            element={
              <RequireAuth>
                <RoomPage />
              </RequireAuth>
            }
          />
          <Route
            path="/roomservice"
            element={
              <RequireAuth>
                <RoomServiceTable/>
              </RequireAuth>
            }
          />
          <Route
            path="/managebooking"
            element={
              <RequireAuth>
                <ManageBookingPage />
              </RequireAuth>
            }
          />
          <Route
            path="/department"
            element={
              <RequireAuth>
                <Department />
              </RequireAuth>
            }
          />
          <Route
            path="/designation"
            element={
              <RequireAuth>
                <Designation />
              </RequireAuth>
            }
          />
          <Route
            path="/configurationpage"
            element={
              <RequireAuth>
                <TabPanel />
              </RequireAuth>
            }
          />
          <Route
            path="/rolemaster"
            element={
              <RequireAuth>
                <Rolemaster />
              </RequireAuth>
            }
          />
          <Route
            path="/acl"
            element={
              <RequireAuth>
                <Access />
              </RequireAuth>
            }
          />
          {/* <Route
            path="/roomconfiguration"
            element={
              <RequireAuth>
                <RoomConfiguration />
              </RequireAuth>
            }
          /> */}
          <Route
            path="/dashboardnew"
            element={
              <RequireAuth>
                <Home />
              </RequireAuth>
            }
          />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
};
export default App;
