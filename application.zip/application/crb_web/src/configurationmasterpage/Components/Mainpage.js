import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Dialog,
  DialogActions,
  InputAdornment,
  Paper,
  Typography,
  TableContainer,
  Grid,
  Table,
  TableCell,
  TableRow,
  Checkbox,
  DialogContent,
  DialogContentText,
} from "@mui/material";
import { styled } from "@mui/system";
import { useSelector, useDispatch } from "react-redux";
import CorporateFareIcon from "@mui/icons-material/CorporateFare";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import EmailIcon from "@mui/icons-material/Email";
import PlaceIcon from "@mui/icons-material/Place";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import PhoneIcon from "@mui/icons-material/Phone";
import EventAvailableIcon from "@mui/icons-material/EventAvailable";
import { Avatar } from "@mui/material";
import TimezoneSelect from "react-timezone-select";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { useRef } from "react";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import RadioButtonUncheckedIcon from "@mui/icons-material/RadioButtonUnchecked";
import { checkUserAccess } from "../../CheckUserAccess";
import { updateCompanyProfile, UploadCompanyLogo, getCompanyProfile } from "../../api/Companyprofile/companyprofileApi";
import {
  fetchtimingsData,
  edittimingsData,
} from "../../api/Settings/timingReducer";
import { fetchBuildingsData } from "../../api/Building/buildingReducers";
const hasAccess = checkUserAccess("configuration_company_details")
const CustomAvatar = ({ image }) => {
  return (
    <Avatar
      style={{
        width: "150px",
        height: "150px",
        marginBottom: "8px",
        backgroundColor: "#F7F2FF",
        fontSize: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
        borderRadius: "50%",
      }}
    >
      {image && (
        <img
          src={URL.createObjectURL(image)}
          alt="Selected Logo"
          style={{ width: "100%", height: "100%", objectFit: "contain" }}
        />
      )}
    </Avatar>
  );
};
export const General = () => {
  const [selectedTimezone, setSelectedTimezone] = useState(
    Intl.DateTimeFormat().resolvedOptions().timeZone
  );

  const [companydetails] = useState("");
  const [uploadedImage, setUploadedImage] = useState(null);
  const [selectedLogo, setSelectedLogo] = useState(null);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [, setErrorMessage] = useState("");
  const [value] = useState("");
  const [, setCompanyName] = useState("");
  const [, setCompanyAddress] = useState("");
  const [, setStatus] = useState(false);
  const [, setCompanyId] = useState("");
  const [, setStartTime] = useState("");
  const [, setEndTime] = useState("");
  const [, setSunday] = useState("");
  const [, setMonday] = useState("");
  const [, setTuesday] = useState("");
  const [, setWednesday] = useState("");
  const [, setThursday] = useState("");
  const [, setFriday] = useState("");
  const [, setSaturday] = useState("");
  const [, setSystemUserId] = useState("");
  const [data, setData] = useState([]);
  const [, setCreatedBy] = useState("");
  const fileInputRef = useRef(null);



  const handleChangeChecked = (day) => {
    setCompanyData((prevData) => ({
      ...prevData,
      [day]: !prevData[day],
    }));
  };

  const handleContainerClick = () => {
    fileInputRef.current.click();
  };
  const handleClose = () => {
    setCompanyData({
      id: "",
      company_name: "",
      start_time: "",
      end_time: "",
      sunday: false,
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
    });
  };

  const handleEditUpdate = async () => {
    setStatus(false);
    setErrorMessage("");

    const payload = {
      companytimings_id: companyData.id,
      company_name: companyData.company_name,
      start_time: companyData.start_time,
      end_time: companyData.end_time,
      sunday: companyData.sunday,
      monday: companyData.monday,
      tuesday: companyData.tuesday,
      wednesday: companyData.wednesday,
      thursday: companyData.thursday,
      friday: companyData.friday,
      saturday: companyData.saturday,
    };

    // Dispatch the action
    await dispatch(edittimingsData(payload))
      .then((response) => {
        if (response.payload.status) {
          setStatus(true);
          dispatch(fetchtimingsData());
          setTimeout(() => {
            toast.success("Settings updated successfully");
          }, 500);
        } else {
          setStatus(false);
          setErrorMessage(response.errorMessage);
          setTimeout(() => {
            toast.error(response.errorMessage);
          }, 500);
        }
      })
      .catch((error) => {
        setStatus(false);
        setErrorMessage("Failed to update Timings");
        setTimeout(() => {
          toast.error("Failed to update Timings");
        }, 500);
      });
  };

  useEffect(() => {



    // Fetch company logo
    const fetchCompanyLogo = async () => {
      try {
        const token = sessionStorage.getItem("userToken");
        const response = await fetch(`${process.env.REACT_APP_BASE_URL}/companyprofile/getlogo/${token}`);
        if (response.ok) {
          const imageUrl = await response.blob();
          setUploadedImage(URL.createObjectURL(imageUrl));
        }
      } catch (error) {
        console.error("Error fetching company logo:", error);
      }
    };

    fetchCompanyLogo();
  }, []);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImage(reader.result);
      setSelectedLogo(file);
      setShowConfirmationDialog(true);
    };
    reader.readAsDataURL(file);
  };
  const handleUploadCancel = () => {
    setShowConfirmationDialog(false);
    window.location.reload();
  };

  const handleUpload = async () => {
    if (!selectedLogo) {
      return;
    }
    try {
      const formData = new FormData();
      formData.append("organisation_logo", selectedLogo);
      await UploadCompanyLogo(formData);
      toast.success("Logo updated successfully");
      setUploadedImage(URL.createObjectURL(selectedLogo));
    } catch (error) {
      toast.error("Failed to upload logo:", error);
    }
    setShowConfirmationDialog(false);
  };


  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  const dispatch = useDispatch();
  const timingsData = useSelector((state) => state.timings);
  useEffect(() => {
    if (timingsData?.Settings?.data?.length > 0) {
      const initialCompanyData = timingsData?.Settings?.data[0];
      setCompanyData({
        ...initialCompanyData,
      });
    }
  }, [timingsData]);

  const { Settings } = timingsData;
  const [companyData, setCompanyData] = useState({
    email: "",
    phone_number: "",
    company_address: "",
    company_name: ""
  });
  const handleChange = (e, fieldName) => {
    const { value } = e.target;
    setCompanyData(prevData => ({
      ...prevData,
      [fieldName]: value
    }));
  };

  const handleUpdateProfile = async () => {
    try {
      const response = await updateCompanyProfile({
        email: companyData.email,
        phone_number: companyData.phone_number,
        company_address: companyData.company_address,
        company_name: companyData.company_name
      });
      if (response.status == true) {
        toast.success(response.message);
      } else {
        toast.error(response.errorMessage)
      }
    } catch (error) {
      throw new Error("Failed to Update Profile.");
    }
  };

  // const handleChange = (e, v, name) => {
  //   console.log({ e, v, name });
  //   console.log("==", e._d);
  //   if (v === "time") {
  //     setCompanyData((prevData) => ({
  //       ...prevData,
  //       [name]: e?._d,
  //     }));
  //   } else {
  //     const val = v === null ? e?.target?.value : v[name];
  //     setCompanyData((prevData) => ({
  //       ...prevData,
  //       [name]: val,
  //     }));
  //   }
  // };
  const dayLabels = {
    sunday: "Sun",
    monday: "Mon",
    tuesday: "Tue",
    wednesday: "Wed",
    thursday: "Thu",
    friday: "Fri",
    saturday: "Sat",
  };

  const handleChangeTime = (value, name) => {
    const dateString = value._d;
    const date = new Date(dateString);
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const formattedTime = `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
    setCompanyData((prevData) => ({
      ...prevData,
      [name]: formattedTime,
    }));
  };

  useEffect(() => {
    if (Settings.data && Settings.data.length > 0) {
      setCompanyData(timingsData.Settings.data[0]);
    }
  }, [Settings.data, timingsData]);

  useEffect(() => {
    dispatch(fetchtimingsData());
  }, [dispatch]);
  return (
    <>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <div
        className="sub-main"
        style={{
          overflow: "hidden",
          padding: "20px",
        }}
      >
        <Paper
          sx={{
            display: "flex",
            background: "#FFFFFF 0% 0% no-repeat padding-box",
            boxShadow: "6px 9px 23px #00000012",
            border: "1px solid #CCC6C6",
            borderRadius: "24px",
            opacity: 1,
            padding: "20px",
            width: "100%",
            marginBottom: "20px",
            justifyContent: "space-between",
            "@media (max-width: 768px)": {
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
              width: "100%",
              margin: "0px auto 20px",
            },
          }}
        >
          <div style={{ display: "flex", flexWrap: "wrap" }}>
            <div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  maxWidth: "300px",
                  margin: "0 auto",
                  padding: "20px",
                }}
              >
                <Avatar
                  style={{
                    color: "#3E0BA1",
                    background: " #F7F2FF 0% 0% no-repeat padding-box",
                    fontSize: "100%",
                    width: "20vw",
                    height: "20vw",
                    maxWidth: "100px",
                    maxHeight: "100px",
                  }}
                >
                  {uploadedImage ? (
                    <img
                      src={uploadedImage}
                      alt="Uploaded"
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  ) : (
                    <div>Upload Icon</div>
                  )}
                </Avatar>
                <Typography
                  variant="body"
                  style={{ wordWrap: "break-word", textAlign: "center" }}
                >
                  {uploadedImage
                    ? "Upload another logo to replace"
                    : "Upload files to upload the logo"}
                </Typography>
                <label htmlFor="logoUploadInput">
                  <input
                    type="file"
                    id="logoUploadInput"
                    accept="image/*"
                    onChange={handleFileUpload}
                    style={{ display: "none" }}
                  />
                  {hasAccess.exists &&
                    <Button variant="contained" component="span" style={{ borderRadius: "30px" }}>Upload</Button>
                  }
                </label>
              </div>
            </div>
          </div>
          <div>
            {/* Organization Details Section */}
            <div style={{ flex: 1 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6} lg={6}>
                  <TextField
                    fullWidth
                    label={
                      <span>
                        Organization Name
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    name="company_name"
                    onChange={(e) => handleChange(e, "company_name")}
                    value={companyData.company_name}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="start">
                          <CorporateFareIcon />
                        </InputAdornment>
                      ),
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    size="small"
                    sx={{
                      fieldset: {
                        borderColor: "#3E0BA1 !important",
                        borderRadius: "5px",
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={6}>
                  <TextField
                    fullWidth
                    label={
                      <span>
                        Organization Email
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    name="email"
                    onChange={(e) => handleChange(e, "email")}
                    value={companyData.email}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="start">
                          <EmailIcon />
                        </InputAdornment>
                      ),
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    size="small"
                    sx={{
                      fieldset: {
                        borderColor: "#3E0BA1 !important",
                        borderRadius: "5px",
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6} lg={6}>
                  <TextField
                    fullWidth
                    label="Phone Number"
                    id="phone_number"
                    name="phone_number"
                    onChange={(e) => handleChange(e, "phone_number")}
                    value={companyData.phone_number}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="start">
                          <PhoneIcon />
                        </InputAdornment>
                      ),
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    size="small"
                    sx={{
                      fieldset: {
                        borderColor: "#3E0BA1 !important",
                        borderRadius: "5px",
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12}>
                  <TextField
                    fullWidth
                    multiline
                    rows={3}
                    sx={{
                      width: "100%",
                      fieldset: {
                        borderColor: "#3E0BA1 !important",
                        borderRadius: "5px",
                      },
                    }}
                    label={
                      <span>
                        Company Registered Address
                        <RequiredAsterisk>*</RequiredAsterisk>
                      </span>
                    }
                    name="company_address"
                    onChange={(e) => handleChange(e, "company_address")}
                    value={companyData.company_address}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="start">
                          <PlaceIcon />
                        </InputAdornment>
                      ),
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Grid>
                {hasAccess.exists &&
                  <Button
                    variant="contained"
                    style={{
                      marginRight: "15px",
                      background: "#3E0BA1 0% 0% no-repeat padding-box",
                      boxShadow: "3px 11px 12px #3E0BA154",
                      borderRadius: "38px",
                      textTransform: "none",
                      marginTop: "15px",
                    }}
                    onClick={handleUpdateProfile}
                  >
                    Update Profile
                  </Button>}
              </Grid>
            </div>
          </div>
        </Paper>
        <div>
          <Paper
            sx={{
              padding: "16px",
              background: "#FFFFFF 0% 0% no-repeat padding-box",
              boxShadow: "6px 9px 23px #00000012",
              border: "1px solid #CCC6C6",
              borderRadius: "24px",
              opacity: 1,
              marginBottom: "20px",
              // Responsive styles using media queries
              "@media (max-width: 1200px)": {
                padding: "12px",
              },
            }}
          >
            <Typography
              variant="h6"
              sx={{
                color: "#3E0BA1",
                marginBottom: "2%",
                fontSize: "1.5rem",
                "@media (max-width: 768px)": {
                  fontSize: "1.2rem",
                  marginBottom: "1%",
                },
              }}
            >
              <AccessTimeIcon sx={{ marginRight: "1%", color: "#3E0BA1" }} />
              Work Timings
            </Typography>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={12} md={6}>
                  <div
                    className="select-wrapper"
                    style={{
                      marginBottom: "2%",
                      "@media (max-width: 768px)": {
                        marginBottom: "1%",
                        marginRight: 0,
                      },
                    }}
                  >
                    <TimezoneSelect
                      aria-label="time"
                      label="Time Zone"
                      value={selectedTimezone}
                      onChange={setSelectedTimezone}
                      styles={{
                        control: (provided) => ({
                          ...provided,
                          borderColor: "#3E0BA1",
                          borderRadius: "5px",
                        }),
                      }}
                    />
                  </div>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <div>
                    <LocalizationProvider dateAdapter={AdapterMoment}>
                      <TimePicker
                        label={<span>Business hours starts from <RequiredAsterisk>*</RequiredAsterisk></span>}
                        id="start_time"
                        name="start_time"
                        value={`Thu Aug 24 2023 ${companyData?.start_time} GMT+0530 (India Standard Time)`}
                        onChange={(value) => handleChangeTime(value, "start_time")}
                        renderInput={(params) => (
                          <TextField
                            fullWidth
                            size="small"
                            sx={{
                              fieldset: {
                                borderColor: "#3E0BA1 !important",
                                borderRadius: "5px",
                              },
                            }} 
                            {...params}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </div>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <div>
                    <LocalizationProvider dateAdapter={AdapterMoment}>
                      <TimePicker
                        label={<span>Business hours ends at <RequiredAsterisk>*</RequiredAsterisk></span>}
                        id="end_time"
                        name="end_time"
                        value={`Thu Aug 24 2023 ${companyData?.end_time} GMT+0530 (India Standard Time)`}
                        onChange={(value) => handleChangeTime(value, "end_time")}
                        renderInput={(params) => (
                          <TextField
                            fullWidth
                            size="small"
                            sx={{
                              fieldset: {
                                borderColor: "#3E0BA1 !important",
                                borderRadius: "5px",
                              },
                            }}  
                            {...params}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </div>
                </Grid>

              </Grid>
            </div>
          </Paper>
        </div>
        <Paper
          sx={{
            padding: "16px",
            background: "#FFFFFF 0% 0% no-repeat padding-box",
            boxShadow: "6px 9px 23px #00000012",
            border: "1px solid #CCC6C6",
            borderRadius: "24px",
            opacity: 1,
            marginTop: "2%",
          }}
        >
          <div>
            <Typography
              variant="h6"
              sx={{
                display: "flex",
                alignItems: "center", // Center items vertically
                justifyContent: "left", // Center items horizontally
                color: "#3E0BA1",
                marginBottom: "2%",
                fontSize: "1.5rem",
                textAlign: "center",
                "@media (max-width: 768px)": {
                  fontSize: "1.2rem",
                  marginBottom: "1%",
                },
              }}
            >
              <EventAvailableIcon
                sx={{
                  marginRight: "1%",
                  color: "#3E0BA1",
                }}
              />
              Business Days
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={12} md={8}>
                <TableContainer>
                  <Table style={{ padding: "none", marginTop: "4%" }}>
                    <TableRow style={{ padding: "0px" }}>
                      {[
                        "sunday",
                        "monday",
                        "tuesday",
                        "wednesday",
                        "thursday",
                        "friday",
                        "saturday",
                      ].map((day) => {
                        return (
                          <TableCell align="left" key={day}>
                            <Grid item xs={6} sm={2}>
                              <Button
                                variant="contained"
                                size="small"
                                style={{
                                  textTransform: "none",
                                  display: "flex",
                                  flexDirection: "column",
                                  alignItems: "center",
                                  background: companyData[day]
                                    ? "#3E0BA1"
                                    : "#F0E8FF",
                                  borderRadius: "26px",
                                  width: "100%",
                                  marginBottom: "10px",
                                  padding: "10px",
                                  fontSize: "16px",
                                }}
                              >
                                {dayLabels[day] &&
                                  companyData[day] !== undefined && (
                                    <>
                                      <Checkbox
                                        icon={<RadioButtonUncheckedIcon />}
                                        checkedIcon={<CheckCircleIcon />}
                                        onChange={() => handleChangeChecked(day)}
                                        checked={companyData[day]}
                                        style={{
                                          color: companyData[day]
                                            ? "white"
                                            : "#3E0BA1",
                                          fontSize: "16px",
                                        }}
                                      />
                                      <span
                                        style={{
                                          color: companyData[day]
                                            ? "white"
                                            : "#3E0BA1",
                                          fontSize: "14px",
                                        }}
                                      >
                                        {dayLabels[day]}
                                      </span>
                                    </>
                                  )}
                              </Button>
                            </Grid>
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </Table>
                </TableContainer>
              </Grid>
              <Grid item xs={12} sm={12} md={4} sx={{ marginTop: "5%" }}>
                {hasAccess.exists && (
                  <div style={{ textAlign: "right" }}>
                    <Button
                      variant="contained"
                      style={{
                        marginRight: "15px",
                        background: "#3E0BA1 0% 0% no-repeat padding-box",
                        boxShadow: "3px 11px 12px #3E0BA154",
                        borderRadius: "38px",
                        textTransform: "none",
                        marginTop: "15px",
                      }}
                      onClick={handleEditUpdate}
                    >
                      Update
                    </Button>
                    <Button
                      variant="contained"
                      style={{
                        marginRight: "15px",
                        background: "#E33419 0% 0% no-repeat padding-box",
                        boxShadow: "3px 11px 12px #E3341970",
                        borderRadius: "38px",
                        textTransform: "none",
                        marginTop: "15px",
                      }}
                      onClick={handleClose}
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </Grid>
            </Grid>
          </div>
        </Paper>
      </div>
      <Dialog
        open={showConfirmationDialog}
        onClose={handleUploadCancel}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        style={{
          background: "rgba(148, 0, 211, 0.5)", // Transparent bluish color
          backdropFilter: "blur(0px)",
          WebkitBackdropFilter: "blur(0px)",
          opacity: 1,
        }}
      >
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <Button onClick={handleUploadCancel}>X</Button>
        </div>
        <DialogContent
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <CustomAvatar image={selectedLogo} />
          <DialogContentText id="alert-dialog-description">
            <Typography variant="h6">
              {" "}
              Are you sure you want to apply this logo?
            </Typography>
          </DialogContentText>
        </DialogContent>
        <DialogActions style={{ justifyContent: "center" }}>
          <Button
            onClick={handleUpload}
            sx={{
              backgroundColor: "#3E0BA1",
              color: "#FFFFFF",
              width: "150px",
              height: "40px",
              borderRadius: "45px",
              opacity: 1,
              textTransform: "none",
              "&:hover": {
                backgroundColor: "#3E0BA1", // Set the same background color as non-hovered state
                outline: "none", // Remove the outline on hover
              },
            }}
          >
            Apply
          </Button>
          <Button
            onClick={handleUploadCancel}
            sx={{
              backgroundColor: "#E33419",
              color: "#FFFFFF",
              width: "150px",
              height: "40px",
              borderRadius: "45px",
              opacity: 1,
              textTransform: "none",
              "&:hover": {
                backgroundColor: "#E33419", // Set the same background color as non-hovered state
                outline: "none", // Remove the outline on hover
              },
            }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
