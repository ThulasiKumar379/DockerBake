import React,{useState} from "react";
import PropTypes from "prop-types";
import {Tabs,Button,Box} from "@mui/material";
import { General } from "./Mainpage";
import ColorPicker from "./CustomLayout";
import { checkUserAccess } from "../../CheckUserAccess";
const hasAccess=checkUserAccess("confirguration_custom_layout")
function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 1 }}>{children}</Box>}
    </div>
  );
}
TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};
export default function BasicTabs() {
  const [value, setValue] = useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Box sx={{ width: "100%" }}>
      <Box
        sx={{ borderBottom: 0, borderColor: "divider", padding: "20px 12px" }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
          TabIndicatorProps={{ style: { display: "none" } }}
        >
          <Button
            onClick={(e) => handleChange(e, 0)}
            variant={value === 0 ? "contained" : "outlined"}
            sx={{
              textTransform: "none",
              fontWeight: value === 0 ? "bold" : "normal",
              backgroundColor: value === 0 ? "#3E0BA1" : "#FFFFFF",
              border: "1px solid #707070",
              borderRadius: "44px",
              "&:hover": {
                backgroundColor: value === 0 ? "#3E0BA1" : "#FFFFFF",  
              },
            }}
          >
            Company Details
          </Button>
          {hasAccess.exists&&
          <Button
            onClick={(e) => handleChange(e, 1)}
            variant={value === 1 ? "contained" : "outlined"}
            sx={{
              textTransform: "none",
              fontWeight: value === 1 ? "bold" : "normal",
              backgroundColor: value === 1 ? "#3E0BA1" : "#FFFFFF",
              marginLeft: "2%",
              border: "1px solid #707070",
              borderRadius: "44px",
              "&:hover": {
                backgroundColor: value === 1 ? "#3E0BA1" : "#FFFFFF",  
              },
            }}
          >
            Custom Layout
          </Button>}
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <General />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <ColorPicker />
      </TabPanel>
    </Box>
  );
}
