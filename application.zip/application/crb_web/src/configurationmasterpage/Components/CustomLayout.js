import React, { useState, useEffect } from "react";
import {
  Paper,
  TextField,
  FormControlLabel,
  Switch,
  Grid,
  Typography,
  InputLabel,
  Button,
  MenuItem, Select 
} from "@mui/material";
import { styled } from "@mui/material/styles";
import { checkUserAccess } from "../../CheckUserAccess";
import {
  fetchSettingsData,
  updateSettingData,
} from "../../api/Settings/settingReducer";
import { toast,ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useSelector, useDispatch } from "react-redux";
import Stack from "@mui/material/Stack";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
const IOSSwitch = styled((props) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 42,
  height: 26,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(16px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 0,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },

    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#33cf4d",
      border: "6px solid #fff",
    },

    "&.Mui-disabled .MuiSwitch-thumb": {
      color:
        theme.palette.mode === "light"
          ? theme.palette.grey[100]
          : theme.palette.grey[600],
    },

    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 22,
    height: 22,
  },
  "& .MuiSwitch-track": {
    borderRadius: 26 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
    transition: theme.transitions.create(["background-color"], {
      duration: 500,
    }),
  },
}));
export const ColorPicker = () => {
  const [, setBookedColor] = useState("#FF0000");
  const [customData] = useState("");
  const [, setUnbookedColor] = useState("#0000FF");
  const [, setValidationErrors] = useState({});
  const [checkInRemainMinutes, setCheckInRemainMinutes] = useState("");
  const [, setOpenEdit] = useState(false);
  const [reservationDuration, setReservationDuration] = useState("");
  const [emailNotification, setEmailNotification] = useState(true);
  const [, setEmailNotificationMessage] = useState("");
  const [publicAccess, setPublicAccess] = useState(true);
  const [data, setData] = useState([]);
  const [reservationRemainder, setReservationRemainder] = useState(true);
  const dispatch = useDispatch();
  const settingsData = useSelector((state) => state.settings);
  const { Settings } = settingsData;
  const hasAccess=checkUserAccess("confirguration_custom_layout")

  useEffect(() => {
    dispatch(fetchSettingsData());
  }, [dispatch]);

  useEffect(() => {
    if (settingsData?.Settings?.data?.length > 0) {
      setData(settingsData?.Settings?.data[0]);
    }
  }, [settingsData]);
  useEffect(() => {
    if (Settings.data && Settings.data.length > 0) {
      const {
        booked_room_color,
        unbooked_room_color,
        check_in_remain_minutes,
        reservation_duration,
        email_notification,
        email_notification_message,
        public_access,
        reservation_remainder,
      } = Settings.data[0];
      setBookedColor(booked_room_color);
      setUnbookedColor(unbooked_room_color);
      setCheckInRemainMinutes(check_in_remain_minutes);
      setReservationDuration(reservation_duration);
      setEmailNotification(email_notification);
      setEmailNotificationMessage(email_notification_message);
      setPublicAccess(public_access);
      setReservationRemainder(reservation_remainder);
    }
  }, [Settings]);
  const handleTextFieldChange = (fieldName, value) => {
    setData((prevData) => ({
      ...prevData,
      [fieldName]: value,
    }));
  };
  const handleEditUpdate = async () => {
    setValidationErrors({});
    const payload = {
      booked_room_color: data.booked_room_color,
      unbooked_room_color: data.unbooked_room_color,
      check_in_remain_minutes: checkInRemainMinutes,
      reservation_duration: reservationDuration,
      reservation_remainder: data.reservation_remainder,
      email_notification: data.email_notification,
      public_access: data.public_access,
      email_notification_message: data.email_notification_message,
      reservation_message:data.reservation_message
    };
    await dispatch(updateSettingData(payload))
      .then((data) => {
        if (data.payload.status) {
          console.log("deeeeeeeeee",data.payload)
          dispatch(fetchSettingsData());
          setTimeout(() => {
            toast.success("Settings updated successfully");
          }, 500);
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update settings");
        }, 500);
      });
    setOpenEdit(false);
  };
  const handleChange = (fieldName, value) => {
    // Update the state based on the field name
    setData((prevData) => ({
      ...prevData,
      [fieldName]: value,
    }));
  };
  const handleChangeTime = (value) => {
    if (!isNaN(value)) { 
        const hours = Math.floor(value / 60).toString().padStart(2, "0");
        const minutes = (value % 60).toString().padStart(2, "0");
        const formattedTime = `${hours} hours ${minutes} minutes`;
        setCheckInRemainMinutes(formattedTime);
    } else {
        console.error("Invalid value received:", value);
    }
};

const handleReservationslot = (value) => {
  if (!isNaN(value)) { 
      const hours = Math.floor(value / 60).toString().padStart(2, "0");
      const minutes = (value % 60).toString().padStart(2, "0");
      const formattedTime = `${hours} hours ${minutes} minutes`;
      setReservationDuration(formattedTime);
  } else {
      console.error("Invalid value received:", value);
  }
};

  console.log({ data });
  return (
    <>
    <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
    <div>
      <Grid container spacing={2} className="custom">
        <Grid item xs={12} sm={6}>
          <Paper
            elevation={3}
            style={{
              padding: "20px",
              marginBottom: "20px",
              display: "flex",
              flexDirection: "column",
              background: "#FFFFFF 0% 0% no-repeat padding-box",
              boxShadow: "6px 9px 23px #00000012",
              border: "1px solid #CCC6C6",
              borderRadius: "24px",
              opacity: "1",
            }}
          >
            <Typography variant="h6">Remainder</Typography>

            <Grid container spacing={2}>
              <Grid item xs={12} sm={12}>
              <InputLabel htmlFor="booked_room_color">
                Checkin remainder minutes
              </InputLabel>
              <Select
                id="check_in_remain_minutes"
                name="check_in_remain_minutes"
                value={checkInRemainMinutes}
                onChange={(event) => handleChangeTime(event.target.value)}
                renderValue={(value) => `${value} `}
                fullWidth
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: "5px",
                  },
                }}
              >
                <MenuItem value={10}>10 minutes</MenuItem>
                <MenuItem value={15}>15 minutes</MenuItem>
                <MenuItem value={20}>20 minutes</MenuItem>
                <MenuItem value={25}>25 minutes</MenuItem>
                <MenuItem value={30}>30 minutes</MenuItem>
                <MenuItem value={45}>45 minutes</MenuItem>
                <MenuItem value={60}>60 minutes</MenuItem>
              </Select>
            </Grid>


              <Grid item xs={12} sm={12}>
              <InputLabel htmlFor="booked_room_color">
                Reservation Duration slot
              </InputLabel>
              <Select
                id="check_in_remain_minutes"
                name="check_in_remain_minutes"
                value={reservationDuration}
                onChange={(event) => handleReservationslot(event.target.value)}
                renderValue={(value) => `${value} `}
                fullWidth
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: "5px",
                  },
                }}
              >
                <MenuItem value={30}>30 minutes</MenuItem>
                <MenuItem value={45}>45 minutes</MenuItem>
                <MenuItem value={60}>60 minutes</MenuItem>
                <MenuItem value={120}>90 minutes</MenuItem>
                <MenuItem value={150}>120 minutes</MenuItem>
                <MenuItem value={180}>150 minutes</MenuItem>
              </Select>
            </Grid>

              <Grid item xs={12} sm={12}>
              <FormControlLabel
                  sx={{ marginBottom: "0" }}
                  control={
                    <IOSSwitch
                      sx={{ m: 1 }}
                      checked={data?.reservation_remainder}
                      onChange={(e) =>
                        handleChange("reservation_remainder", e.target.checked)
                      }
                    />
                  }
                  id="reservation_remainder"
                  label="Reservation remainder"
                  name="reservation_remainder"
                  labelPlacement="start"
                />
              </Grid>

              <Grid item xs={12} sm={12}>
                <TextField
                  fullWidth
                  multiline
                  label="Reservation message"
                  rows={3}
                  sx={{
                    marginBottom: "10px",
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: "5px",
                    },
                  }}
                  id="reservation_message"
                  name="reservation_message"
                  InputLabelProps={{
                    shrink: data?.reservation_message || true,
                  }}
                  value={data?.reservation_message}
                  onChange={(e) =>
                    handleTextFieldChange(
                      "reservation_message",
                      e.target.value
                    )
                  }
                />
              </Grid>
            </Grid>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Paper
            elevation={3}
            style={{
              width: "100%",
              padding: "20px",
              marginBottom: "20px",
              display: "inline-block",
              background: "#FFFFFF 0% 0% no-repeat padding-box",
              boxShadow: "6px 9px 23px #00000012",
              border: "1px solid #CCC6C6",
              borderRadius: "24px",
              opacity: "1",
            }}
          >
            <Typography variant="h6">Pick the color</Typography>

            <Grid container spacing={1}>
              <Grid item xs={6} sm={6}>
                <InputLabel htmlFor="booked_room_color">
                  Booked room color
                </InputLabel>

                <TextField
                  type="color"
                  id="booked_room_color"
                  name="booked_room_color"
                  value={data?.booked_room_color}
                  // value={bookedColor}
                  // name="bookedColor"
                  onChange={(e) =>
                    handleChange("booked_room_color", e.target.value)
                  }
                  sx={{
                    maxWidth: "200px",
                    minWidth: "100px",
                    marginLeft: 0,
                    fieldset: {
                      borderColor: "#3E0BA1 !important",

                      borderRadius: "5px",
                    },
                  }}
                  size="small"
                />
              </Grid>

              <Grid item xs={6} sm={6}>
                <InputLabel htmlFor="unbooked_room_color">
                  Unbooked room color
                </InputLabel>

                <TextField
                  type="color"
                  id="unbooked_room_color"
                  name="unbooked_room_color"
                  value={data?.unbooked_room_color}
                  onChange={(e) =>
                    handleChange("unbooked_room_color", e.target.value)
                  }
                  sx={{
                    maxWidth: "200px",
                    minWidth: "100px",
                    marginLeft: 0,
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: "5px",
                    },
                  }}
                  size="small"
                />
              </Grid>
            </Grid>
          </Paper>

          <Paper
            sx={{
              width: "100%",
              flexDirection: "column",
              display: "inline-block",
              padding: "20px",
              background: "#FFFFFF 0% 0% no-repeat padding-box",
              boxShadow: "6px 9px 23px #00000012",
              border: "1px solid #CCC6C6",
              borderRadius: "24px",
              opacity: "1",
              marginBottom: "20px",
            }}
          >
            <Grid container spacing={1}>
              <Grid item xs={12}>
                <FormControlLabel
                  sx={{ marginBottom: "0" }}
                  control={
                    <IOSSwitch
                      sx={{ m: 1 }}
                      checked={data?.email_notification}
                      onChange={(e) =>
                        handleChange("email_notification", e.target.checked)
                      }
                    />
                  }
                  id="email_notifications"
                  label="Email Notifications"
                  name="email_notification"
                  labelPlacement="start"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  multiline
                  label="Email Notification message"
                  rows={2}
                  sx={{
                    width: "100%",
                    marginTop: "5px",
                    fieldset: {
                      borderColor: "#3E0BA1 !important",

                      borderRadius: "5px",
                    },
                  }}
                  id="email_notification_message"
                  name="email_notification_message"
                  InputLabelProps={{
                    shrink: data?.email_notification_message || true,
                  }}
                  value={data?.email_notification_message}
                  onChange={(e) =>
                    handleTextFieldChange(
                      "email_notification_message",
                      e.target.value
                    )
                  }
                ></TextField>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>

      <Paper
        style={{
          marginBottom: "20px",
          background: "#FFFFFF 0% 0% no-repeat padding-box",
          boxShadow: "6px 9px 23px #00000012",
          border: "1px solid #CCC6C6",
          borderRadius: "24px",
          opacity: "1",
          padding: "15px",
        }}
      >
        <Grid container spacing={2} sx={{ alignItems: "center" }}>
          <Grid item xs={12} sm={6}>
          <FormControlLabel
                  sx={{ marginBottom: "0" }}
                  control={
                    <IOSSwitch
                      sx={{ m: 1 }}
                      checked={data?.public_access}
                      onChange={(e) =>
                        handleChange("public_access", e.target.checked)
                      }
                    />
                  }
                  id="public_access"
                  label="Public Access"
                  name="public_access"
                  labelPlacement="start"
                />
          </Grid>
          {hasAccess.exists&&(
          <Grid item xs={12} sm={6} className="text-sm-right">
            <Button
              variant="contained"
              style={{
                marginRight: "15px",
                background: "#3E0BA1 0% 0% no-repeat padding-box",
                boxShadow: "3px 11px 12px #3E0BA154",
                borderRadius: "38px",
                textTransform: "none",
              }}
              onClick={handleEditUpdate}
            >
              Update
            </Button>

            <Button
              variant="contained"
              style={{
                background: "#E33419 0% 0% no-repeat padding-box",
                boxShadow: "4px 10px 17px #E3341970",
                borderRadius: "38px",
                textTransform: "none",
              }}
            >
              Cancel
            </Button>
          </Grid>
          )}
        </Grid>
      </Paper>
    </div>
    </>
  );
};
export default ColorPicker;
