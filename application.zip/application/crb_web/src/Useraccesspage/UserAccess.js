import { UseracessmanagementTabel } from './Useraccesstabel';
export const UserAccess = () => {
  return (
    <>
      <div className="App1">
        <UseracessmanagementTabel />
      </div>
    </>
  );
}