import * as React from "react";
import Table from "../Components/Table";
import { FilterUser } from "./users";
import { useEffect, useState } from "react";
import { checkUserAccess } from "../CheckUserAccess";
import {
  fetchUsersData, 
  deleteUserData,
} from "../api/UserAccessManagementPage/UserAccessReducers";
import { useSelector, useDispatch } from "react-redux";
import { fetchDepartmentsData } from "../api/Department/departmentReducers";
import { fetchDesignationsData } from "../api/Designation/designationReducers";
import { fetchBuildingsData } from "../api/Building/buildingReducers";
import { fetchRolesData } from "../api/Rolemaster/RoleReducer";
import { fetchLocationsData } from "../api/Location/locationReducer";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { EditUser } from "./popups/EditUser";
import {
  PersonAddAltOutlined as PersonAddAltOutlinedIcon,
  PersonRemoveOutlined as PersonRemoveOutlinedIcon,
} from "@mui/icons-material";
import {
  Stack,
  Button, 
  Tooltip, 
  Dialog,
  DialogContent,
  DialogTitle,
  DialogActions,
} from "@mui/material";
import { EditNote } from "@mui/icons-material";
 
import { buildAggregatedSortingApplier } from "@mui/x-data-grid/hooks/features/sorting/gridSortingUtils";

export const UseracessmanagementTabel = () => {
  const [tableRander, setTableRander] = React.useState(false);
  const [openedit, setOpenEdit] = React.useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [tableData, setTableData] = React.useState([]);
  const [deleteUserId, setDeleteUserId] = useState(null);
  const [currentRow, setCurrentRow] = useState(null);
  const [, keyChange] = useState(""); 
  const [show, setshow] = useState(true);
  const [rowData, setRowData] = useState(null);
  const dispatch = useDispatch();  
  const userData = useSelector((state) => state.users);
  const [searchObj, setSearchObj] = React.useState(null);
 let closeEdit=()=>{
  setOpenEdit(false)
 }
  const handleCloseedit = () => { 
    setshow(true);
  };
  let usersTable=()=>{  setTableRander(!tableRander); }

  let searchUserData=(obj)=>{     
    setSearchObj(obj);    
    setTableRander(!tableRander);
  }
  const hasAccessToEdit=checkUserAccess("edit_user")
  const hasAccessToDelete=checkUserAccess("delete_user")
  useEffect(() => {
    dispatch(fetchUsersData(searchObj));
  }, [tableRander]);
  const UsersData = userData?.users?.data || []; 
  useEffect(() => {
    if (UsersData?.length > 0) {
      const newData = UsersData.map((d) => { 
        const {
          crbt_buildings,
          crbt_departments,
          crbt_designations,
          crbt_locations,
          crbt_roles,
          email, 
          first_name,
          mobile_number,
          isactive,
          employee_code,
          last_name,   
          user_id
        } = d;         
        const building_name = crbt_buildings?.building_name; 
        const building_id = crbt_buildings?.building_id; 
        const department_name = crbt_departments?.department_name; 
        const department_id = crbt_departments?.department_id; 
        const designation_name = crbt_designations?.designation_name;  
        const designation_id = crbt_designations?.designation_id;            
        const location_name = crbt_locations?.location_name;   
        const location_id = crbt_locations?.location_id;   
        const role_name = crbt_roles?.role_name;
        const role_id = crbt_roles?.role_id;
        const constructData = {  
          email, 
          first_name,
          isactive:isactive?"Active":"InActive",
          last_name, 
          user_id,   
          mobile_number,
          location_name, 
          building_name, 
          designation_name, 
          department_name, 
          role_name, 
          data:{ employee_code,building_id,department_id,location_id,role_id,designation_id}
        }; 
        return constructData;
      });
      setTableData(newData);
    }else{
      setTableData([]);
    }
  }, [UsersData]); 

 
  useEffect(() => {
    dispatch(fetchDepartmentsData());
    // dispatch(fetchDesignationsData());
    dispatch(fetchRolesData());
    dispatch(fetchLocationsData());
    // dispatch(fetchBuildingsData());
  }, [dispatch]);
  
  const handleClickOpen = (currentRow) => {
    setDeleteUserId(currentRow);
    setCurrentRow(currentRow);
    setOpenDelete(true);
  };
  const handleCloseDelete = () => {
    setOpenDelete(false); 
  };
  
  const [validationErrors, setValidationErrors] = useState({});
  const initialValidationErrors = {
    email: "",
    first_name: "",
    last_name: "",
    mobile_number: "",
    employee_code: "",
    department_id: "",
    designation_id: "",
    building_id: "",
    location_id: "",
    role_id: "",
    password: "",
  };
  


  const handleEditButton = (currentRow) => {
    setValidationErrors(initialValidationErrors);
    setOpenEdit(true);
    const {
      user_id,
      email,
      first_name,
      last_name,
      mobile_number, 
      building_name, 
      department_name,
      designation_name, 
      role_name, 
      location_name,
      isactive,
      data
    } = currentRow;
  let employee_code=  data?.employee_code;
  let building_id=   data?.building_id;
  let role_id=   data?.role_id;
  let location_id=   data?.location_id;
  let department_id=data?.department_id;
  let designation_id=data?.designation_id; 
    const createPayload = {
      user_id,
      email,
      first_name,
      last_name, 
      mobile_number,
      employee_code,
      building_id,
      building_name,
      department_id,
      department_name,
      designation_name,
      designation_id,
      role_id,
      role_name,
      location_id,
      location_name,
      isactive
    };
    setRowData(createPayload);
  };
  

  const onDelete = async (currentRow) => {
    const { user_id, isactive } = currentRow;
    const action = isactive ? "deactivated" : "activated";
    const payload = {
      user_id: user_id,
      isactive: isactive ? "0" : "1",
    };
    await dispatch(deleteUserData(payload))
      .then((data) => {
        if (data.payload.status) {
          usersTable();
          setTimeout(() => {
            toast.success(`User ${action} successfully`);
          }, 500);
        } else {
          setTimeout(() => {
            toast.error(data.message);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error(`Failed to ${action} user`);
        }, 500);
      });
  };
  const handleDeleteConfirmation = () => {
    setOpenDelete(false);
    if (deleteUserId.user_id) {
      onDelete(deleteUserId);
    }
  };
  const columns = [
    {
      field: "user_id",
      headerName: "ID",
      flex: 1,
      width: 100,
      minWidth: 70,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "User name",
      headerName: "User name",
      flex: 1,
      width: 300,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => (
        <div>
          {params.row.first_name} {params.row.last_name}
        </div>
      ),
    },
    {
      field: "email",
      headerName: "Mail id",
      flex: 1,
      width: 250,
      minWidth: 250,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "location_name",
      headerName: "Location",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const userDataItem = userData?.users?.data?.find(
          (user) => user.user_id === params.row.user_id
        );
        const locationName = userDataItem?.crbt_locations?.location_name || "";
        return locationName;
      },
    },
    {
      field: "building_name",
      headerName: "Building",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const userDataItem = userData?.users?.data?.find(
          (user) => user.user_id === params.row.user_id
        );
        const buildingName = userDataItem?.crbt_buildings?.building_name || "";
        return buildingName;
      },
    },
    {
      field: "designation_name",
      headerName: "Designation",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const userDataItem = userData?.users?.data?.find(
          (user) => user.user_id === params.row.user_id
        );
        const designationName = userDataItem?.crbt_designations?.designation_name || "";
        return designationName;
      },
    },
    {
      field: "department_name",
      headerName: "Department",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const userDataItem = userData?.users?.data?.find(
          (user) => user.user_id === params.row.user_id
        );
        const departmentName =
          userDataItem?.crbt_departments?.department_name || "";
        return departmentName;
      },
    },
    {
      field: "role_name",
      headerName: "Role",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const userDataItem = userData?.users?.data?.find(
          (user) => user.user_id === params.row.user_id
        );
        const designationName = userDataItem?.crbt_roles?.role_name || "";
        return designationName;
      },
    },
    {
      field: "isactive",
      // field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        // const status = params.value?"active":"inactive";
        return <span>{params.value}</span>;
      },
    },
    {
      field: "Actions",
      headerClassName: "super-app-theme--header",
      headerName: "Actions",
      sortable: false,
      flex: 1,
      width: 150,
      minWidth: 150,
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleEditButton(currentRow)}
                sx={{ minWidth: "32px" }}
              >
                <EditNote openedit={openedit}                 
                closeEdit={handleCloseedit}/>
              </Button>
            </Tooltip>
            <Tooltip title={currentRow.isactive === "Active" ? "Deactivate" : ""}>
              <Button
                variant="text"
                color="error"
                size="small"
                disabled={!hasAccessToDelete.exists}
                onClick={currentRow.isactive === "Active" ? () => handleClickOpen(currentRow) : undefined}
                sx={{ minWidth: "32px" }}
              >
                {currentRow.isactive=="Active" ? (
                  <PersonRemoveOutlinedIcon color="error" />
                ) : (
                  <PersonAddAltOutlinedIcon color="disabled" />
                )}
              </Button>
            </Tooltip>
          </Stack>
        );
      },
    },
  ];
  return (
    <>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
     <EditUser 
     closeEdit={closeEdit}
     usersTable={usersTable}
     openedit={openedit}
     Editdata={rowData}/>
      <div style={{ marginTop: "2%" }}>
        <div style={{ marginBottom: "2%" }}>
          <FilterUser usersTable={usersTable} searchUserData={searchUserData}/>
        </div>
        <Table data={tableData} columns={columns} id={"user_id"}/>
        

        <Dialog open={opendelete} onClose={handleCloseDelete}>
        <DialogTitle
          sx={{
            borderBottom: "1px solid #e9ecef",
            paddingBottom: "10px",
            marginBottom: "14px",
            fontSize: "1rem",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <>Deactivate User</>
            <Button onClick={handleCloseDelete}>X</Button>
          </div>
        </DialogTitle>
        <DialogContent sx={{ color: "black" }}>
          Are you sure you want to deactivate this user?
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            className="bookingbtn"
            onClick={handleDeleteConfirmation}
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
              marginRight: "10px",
            }}
          >
            Deactivate
          </Button>
          <Button
            variant="outlined"
            className="bookingbtn1"
            sx={{
              textTransform: "capitalize",
              fontSize: "0.75rem",
            }}
            onClick={handleCloseDelete}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      </div>
      
    </>
  );
};
