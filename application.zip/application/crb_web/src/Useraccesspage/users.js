import {
  TextField,
  Button,
  Typography,
  DialogContent,
  DialogTitle,
  Dialog, 
  Grid,
} from "@mui/material";
import {
  Add as AddIcon,
  Search as SearchIcon,
  FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import { checkUserAccess } from "../CheckUserAccess";
import { Link, useNavigate, useLocation } from "react-router-dom";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux"; 
import { Add } from "./popups/AddUser";
import {UserAccessFilter} from './UserAccessFilter'


export const FilterUser = ({ 
  usersTable,searchUserData
}) => {
  const [openadd, setOpenAdd] = React.useState(false);
  const [, setCreateData] = useState({});
  const dispatch = useDispatch(); 
  const clearDesignation = () => {
   setCreateData((prevData) => ({
    ...prevData,
    ['designation_id']: '',
    ['designation_name']: '',
    ['udesignation_id']: ''
  }));
}
  const hasAccess=checkUserAccess("user_access_management")
  const hasAccessToCreate=checkUserAccess("add_user")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
      navigate("/");
   }
 
const handleClickadd = () => {
  setOpenAdd(true);
  };
const handleCloseadd = () => {
  setOpenAdd(false);
};


return (
  <>
    <Dialog open={openadd} fullWidth={true} maxWidth={"sm"}>
      <DialogTitle sx={{ borderBottom: "1px solid #e9ecef" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography variant="h5">Add a User</Typography>
          <Button onClick={handleCloseadd} sx={{ color: "black" }}>
            X
          </Button>
        </div>
      </DialogTitle>
      <DialogContent sx={{ paddingTop: "20px !important" }}>
        <Add onClose={handleCloseadd} usersTable={usersTable}  />
      </DialogContent>
    </Dialog>
    <Grid container spacing={1}>
      <Grid item xs={12} sm={8} md={9} lg={10}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          User Access Management
        </Typography>
      </Grid>
      <Grid
        item
        xs={12}
        sm={4}
        md={3}
        lg={2}
        className="noPadding noPadding600"
      >
        {hasAccessToCreate.exists&&(
        <Button
          fullWidth
          variant="contained"
          onClick={handleClickadd}
          sx={{
            padding: "10px 0",
            backgroundColor: "#0B78A1 !important",
            borderRadius: 0,
            fontSize: "0.75rem !important",
            lineHeight: "1.125rem",
            letterSpacing: 0,
            marginBottom: "15px;",
          }}
          startIcon={<AddIcon />}
        >
          Add User
        </Button>
        )}
      </Grid>
    </Grid>
   <UserAccessFilter searchUserData={searchUserData}/>
  </>
);
};
