import {
  TextField,
  Button,
  Box,
  Grid,
  FormControl,
  Autocomplete,
  Switch,
  FormControlLabel
} from "@mui/material";
import { useEffect, useState,useRef } from "react";
import {
  fetchUsersData,
  createUserData,
} from "../../api/UserAccessManagementPage/UserAccessReducers";
import { fetchDepartmentsData } from "../../api/Department/departmentReducers";
import { fetchDesignations } from "../../api/Designation/designationApi";
import { fetchBuildings, getBuildings } from "../../api/Building/buildingApi";
import { fetchRoles } from "../../api/Rolemaster/RoleApi";
import { fetchLocationsData } from "../../api/Location/locationReducer";

import { useSelector, useDispatch } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import React from "react";
import { styled } from "@mui/system";
const labelClassess = {
  label: { style: { color: "#2c2c2c" } },
};
export const Add = ({ onClose, usersTable }) => {
  const [isActiveAdd, setIsActiveAdd] = useState(true);
  const [createData, setCreateData] = useState({
    status: isActiveAdd, email: '',
    udesignation_id: '', designation_id: '', ubuilding_id: '', employee_code: '', last_name: '',
    building_id: '', role_id: '', designation_name: '', building_name: '', role_name: '', mobile_number: ''
  });
  const [validationErrors, setValidationErrors] = useState({});
  const [keyChange, setKeyChange] = useState("");
  const [buildingData, setBuildingData] = useState([]);
  const [designationData, setDesignationData] = useState([]);
  const [buildingError, setBuildingError] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const [mobileNumberError, setMobileNumberError] = useState(false);
  const [emailError, setEmailError] = useState(false);
  const [employeeCodeError, setEmployeeCodeError] = useState(false);
  const [lastNameError, setLastNameError] = useState(false);
  const [firstNameError, setFirstNameError] = useState(false);
  const [roleError, setRoleError] = useState(false);
  const [departmentError, setDepartmentError] = useState(false);
  const [designationError, setDesignationError] = useState(false);
  const departmentData = useSelector((state) => state.departments);
  const rolesData = useSelector((state) => state.roles.roles);
  const firstNameRef = useRef(null);
  const lastNameRef = useRef(null);
  const employeCodeRef = useRef(null);
  const emailRef = useRef(null);
  const phoneNumberRef = useRef(null);
  
  function validateEmail(email) { 
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  function validatePhoneNumber(phoneNumber) { 
    const phoneRegex = /^\d{10}$/;
    return phoneRegex.test(phoneNumber);
  }
  

  // const buildingData = useSelector((state) => state.buildings);
  const locationData = useSelector((state) => state.locations);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchDepartmentsData());
    dispatch(fetchLocationsData([]));
  }, [dispatch]);
  const HandleCancel = () => {
    onClose();
  };
  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const handleToogleAdd = (event) => {
    setIsActiveAdd(event.target.checked);
  };

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const handleChange = (e, v, name) => {

    const val = v === null ? e?.target?.value : v[name];
    if (Array.isArray(v)) {
      setCreateData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    } else if (name === "department" || name === "designation" || name === "location" || name === "building" || name === "role") {
      setCreateData((prevData) => ({
        ...prevData,
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setCreateData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }
    let setEmptyCreateData = (name, v) => {
      setCreateData((prevData) => ({
        ...prevData,
        [`${name}_id`]: "",
        [`${name}_name`]: "",
      }));
    }
    let fetchDesignationData = async (v) => {
      if (v != null) {
        const rlt = await fetchDesignations(v);
        setDesignationData({ designations: rlt.DesignationsData || [] });
      } else {
        setDesignationData([])
      }
    }
    if (name === "department") {
      setEmptyCreateData('designation', v)
      fetchDesignationData(v)
    }
    let fetchBuildingData = async (v) => {
      if (v != null) {
        let rlt = await fetchBuildings(v)
        setBuildingData({ buildings: rlt })
      } else {
        setBuildingData([])
      }
    }
    if (name === "location") {
      setEmptyCreateData('building', v)
      fetchBuildingData(v)
    }
    if (name === 'email') {
      if (!emailRegex.test(val)) {
        setEmailError(true);
      } else {
        setEmailError(false);
      }
    }

  };

  const getOptionLabelWithIdDepartment = (option) => {
    if (option?.department_id) {
      return `${option.udepartment_id} - ${option.department_name}`;
    } else {
      return option?.department_name;
    }
  };

  const getOptionLabelWithIdDesignation = (option) => {
    if (option?.designation_id) {
      return `${option?.udesignation_id} - ${option?.designation_name}`;
    } else {
      return '';
    }
  };
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.ubuilding_id} - ${option.building_name}`;
    } else {
      return '';
    }
  };
  const getOptionLabelWithIdRole = (option) => {
    if (option?.role_id) {
      return `${option?.role_id} - ${option?.role_name}`;
    } else {
      return option?.role_name;
    }
  };



  // const handleIsManagerChange = (event) => {
  //   setCreateData(prevState => ({
  //     ...prevState,
  //     isManager: event.target.checked
  // }));
  // };


  const handleSave = async () => {

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let isValid = true;
    if (!createData.email) {
      setEmailError("Email is required.");
      emailRef.current.focus()
      isValid = false;
    } else if (!emailRegex.test(createData.email)) {
      setEmailError("Invalid email format.");
      emailRef.current.focus()
      isValid = false;
    }
    if (!createData.mobile_number) {
      setMobileNumberError("Mobile number is required.");
      phoneNumberRef.current.focus()
      isValid = false;
    } else if (createData.mobile_number.length !== 10) {
      setMobileNumberError("Mobile number must be exactly 10 digits.");
      phoneNumberRef.current.focus()
      isValid = false;
    } else {
      setMobileNumberError(""); // Clear error if validation passes
    }
    const departmentIdAsInt = parseInt(createData.department_id, 10);
    const designationIdAsInt = parseInt(createData.designation_id, 10);
    const locationIdAsInt = parseInt(createData.location_id, 10);
    const buildingIdAsInt = parseInt(createData.building_id, 10);
    const roleIdAsInt = parseInt(createData.role_id, 10);
    const updatedCreateData = {
      ...createData,
      department_id: departmentIdAsInt,
      designation_id: designationIdAsInt,
      location_id: locationIdAsInt,
      building_id: buildingIdAsInt,
      role_id: roleIdAsInt,
      // isManager: createData.isManager
    };

    if (
      !createData.first_name ||
      !createData.last_name ||
      !createData.employee_code ||
      !createData.email ||
      !createData.mobile_number ||
      !createData.department_id ||
      !createData.designation_id ||
      !createData.location_id ||
      !createData.building_id ||
      !createData.role_id
    ) {
      setFirstNameError(!createData?.first_name)
      setLastNameError(!createData?.last_name)
      setEmployeeCodeError(!createData?.employee_code)
      setLocationError(!createData.location_id);
      setBuildingError(!createData.building_id);
      setDepartmentError(!createData.department_id);
      setDesignationError(!createData.designation_id);
      setRoleError(!createData.role_id);

      let object=[{
      key:createData.first_name,
      ref:firstNameRef.current,

    },
    {
      key:createData.last_name,
      ref:lastNameRef.current,
    },
    {
      key:createData.employee_code,
      ref:employeCodeRef.current,
    },
  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }
      return;
    }
    if (!isValid) {
      return;
    }
    await dispatch(createUserData(updatedCreateData))
      .then((data) => {
        if (data.payload.status) {
          setKeyChange(Math.random());
          setTimeout(() => {
            toast.success("User created successfully");
          }, 500);
          setIsActiveAdd(true);
          usersTable()
          HandleCancel();
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500)
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to create User");
        }, 500);
      });
  };
  return (
    <>
      <div>
        <FormControl>
          <Box sx={{ flexGrow: 1 }}>
            <Grid container spacing={2}>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  id={"first_name"}
                  name="first_name"
                  value={createData.first_name || ""}
                  inputRef={firstNameRef}
                  label={<span>
                    First Name
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>}
                  variant="outlined"
                  onChange={(e) => { handleChange(e, null, "first_name"); setFirstNameError(e.target.value.length < 2 || e.target.value.length > 120); }}
                  error={firstNameError}
                  helperText={
                    firstNameError ?
                      (createData.first_name && createData.first_name.length < 2 ? "Minimum 2 characters required." : "Maximum 120 characters allowed.")
                      : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  id={"last_name"}
                  name="last_name"
                  value={createData.last_name || ""}
                  inputRef={lastNameRef}
                  label={<span>
                    Last Name
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>}
                  variant="outlined"
                  onChange={(e) => { handleChange(e, null, "last_name"); setLastNameError(e.target.value.length < 2 || e.target.value.length > 120); }}
                  error={lastNameError}
                  helperText={
                    lastNameError ?
                      (createData.last_name && createData.last_name.length < 2 ? "Minimum 2 characters required." : "Maximum 120 characters allowed.")
                      : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  name="Employee code"
                  variant="outlined"
                  value={createData.employee_code || ""}
                  inputRef={employeCodeRef}
                  label={<span>
                    Employee code
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>}
                  onChange={(e) => { handleChange(e, null, "employee_code"); setEmployeeCodeError(e.target.value.length < 2 || e.target.value.length > 120); }}
                  error={employeeCodeError}
                  helperText={
                    employeeCodeError ?
                      (createData.employee_code && createData.employee_code.length < 2 ? "Minimum 2 characters required." : "Maximum 120 characters allowed.")
                      : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  value={createData.email || ""}
                  inputRef={emailRef}
                  label={
                    <span>
                      Email
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                  onChange={(e) => { handleChange(e, null, "email"); setEmailError(!validateEmail(e.target.value)); }}
                  error={emailError}
                  helperText={emailError ? "Invalid email format." : ""}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  name="phone number"
                  variant="outlined"
                  value={createData.mobile_number || ""}
                  inputRef={phoneNumberRef}
                  label={<span>
                    Phone number
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>}
                  onChange={(e) => { handleChange(e, null, "mobile_number"); setMobileNumberError(!validatePhoneNumber(e.target.value)); }}
                  error={mobileNumberError}
                  helperText={mobileNumberError ? "Invalid phone number." : ""}
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <Autocomplete
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="department_name"
                  onChange={(e, v) => {
                    console.log("vvvvv", v)
                    handleChange(e, v, "department");
                    setDepartmentError("");
                  }}
                  key={keyChange}
                  options={departmentData?.departments?.departmentData ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdDepartment(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Department ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Department Id-Name"
                      value={createData.department_id || []}
                      error={departmentError}
                      helperText={
                        departmentError ? "Department name is required." : ""
                      }
                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="designation_name"
                  onChange={(e, v) => {
                    handleChange(e, v, "designation");
                    setDesignationError("");
                  }}
                  key={keyChange}
                  options={designationData?.designations ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdDesignation(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Designation ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Designation ID-Name"
                      value={{ udesignation_id: createData.udesignation_id, designation_id: createData.designation_id, designation_name: createData.designation_name }}
                      error={designationError}
                      helperText={
                        designationError ? "Designation name is required." : ""
                      }
                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="location_id"
                  onChange={(e, v) => {
                    handleChange(e, v, "location");
                    setLocationError("");
                  }}
                  key={keyChange}
                  options={locationData?.locations?.location ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdLocation(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Location Id-Name"
                      value={createData.location_id || []}
                      error={locationError}
                      helperText={
                        locationError ? "Location name is required." : ""
                      }
                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="building_name"
                  onChange={(e, v) => {
                    handleChange(e, v, "building");
                    setBuildingError("");
                  }}
                  key={keyChange}
                  options={buildingData?.buildings?.BuildingsData ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdBuilding(option)
                  }
                  value={{ ubuilding_id: createData.ubuilding_id, building_id: createData.building_id, building_name: createData.building_name }}
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Building ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Building Id-Name"
                      value={createData.building_id || []}
                      error={buildingError}
                      helperText={
                        buildingError ? "Building name is required." : ""
                      }
                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id="checkboxes-tags-demo"
                  name="role_name"
                  onChange={(e, v) => {
                    handleChange(e, v, "role");
                    setRoleError("");
                  }}
                  key={keyChange}
                  options={rolesData?.roles || ""}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdRole(option)
                  }
                  getOptionDisabled={(option) => option.status === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={<div>
                        Role ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Role Id-Name"
                      value={createData.role_id || []}
                      error={roleError}
                      helperText={
                        roleError ? "Role Name is required." : ""
                      }
                      InputLabelProps={{
                        ...params.InputLabelProps,
                        ...labelClassess.label,
                      }}
                    />
                  )}
                />
              </Grid>
              {/* <Grid item xs={12} sm={6}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={createData.isManager}
                      onChange={handleIsManagerChange}
                      name="isManager"
                      color="primary"
                    />
                  }
                  label={
                    <span>
                      isManager
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                />
              </Grid>  */}
              <Grid item xs={12} sm={12} className="text-right">
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={isActiveAdd}
                      onChange={handleToogleAdd}
                    />
                  }
                  label={isActiveAdd ? "Active" : "Inactive"}
                  sx={{ marginBottom: "0" }}
                  labelPlacement="top"
                />
                <Button
                  className="bookingbtn"
                  onClick={handleSave}
                  sx={{
                    marginRight: "5px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                >
                  Add
                </Button>
                <Button
                  className="bookingbtn1"
                  onClick={HandleCancel}
                  sx={{ fontSize: "0.75rem", textTransform: "capitalize" }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </FormControl>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
    </>
  );
};
