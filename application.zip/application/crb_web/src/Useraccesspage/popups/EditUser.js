import { useEffect, useState, useRef } from "react";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import {
  Stack,
  Button,
  Grid,
  Box,
  TextField,
  IconButton,
  Typography,
  Dialog,
  DialogContent,
  Tooltip,
  DialogTitle,
  DialogContentText,
  DialogActions,
  FormControl,
  Autocomplete,
  InputAdornment,
  FormControlLabel,
  Switch,
} from "@mui/material";
import { styled } from "@mui/system";
import {
  updateUserData,
} from "../../api/UserAccessManagementPage/UserAccessReducers";
import { toast, ToastContainer } from "react-toastify";
import { useSelector, useDispatch } from "react-redux";
import { fetchBuildings } from "../../api/Building/buildingApi"
import { fetchDesignations } from "../../api/Designation/designationApi";
export const EditUser = ({ openedit, closeEdit, Editdata, usersTable }) => {
  const dispatch = useDispatch();
  const [buildingError, setBuildingError] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const [mobileNumberError, setMobileNumberError] = useState(false);
  const [emailError, setEmailError] = useState(false);
  const [employeeCodeError, setEmployeeCodeError] = useState(false);
  const [lastNameError, setLastNameError] = useState(false);
  const [firstNameError, setFirstNameError] = useState(false);
  const [roleError, setRoleError] = useState(false);
  const [departmentError, setDepartmentError] = useState(false);
  const [designationError, setDesignationError] = useState(false);
  const [passwordMismatch, setPasswordMismatch] = useState(false);
  const [showPasswordFields, setShowPasswordFields] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const RequiredAsterisk = styled("span")({ color: "red" });
  const [show, setshow] = useState(true);
  const [rowData, setRowData] = useState(Editdata || {});
  const [buildingData, setBuildingData] = useState([]);
  const [designationData, setDesignationData] = useState([]);
  const handleClickShowCurrentPassword = () => setShowCurrentPassword(!showCurrentPassword);
  const handleMouseDownCurrentPassword = () => setShowCurrentPassword(!showCurrentPassword);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState('');
  const departmentData = useSelector((state) => state.departments);
  const RoleData = useSelector((state) => state.roles);
  const locationData = useSelector((state) => state.locations);
  const [, keyChange] = useState("");
  const [, setIsActive] = useState(true);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const firstNameRef = useRef(null);
  const lastNameRef = useRef(null);
  const employeCodeRef = useRef(null);
  const emailRef = useRef(null);
  const phoneNumberRef = useRef(null);


  useEffect(() => {
    setRowData(Editdata);
    fetchDesignationsData([Editdata])
    fetchBuildingData([Editdata])
  },
    [Editdata]);

  // const handleIsManagerChange = (event) => {
  //   setRowData(prevState => ({
  //     ...prevState,
  //     isManager: event.target.checked
  //   }));
  // };

  const newPasswordRef = useRef(null);
  const confirmPasswordRef = useRef(null);

  

  const handlePassword = () => {
    if (showPasswordFields) {
      setNewPassword('');
      setConfirmPassword('');
    }
    setShowPasswordFields(!showPasswordFields);
  };

  const handleClickNewPassword = () => {
    setShowNewPassword(!showNewPassword);
  };

  const handleClickConfirmPassword = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  

  const setCursorAtEnd = (inputRef, password) => {
    setTimeout(() => {
      inputRef.focus();
      inputRef.setSelectionRange(password.length, password.length);
    }, 0);
  };

  useEffect(() => {
    if (newPasswordRef.current) {
      setCursorAtEnd(newPasswordRef.current, newPassword);
    }
  }, [showNewPassword, newPassword]);

  useEffect(() => {
    if (confirmPasswordRef.current) {
      setCursorAtEnd(confirmPasswordRef.current, confirmPassword);
    }
  }, [showConfirmPassword, confirmPassword]);

  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 34 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    maxWidth: "600px",
    width: "calc(100% - 64px)",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 0,
  };
  const toggleStatus = (isactive) => {
    setRowData((prevData) => ({
      ...prevData,
      isactive: isactive,
    }));
  };
  const handleToogleEdit = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };

  const handleClickShowPasswordFields = () => {
    setShowPasswordFields(!showPasswordFields);
    setNewPassword('');
    setConfirmPassword('');
    setPasswordMismatch(false);
  };

  const handleNewPasswordChange = (e) => {
    setNewPassword(e.target.value);
    if (confirmPassword && e.target.value !== confirmPassword) {
      setPasswordMismatch(true);
    } else {
      setPasswordMismatch(false);
    }
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
    if (newPassword && e.target.value !== newPassword) {
      setPasswordMismatch(true);
    } else {
      setPasswordMismatch(false);
    }
  };

  const handleEditUpdate = async () => {
    if (newPassword !== confirmPassword) {
      setPasswordMismatch(true);
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let isValid = true;
    if (!rowData.email) {
      setEmailError("Email is required.");
      emailRef.current.focus()
      isValid = false;
    } else if (!emailRegex.test(rowData.email)) {
      setEmailError("Invalid email format.");
      emailRef.current.focus()
      isValid = false;
    }
    if (!rowData.mobile_number) {
      setMobileNumberError("Mobile number is required.");
      phoneNumberRef.current.focus()
      isValid = false;
    } else if (rowData.mobile_number.length !== 10) {
      setMobileNumberError("Mobile number must be exactly 10 digits.");
      phoneNumberRef.current.focus()
      isValid = false;
    } else {
      setMobileNumberError(""); // Clear error if validation passes
    }
    const departmentIdAsInt = parseInt(rowData.department_id, 10);
    const designationIdAsInt = parseInt(rowData.designation_id, 10);
    const locationIdAsInt = parseInt(rowData.location_id, 10);
    const buildingIdAsInt = parseInt(rowData.building_id, 10);
    const roleIdAsInt = parseInt(rowData.role_id, 10);
    const updatedCreateData = {
      ...rowData,
      department_id: departmentIdAsInt,
      designation_id: designationIdAsInt,
      location_id: locationIdAsInt,
      building_id: buildingIdAsInt,
      role_id: roleIdAsInt,
      // isManager: rowData.isManager
    };

    if (
      !rowData.first_name ||
      !rowData.last_name ||
      !rowData.employee_code ||
      !rowData.email ||
      !rowData.mobile_number ||
      !rowData.department_id ||
      !rowData.designation_id ||
      !rowData.location_id ||
      !rowData.building_id ||
      !rowData.role_id
    ) {
      setFirstNameError(!rowData?.first_name)
      setLastNameError(!rowData?.last_name)
      setEmployeeCodeError(!rowData?.employee_code)
      setLocationError(!rowData.location_id);
      setBuildingError(!rowData.building_id);
      setDepartmentError(!rowData.department_id);
      setDesignationError(!rowData.designation_id);
      setRoleError(!rowData.role_id);

      let object=[{
      key:rowData.first_name,
      ref:firstNameRef.current,

    },
    {
      key:rowData.last_name,
      ref:lastNameRef.current,
    },
    {
      key:rowData.employee_code,
      ref:employeCodeRef.current,
    },
  ]
  for(let i=0;i<object.length;i++){
     if (!object[i].key) { 
      object[i].ref.focus();
      break;
    } 
  }




      return;
    }
    if (!isValid) {
      return;
    }
    rowData.newpassword = newPassword
    rowData.confirmpassword = confirmPassword
    await dispatch(updateUserData(rowData))
      .then((data) => {
        if (data.payload.status) {
          closeEdit();
          usersTable()
          setTimeout(() => {
            toast.success("User data updated successfully");
          }, 500);
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update user data");
        }, 500);
      });
    setIsActive(true);
  };
  const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.location_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  };
  const getOptionLabelWithIdRole = (option) => {
    if (option?.role_id) {
      return `${option.role_id} - ${option.role_name}`;
    } else {
      return option?.role_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option.building_id} - ${option.building_name}`;
    } else {
      return option?.building_name;
    }
  };

  const getOptionLabelWithIdDepartment = (option) => {
    if (option?.department_id) {
      return `${option.department_id} - ${option.department_name}`;
    } else {
      return option?.department_name;
    }
  };
  const HandelPassword = () => {
    setshow(false);
  };
  const getOptionLabelWithIdDesignation = (option) => {
    if (option?.designation_id) {
      return `${option.designation_id} - ${option.designation_name}`;
    } else {
      return option?.designation_name;
    }
  };

  let fetchBuildingData = async (v) => {
    if (openedit) {
      if (v != null) {
        let rlt = await fetchBuildings(v)
        console.log(rlt)
        setBuildingData({ buildings: rlt })
      } else {
        setBuildingData([])
      }
    }
  }
  let fetchDesignationsData = async (v) => {
    if (openedit) {
      if (v != null) {
        let rlt = await fetchDesignations(v)
        setDesignationData({ designations: rlt.DesignationsData || [] })
      } else {
        setDesignationData([])
      }
    }

  }

  const handleEditChange = async (e, v, name) => {
    let val = v === null ? e?.target?.value : v[name];
    if (name === "room_amenities") {
      setRowData((prevData) => ({
        ...prevData,
        [name]: v,
      }))
      if (name === "status") {
        setIsActive(val);
      }
    }
    else if (name === "department" || name === "designation" || name === "location" || name === "building" || name === "role") {
      setRowData((prevData) => ({
        ...prevData,
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      setRowData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }
    if (name === "department") {
      setRowData((prevData) => ({
        ...prevData,
        [`designation_id`]: "",
        [`designation_name`]: "",
      }));
      await fetchDesignationsData(v);
    }
    if (name === "location") {
      setRowData((prevData) => ({
        ...prevData,
        [`building_id`]: "",
        [`building_name`]: "",
      }));
      await fetchBuildingData(v);
    }

  };


  return (
    <Dialog
      open={openedit}
      onClose={closeEdit}
      fullWidth={true}
      maxWidth={"sm"}
    >
      <DialogTitle
        style={{ display: "flex", justifyContent: "space-between" }}
        sx={{ borderBottom: "1px solid #e9ecef" }}
      >
        <Typography variant="h5">Edit User</Typography>
        <Button onClick={closeEdit} sx={{ color: "black" }}>
          X
        </Button>
      </DialogTitle>
      <DialogContent>
        <FormControl>
          <Box sx={{ flexGrow: 1, marginTop: "2%" }}>
            <Grid container spacing={2}>


              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  id={"first_name"}
                  name="first_name"
                  value={rowData && rowData.first_name}
                  inputRef={firstNameRef}
                  InputLabelProps={{ shrink: rowData && rowData?.first_name }}
                  onChange={(e) => { handleEditChange(e, null, "first_name"); setFirstNameError(false); }}
                  label={<span>First Name <RequiredAsterisk>*</RequiredAsterisk></span>}
                  variant="outlined"
                  error={firstNameError}
                  helperText={
                    firstNameError ? "First Name is required." : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  id={"last_name"}
                  name="last_name"
                  value={rowData && rowData.last_name}
                  inputRef={lastNameRef}
                  InputLabelProps={{ shrink: rowData && rowData?.last_name }}
                  onChange={(e) => { handleEditChange(e, null, "last_name"); setLastNameError(false) }}
                  label={<span>Last Name <RequiredAsterisk>*</RequiredAsterisk></span>}
                  variant="outlined"
                  error={lastNameError}
                  helperText={
                    lastNameError ? "Last Name is required." : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={<div>
                    Employee Code <RequiredAsterisk>*</RequiredAsterisk>
                  </div>}
                  variant="outlined"
                  id={"employee_code"}
                  name="employee_code"
                  value={rowData && rowData.employee_code}
                  inputRef={employeCodeRef}
                  InputLabelProps={{
                    shrink: rowData && rowData?.employee_code,
                  }}
                  onChange={(e) => { setEmployeeCodeError(false); handleEditChange(e, null, "employee_code") }}
                  error={employeeCodeError}
                  helperText={
                    employeeCodeError ? "Employee code is required." : ""
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  id={"email"}
                  name="email"
                  value={rowData && rowData?.email}
                  inputRef={emailRef}
                  InputLabelProps={{ shrink: rowData && rowData?.email }}
                  onChange={(e) => { handleEditChange(e, null, "email"); setEmailError(false); }}
                  label={
                    <span>
                      Email
                      <RequiredAsterisk>*</RequiredAsterisk>
                    </span>
                  }
                  variant="outlined"
                  error={emailError}
                  helperText={
                    emailError
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label={<div>
                    Phone Number <RequiredAsterisk>*</RequiredAsterisk>
                  </div>}
                  variant="outlined"
                  id={"mobile_number"}
                  name="mobile_number"
                  value={rowData && rowData.mobile_number}
                  inputRef={phoneNumberRef}
                  InputLabelProps={{
                    shrink: rowData && rowData?.mobile_number,
                  }}
                  onChange={(e) => { handleEditChange(e, null, "mobile_number"); setMobileNumberError(false); }}
                  error={mobileNumberError}
                  helperText={
                    mobileNumberError
                  }
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <Autocomplete
                  id="department_name"
                  name="department_id"
                  onChange={(e, v) => { setDepartmentError(false); handleEditChange(e, v, "department") }}
                  key={keyChange}
                  value={{
                    udepartment_id: rowData?.udepartment_id,
                    department_name: rowData?.department_name,
                    department_id: rowData?.department_id,
                  }}
                  options={departmentData?.departments?.departmentData ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdDepartment(option)
                  }
                  getOptionDisabled={(option) => option.isactive === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      size="small"
                      label={<div>
                        Department ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      id={"department_name"}
                      name="department_id"
                      autoComplete="on"
                      // value={rowData.department_name}
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.department_name),
                      }}
                      sx={{ marginBottom: "0px", marginRight: "10px" }}
                      error={departmentError}
                      helperText={
                        departmentError ? "Department name is required." : ""
                      }
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  fullWidth
                  size="small"
                  id="checkboxes-tags-demo"
                  onChange={(e, v) => { setDesignationError(false); handleEditChange(e, v, "designation") }}
                  key={keyChange}
                  value={{
                    designation_name: rowData?.designation_name,
                    designation_id: rowData?.designation_id,
                    udesignation_id: rowData?.udesignation_id,
                  }}
                  name="designation_name"
                  options={designationData?.designations || []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdDesignation(option)
                  }
                  getOptionDisabled={(option) => option.isactive === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label={
                        <span>
                          Designation ID-Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      placeholder="Designation"
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.designation_name),
                      }}
                      error={designationError}
                      helperText={
                        designationError ? "Designation name is required." : ""
                      }
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  // fullWidth
                  size="small"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                  }}
                  id={"location_name"}
                  name="location_name"
                  onChange={(e, v) => {
                    handleEditChange(e, v, "location")
                    setLocationError(false);
                  }}
                  key={keyChange}
                  options={locationData?.locations?.location ?? []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdLocation(option)
                  }
                  value={{
                    location_name: rowData?.location_name,
                    location_id: rowData?.location_id,
                    ulocation_id: rowData?.ulocation_id,
                  }}
                  getOptionDisabled={(option) => option.isactive === false}
                  renderInput={(params) => (
                    <TextField
                      fullWidth
                      {...params}
                      label={<div>
                        Location ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      placeholder="Location"
                      error={locationError}
                      helperText={
                        locationError ? "Location name is required." : ""
                      }
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.location_name),
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  id="building_name"
                  name="building_name"
                  onChange={(e, v) => {
                    handleEditChange(e, v, "building");
                    setBuildingError("");
                  }
                  }
                  key={keyChange}
                  value={{
                    building_name: rowData?.building_name,
                    building_id: rowData?.building_id,
                    ubuilding_id: rowData?.ubuilding_id,
                  }}
                  options={
                    buildingData?.buildings?.BuildingsData || []
                  }
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdBuilding(option)
                  }
                  getOptionDisabled={(option) => option.isactive === false}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      size="small"
                      label={<div>
                        Building ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                      </div>}
                      id={"building_name"}
                      name="building_name"
                      autoComplete="on"
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.building_name),
                      }}
                      error={buildingError}
                      helperText={
                        buildingError ? "Building name is required." : ""
                      }
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <Autocomplete
                  fullWidth
                  size="small"
                  id="checkboxes-tags-demo"
                  options={RoleData.roles.roles}
                  onChange={(e, v) => {
                    setRoleError(false);
                    handleEditChange(e, v, "role");
                  }}
                  key={keyChange}
                  value={{
                    role_name: rowData?.role_name,
                    role_id: rowData?.role_id,
                  }}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdRole(option)
                  }
                  getOptionDisabled={(option) => option.isactive === false}
                  renderInput={(params) => (
                    <TextField
                      value={rowData?.role_name}
                      defaultValue={{ role_name: rowData?.role_name }}
                      InputLabelProps={{
                        shrink:
                          Boolean(params.inputProps.value) ||
                          Boolean(rowData?.role_name),
                      }}
                      {...params}
                      label={
                        <span>
                          Role Id-Name
                          <RequiredAsterisk>*</RequiredAsterisk>
                        </span>
                      }
                      placeholder="Role"
                      error={roleError}
                      helperText={
                        roleError ? "Role Name is required." : ""
                      }
                    />
                  )}
                />
              </Grid>
              {/* <Grid item xs={12} sm={6}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={rowData?.isManager}
                      onChange={handleIsManagerChange}
                      name="isManager"
                      color="primary"
                    />
                  }
                  label={
                    <span>
                      isManager
                    </span>
                  }
                />
              </Grid> */}
              <Grid item xs={12} sm={6}>
                <div>
                  <span>
                    <Button
                      variant="contained"
                      size="small"
                      onClick={handleClickShowPasswordFields}
                      className="Invitedbtn"
                    >
                      Change Password
                    </Button>
                  </span>
                </div>
              </Grid>
              <Grid item xs={12} sm={6}></Grid>
              <Grid container spacing={3}>
                {showPasswordFields && (
                  <>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        size="small"
                        label="New Password"
                        value={newPassword}
                        onChange={handleNewPasswordChange}
                        variant="outlined"
                        type={showNewPassword ? "text" : "password"}
                        error={passwordMismatch}
                        helperText={passwordMismatch ? "Passwords do not match" : ""}
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                aria-label="toggle password visibility"
                                onClick={handleClickNewPassword}
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showNewPassword ? <Visibility /> : <VisibilityOff />}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Confirm Password"
                        value={confirmPassword}
                        onChange={handleConfirmPasswordChange}
                        variant="outlined"
                        type={showConfirmPassword ? "text" : "password"}
                        error={passwordMismatch}
                        helperText={passwordMismatch ? "Passwords do not match" : ""}
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                aria-label="toggle password visibility"
                                onClick={handleClickConfirmPassword}
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showConfirmPassword ? <Visibility /> : <VisibilityOff />}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Grid>
                  </>
                )}
              </Grid>
              <Grid item xs={12} sm={12} className="text-right">
                <FormControlLabel
                  control={
                    <IOSSwitch
                      checked={(rowData?.isactive === true || rowData?.isactive === 'Active') ? true : false}
                      onChange={handleToogleEdit}
                    />
                  }
                  label={(rowData?.isactive === "Active" || rowData?.isactive === true) ? "Active" : "Inactive"}
                  sx={{ marginBottom: "0" }}
                  labelPlacement="top"
                />
                <Button
                  className="bookingbtn"
                  onClick={handleEditUpdate}
                  sx={{
                    marginRight: "10px",
                    fontSize: "0.75rem",
                    textTransform: "capitalize",
                  }}
                >
                  Update
                </Button>
                <Button
                  className="bookingbtn1"
                  onClick={closeEdit}
                  sx={{ fontSize: "0.75rem", textTransform: "capitalize" }}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </FormControl>
      </DialogContent>
    </Dialog>
  )
}