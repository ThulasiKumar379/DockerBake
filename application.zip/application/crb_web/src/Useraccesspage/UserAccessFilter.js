import {
    TextField, 
    Typography, 
    Autocomplete,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    styled,
    Box,
    Grid,
  } from "@mui/material";
  import {
    Add as AddIcon,
    Search as SearchIcon,
    FilterAlt as FilterAltIcon,
    ExpandMore as ExpandMoreIcon,
  } from "@mui/icons-material";
    import React, { useState,useEffect } from "react";
    import { useDispatch, useSelector } from "react-redux"; 
    import { fetchBuildings, getBuildings } from "../api/Building/buildingApi";
    import { fetchDesignations } from "../api/Designation/designationApi";
export const UserAccessFilter = ({ searchUserData  }) => {
    const dispatch = useDispatch();
    const [selectedDesignationFilter, setSelectedDesignationFilter] = useState([]);
    const [designationData, setDesignationData] = useState([]);   
    const [selectedBuldingFilter, setSelectedBuldingFilter] = useState([]);    
    const [keyChange, setKeyChange] = useState("");   
    const [buildingData, setBuildingData] = useState([]);   
    const [rolesSearch, setRolesSearch] = useState([]);
    const [designationSearch, setDesignationSearch] = useState([]);
    const [departmentSearch, setDepartmentSearch] = useState([]);
    const [locationSearch, setLocationSearch] = useState([]);
    const [buldingSearch, setBuldingSearch] = useState([]);
    const [selectedRolesFilter, setselectedRolesFilter] = useState([]);
    const rolesData = useSelector((state) => state.roles.roles); 
    const departmentData = useSelector((state) => state.departments);
    const locationData = useSelector((state) => state.locations);
  
    const RequiredAsterisk = styled("span")({
      color: "red",
    });

    useEffect(() => { 
      searchUserData({rolesSearch,
        designationSearch,
        departmentSearch,
        locationSearch,
        buldingSearch
      }) 
    },[rolesSearch,designationSearch,departmentSearch,locationSearch,buldingSearch]);

const getOptionLabelWithIdLocation = (option) => {
    if (option?.location_id) {
      return `${option.ulocation_id} - ${option.location_name}`;
    } else {
      return option?.location_name;
    }
  }; 
  const getOptionLabelWithIdRole = (option) => {
    if (option?.role_id) {
      return `${option?.role_id} - ${option?.role_name}`;
    } else {
      return option?.role_name;
    }
  };
  const getOptionLabelWithIdBuilding = (option) => {
    if (option?.building_id) {
      return `${option?.ubuilding_id} - ${option?.building_name}`;
    } else {
      return '';
    }
  };
  const getOptionLabelWithIdDepartment = (option) => {
    if (option?.department_id) {
      return `${option?.udepartment_id} - ${option?.department_name}`;
    } else {
      return option?.department_name;
    }
  }; 
  const labelClassess = {
      label: { style: { color: "#2c2c2c" } },
    }; 
  const getOptionLabelWithIdDesignation = (option) => { 
      if (option?.designation_id) {
      return `${option?.udesignation_id} - ${option?.designation_name}`;
      } else {
      return '';
      }
  };  

  const departmentDataHandler = async (e, v) => {
    setSelectedDesignationFilter([]);
    setDesignationData([]);
    setDesignationSearch([]);
    let value = v ? v.map((option) => option.department_id) : [];
    value = value.length > 0 ? value : [];
    setDepartmentSearch(value);
    if (value.length !== 0) { 
        const rlt = await fetchDesignations(value); 
        setDesignationData( {designations:rlt?.DesignationsData || [] } );
    }
  };
  const designationDataHandler = (e, v) => {
    let value = v ? v.map((option) => option.designation_id) : [];
    setDesignationSearch(value)
    setSelectedDesignationFilter(v)
  };
  const roleNameHandler = async (e, v) => {
    setselectedRolesFilter(v)
    let value = v
      ? v.map((option) => option.role_id)
      : [];
    value = value.length > 0 ? value : [];
    setRolesSearch(value)
   
  }; 
   
  const locationNameHandler = async (e, v) => {
    setSelectedBuldingFilter([])
    setBuildingData([])
    setBuldingSearch([])
    let value = v
      ? v.map((option) => option.location_id)
      : [];
    value = value.length > 0 ? value : [];
    setLocationSearch(value)
    if (value.length > 0) {
      let rlt = await fetchBuildings(v)
      setBuildingData({ buildings: rlt })
    }
  }; 
  const buildingNameHandler = (e, v) => {
    let value = v? v.map((option) => option.building_id): [];
    setBuldingSearch(value)
    setSelectedBuldingFilter(v)
  };
return (
    <Accordion
    sx={{
      backgroundColor: "#3E0BA1",
      color: "#fff",
      margin: "0 0 15px !important",
      borderRadius: "0 !important",
    }}
  >
    <AccordionSummary
      expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
      aria-controls="panel1a-content"
      id="panel1a-header"
      sx={{
        minHeight: "48px !important",
        "& .Mui-expanded": {
          margin: "12px 0 !important",
        },
      }}
    >
      <Typography>
        <FilterAltIcon /> Filter
      </Typography>
    </AccordionSummary>
    <AccordionDetails
      sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
    >
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={1}>
        <Grid item xs={12} sm={6} md={3} lg={2}>
            <Autocomplete
              multiple
              size="small"
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                marginBottom: "10px",
              }}
              id="checkboxes-tags-demo"
              name="location_name"
              onChange={(e, v) =>
                locationNameHandler(e, v)
              }
              key={keyChange && Math.random()}
              options={locationData?.locations?.location ?? []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdLocation(option)
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Location Id-Name"
                  placeholder="Location Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3} lg={2}>
            <Autocomplete
              multiple
              size="small"
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                marginBottom: "10px",
              }}
              id="checkboxes-tags-demo"
              name="building_name"
              value={selectedBuldingFilter}
              onChange={(e, v) =>
                buildingNameHandler(e, v)
              }
              key={keyChange && Math.random()}
              options={buildingData?.buildings?.BuildingsData || []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdBuilding(option)
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Building Id-Name"
                  placeholder="Building Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3} lg={2.3}>
            <Autocomplete
              multiple
              fullWidth
              clearOnEscape
              size="small"
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                marginBottom: "10px",
              }}
              // margin="dense"
              id="checkboxes-tags-demo"
              name="department_name"
              // value={selectedDesignationFilter}
              onChange={(e, v) => { departmentDataHandler(e, v) }
              }
              key={keyChange && Math.random()}
              options={departmentData?.departments?.departmentData || []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdDepartment(option)
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Department Id-Name"
                  placeholder="department Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3} lg={2.3}>
            <Autocomplete
              multiple
              // fullWidth
              // clearOnEscape
              size="small"
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                marginBottom: "10px",
              }}
              // margin="dense"
              id="checkboxes-tags-demo"
              name="designation_name"
              value={selectedDesignationFilter}
              onChange={(e, v) => 
                { designationDataHandler(e, v) }
              }
              key={keyChange && Math.random()}
              options={designationData?.designations??  []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdDesignation(option)
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={<div>
                    Designation ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>}
                  placeholder="Designation ID-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid>
          
         
          <Grid item xs={12} sm={6} md={3} lg={2}>
            <Autocomplete
              multiple
              size="small"
              sx={{
                fieldset: {
                  borderColor: "#3E0BA1 !important",
                  borderRadius: 0,
                },
                marginBottom: "10px",
              }}
              id="checkboxes-tags-demo"
              name="building_name"
              value={selectedRolesFilter}
              onChange={(e, v) =>
                roleNameHandler(e, v)
              }
              key={keyChange && Math.random()}
              options={rolesData?.roles || []}
              getOptionLabel={(option) =>
                getOptionLabelWithIdRole(option)
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Role Id-Name"
                  placeholder="Role Id-Name"
                  InputLabelProps={{
                    ...params.InputLabelProps,
                    ...labelClassess.label,
                  }}
                />
              )}
            />
          </Grid> 
        </Grid> 
      </Box>
    </AccordionDetails>
  </Accordion>
)
}