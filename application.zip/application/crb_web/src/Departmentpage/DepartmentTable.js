import * as React from "react";
import { useSelector, useDispatch } from "react-redux";
import Table from "../Components/Table";
import { red } from "@mui/material/colors";
import {
  getDepartmentsData,
  updateDepartmentData,
  deleteDepartmentData,
} from "../api/Department/departmentReducers";
import { checkUserAccess } from "../CheckUserAccess";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useEffect, useState, useRef } from "react";
import DepartmentForm from "./DepartmentForm";
import {
  Button,
  Grid,
  Box,
  TextField,
  Dialog,
  DialogContent,
  Tooltip,
  DialogTitle,
  DialogActions,
  FormControlLabel,
  Switch,
} from "@mui/material";
import { styled } from "@mui/system";
import { EditNote, DoNotDisturbOn as DoNotDisturbOnIcon } from "@mui/icons-material";
export const DepartmentTable = () => {
  const [openedit, setOpenEdit] = React.useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [deleteDepId, setDeleteDepId] = useState(null);
  const [rowData, setRowData] = useState(null);
  const [, setIsActive] = useState(true)
  const [, setSearchValue] = useState({})
  const [validationErrors, setValidationErrors] = useState({});
  const [departmentIdSearch, setDepartmentIdSearch] = useState("");
  const [departmentNameSearch, setDepartmentNameSearch] = useState("");
  const [filteroptions, setFilterOption] = useState(false);
  const [tableData, setTableData] = useState([]);
  const departmentNameRef = useRef(null);
  const dispatch = useDispatch();
  const departmentData = useSelector((state) => state.departments);
  const departmentsData = departmentData?.departments?.data;
  const FilteredData = (department_id, department_name) => {
    const filteredDepartments = departmentsData.filter(
      (department) =>
        department.department_id.toString().includes(department_id) &&
        department.department_name
          .toLowerCase()
          .includes(department_name.toLowerCase())
    );
    return filteredDepartments;
  };
  const hasAccessToEdit = checkUserAccess("edit_department")
  const hasAccessToDelete = checkUserAccess("delete_department")
  useEffect(() => {
    dispatch(getDepartmentsData());
  }, [dispatch]);
  useEffect(() => {
    if (departmentsData?.length > 0) {
      const newData = departmentsData.map((d) => {
        const {
          department_id,
          department_name,
          status,
          system_user_id,
          created_at,
          updated_at,
        } = d;
        const constructData = {
          department_id,
          department_name,
          status: status ? "Active" : "Inactive",
          system_user_id,
          created_at,
          updated_at,
        };
        return constructData;
      });
      setTableData(newData);
    }
  }, [departmentsData]);
  useEffect(() => {
    if (
      departmentIdSearch === "" &&
      departmentNameSearch === "" &&
      filteroptions
    ) {
      dispatch(getDepartmentsData());
    }
  }, [departmentIdSearch, departmentNameSearch, dispatch, filteroptions]);
  const filterIdHandler = (e) => {
    const value = e.target.value;
    setDepartmentIdSearch(value);
    if (value === "" && departmentNameSearch !== "") {
      setTableData(FilteredData(value, departmentNameSearch));
    } else {
      setTableData(FilteredData(value, departmentNameSearch, true));
    }
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  const filterNameHandler = (e) => {
    const value = e.target.value;
    setDepartmentNameSearch(value);
    if (value === "" && departmentIdSearch !== "") {
      setTableData(FilteredData(departmentIdSearch, value));
    } else {
      setTableData(FilteredData(departmentIdSearch, value, true));
    }
  };
  const toggleStatus = (status) => {
    setRowData((prevData) => ({
      ...prevData,
      status: status, // Toggle the status
    }));
  };
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
    toggleStatus(event.target.checked);
  };
  const handleShowDeleteConfirmation = (roomId) => {
    setDeleteDepId(roomId);
    setOpenDelete(true);
  };
  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const handleClickEdit = (currentRow) => {
    setRowData(currentRow)
    setOpenEdit(true);
  };
  const handleCloseedit = () => {
    setOpenEdit(false);
    setIsActive(false);
    setValidationErrors("");
  };
  const handleEdit = (e) => {
    const { name, value } = e.target;
    setValidationErrors((prevState) => ({ ...prevState, [name]: "" }));
    setRowData({
      ...rowData,
      [name]: value,
    });
  };
  const handleSearchClick = (departmentIdSearch, departmentNameSearch) => {
    if (departmentIdSearch === "" && departmentNameSearch === "") {
      setFilterOption(true);
    } else {
      setTableData(FilteredData(departmentIdSearch, departmentNameSearch));
    }
  };
  const handleEditUpdate = () => {
    setValidationErrors({});
    const errors = {};
    if (!rowData || !rowData.department_name) {
      errors.department_name = "Department Name can't be empty.";
      departmentNameRef.current.focus()
    }
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }
    dispatch(updateDepartmentData(rowData))
      .then((data) => {
        if (data.payload.status) {
          setTimeout(() => {
            toast.success("Department updated successfully");
          }, 500);
          dispatch(getDepartmentsData());
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => toast.error("Failed to update Department"), 500);
      });
    setRowData("");
    setIsActive(false);
    setOpenEdit(false);
  };
  const onDelete = async (currentRow) => {
    const { status } = currentRow;
    const payload = {
      department_id: currentRow,
      status: status ? "1" : "0",
    };
    await dispatch(deleteDepartmentData(payload))
      .then((data) => {
        if (data.payload.status) {
          setTimeout(() => {
            toast.success("Department deactivated successfully");
          }, 500);
          dispatch(getDepartmentsData());
        } else {
          setTimeout(() => {
            toast.error(data.message);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to deactivate department");
        }, 500);
      });
  };
  const handleDeleteConfirmation = () => {
    setOpenDelete(false);
    if (deleteDepId) {
      onDelete(deleteDepId);
    }
  };
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {},
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const columns = [
    {
      field: "department_id",
      headerName: "Id",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "department_name",
      headerName: "Department Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "created_at",
      headerName: "Created Date",
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      flex: 1,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "updated_at",
      headerClassName: "super-app-theme--header",
      headerName: "Last Updated Date",
      sortable: false,
      flex: 1,
      width: 200,
      minWidth: 200,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        const status = params.value;
        return <span>{status}</span>;
      },
    },
    {
      field: "Operations",
      headerName: "Operations",
      headerClassName: "super-app-theme--header",
      sortable: false,
      flex: 1,
      width: 150,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        let buttonColor;
        let isDisabled = false;
        if (currentRow.status) {
          buttonColor = red[700];
        } else {
          buttonColor = red[700];
          isDisabled = true;
        }
        return (
          <Box display="flex" alignItems="center" sx={{ overflowX: "auto" }}>
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleClickEdit(currentRow)}
                sx={{ minWidth: 0 }}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title="Deactivate">
                <DoNotDisturbOnIcon
                  variant="contained"
                  size="small"
                  sx={{
                    minWidth: "32px",
                    color: currentRow?.status === "Inactive" ? "success" : buttonColor,
                    pointerEvents: currentRow?.status === "Inactive" ? "none" : "auto",
                    opacity: currentRow?.status === "Inactive" ? 0.2 : 1,
                  }}
                  disabled={currentRow?.status === "Inactive"}
                  onClick={() => handleShowDeleteConfirmation(currentRow.department_id)}
                />
              </Tooltip>
            )}
          </Box>
        );
      },
    },
  ];
  return (
    <>
      <Dialog open={openedit} onClose={handleCloseedit} fullWidth maxWidth="sm">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle sx={{ fontSize: "1rem" }}>Edit Department</DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleCloseedit}>X</Button>
          </div>
        </div>
        <DialogContent>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={<div>
                  Department ID <RequiredAsterisk>*</RequiredAsterisk>
                </div>}
                size="small"
                id="department_id"
                name="department_id"
                value={rowData && rowData.department_id}
                onChange={(e) => handleEdit(e)}
                InputProps={{
                  readOnly: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={
                  <div>
                    Department Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                name="department_name"
                id="department_name"
                value={rowData && rowData.department_name}
                 inputRef={departmentNameRef}
                onChange={(e) => handleEdit(e)}
                error={!!validationErrors.department_name}
                helperText={
                  validationErrors.department_name
                    ? <span style={{ color: 'red' }}>{validationErrors.department_name}</span>
                    : (rowData && rowData.department_name && rowData.department_name.length < 2)
                      ? <span style={{ color: 'red' }}>Minimum 2 characters required.</span>
                      : (rowData && rowData.department_name && rowData.department_name.length > 120)
                        ? <span style={{ color: 'red' }}>Maximum 120 characters allowed.</span>
                        : ""
                }
              /> 
            </Grid>
            <Grid item xs={12} sm={12} className="text-right">
              <FormControlLabel
                control={
                  <IOSSwitch
                    checked={(rowData?.status == true || rowData?.status == 'Active') ? true : false}
                    onChange={handleToogleChange}
                  />
                }
                label={(rowData?.status === "Active" || rowData?.status === true) ? "Active" : "Inactive"}
                sx={{
                  marginLeft: "0px",
                  marginBottom: "0",
                  marginRight: "10px",
                }}
                labelPlacement="top"
              />
              <Button
                className="bookingbtn"
                onClick={handleEditUpdate}
                sx={{
                  marginRight: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                  marginTop: "10px",
                }}
              >
                Update
              </Button>
              <Button
                onClick={handleCloseedit}
                color="error"
                className="bookingbtn1"
                sx={{
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                  marginTop: "10px",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
      <Dialog open={opendelete} onClose={handleCloseDelete}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle>Deactivate Department</DialogTitle>
          <Button onClick={handleCloseDelete} sx={{ color: "black" }}>
            X
          </Button>
        </div>
        <DialogContent>
          Are you sure,Do you want to deactivate this Department?
        </DialogContent>
        <DialogActions sx={{ paddingBottom: "15px" }}>
          <Button
            variant="contained"
            onClick={handleDeleteConfirmation}
            className="bookingbtn"
            sx={{
              marginRight: "10px",
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
          >
            Deactivate
          </Button>
          <Button
            variant="outlined"
            onClick={handleCloseDelete}
            className="bookingbtn1"
            sx={{
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      <div style={{ marginTop: "2%" }}>
        <div style={{ marginBottom: "20px" }}>
          <DepartmentForm
            onSearch={handleSearchClick}
            setSearchValue={setSearchValue}
            filterIdHandler={filterIdHandler}
            filterNameHandler={filterNameHandler}
            departmentIdSearch={departmentIdSearch}
            departmentNameSearch={departmentNameSearch}
          />
        </div>
        <Table data={tableData} columns={columns} id="department_id" />
      </div>
    </>
  );
};