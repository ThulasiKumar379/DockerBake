import React, { useEffect, useState, useRef } from "react";
import {
  Box,
  Grid,
  TextField,
  Button,
  Typography,
  Dialog,
  DialogContent,
  DialogTitle,
  Switch,
  FormControlLabel,
  styled,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import {
  Add as AddIcon,
  Search as SearchIcon,
  // FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { checkUserAccess } from "../CheckUserAccess";
import {
  createDepartmentData,
  getDepartmentsData,
} from "../api/Department/departmentReducers";
const IOSSwitch = styled((props) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 55,
  height: 25,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(30px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 21,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#ffff",
      border: "6px solid #fff",
    },
    "&.Mui-disabled .MuiSwitch-thumb": {},
    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 21,
    height: 21,
  },
  "& .MuiSwitch-track": {
    borderRadius: 34 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
  },
}));
export default function DepartmentForm({
  onSearch,
  filterIdHandler,
  filterNameHandler,
  departmentIdSearch,
  departmentNameSearch,
}) {
  const [depName, setDepName] = useState("");
  const [depId, setDepId] = useState("");
  const [depNameError, setDepNameError] = useState("");
  const [depIdError, setDepIdError] = useState("");
  const [openeadd, setOpenAdd] = React.useState(false);
  const [isActive, setIsActive] = useState(true);
  const departmentIdRef = useRef(null);
  const departmentNameRef = useRef(null);
  const handleClickadd = () => {
    setOpenAdd(true);
  };
  const handleCloseadd = () => {
    setOpenAdd(false);
    setIsActive(true);
    setDepName("");
    setDepId("");
    setDepNameError("");
    setDepIdError("");
  };
  const handleSearch = () => {
    onSearch(departmentIdSearch, departmentNameSearch);
  };
  const [, setCreateData] = useState({});
  const [, setKeyChange] = useState("");
  const [, setDepartmentDataError] = useState({
    department_id: "",
    department_name: "",
  });
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const hasAccess = checkUserAccess("department")
  const hasAccessToCreate = checkUserAccess("add_department")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getDepartmentsData());
  }, [dispatch]);
  const handleSave = async () => {
    try {
      setDepartmentDataError({ department_id: "", department_name: "" });
      setDepNameError("");
      if (depName.trim() === "") {
        setDepNameError("Department Name is required");
        departmentNameRef.current.focus()
      } else {
        setDepNameError("");
      }

      if (depId.trim() === "") {
        setDepIdError("Department Id is required");
        departmentIdRef.current.focus()
      } else {
        setDepIdError("");
      }

      if (depName.trim() === "" || depId.trim() === "") {
        return;
      }
      const addDetails = {
        department_id: depId,
        department_name: depName,
        status: isActive,
      };
      const data = await dispatch(createDepartmentData(addDetails));
      if (data.payload.status) {
        setCreateData({});
        setKeyChange(Math.random());
        setOpenAdd(false);
        setTimeout(() => {
          toast.success("Department created successfully");
        }, 500);
        dispatch(getDepartmentsData());
      } else {
        setOpenAdd(true);
        setTimeout(() => {
          toast.error(data.payload.errorMessage);
        }, 500);
      }
    } catch (error) {
      setTimeout(() => {
        toast.error("Failed to create Department");
      }, 500);
    }
    setDepName("");
    setDepId("");
    setIsActive(true);
  };
  return (
    <>
      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Dialog open={openeadd} fullWidth maxWidth="sm">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle sx={{ fontSize: "1rem" }}>Add Department</DialogTitle>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <Button onClick={handleCloseadd}>X</Button>
          </div>
        </div>
        <DialogContent>
          <Grid container spacing={1}>
            <Grid item xs={12} sm={6} sx={{ marginTop: "2%" }}>
              <TextField
                fullWidth
                autoFocus
                label={
                  <div>
                    Department ID <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                name="department_id"
                id="department_id"
                value={depId}
                 inputRef={departmentIdRef}
                onChange={(e) => {
                  setDepId(e.target.value);

                  if (!e.target.value || e.target.value.length < 1 || e.target.value.length > 120) {
                    setDepIdError("Must be between 1 to 120 characters.");
                  } else {
                    setDepIdError("");
                  }
                }}
                error={!!depIdError}
                helperText={depIdError}
              />
            </Grid>
            <Grid item xs={12} sm={6} sx={{ marginTop: "2%" }}>
              <TextField
                fullWidth
                label={
                  <div>
                    Department Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                size="small"
                name="department_name"
                id="department_name"
                value={depName}
                 inputRef={departmentNameRef}
                onChange={(e) => {
                  setDepName(e.target.value);

                  if (!e.target.value || e.target.value.length < 2 || e.target.value.length > 120) {
                    setDepNameError("Must be between 2 to 120 characters.");
                  } else {
                    setDepNameError("");
                  }
                }}
                error={!!depNameError}
                helperText={depNameError}
              /> 
            </Grid>
            <Grid item xs={12} sm={12} className="text-right">
              <FormControlLabel
                control={
                  <IOSSwitch checked={isActive} onChange={handleToogleChange} />
                }
                label={isActive ? "Active" : "Inactive"}
                sx={{
                  marginLeft: "0px",
                  marginBottom: "0",
                  marginRight: "10px",
                }}
                labelPlacement="top"
              />
              <Button
                className="bookingbtn"
                onClick={handleSave}
                sx={{
                  marginRight: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                  marginTop: "15px",
                }}
              >
                Save
              </Button>
              <Button
                onClick={handleCloseadd}
                color="error"
                className="bookingbtn1"
                sx={{
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                  marginTop: "15px",
                }}
              >
                Cancel
              </Button>
            </Grid>
            {/* </DialogActions> */}
          </Grid>
        </DialogContent>
      </Dialog>
      <Box sx={{ marginBottom: "20px" }}>
        <Grid container spacing={1}>
          <Grid item xs={12} sm={8} md={9} lg={10}>
            <Typography variant="h4" sx={{ fontWeight: "600" }}>
              Department Master
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4} md={3} lg={2} className="noPadding">
            {hasAccessToCreate.exists && (
              <Button
                variant="contained"
                onClick={handleClickadd}
                fullWidth
                sx={{
                  padding: "10px 0",
                  backgroundColor: "#0B78A1 !important",
                  borderRadius: 0,
                  fontSize: "0.75rem !important",
                  lineHeight: "1.125rem",
                  letterSpacing: 0,
                }}
                startIcon={<AddIcon />}
              >
                Add Department
              </Button>
            )}
          </Grid>
        </Grid>
      </Box>
      {/* <Accordion
        sx={{
          backgroundColor: "#3E0BA1",
          color: "#fff",
          margin: "0 0 15px !important",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          sx={{
            minHeight: "48px !important",
            "& .Mui-expanded": {
              margin: "12px 0 !important",
            },
          }}
        >
          <Typography>
            <FilterAltIcon /> Filter
          </Typography>
        </AccordionSummary>
        <AccordionDetails
          sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
        >
          <Box sx={{ marginTop: "10px" }}>
            <Grid container spacing={1}>
              <Grid item xs={12} sm={6} md={4} lg={2}>
                <TextField
                  label="Department Id"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                    marginBottom: "10px",
                  }}
                  fullWidth
                  size="small"
                  value={departmentIdSearch}
                  onChange={(e) => filterIdHandler(e)}
                  InputLabelProps={{
                    sx: {
                      color: "#2c2c2c",
                      "&.Mui-focused": { color: "#2c2c2c" },
                    },
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4} lg={2}>
                <TextField
                  label="Department Name"
                  sx={{
                    fieldset: {
                      borderColor: "#3E0BA1 !important",
                      borderRadius: 0,
                    },
                    marginBottom: "15px",
                  }}
                  value={departmentNameSearch}
                  onChange={(e) => filterNameHandler(e)}
                  fullWidth
                  size="small"
                  InputLabelProps={{
                    sx: {
                      color: "#2c2c2c",
                      "&.Mui-focused": { color: "#2c2c2c" },
                    },
                  }}
                />
              </Grid>
            </Grid>
            <Grid container spacing={1} sx={{ justifyContent: "end" }}>
              <Grid item xs={12} sm={4} md={3} lg={2}>
                <Button
                  variant="contained"
                  fullWidth
                  onClick={handleSearch}
                  sx={{
                    padding: "10px 0",
                    backgroundColor: "#3E0BA1 !important",
                    borderRadius: 0,
                    fontSize: "0.75rem !important",
                    lineHeight: "1.125rem",
                    letterSpacing: 0,
                  }}
                  startIcon={<SearchIcon />}
                >
                  Search
                </Button>
              </Grid>
            </Grid>
          </Box>
        </AccordionDetails>
      </Accordion> */}
    </>
  );
}
