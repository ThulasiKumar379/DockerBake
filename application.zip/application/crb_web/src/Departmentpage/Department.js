import React from 'react';
import {DepartmentTable }from './DepartmentTable';
export const Department =()=> {
    return(
        <div>  
            <DepartmentTable/>
        </div>
    
    )
}