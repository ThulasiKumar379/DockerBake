import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import Table from "../Components/Table";
import { red } from "@mui/material/colors";
import { checkUserAccess } from "../CheckUserAccess";
import {
  fetchDesignationsData,
  updateDesignationData,
  deleteDesignationData,
  getDesignationsData
} from "../api/Designation/designationReducers";
import DesignationForm from "./DesignationForm";
import {
  Button,
  Grid,
  Box,
  TextField,
  Dialog,
  DialogContent,
  Tooltip,
  DialogTitle,
  DialogActions,
  FormControlLabel,
  Switch,
  Autocomplete,
  DialogContentText,
} from "@mui/material";
import {
  DoNotDisturbOn as DoNotDisturbOnIcon,
  EditNote,
} from "@mui/icons-material";
import { styled } from "@mui/system";
import { fetchDepartmentsData } from "../api/Department/departmentReducers";
export const DesignationTable = () => {
  const [openedit, setOpenEdit] = React.useState(false);
  const [opendelete, setOpenDelete] = React.useState(false);
  const [keyChange] = useState("");
  const [, setValidationErrors] = useState({});
  const [rowData, setRowData] = useState(null);
  const [selectedDepartment] = useState("");
  const [, setIsActive] = useState(false);
  const [deleteDesId, setDeleteDesId] = useState(null);
  const [depNameError, setDepNameError] = useState("");
  const [, setDepName] = useState("");
  const [, setDesName] = useState("");
  const [tabledata, setTableData] = useState([]);
  const departmentData = useSelector((state) => state.departments);
  const [desNameError, setDesNameError] = useState("");
  const designationNameRef = useRef(null);
  const [, setCreateData] = useState({
    designation_id: "",
    designation_name: "",
    description: "",
  });
  const designationsData = useSelector((state) => state.designations);
  const desdata = designationsData?.designations;
  useEffect(() => {
    if (desdata?.length > 0) {
      setTableData(desdata);
    }
  }, [desdata]);

  const hasAccessToEdit = checkUserAccess("edit_designation")
  const hasAccessToDelete = checkUserAccess("delete_designation")
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getDesignationsData([]));
  }, [dispatch]);


  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const handleEditChange = (e, v, name) => {
    if (name == 'department') {
      setRowData((prevData) => ({
        ...prevData,
        [`${name}_id`]: v ? v[`${name}_id`] : "",
        [`u${name}_id`]: v ? v[`u${name}_id`] : "",
        [`${name}_name`]: v ? v[`${name}_name`] : "",
      }));
    } else {
      const val = v === null ? e?.target?.value : v.departmentid;
      setRowData((prevData) => ({
        ...prevData,
        [name]: val,
      }));
    }

  };

  const onDelete = async (currentRow) => {
    const designation_id = currentRow;
    await dispatch(deleteDesignationData(designation_id))
      .then((data) => {
        if (data.payload.status) {
          setTimeout(() => {
            toast.success("Designation deactivated successfully");
          }, 500);
          dispatch(getDesignationsData());
        } else {
          setTimeout(() => {
            toast.error(data.message);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to deactivate designation");
        }, 500);
      });
  };
  const handleDeleteConfirmation = () => {
    setOpenDelete(false);
    onDelete(deleteDesId);
  };
  const toggleStatus = () => {
    setRowData((prevData) => ({
      ...prevData,
      active: !prevData.active, // Toggle the status
    }));
  };
  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
    toggleStatus();
  };
  const handleCloseDelete = () => {
    setOpenDelete(false);
  };
  const handleShowDeleteConfirmation = (designationId) => {
    setDeleteDesId(designationId);
    setOpenDelete(true);
  };
  const handleEditButton = (currentRow) => {
    setOpenEdit(true);
    setRowData(currentRow);
    setCreateData(currentRow);
  };
  const handleCloseedit = () => {
    setOpenEdit(false);
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const getOptionLabel = (option) =>
    `${option.department_id || rowData.department_id}-${option.department_name
    } `;
  const handleEditUpdate = async () => {
    setDesNameError("");
    setDepNameError("");
    setDepName(rowData.department_id);
    setDesName(rowData.designation_name);
    let isValid = true;

    if (rowData.designation_name === "") {
      setDesNameError("Designation Name is required");
      designationNameRef.current.focus()
      isValid = false;
    }

    if (!rowData.department_id) {
      setDepNameError("Department Name is required");
      isValid = false;
    }

    if (!isValid) {
      return;
    }

    setValidationErrors({});
    const errors = {};

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }

    await dispatch(updateDesignationData(rowData))
      .then((data) => {
        if (data.payload.status) {
          setTimeout(() => {
            toast.success("Designation updated successfully");
          }, 500);
          dispatch(getDesignationsData());
        } else {
          setTimeout(() => {
            toast.error(data.payload.errorMessage);
          }, 500);
        }
      })
      .catch(() => {
        setTimeout(() => {
          toast.error("Failed to update designation");
        }, 500);
      });

    setOpenEdit(false);
  };


  const columns = [
    {
      field: "designation_id",
      headerName: "ID",
      flex: 1,
      width: 100,
      minWidth: 100,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "designation_name",
      headerName: "Designation Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "department_name",
      headerName: "Department Name",
      flex: 1,
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
    },
    {
      field: "created_at",
      headerName: "Created Date",
      width: 200,
      minWidth: 200,
      headerClassName: "super-app-theme--header",
      flex: 1,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "updated_at",
      headerClassName: "super-app-theme--header",
      headerName: "Last Updated Date",
      sortable: false,
      flex: 1,
      width: 200,
      minWidth: 200,
      valueGetter: (params) => {
        const updatedDate = new Date(params.value);
        return updatedDate.toLocaleString({
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
        });
      },
    },
    {
      field: "active",
      headerClassName: "super-app-theme--header",
      headerName: "Status",
      flex: 1,
      width: 100,
      minWidth: 100,
      renderCell: (params) => {
        let status = params?.row?.active ? "Active" : "Inactive";
        // const status = params.value;
        return <span>{status}</span>;
      },
    },
    {
      field: "Operations",
      headerName: "Operations",
      sortable: false,
      flex: 1,
      width: 150,
      minWidth: 150,
      headerClassName: "super-app-theme--header",
      valueGetter: (params) =>
        `${params.row.firstName || ""} ${params.row.lastName || ""}`,
      renderCell: (params) => {
        const currentRow = params.row;
        let buttonColor;
        let isDisabled = false;
        if (currentRow.active) {
          // Active state
          buttonColor = red[700];
        } else {
          // Inactive state
          buttonColor = red[700];
          isDisabled = true;
        }
        return (
          <Box display="flex" alignItems="center">
            <Tooltip title="Edit">
              <Button
                variant="text"
                color="primary"
                size="small"
                sx={{ minWidth: "32px" }}
                disabled={!hasAccessToEdit.exists}
                onClick={() => handleEditButton(currentRow)}
              >
                <EditNote />
              </Button>
            </Tooltip>
            {hasAccessToDelete.exists && (
              <Tooltip title="Deactivate">
                <DoNotDisturbOnIcon
                  variant="contained"
                  size="small"
                  sx={{
                    minWidth: "32px",
                    color: isDisabled ? "#d32f2f" : buttonColor,
                    pointerEvents: isDisabled ? "none" : "auto",
                    opacity: isDisabled ? 0.2 : 1,
                  }}
                  id="designation_id"
                  disabled={isDisabled}
                  onClick={() =>
                    handleShowDeleteConfirmation(currentRow.designation_id)
                  }
                />
              </Tooltip>
            )}
          </Box>
        );
      },
    },
  ];
  const getOptionLabelWithId = (option) => {
    if (option?.department_id) {
      return `${option.udepartment_id} - ${option.department_name}`;
    } else {
      return option?.department_name;
    }
  };

  let desigationFilterHandler = (deptIds) => {
    console.log("deptIdsdeptIdsdeptIdsdeptIds", deptIds)
    dispatch(getDesignationsData(deptIds));
  }
  return (
    <>
      <ToastContainer
        position="bottom-right"
        autoClose="5000"
        hideProgressBar={false}
        pauseOnHover={false}
        draggable={true}
      />
      <Dialog open={openedit} onClose={handleCloseedit} fullWidth maxWidth="sm">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle sx={{ fontSize: "1rem" }}>Edit Designation</DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleCloseedit}>X</Button>
          </div>
        </div>
        <DialogContent>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                size="small"
                sx={{
                  fieldset: {
                    borderColor: "#3E0BA1 !important",
                    borderRadius: 0,
                  },
                }}
                id={"department_name"}
                name="department_name"
                onChange={(e, v) => {
                  handleEditChange(e, v, "department");
                  setDesNameError("");
                }}
                options={departmentData?.departments?.departmentData || []}
                getOptionLabel={(option) =>
                  getOptionLabelWithId(option)}
                getOptionDisabled={(option) => option.status === false}
                value={{
                  department_name: rowData?.department_name,
                  department_id: rowData?.department_id,
                  udepartment_id: rowData?.udepartment_id,
                }}

                renderInput={(params) => (
                  <TextField
                    fullWidth
                    {...params}
                    label={<div>
                      Department Name <RequiredAsterisk>*</RequiredAsterisk>
                    </div>}
                    placeholder="Department Name"
                    error={!!depNameError}
                    helperText={
                      depNameError ? "Department can't be empty." : ""
                    }
                    InputLabelProps={{
                      shrink:
                        Boolean(params.inputProps.value) ||
                        Boolean(rowData?.department_name),
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label={<div>
                  Designation ID <RequiredAsterisk>*</RequiredAsterisk>
                </div>}
                id={"designation_id"}
                name="designation_id"
                value={rowData && rowData.designation_id}
                InputLabelProps={{
                  shrink: rowData && rowData.designation_id,
                  readOnly: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label={
                  <div>
                    Designation Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>
                }
                id={"designation_name"}
                name="designation_name"
                value={rowData && rowData.designation_name}
                InputLabelProps={{
                  shrink: rowData && rowData.designation_name,
                }}
                 inputRef={designationNameRef}
                onChange={(e) => handleEditChange(e, null, "designation_name")}
                error={!!desNameError || (rowData && rowData.designation_name && (rowData.designation_name.length < 2 || rowData.designation_name.length > 120))}
                helperText={
                  desNameError
                    ? <span style={{ color: 'red' }}>{desNameError}</span>
                    : ((rowData && rowData.designation_name && rowData.designation_name.length < 2)
                      ? <span style={{ color: 'red' }}>Minimum 2 characters required.</span>
                      : (rowData && rowData.designation_name && rowData.designation_name.length > 120)
                        ? <span style={{ color: 'red' }}>Maximum 120 characters allowed.</span>
                        : "")
                }
              /> 
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              sx={{
                display: "flex",
                justifyContent: "end",
                alignItems: "end",
              }}
            >
              <FormControlLabel
                control={
                  <IOSSwitch
                    checked={rowData?.active}
                    onChange={handleToogleChange}
                  />
                }
                label={rowData?.active ? "Active" : "InActive"}
                sx={{
                  marginLeft: "0px",
                  marginBottom: "0",
                  marginRight: "10px",
                }}
                labelPlacement="top"
              />
              <Button
                className="bookingbtn"
                onClick={handleEditUpdate}
                sx={{
                  marginRight: "10px",
                  marginTop: "10px",
                  fontSize: "0.75rem",
                  textTransform: "capitalize",
                }}
              >
                Update
              </Button>
              <Button
                onClick={handleCloseedit}
                color="error"
                className="bookingbtn1"
                sx={{
                  fontSize: "0.75rem",
                  marginTop: "10px",
                  textTransform: "capitalize",
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>

      {/* borderBottom:"1px solid #e9ecef" */}
      <Dialog open={opendelete} onClose={handleCloseDelete}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e9ecef",
          }}
        >
          <DialogTitle>Deactivate Designation</DialogTitle>
          <div style={{ textAlign: "right" }}>
            <Button onClick={handleCloseDelete}>X</Button>
          </div>
        </div>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to deactivate this designation?
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ paddingBottom: "15px" }}>
          <Button
            variant="contained"
            className="bookingbtn"
            onClick={handleDeleteConfirmation}
            sx={{
              marginRight: "10px",
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
          >
            Deactivate
          </Button>
          <Button
            variant="outlined"
            className="bookingbtn1"
            onClick={handleCloseDelete}
            sx={{
              fontSize: "0.75rem",
              textTransform: "capitalize",
            }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      <div style={{ marginTop: "2%" }}>
        <div style={{ marginBottom: "2%" }}>
          <DesignationForm
            desigationFilterHandler={desigationFilterHandler} />
        </div>
        <Table id="designation_id" data={tabledata} columns={columns} />
      </div>
    </>
  );
};
