import React from 'react';
import { DesignationTable } from './DesignationTable';
export const Designation =()=> {
    return(
        <div>
            <DesignationTable/>
        </div>
    
    )
}