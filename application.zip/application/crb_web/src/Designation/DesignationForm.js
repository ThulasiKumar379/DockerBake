import React, { useState, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { checkUserAccess } from "../CheckUserAccess";
import { useEffect } from "react";
import {
  Box,
  Grid,
  TextField,
  Button,
  Typography,
  Dialog,
  DialogContent,
  FormControlLabel,
  Switch,
  Autocomplete,
  DialogTitle,
  styled,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import { toast } from "react-toastify";
import {
  Add as AddIcon,
  Search as SearchIcon,
  FilterAlt as FilterAltIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import {
  fetchDesignationsData,
  createDesignationData,
  getDesignationsData,
} from "../api/Designation/designationReducers";
import { fetchDepartmentsData } from "../api/Department/departmentReducers";
export const AddDesignation = ({ onClose }) => {
  const [isActive, setIsActive] = useState(true);
  const [designations, setDesignations] = useState([]);
  const [keyChange, setKeyChange] = useState(Math.random());
  const [depNameError, setDepNameError] = useState("");
  const [, setDepName] = useState("");
  const [createdata, setCreateData] = useState({});
  const [labelClassess] = useState("");
  const [, setDesName] = useState("");
  const departmentData = useSelector((state) => state.departments);
  const [desNameError, setDesNameError] = useState("");
  const [designationId, setDesignationId] = useState("");
  const designationIdRef = useRef(null);
  const designationNameRef = useRef(null);
  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  const handleToogleChange = (event) => {
    setIsActive(event.target.checked);
  };
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 55,
    height: 25,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(30px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 21,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#ffff",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {
        //   color:
        //     theme.palette.mode === "light"
        //       ? theme.palette.grey[600]
        //       : theme.palette.grey[600],
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 21,
      height: 21,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
    },
  }));
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchDepartmentsData());
    dispatch(getDesignationsData());
  },
    [dispatch],);

  const handleSave = async () => {
    setDesNameError("");
    setDepNameError("");
    setDepName(createdata.department_id);
    setDesName(createdata.designation_name);
    setDesName(createdata.designation_id);
    let isValid = true;
    if (!createdata.designation_name) {
      setDesNameError("Designation Name is required");
      designationNameRef.current.focus()
      isValid = false;
    }
    if (!createdata.designation_id) {
      setDepNameError("Department ID is required");
      designationIdRef.current.focus()
      isValid = false;
    }
     if (!createdata.department_id) {
      setDepNameError("Department ID is required");
      isValid = false;
    }
    
    if (!isValid) {
      return;
    }

    try {
      const response = await dispatch(createDesignationData(createdata));
      if (response.payload.status) {
        setCreateData({});
        setKeyChange(Math.random());
        setTimeout(() => {
          toast.success("Designation created successfully", {
            // onClose: () => {
            //     window.location.reload();
            // }
          });
        }, 300);
        dispatch(getDesignationsData());
      } else {
        setTimeout(() => {
          toast.error(response.payload.errorMessage);
        }, 500);
      }
    } catch (error) {
      console.error(error);
      setTimeout(() => {
        toast.error("Failed to create Designation");
      }, 500);
    }

    onClose();
  };
  const handleChange = (e, v, name) => {
    const val = v === null ? e?.target?.value : v.department_id;
    setCreateData((prevData) => ({
      ...prevData,
      [name]: val,
    }));
  };
  const handleCancel = () => {
    onClose();
  };
  const getOptionLabelWithId = (option) => {
    // Assuming each department object has 'department_name' and 'department_id' properties
    return `${option.udepartment_id} - ${option.department_name}`;
  };
  return (
    <Box>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          borderBottom: "1px solid #e9ecef",
          alignItems: "center",
        }}
      >
        <DialogTitle>Add Designation</DialogTitle>
        <Button onClick={handleCancel}>X</Button>
      </div>
      <DialogContent>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <Autocomplete
              //sx={{ marginTop: "8px" }}
              fullWidth
              size="small"
              id="department_name"
              name="department_name"
              onChange={(e, v) => handleChange(e, v, "department_id")}
              options={departmentData?.departments?.departmentData || []}
              getOptionLabel={(option) => getOptionLabelWithId(option)}
              getOptionDisabled={(option) => option.status === false}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={<div>
                    Department ID-Name <RequiredAsterisk>*</RequiredAsterisk>
                  </div>}
                  placeholder="department Id-Name"
                  InputLabelProps={{
                    ...labelClassess.label,
                  }}
                  error={!!depNameError}
                  helperText={depNameError}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              size="small"
              label={
                <div>
                  Designation ID  <RequiredAsterisk>*</RequiredAsterisk>
                </div>
              }
              value={createdata.designation_id || ""}
               inputRef={designationIdRef}
              onChange={(e) => handleChange(e, null, "designation_id")}
              fullWidth
              name="designation_id"
              id="designation_id"
              error={!!desNameError || (createdata.designation_id && (createdata.designation_id.length < 1 || createdata.designation_id.length > 120))}
              helperText={
                desNameError
                  ? <span style={{ color: 'red' }}>{desNameError}</span>
                  : ((createdata.designation_id && createdata.designation_id.length < 1)
                    ? <span style={{ color: 'red' }}>Minimum 1 character is required.</span>
                    : (createdata.designation_id && createdata.designation_id.length > 120)
                      ? <span style={{ color: 'red' }}>Maximum 120 characters allowed.</span>
                      : "")
              }
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              size="small"
              label={
                <div>
                  Designation Name <RequiredAsterisk>*</RequiredAsterisk>
                </div>
              }
              value={createdata.designation_name || ""}
              inputRef={designationNameRef}
              onChange={(e) => handleChange(e, null, "designation_name")}
              fullWidth
              name="designation_name"
              id="designation_name"
              error={!!desNameError || (createdata.designation_name && (createdata.designation_name.length < 2 || createdata.designation_name.length > 120))}
              helperText={
                desNameError
                  ? <span style={{ color: 'red' }}>{desNameError}</span>
                  : ((createdata.designation_name && createdata.designation_name.length < 2)
                    ? <span style={{ color: 'red' }}>Minimum 2 characters required.</span>
                    : (createdata.designation_name && createdata.designation_name.length > 120)
                      ? <span style={{ color: 'red' }}>Maximum 120 characters allowed.</span>
                      : "")
              }
            /> 
          </Grid>
          <Grid item xs={12} sm={12} className="text-right">

            <FormControlLabel
              control={
                <IOSSwitch checked={isActive} onChange={handleToogleChange} />
              }
              label={isActive ? "Active" : "Inactive"}
              sx={{ marginLeft: "0", marginBottom: "0" }}
              labelPlacement="top"
            />
            <Button
              className="bookingbtn"
              onClick={handleSave}
              sx={{
                backgroundColor: "#3E0BA1",
                marginRight: "10px",
                marginTop: "10px",
                textTransform: "capitalize",
                fontSize: "0.75rem",
              }}
            >
              Save
            </Button>
            <Button
              className="bookingbtn1"
              onClick={handleCancel}
              sx={{
                textTransform: "capitalize",
                marginTop: "10px",
                fontSize: "0.75rem",
              }}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </DialogContent>
    </Box>
  );
};
export default function DesignationForm({
  desigationFilterHandler
}) {
  const [openeadd, setOpenAdd] = React.useState(false);

  const hasAccess = checkUserAccess("designation")
  const hasAccessToCreate = checkUserAccess("add_designation")
  const navigate = useNavigate();
  if (!hasAccess.exists) {
    navigate("/");
  }

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchDepartmentsData());
  }, [dispatch]);

  const departmentData = useSelector((state) => state.departments);
  const desdata = departmentData?.departments?.departmentData;
  console.log({ desdata });
  const [createdata] = useState({
    designation_id: "",
    designation_name: "",
    description: "",
  });
  const handleClickadd = () => {
    setOpenAdd(true);
    dispatch(createDesignationData(createdata));
  };
  const handleCloseadd = () => {
    setOpenAdd(false);
  };
  const handleClicksearch = () => {

  };
  const labelClassess = {
    label: { style: { color: "#2c2c2c" } },
  };
  // };
  const getOptionLabelWithIdDepartment = (option) => {
    if (option && option.department_name && option.udepartment_id) {
      return `${option.udepartment_id}-${option.department_name}`;
    } else if (option && option.department_name) {
      return option.department_name;
    }
    return "";
  };

  const filterDesignationdata = (e, v) => {
    let value = v
      ? v.map((option) => option.department_id)
      : [];
    desigationFilterHandler(value)
  }
  return (
    <>
      <Dialog open={openeadd} onClose={handleCloseadd} fullWidth maxWidth="sm">
        <AddDesignation onClose={handleCloseadd} />
      </Dialog>
      <Box sx={{ marginBottom: "20px" }}>
        <Grid container spacing={1}>
          <Grid item xs={12} sm={8} md={9} lg={10}>
            <Typography variant="h4" sx={{ fontWeight: "600" }}>
              Designation Master
            </Typography>
          </Grid>
          <Grid
            item
            xs={12}
            sm={4}
            md={3}
            lg={2}
            className="noPadding noPadding600"
          >
            {hasAccessToCreate.exists && (
              <Button
                fullWidth
                variant="contained"
                onClick={handleClickadd}
                sx={{
                  padding: "10px 0",
                  backgroundColor: "#0B78A1 !important",
                  borderRadius: 0,
                  fontSize: "0.75rem !important",
                  lineHeight: "1.125rem",
                  letterSpacing: 0,
                }}
                startIcon={<AddIcon />}
              >
                Add Designation
              </Button>
            )}
          </Grid>
        </Grid>
      </Box>
      <Accordion
        sx={{
          backgroundColor: "#3E0BA1",
          color: "#fff",
          margin: "0 0 15px !important",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon sx={{ color: "#fff" }} />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          sx={{
            minHeight: "48px !important",
            "& .Mui-expanded": {
              margin: "12px 0 !important",
            },
          }}
        >
          <Typography>
            <FilterAltIcon /> Filter
          </Typography>
        </AccordionSummary>
        <AccordionDetails
          sx={{ background: "rgb(255, 255, 255)", paddingTop: "16px" }}
        >
          <Box>
            <Grid container spacing={1}>

              <Grid item xs={12} sm={4} md={3} lg={2}>
                <Autocomplete
                  multiple
                  fullWidth
                  clearOnEscape
                  size="small"
                  margin="dense"
                  id="department_name"
                  name="department_name"
                  onChange={(e, v) => { filterDesignationdata(e, v) }
                  }
                  options={departmentData?.departments?.departmentData || []}
                  getOptionLabel={(option) =>
                    getOptionLabelWithIdDepartment(option)
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Department Id-Name"
                      placeholder="department Name"
                      InputLabelProps={{
                        ...labelClassess.label,
                      }}
                      sx={{
                        fieldset: {
                          borderColor: "#3E0BA1 !important",
                          borderRadius: 0,
                        },
                      }}

                    />
                  )}
                />
              </Grid>
            </Grid>

          </Box>
        </AccordionDetails>
      </Accordion>
    </>
  );
}
