import React, { useState, useEffect, useRef } from "react";
import { Button, Typography, TextField } from "@mui/material";
import Group217 from "./Components/Images/Group217.svg";
import { styled } from "@mui/system";
import { useDispatch } from "react-redux";
import { initiateForgotPassword, verifyOtpThunk } from "./api/Auth/authReducer";

const Otpone = ({ onClose, open1, handleChangePassword, handlePwOpen }) => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [timer, setTimer] = useState(59);
  const [isButtonClicked, setIsButtonClicked] = useState(false);
  const [isOtpEntered, setIsOtpEntered] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [otpError, setOtpError] = useState("");
  const [generateOtpError, setgenerateOtpError] = useState("");
  

  const inputRefs = useRef(Array(6).fill(null));
  useEffect(() => {
    setIsOtpEntered(otp.every((digit) => digit !== ""));
  }, [otp]);


  const handleNewpasswordopen = async () => {
    try {
      // Assuming otp is an array of individual digits
      const joinedOtp = otp.join('');
  
      // Validate OTP format (e.g., 6 digits)
      if (!/^\d{6}$/.test(joinedOtp)) {
        setOtpError("Invalid OTP format. Please enter a 6-digit OTP.");
        return;
      }
  
      const response = await dispatch(verifyOtpThunk({ otp: joinedOtp }));
  
      console.log("Response structure:", response);
  
      if (response.payload.status === true) {
        setOtpError("");
        onClose();
        handlePwOpen();
      } else {
        setOtpError("Invalid OTP. Please try again.");
      }
    } catch (error) {
      console.error("Error in handleNewpasswordopen:", error);
    }
  };
  
  
  const handleCloseDelete = () => {
    onClose();
  };

  const handleChangeEmail = (event) => {
    setEmail(event.target.value);
    setEmailError("");
  };

  const handleChangeOtp = (event, index) => {
    const newOtp = [...otp];
    const inputValue = event.target.value;

    if (/^\d$/.test(inputValue)) {
      newOtp[index] = inputValue;
      setOtp(newOtp);
      focusNextInput(index);
    }
  };
  const focusNextInput = (index) => {
    if (index < otp.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (event, index) => {
    switch (event.key) {
      case 'Backspace':
        handleBackspace(index);
        break;
      case 'ArrowLeft':
        handleArrowLeft(index);
        break;
      case 'ArrowRight':
        handleArrowRight(index);
        break;
      default:
        break;
    }
  };
  
  const handleBackspace = (index) => {
    if (index > 0) {
      const newOtp = [...otp];
      newOtp[index] = '';
      setOtp(newOtp);
      inputRefs.current[index - 1].focus();
    } else if (index === 0) {
      const newOtp = otp.map(() => '');
      setOtp(newOtp);
      inputRefs.current[0].focus();
    }
  };     
  
  const handleArrowLeft = (index) => {
    if (index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };
  
  const handleArrowRight = (index) => {
    if (index < otp.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  const dispatch = useDispatch();

  const handleGenerateOtp = async () => {
    if (!validateEmail()) {
      return;
    }

    try {
      const response = await dispatch(initiateForgotPassword({ email }));
      if(response.payload.status === true){
        setgenerateOtpError("")
        setTimer(59);
        startTimer();
        setIsButtonClicked(true);
      localStorage.setItem('FPT', response.payload.data);
       }else{
        setIsButtonClicked(false);
        setgenerateOtpError("user not found")
       }
      console.log("Response from initiateForgotPassword:", response);
    } catch (error) {
      console.error("Error in handleGenerateOtp:", error);
    }
  };

  const handleResendOtp = async () => {
    if (!validateEmail()) {
      return;
    }

    try {
      const response = await dispatch(initiateForgotPassword({ email }));
      if(response.payload.status === true){
        // setOtpError("user not defined")
        setOtpError("")
        setTimer(59);
      startTimer();
      setIsButtonClicked(true);
       }else{
        setIsButtonClicked(false);
        setOtpError("user not found")
       }
      console.log("Response from initiateForgotPassword:", response);
      setTimer(59);
      startTimer();
    } catch (error) {
      console.error("Error in handleGenerateOtp:", error);
    }
  };

  const startTimer = () => {
    const interval = setInterval(() => {
      setTimer((prevTimer) => {
        if (prevTimer > 0) {
          return prevTimer - 1;
        } else {
          clearInterval(interval);
          return prevTimer;
        }
      });
    }, 1000);

    setTimeout(() => {
      clearInterval(interval);
    }, 60000);
  };

  const validateEmail = () => {
    if (!email) {
      setEmailError("Email is required");
      return false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError("Invalid email address");
      return false;
    } else {
      setEmailError("");
      return true;
    }
  };

  const validateOtp = () => {
    const isValidOtp = otp.every((digit) => /\d/.test(digit));
    if (!isValidOtp) {
      setOtpError("Invalid OTP. Please enter a valid OTP.");
      return false;
    } else {
      setOtpError("");
      return true;
    }
  };

  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  const handlePaste = (event) => {
    event.preventDefault();
    const pastedText = event.clipboardData.getData('text');
    const newOtp = pastedText
      .split('')
      .slice(0, otp.length)
      .map((digit) => (/^\d$/.test(digit) ? digit : ''));
    setOtp(newOtp);
  };
  const renderOtpFields = () => {
    return (
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        {otp.map((digit, index) => (
          <input
            key={index}
            type="text"
            value={digit}
            onChange={(event) => handleChangeOtp(event, index)}
            maxLength={1}
            pattern="[0-9]"
            style={{
              width: '2em',
              height: '2em',
              fontSize: '1.5em',
              textAlign: 'center',
              margin: '0 0.25em',
              background: 'none',
              border: 'none',
              borderBottom: '1px solid #3E0BA1',
              outline: 'none',
            }}
            onKeyDown={(event) => handleKeyDown(event, index)}
            ref={(ref) => (inputRefs.current[index] = ref)}
          />
        ))}
      </div>
    );
  };

  return (
    <div style={{ textAlign: "center", alignItems: "center" }}>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <Button onClick={handleCloseDelete} sx={{ color: "black", minWidth: "32px" }}>
          X
        </Button>
      </div>
      <div>
        <Typography variant="h4" color="primary">
          <span>
            <img
              src={Group217}
              alt="Key"
              style={{
                maxWidth: "85px",
                objectFit: "contain",
                margin: "0 auto",
                padding: "0",
              }}
            />
          </span>
        </Typography>
        <Typography
          variant="h6"
          sx={{
            color: "#3E0BA1",
            letterSpacing: "0px",
            textAlign: "center",
            marginTop: "0.5em",
            textTransform: "capitalize",
          }}
        >
          Forget password
        </Typography>
        <p style={{ marginBottom: ".1em", fontSize: "14px" }}>
          No worries, we'll send you reset instructions
        </p>
      </div>
      <div>
        <TextField
          value={email}
          onChange={handleChangeEmail}
          variant="outlined"
          margin="normal"
          sx={{
            background: "#FFFFFF 0% 0% no-repeat padding-box",
            borderRadius: "7px",
            opacity: "1",
            fontSize: "14px",
            width: "100%",
            height: "57px",
            outline: "none",
            marginBottom: "1em",
          }}
          label={
            <span>
              Enter your Email ID
              <RequiredAsterisk>*</RequiredAsterisk>
            </span>
          }
          error={!!emailError}
          helperText={emailError}
        />
      </div>
      <br />
      <div>
        <Button
          variant="contained"
          onClick={handleGenerateOtp}
          style={{
            backgroundColor: isButtonClicked ? "#707070" : "#3E0BA1",
            color: isButtonClicked ? "white" : "white",
            width: "200px",
            height: "50px",
          }}
          disabled={isButtonClicked}
        >
          <span>{isButtonClicked ? "OTP Generated!" : "Generate OTP"}</span>
        </Button>
        {generateOtpError && (
        <Typography
        variant="body1"
        color="error"
        sx={{ marginTop: "0.5em" }}
        >
        {generateOtpError}
        </Typography>
        )}
      </div>
      {isButtonClicked && (
        <div
          style={{
            fontFamily: "Montserrat",
            fontSize: "14px",
            color: "#3E0BA1",
            opacity: "1",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            marginTop: "1em",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginBottom: "10px",
            }}
          >
            <Typography
              variant="h6"
              style={{
                marginRight: "0.5em",
                fontSize: "14px",
                marginTop: "0",
              }}
            >
              0:{timer < 10 ? `0${timer}` : timer} remaining
            </Typography>
            <p
              onClick={handleResendOtp}
              style={{
                cursor: "pointer",
                color: "#3E0BA1",
                fontSize: "14px",
                marginBottom: "0.2em",
                marginTop: "0",
                textDecoration: "underline",
              }}
            >
              Resend OTP
            </p>
          </div>
          <div
        style={{
          marginBottom: '1.5em',
          width: 'fit-content',
          margin: '0 auto',
          border: '1px solid #3E0BA1',
          padding: '0.5em',
          borderRadius: '5px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          {otp.map((digit, index) => (
            <input
              key={index}
              type="text"
              value={digit}
              onChange={(event) => handleChangeOtp(event, index)}
              onKeyDown={(event) => handleKeyDown(event, index)}
              maxLength={1}
              style={{
                width: '2em',
                height: '2em',
                fontSize: '1.5em',
                textAlign: 'center',
                margin: '0 0.25em',
                background: 'none',
                border: 'none',
                borderBottom: '1px solid #3E0BA1',
                outline: 'none',
              }}
              onPaste={handlePaste}
              ref={(ref) => (inputRefs.current[index] = ref)}
            />
          ))}
        </div>
      </div>
      <p style={{ margin: '10px 0 0 0' }}>
        Enter the OTP<RequiredAsterisk>*</RequiredAsterisk>
      </p>
      <Button
            variant="contained"
            onClick={handleNewpasswordopen}
            style={{
              backgroundColor: isOtpEntered ? "#3E0BA1" : "#707070",
              color: "white",
              width: "200px",
              height: "50px",
            }}
            disabled={!isOtpEntered}
          >
            <span>Verify OTP</span>
          </Button>
          {otpError && (
            <Typography
              variant="body2"
              color="error"
              sx={{ marginTop: "0.5em" }}
            >
              {otpError}
            </Typography>
          )}
        </div>
      )}
    </div>
  );
};

export default Otpone;
