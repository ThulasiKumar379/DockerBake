import CryptoJS from 'crypto-js';
import { secretKey } from './config/apiConfig';
import { getPermissions } from './api/Auth/authApi';
export function checkUserAccess(key) {
  try {
    let encryptedPermissions = localStorage.getItem("permissions");

    if (!encryptedPermissions) {
      return { error: "Permissions not found in localStorage", permissions: [] };
    }

    const decryptedBytes = CryptoJS.AES.decrypt(encryptedPermissions, secretKey);
    const decryptedPermissions = decryptedBytes.toString(CryptoJS.enc.Utf8);

    if (!decryptedPermissions) {
      return { error: "Error decrypting permissions", permissions: [] };
    }

    const permissions = JSON.parse(decryptedPermissions);
    const exists = permissions.find((item) => item.key === key) !== undefined;

    if (exists) {
        // console.log("User has access", exists)
      return { message: "User has access", exists };
    } else {
        // console.log("User require's access", exists)
      return { error: "User access required", exists };//return false, if user doesn't have access...!
    }
  } catch (error) {
    return { error: "Error while checking user access" };
  }
}
const encryptData = (data) => {
  return CryptoJS.AES.encrypt(JSON.stringify(data), secretKey).toString();
};
export const resetPermissions = async () => {
      getPermissions().then((response) => {
      const { data, status } = response.data;
          const encryptedPermissions = encryptData(data.permissions);
          localStorage.setItem('permissions', encryptedPermissions);        
  }).catch((error) => {
        console.error('Error fetching permissions:', error);
      });
};

export function getToken() {
  return localStorage.getItem("token");
}

export function getUserName() {
  return localStorage.getItem("userName");
}