import React from "react";

import "./App.css";
import Section from "./Components/Section";
// import Home from "./Components/Home";
// import Banner from "./Components/Banner";
// import mobile from "./Components/Images/mobile.png";
// import appCal from "./Components/Images/app-calendar.png";
import { header, content,  header1, content1, img1,header2,content2,img2,header3,content3,img3 } from "./constant";



function App() {
  return (
    <div>
      <Section header={header} content={content}  align="right" backgroundimage={true}/>
      <Section header={header1} content={content1} image={img1} align="left" backgroundcolor={true}/>
      <Section header={header2} content={content2} image={img2} align="right" backgroundcolor={false}  />
      <Section header={header3} content={content3} image={img3} align="left" backgroundcolor={false}/>
    </div>
  );
}

export default App;
