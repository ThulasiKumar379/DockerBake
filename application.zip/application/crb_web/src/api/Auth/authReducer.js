import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { userLogin, forgotPassword, verifyOtp, changeSysPassword } from "./authApi";

// initialize userToken from local storage
const userToken = sessionStorage.getItem("userToken")
  ? sessionStorage.getItem("userToken")
  : null;

export const fetchUserLogin = createAsyncThunk(
  "auth/login",
  async (credentials) => {
    const data = await userLogin(credentials);
    return data;
  }
);

const initialState = {
  loading: false,
  userInfo: null,
  userToken,
  error: null,
  success: false,
};

export const verifyOtpThunk = createAsyncThunk(
  "auth/verify_otp",
  async (credentials) => {
    const data = await verifyOtp(credentials);
    console.log("auth reducer data  :",data)
    return data;
  }
);

export const initiateForgotPassword = createAsyncThunk(
  "auth/initiateForgotPassword",
  async (credentials) => {
    const data = await forgotPassword(credentials);

    console.log(data)
    return data;
  }
);

export const initiateChangePassword = createAsyncThunk(
  "auth/changeSysPassword",
  async (credentials) => {
    const data = await changeSysPassword(credentials);
    return data;
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {},
  extraReducers: {
    [fetchUserLogin.pending]: (state) => {
      state.loading = true;
      state.error = null;
    },
    [fetchUserLogin.fulfilled]: (state, { payload }) => {
      state.loading = false;
      state.userInfo = payload;
      state.userToken = payload.data.token;
    },
    [fetchUserLogin.rejected]: (state, { payload }) => {
      state.loading = false;
      state.error = payload;
    },
    [verifyOtpThunk.pending]: (state) => {
      state.loading = true;
      state.error = null;
    },
    [verifyOtpThunk.fulfilled]: (state, { payload }) => {
      state.loading = false;
      // Handle the OTP verification success, e.g., set a flag
      state.otpVerified = true;
    },
    [verifyOtpThunk.rejected]: (state, { payload }) => {
      state.loading = false;
      state.error = payload;
    },

    [initiateForgotPassword.pending]: (state) => {
      state.loading = true;
      state.error = null;
    },
    [initiateForgotPassword.fulfilled]: (state, { payload }) => {
      state.loading = false;
      // Handle the initiation of forgot password success, e.g., set a flag
      state.forgotPasswordInitiated = true;
    },
    [initiateForgotPassword.rejected]: (state, { payload }) => {
      state.loading = false;
      state.error = payload;
    },
  },
});
export default authSlice.reducer;
