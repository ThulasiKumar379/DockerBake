// authApi.js

import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/systemusers`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
export const userLogin = async (credentials) => {
  const { email, password } = credentials;
  try {
    const response = await axios({
      method: "POST",
      url: `${BASE_URL}/login`,
      data: credentials,
    });
    // store user's token and users Data in Session storage
    sessionStorage.setItem("userToken", response.data.data.token);
    // sessionStorage.setItem("userData", response.data.data.userInfo);
    return response.data;
  } catch (error) {
    throw new Error("Failed to create building");
  }
};
export const getPermissions = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/userPermissionById`, {
      headers: { Authorization: getUserToken() },
    });
    return response;
  } catch (error) {
    throw new Error("Failed to fetch Permission");
  }
};

export const forgotPassword = async (credentials) => {
  const { email } = credentials;
  try {
    const response = await axios({
      method: "POST",
      url: `${BASE_URL}/forgotPassword?email=${email}`,
      data: credentials,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to initiate password reset");
  }
};

export const verifyOtp = async (credentials) => {
  const { otp } = credentials;
  try {
    const response = await axios({
      method: "POST",
      url: `${BASE_URL}/verify_otp?otp=${otp}`,
      data: credentials,
    });
    console.log("authApi data :",response.data)
    return response.data;
  } catch (error) {
    throw new Error("Failed to initiate password reset");
  }
};

export const changeSysPassword = async (credentials) => { 
  try {
    const response = await axios({
      method: "PUT",
      url: `${BASE_URL}/changeSysPassword`,
      data: credentials,
    }); 
    return response.data;
  } catch (error) {
    throw new Error("Failed to initiate password reset");
  }
};
