import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { getACL, getRole, createACL, deleteACL } from "./aclApi";

export const getACLData = createAsyncThunk("acl/getacl", async () => {
  const acl = await getACL();
  return acl;
});
export const getRoleData = createAsyncThunk("acl/getRoles", async () => {
  const acl = await getRole();
  return acl;
});
// export const createACLData = createAsyncThunk(
//   "acl/createacl",
//   async (aclData) => {
//     const newAcl = await createACL(aclData);
//     return newAcl;

//   }
// );
export const createACLData = createAsyncThunk(
  "acl/createacl",
  async (payload) => {
    try {
      const response = await createACL(payload);
      return response.data; // Assuming the response contains a 'data' field
    } catch (error) {
      throw new Error("Failed to create ACL data");
    }
  }
);
export const deleteACLData = createAsyncThunk(
  "acl/deleteacl",
  async (payload) => {
    const deleteacl = await deleteACL(payload);
    return deleteacl;
  }
);
const aclSlice = createSlice({
  name: "acl",
  initialState: {
    acl: [],
    roles: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(getACLData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(getACLData.fulfilled, (state, action) => {
        state.loading = false;
        state.acl = action.payload;
      })

      .addCase(getACLData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(getRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(getRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })

      .addCase(getRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(createACLData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createACLData.fulfilled, (state) => {
        state.loading = false;
      })

      .addCase(createACLData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(deleteACLData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(deleteACLData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })

      .addCase(deleteACLData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default aclSlice.reducer;
