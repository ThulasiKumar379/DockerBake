import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/acl`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// get call to get all departments
export const getACL = async (param1, param2) => {
  try {
    const response = await axios.get(`${BASE_URL}/getacl`, {
      headers: { Authorization: getUserToken() },
      params: {
        key1: param1,
        key2: param2,
      },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch ACL");
  }
};
export const getRole = async (param1, param2) => {
  try {
    const response = await axios.get(`${BASE_URL}/getRoles`, {
      headers: { Authorization: getUserToken() },
      params: {
        key1: param1,
        key2: param2,
      },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch ACL");
  }
};
// Post call to create a new department
export const createACL = async (payload) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createacl`,
      data: payload,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create acl");
  }
};
export const deleteACL = async (payload) => {
  try {
    const response = await axios({
      method: "DELETE",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/deleteacl`,
      data: payload,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to delete ACL");
  }
};
