import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/location`;

export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// get call to get all locations
export const getLocations = async () => {
  try {
    const response = await axios.get(
      `${BASE_URL}/getlocation`,
      {
        headers: { Authorization: getUserToken() },
      }
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to get locations");
  }
};
// fetch call to get all locations
export const fetchLocations = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/fetchLocations`, {
      headers: { Authorization: getUserToken() },
    });
        return response.data;
  } catch (error) {
    throw new Error("Failed to fetch locations");
  }
};

// Post call to create a new location
export const createLocation = async (locationData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createlocation`,
      data: locationData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create location");
  }
};

// Update / Edit location
export const updateLocation = async (locationedit) => {
  console.log("location apis", locationedit);
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/editlocation`,
      data: locationedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update location");
  }
};

export const deleteLocation = async (currentRow) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}/deleteLocation?location_id=${currentRow}`,
      {
        headers: { Authorization: getUserToken() },
        data: { location_id: currentRow },
      }
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete location");
  }
};
