import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { fetchLocations, createLocation, updateLocation, deleteLocation, getLocations } from "./locationApis";

export const getLocationsData = createAsyncThunk(
  "locations/getLocationsData",
  async () => {
    const getlocations = await getLocations();
    return getlocations;
  }
);
export const fetchLocationsData = createAsyncThunk(
  "locations/fetchLocationsData",
  async () => {
    const locations = await fetchLocations();
    return locations;
  }
);
export const createLocationData = createAsyncThunk(
  "locations/createLocationData",
  async (locationData) => {
    console.log();
    const newLocation = await createLocation(locationData);
    return newLocation;
  }
);

export const updateLocationData = createAsyncThunk(
  "locations/updateLocationData",
  async (locationData) => {
    console.log("location Reducer", locationData);
    const updatedLocation = await updateLocation(locationData);
    return updatedLocation;
  }
);

export const deleteLocationData = createAsyncThunk(
  "locations/deleteLocationData",
  async (locationId) => {
    const delLocation = await deleteLocation(locationId);
    return delLocation;
  }
);

const locationsSlice = createSlice({
  name: "locations",
  initialState: {
    locations: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(getLocationsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(getLocationsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.locations = action.payload;
      })

      .addCase(getLocationsData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(fetchLocationsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchLocationsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.locations = action.payload;
      })

      .addCase(fetchLocationsData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(createLocationData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(createLocationData.fulfilled, (state, action) => {
        console.log("respo", current(state));
        state.isLoading = false;
      })

      .addCase(createLocationData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(updateLocationData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(updateLocationData.fulfilled, (state, action) => {
        state.isLoading = false;
      })

      .addCase(updateLocationData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(deleteLocationData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(deleteLocationData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data = action.payload;
      })

      .addCase(deleteLocationData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      });
  },
});

export default locationsSlice.reducer;
