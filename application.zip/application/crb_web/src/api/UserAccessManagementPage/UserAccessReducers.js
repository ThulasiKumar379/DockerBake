import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { fetchUsers,createUser,updateUser,deleteUser } from "./UserAccessAPi";

export const fetchUsersData = createAsyncThunk(
  "users/fetchUsersData",
  async (obj) => {
    const users = await fetchUsers(obj);
    return users;
  }
);

export const createUserData = createAsyncThunk(
  "users/createUserData",
  async (userData) => {
    const newUser = await createUser(userData);
    return newUser;
   
  }
);

export const updateUserData = createAsyncThunk(
  "users/updateUserData",
  async (userData) => {
    const updatedUser = await updateUser(userData);
    return updatedUser;
  }
);

export const deleteUserData = createAsyncThunk(
  "users/deleteUserData",
  async (currentRow) => {
    const delUser = await deleteUser(currentRow);
    //wait deleteUser(userId);
    return delUser;
  }
);



const usersSlice = createSlice({
  name: "users",
  initialState: {
    users: [],
    data: {},
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchUsersData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(fetchUsersData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.users = action.payload;
      })

      .addCase(fetchUsersData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(createUserData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(createUserData.fulfilled, (state, action) => {
        console.log("respo", current(state));
        state.isLoading = false;
      })

      .addCase(createUserData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(updateUserData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(updateUserData.fulfilled, (state, action) => {
        state.isLoading = false;
      })

      .addCase(updateUserData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(deleteUserData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(deleteUserData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data=action.payload
        // const userId = action.payload;
        // state.users = state.users.filter((user) => user.id !== userId);
      })

      .addCase(deleteUserData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      });
  },
});

export default usersSlice.reducer;
