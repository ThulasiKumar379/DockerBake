import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/users`;

export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};

// Get call to fetch all users
export const fetchUsers = async (obj=null) => {
  try {  
   let location_ids='';   let building_ids='';
   let roll_ids='';   let designation_ids='';   let department_ids='';
    if(obj!=null){ 
      if(obj.locationSearch.length!=0){   
         location_ids =   obj.locationSearch;
      } 
      if(obj.buldingSearch.length!=0){ 
        building_ids = obj.buldingSearch;
      }
      if(obj.rolesSearch.length!=0){ 
        roll_ids = obj.rolesSearch;
      }
      if(obj.designationSearch.length!=0){ 
        designation_ids = obj.designationSearch;
      }
      if(obj.departmentSearch.length!=0){ 
        department_ids = obj.departmentSearch;
      }
    } 
    const response = await axios.get(`${BASE_URL}/fetchUser`, {
      headers: { Authorization: getUserToken() },
      params: {location_ids,building_ids,roll_ids,designation_ids,department_ids},
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch users");
  }
};

// Get call to fetch all users
export const fetchUserData = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/fetchUserData`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch users");
  }
};

// Post call to create a new user
export const createUser = async (userData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createUser`,
      data: userData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create user");
  }
};

// Update / Edit User
export const updateUser = async (useredit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/updateUser`,
      data: useredit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update user");
  }
};

// Function to delete a user
export const deleteUser = async (payload) => {
  console.log("current row radha api calls", { payload });
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/deactiveUser`,
      data: payload,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to deactivate user");
  }
};

export const getUserData = async (term) => {
  try {
    const response = await axios.get(`${BASE_URL}/getUserData`, {
      headers: { Authorization: getUserToken() },
      params:{term}
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch users");
  }
};

