import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { fetchFloors, createFloor, updateFloor, deleteFloor, getFloors } from "./floorApis";
 
export const getFloorsData = createAsyncThunk(
  "floors/getFloorsData",
  async () => {
    const gfloors = await getFloors();
    return gfloors;
  }
);
export const fetchFloorsData = createAsyncThunk(
  "floors/fetchFloorsData",
  async (buildings) => {
    const floors = await fetchFloors(buildings);
    return floors;
  }
);
 
export const createFloorData = createAsyncThunk(
  "floors/createFloorData",
 
  async (floorData) => {
    const newFloor = await createFloor(floorData);
    return newFloor;
  }
);
 
export const updateFloorData = createAsyncThunk(
  "floors/updateFloorData",
  async ( floorData ) => {
    const updatedFloor = await updateFloor(floorData);
    return updatedFloor;
  }
);
 
export const deleteFloorData = createAsyncThunk(
  "floors/deleteFloorData",
  async (data) => {
    const res = await deleteFloor(data);
    return res;
  }
);
 
const floorsSlice = createSlice({
  name: "floors",
  initialState: {
    floors: [],
    isLoading: false,
    error: null,
  },
 
  reducers: {},
 
  extraReducers: (builder) => {
    builder
      .addCase(fetchFloorsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
 
      .addCase(fetchFloorsData.fulfilled, (state, action) => {
        state.loading = false;
        state.floors = action.payload;
      })
 
      .addCase(fetchFloorsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
 
      .addCase(getFloorsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
 
      .addCase(getFloorsData.fulfilled, (state, action) => {
        state.loading = false;
        state.floors = action.payload;
        // console.log("@@",{action})
      })
 
      .addCase(getFloorsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(createFloorData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
 
      .addCase(createFloorData.fulfilled, (state, action) => {
        console.log("respo", action);
        state.loading = false;
        state.payload = action.payload;
        // state.status = action.status
        // state.floors.data.concat(action.payload);
      })
 
      .addCase(createFloorData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
 
      .addCase(updateFloorData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
 
      .addCase(updateFloorData.fulfilled, (state, action) => {
        state.loading = false;
        const { floorId, floorData } = action.payload;
        // const floorIndex = state.floors.findIndex(
        //   (floor) => floor.id === floorId
        // );
 
        // if (floorIndex !== -1) {
        //   state.floors[floorIndex] = {
        //     ...state.floors[floorIndex],
        //     ...floorData,
        //   };
        // }
      })
 
      .addCase(updateFloorData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
 
      .addCase(deleteFloorData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
 
      .addCase(deleteFloorData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
 
      .addCase(deleteFloorData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});
 
export default floorsSlice.reducer;