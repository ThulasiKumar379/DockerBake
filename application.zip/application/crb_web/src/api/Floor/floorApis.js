import axios from "axios";
 
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/floors`;
 
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// get call to get all floors
export const getFloors = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/getFloor`, {
      headers: { Authorization: getUserToken() },
    });
 
    return response.data;
  } catch (error) {
    throw new Error("Failed to get floors");
  }
};

export const getFloorsInfo = async (queryParams=null) => {   
  let urlParms=''
    if(queryParams !=null ){  
      urlParms = `${BASE_URL}/getFloor?${queryParams}`
    } else {
      urlParms = `${BASE_URL}/getFloor`
    } 
    try {
      const response = await axios.get(urlParms, {
        headers: { Authorization: getUserToken() }, 
      }); 
      return response.data;
    } catch (error) {
      throw new Error(`Failed to fetch floors: ${error.message}`);
    }

};
 
export const fetchFloors = async ( buldingId=null) => { 
    let urlParms=''
    if(buldingId !=null ){ 
      const ids = buldingId.map((l) => l.building_id);
      console.log({ ids });
      urlParms = `${BASE_URL}/fetchFloors?building_id=${ids}`
    } else {
      urlParms = `${BASE_URL}/fetchFloors`
    } 
    try {
      const response = await axios.get(urlParms, {
        headers: { Authorization: getUserToken() }, 
      });
      console.log()
      return response.data;
    } catch (error) {
      throw new Error(`Failed to fetch floors: ${error.message}`);
    }
};
// Post call to create a new floor
export const createFloor = async (floorData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createFloor`,
      data: floorData,
    });
 
    return response.data;
  } catch (error) {
    throw new Error("Failed to create floor");
  }
};
 
export const updateFloor = async (floorData) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/updateFloor`,
      data: floorData,
    });
 
    return response.data;
  } catch (error) {
    throw new Error("Failed to update room");
  }
};
 
export const deleteFloor = async (payload) => {
  // const { floor_id, building_id } = payload;
  try {
    const response = await axios.delete(
      `${BASE_URL}/deleteFloor`,
      {
        headers: { Authorization: getUserToken() },
        data: payload,
      }
    );
 
    return response.payload;
  } catch (error) {
    throw new Error("Failed to delete floor");
  }
};