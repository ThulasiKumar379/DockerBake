import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/building`;

export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};

export const getBuildings = async (params) => {
  const paramsData = params && Object.keys(params).length !== 0 ? params : "";
  try {
    const response = await axios.get(`${BASE_URL}/getBuildinginfo`, {
      headers: { Authorization: getUserToken() },
      params: paramsData,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get building");
  }
};

// get call to get all buildings
export const fetchBuildings = async (locations) => {
  console.log(locations, "urlparam");
  let urlParms;

  if (Array.isArray(locations)) {
    if (locations.length > 0) {
      const locationId = locations.map((l) => l.location_id);
      console.log( "locationId" ,locationId );
      urlParms = `${BASE_URL}/fetchBuildings?location_id=${locationId}`;
          } else {
      urlParms = `${BASE_URL}/fetchBuildings`;
    }
  } else {
    const { location_id } = locations;
    urlParms = `${BASE_URL}/fetchBuildings?location_id=${location_id}`;
  }

  try {
    const response = await axios.get(urlParms, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch buildings: ${error.message}`);
  }
};

// Post call to create a new building
export const createBuilding = async (buildingData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createBuilding`,
      data: buildingData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create building");
  }
};

// Update / Edit Building
export const updateBuilding = async (buildingedit) => {
  console.log("building apis", buildingedit);
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/editBuilding`,
      data: buildingedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update building");
  }
};

export const deleteBuilding = async (currentRow) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}/deleteBuilding?building_id=${currentRow}`,
      {
        headers: { Authorization: getUserToken() },
        data: { building_id: currentRow },
      }
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete building");
  }
};
