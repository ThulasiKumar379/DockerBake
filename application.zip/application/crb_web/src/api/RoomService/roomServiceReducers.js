import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { fetchRoomService,createRoomService,updateRoomService,deleteRoomService } from "./roomServiceApi";

export const fetchRoomServiceData = createAsyncThunk(
  "roomservice/fetchRoomServiceData",
  async (params) => {
    const roomservice = await fetchRoomService(params);
    return roomservice;
  }
);

export const createRoomServiceData = createAsyncThunk(
  "roomservice/createRoomServiceData",
  async (roomServiceData) => {
    // console.log()
    const newRoomService = await createRoomService(roomServiceData);
    return newRoomService;
   
  }
);

export const updateRoomServiceData = createAsyncThunk(
  "roomservice/updateRoomServiceData",
  async (roomServiceData) => {
    console.log("roomServiceData Reducer",roomServiceData)
    const updatedRoomService = await updateRoomService(roomServiceData);
    return updatedRoomService;
  }
);

export const deleteRoomServiceData = createAsyncThunk(
  "roomservice/deleteRoomServiceData", 
  async (room_service_id) => {
    const delrs = await deleteRoomService(room_service_id);
    return delrs;
  }
);



const roomserviceSlice = createSlice({
  name: "roomservice",
  initialState: {
    roomservice: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchRoomServiceData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchRoomServiceData.fulfilled, (state, action) => {
        state.loading = false;
        state.roomservice = action.payload;
      })

      .addCase(fetchRoomServiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(createRoomServiceData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createRoomServiceData.fulfilled, (state, action) => {
        console.log("respo", current(state));

        state.loading = false;
      })

      .addCase(createRoomServiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(updateRoomServiceData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(updateRoomServiceData.fulfilled, (state, action) => {
        state.loading = false;
        // const amenityIndex = state.roomservice.findIndex(
        //   (amenity) => amenity.id === amenityId
        // );

        // if (amenityIndex !== -1) {
        //   state.roomservice[amenityIndex] = {
        //     ...state.roomservice[amenityIndex],
        //     ...amenityData,
        //   };
        // }
      })

      .addCase(updateRoomServiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(deleteRoomServiceData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(deleteRoomServiceData.fulfilled, (state, action) => {
        state.loading = false;
        state.data=action.payload
        // const amenityId = action.payload;
        // state.roomservice = state.roomservice.filter((amenity) => amenity.id !== amenityId);
      })

      .addCase(deleteRoomServiceData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default roomserviceSlice.reducer;