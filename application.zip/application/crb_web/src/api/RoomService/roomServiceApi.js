import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/roomservice`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};

export const fetchRoomService = async (params) => {
  const param = params && Object.keys(params).length !== 0 ? params : "";
  try {
    const response = await axios.get(`${BASE_URL}/getroomservice`, {
      headers: { Authorization: getUserToken() },
      params: param,
    });
    console.log("searchfeild", { response });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch RoomService");
  }
};

// Post call to create a new RoomService
export const createRoomService = async (RoomServiceData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: {
        Authorization: getUserToken(),
        "Content-Type": "multipart/form-data",
      },
      url: `${BASE_URL}/createroomservice`,
      data: RoomServiceData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create RoomService");
  }
};

// Update / Edit RoomService
export const updateRoomService = async (RoomServiceedit) => {
  console.log("RoomService apis", RoomServiceedit);
  try {
    const response = await axios({
      method: "PUT",
      headers: {
        Authorization: getUserToken(),
        "Content-Type": "multipart/form-data",
      },
      url: `${BASE_URL}/updateroomservice`,
      data: RoomServiceedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update RoomService");
  }
};

export const deleteRoomService = async (currentRow) => {
  try {
    const response = await axios.delete(`${BASE_URL}/deleteroomservice`, {
      headers: { Authorization: getUserToken() },
      data: { room_service_id: currentRow },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete RoomService");
  }
};
