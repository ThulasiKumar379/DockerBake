import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/companyprofile`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
}; 

// Update / Edit Company Profile
export const updateCompanyProfile = async (CompanyProfileedit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: {
        Authorization: getUserToken() 
      },
      url: `${BASE_URL}/updatecompanyprofile`,
      data: CompanyProfileedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to Update Profile.");
  }
};

// Post call to create a new Company Logo
export const UploadCompanyLogo = async (CompanyLogo) => {
    try {
      const response = await axios({
        method: "POST",
        headers: {
          Authorization: getUserToken(),
          "Content-Type": "multipart/form-data",
        },
        url: `${BASE_URL}/uploadlogo`,
        data: CompanyLogo,
      });
  
      return response.data;
    } catch (error) {
      throw new Error("Failed Upload Logo.");
    }
}; 
 
export const getCompanyProfile = async (CompanyProfileget) => {
  console.log("Company Profile apis", CompanyProfileget);
  try {
    const response = await axios({
      method: "GET",
      headers: {
        Authorization: getUserToken() 
      },
      url: `${BASE_URL}/getprofile`,
      data: CompanyProfileget,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to Get Profile.");
  }
};