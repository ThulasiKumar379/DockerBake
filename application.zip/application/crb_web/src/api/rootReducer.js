import { combineReducers } from "redux";
import floorReducer from "./Floor/floorReducers";
import roomReducer from "./Rooms/roomReducer";
import locationReducer from "./Location/locationReducer";
import buildingReducers from "./Building/buildingReducers";
import roleReducers from './Rolemaster/RoleReducer'
import departmentReducers from "./Department/departmentReducers";
import authReducer from "./Auth/authReducer";
import settingReducer from "./Settings/settingReducer";
import timingReducer from "./Settings/timingReducer";
import designationReducers from "./Designation/designationReducers";
import amenitiesReducers from "./Amenities/amenitiesReducers";
import UserAccessReducers from "./UserAccessManagementPage/UserAccessReducers";
import roomServiceReducers from "./RoomService/roomServiceReducers";
import roombookingReducer from './RoomBooking/roombookingReducer'
import bookingSlotReducer from "./RoomBooking/bookingSlotReducer";
import userProfileReducer from "./UserProfile/userProfileReducer";
import aclReducers from "./Acl/aclReducer";
import bookingManageReducer from "./BookingManage/bookingManageReducer";
import MyInvitationsReducers from "./RoomBooking/MyInvitationsReducers";
import mybookingReducers from "./RoomBooking/mybookingReducers"
const reducers = combineReducers({
  floors: floorReducer,
  rooms: roomReducer,
  locations: locationReducer,
  buildings:buildingReducers,
  departments:departmentReducers,
  roles:roleReducers,
  settings: settingReducer,
  timings:timingReducer,
  designations: designationReducers,
  amenities: amenitiesReducers,
  auth: authReducer,
  users:UserAccessReducers,
  roomService:roomServiceReducers,
  roomBooking:roombookingReducer,
  myBooking:mybookingReducers,
  user:userProfileReducer,
  acl:aclReducers,
  manageBooking:bookingManageReducer,
  bookingslot:bookingSlotReducer,
  myinvitations:MyInvitationsReducers,
});

export default reducers;
