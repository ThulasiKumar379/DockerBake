import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchManageBookingAPI, createManageBookingAPI } from "./bookingManageApi";

export const fetchMangeBookings = createAsyncThunk(
  "manage_bookings/fetchMangeBookings",
  async () => {
    const bookings = await fetchManageBookingAPI();
    return bookings;
  }
);

export const createBooking = createAsyncThunk(
  "manage_bookings/createBooking",
  async () => {
    const newBooking = await createManageBookingAPI();
    return newBooking;
  }
);

const manageBookingSlice = createSlice({
  name: "manage_bookings",
  initialState: {
    bookingsData: [],
    loading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder
      .addCase(fetchMangeBookings.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMangeBookings.fulfilled, (state, action) => {
        state.loading = false;
        state.bookingsData = action.payload;
      })
      .addCase(fetchMangeBookings.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Handle createBooking
      .addCase(createBooking.pending, (state) => {
        state.loading = true;
        // You may want to handle other state changes
      })
      .addCase(createBooking.fulfilled, (state, action) => {
        state.loading = false;
        // Update state with the new booking
        state.bookingsData.push(action.payload);
      })
      .addCase(createBooking.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default manageBookingSlice.reducer;
