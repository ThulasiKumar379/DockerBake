import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/bookings`;
const tokenStr = sessionStorage.getItem("userToken");
export const getUserToken = () => {
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
export const fetchManageBookingAPI = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/manageBookings`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to Fetch Bookings");
  }
};

export const getManageBookingAPI = async (queryParams) => {
  try {
    const response = await axios.get(`${BASE_URL}/manageBookings?${queryParams}`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to Fetch Bookings");
  }
};

export const CancelBookingAPI = async (selectedBookingData,approveStatus) => {
  try {
    const response = await axios.put(`${BASE_URL}/bookingCancel`, selectedBookingData, {
      headers: { Authorization: `Bearer ${tokenStr}` }
    });
    console.log(selectedBookingData)
    return response.data;
  } catch (error) {
    throw new Error("Failed to cancel Bookings");
  }
};
export const ChangeBookingStatusAPI = async (approveBookingID) => {
  try {
    const response = await axios.put(`${BASE_URL}/bookingApproveReject`, approveBookingID, {
      headers: { Authorization: `Bearer ${tokenStr}` }
    });
    // console.log("approveBookingID")
    return response.data;
  } catch (error) {
    throw new Error("Failed to update Booking status");
  }
};

export const getBookingAPI = async () => {
  try {
    const response = await axios.put(`${BASE_URL}/getBookings`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get Bookings");
  }
};
export const getBookingStatusAPI = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/getBookingStatus`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response;
  } catch (error) {
    throw new Error("Failed to get Bookings");
  }
};
export const myBookingAPI = async () => {
  try {
    const response = await axios.put(`${BASE_URL}/mybookings`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get my Bookings");
  }
};
export const slotsBookingAPI = async () => {
  try {
    const response = await axios.put(`${BASE_URL}/availableSlots`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get Bookings slots");
  }
};

export const createManageBookingAPI = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/createBooking`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to create Bookings");
  }
};









