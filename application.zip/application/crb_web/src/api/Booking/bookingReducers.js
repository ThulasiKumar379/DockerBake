import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { fetchBuildings,createBuilding,updateBuilding,deleteBuilding } from "./buildingApi";

export const fetchBuildingsData = createAsyncThunk(
  "buildings/fetchBuildingsData",
  async () => {
    const buildings = await fetchBuildings();
    return buildings;
  }
);

export const createBuildingData = createAsyncThunk(
  "buildings/createBuildingData",
  async (buildingData) => {
    const newBuilding = await createBuilding(buildingData);
    return newBuilding;
   
  }
);

export const updateBuildingData = createAsyncThunk(
  "buildings/updateBuildingData",
  async (buildingData) => {
    const updatedBuilding = await updateBuilding(buildingData);
    return updatedBuilding;
  }
);

export const deleteBuildingData = createAsyncThunk(
  "buildings/deleteBuildingData",
  async (buildingId) => {
    await deleteBuilding(buildingId);
    return buildingId;
  }
);



const buildingsSlice = createSlice({
  name: "buildings",
  initialState: {
    buildings: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchBuildingsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchBuildingsData.fulfilled, (state, action) => {
        state.loading = false;
        state.buildings = action.payload;
      })

      .addCase(fetchBuildingsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(createBuildingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createBuildingData.fulfilled, (state, action) => {
        console.log("respo", current(state));

        state.loading = false;
      })

      .addCase(createBuildingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(updateBuildingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(updateBuildingData.fulfilled, (state, action) => {
        state.loading = false;
        const { buildingId, buildingData } = action.payload;
        // const buildingIndex = state.buildings.findIndex(
        //   (building) => building.id === buildingId
        // );

        // if (buildingIndex !== -1) {
        //   state.buildings[buildingIndex] = {
        //     ...state.buildings[buildingIndex],
        //     ...buildingData,
        //   };
        // }
      })

      .addCase(updateBuildingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(deleteBuildingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(deleteBuildingData.fulfilled, (state, action) => {
        state.loading = false;
        // const buildingId = action.payload;
        // state.buildings = state.buildings.filter((building) => building.id !== buildingId);
      })

      .addCase(deleteBuildingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default buildingsSlice.reducer;
