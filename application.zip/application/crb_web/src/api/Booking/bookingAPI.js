import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/building`;
const tokenStr = sessionStorage.getItem("userToken");
// get call to get all buildings
export const fetchBuildings = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/getBuildingList`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch building");
  }
};

// Post call to create a new building
export const createBuilding = async (buildingData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: `Bearer ${tokenStr}` },
      url: `${BASE_URL}/createBuilding`,
      data: buildingData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create building");
  }
};

// Update / Edit Building
export const updateBuilding = async (buildingedit) => {
  console.log("building apis", buildingedit);
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: `Bearer ${tokenStr}` },
      url: `${BASE_URL}/editBuilding`,
      data: buildingedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update building");
  }
};

export const deleteBuilding = async (currentRow) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}/deleteBuilding?building_id=${currentRow}`,
      {
        headers: { Authorization: `Bearer ${tokenStr}` },
        data: { building_id: currentRow },
      }
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete building");
  }
};
