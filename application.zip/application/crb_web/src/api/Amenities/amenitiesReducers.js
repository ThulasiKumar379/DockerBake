import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import {
  fetchAmenities,
  createAmenity,
  updateAmenity,
  deleteAmenity,
  GetAmenities,
} from "./amenitiesapis";
export const getAmenitiesData = createAsyncThunk(
  "amenities/fetchAmenitiesData",
  async (params) => {
    const amenities = await GetAmenities(params);
    return amenities;
  }
);
export const fetchAmenitiesData = createAsyncThunk(
  "amenities/fetchAmenitiesData",
  async (params) => {
    const amenities = await fetchAmenities(params);
    return amenities;
  }
);
export const createAmenityData = createAsyncThunk(
  "amenities/createAmenityData",
  async (amenityData) => {
    const newAmenity = await createAmenity(amenityData);
    return newAmenity;
  }
);
export const updateAmenityData = createAsyncThunk(
  "amenities/updateAmenityData",
  async (amenityData) => {
    const updatedAmenity = await updateAmenity(amenityData);
    return updatedAmenity;
  }
);
export const deleteAmenityData = createAsyncThunk(
  "amenities/deleteAmenityData",
  async (amenityid) => {
    const delam = await deleteAmenity(amenityid);
    return delam;
  }
);
const amenitiesSlice = createSlice({
  name: "amenities",
  initialState: {
    amenities: [],
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchAmenitiesData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAmenitiesData.fulfilled, (state, action) => {
        state.loading = false;
        state.amenities = action.payload;
      })
      .addCase(fetchAmenitiesData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(createAmenityData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createAmenityData.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(createAmenityData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(updateAmenityData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAmenityData.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(updateAmenityData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(deleteAmenityData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteAmenityData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(deleteAmenityData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});
export default amenitiesSlice.reducer;
