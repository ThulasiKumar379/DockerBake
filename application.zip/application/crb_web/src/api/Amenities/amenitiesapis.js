import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/amenities`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
export const GetAmenities = async (params) => {
  const param = params && Object.keys(params).length !== 0 ? params : "";
  try {
    const response = await axios.get(`${BASE_URL}/getamenitie`, {
      headers: { Authorization: getUserToken() },
      params: param,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch amenities");
  }
};
export const fetchAmenities = async (params) => {
  const param = params && Object.keys(params).length !== 0 ? params : "";
  try {
    const response = await axios.get(`${BASE_URL}/fetchAmenities`, {
      headers: { Authorization: getUserToken() },
      params: param,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch amenities");
  }
};

// Post call to create a new Amenity
export const createAmenity = async (AmenityData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: {
        Authorization: getUserToken(),
        "Content-Type": "multipart/form-data",
      },
      url: `${BASE_URL}/createamenitie`,
      data: AmenityData,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to create Amenity");
  }
};
// Update / Edit Amenity
export const updateAmenity = async (Amenityedit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: {
        Authorization: getUserToken(),
        "Content-Type": "multipart/form-data",
      },
      url: `${BASE_URL}/updateaminities`,
      data: Amenityedit,
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to update Amenity");
  }
};
export const deleteAmenity = async (currentRow) => {
  try {
    const response = await axios.delete(`${BASE_URL}/deleteamenitie`, {
      headers: { Authorization: getUserToken() },
      data: { amenityid: currentRow },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete Amenity");
  }
};
