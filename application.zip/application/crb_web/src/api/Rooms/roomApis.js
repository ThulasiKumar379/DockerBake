import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/room`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// get call to get all rooms
export const getRooms = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/viewRoom`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get rooms");
  }
};
// export const getRoomsdata = async (locations=null,buildings=null,floors=null,capacity=null) => {
//   try {
//     let locationId='';  let building_id=''; let floor_id='';
//       if (locations.length > 0) {
//         locationId = locations.map((l) => l);
//       } 
//       if (buildings.length > 0) {
//         building_id = buildings.map((l) => l);
//       }  
//       if (floors.length > 0) {
//         floor_id = floors.map((l) => l);
//       } 
//     const response = await axios.get(`${BASE_URL}/viewRoom?location_id=${locationId}&building_id=${building_id}&floor_id=${floor_id}&capacity=${capacity}`, {
//       headers: { Authorization: getUserToken() },
//     });
//     return response.data;
//   } catch (error) {
//     throw new Error("Failed to get rooms");
//   }
// };
export const getRoomsdata = async (locations = null, buildings = null, floors = null, capacity = null, amenities = null) => {
  try {
    let locationId = '';
    let building_id = '';
    let floor_id = '';
    let amenity_id = '';

    if (locations.length > 0) {
      locationId = locations.map((l) => l);
    }
    if (buildings.length > 0) {
      building_id = buildings.map((l) => l);
    }
    if (floors.length > 0) {
      floor_id = floors.map((l) => l);
    }
    if (amenities.length > 0) {
      amenity_id = amenities.map((l) => l);
    }

    const response = await axios.get(`${BASE_URL}/viewRoom?location_id=${locationId}&building_id=${building_id}&floor_id=${floor_id}&capacity=${capacity}&amenity_id=${amenity_id}`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get rooms");
  }
};

// get call to fetch all rooms
export const fetchRooms = async (floor_id) => {
  try {
    // const response = await axios.get(`${BASE_URL}/fetchrooms?floor_id=${floor_id}`, {
      const response = await axios.get(`${BASE_URL}/fetchrooms`,{
      headers: { Authorization: getUserToken() },
    }); 
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch rooms");
  }
};
// get call to fetch all rooms
export const getRoomsList = async (floor_id=null) => {
  try {
    let urlParms=''
    if(floor_id !=null ){ 
      const ids = floor_id.map((l) => l.floor_id);
    
      urlParms = `${BASE_URL}/fetchrooms?floor_id=${ids}`
    } else {
      urlParms = `${BASE_URL}/fetchrooms`
    } 

    const response = await axios.get(`${urlParms}`, { 
      headers: { Authorization: getUserToken() },
    }); 
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch rooms");
  }
};

// Post call to create a new room
export const createRoom = async (roomData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization:getUserToken()},
      url: `${BASE_URL}/roomcreation`,
      data: roomData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create room");
  }
};

// Update / Edit Room
export const updateRoom = async (roomedit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/updateRoom`,
      data: roomedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update room");
  }
};

export const deleteRoom = async (payload) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/deactiveroom`,
      data: payload,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to delete role");
  }
};

export const fetchUserRooms = async () => {
  try {
    const response = await axios({
      method: "get",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/getUserRooms`, 
    }); 
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete role");
  }
};
