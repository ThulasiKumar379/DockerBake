import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { getRooms, fetchRooms, createRoom, updateRoom, deleteRoom,fetchUserRooms } from "./roomApis";

export const getUserRooms = createAsyncThunk(
  "rooms/fetchUserRooms",
  async () => {
    const rooms = await fetchUserRooms();
    // console.log("now rooms",rooms)
    return rooms;
  }
);

export const getRoomsData = createAsyncThunk(
  "rooms/getRoomsData",
  async () => {
    const rooms = await getRooms();
    // console.log("now rooms",rooms)
    return rooms;
  }
);

export const fetchRoomsData = createAsyncThunk("rooms/fetchRoomsData", async () => {
  const rooms = await fetchRooms();
  return rooms;
});

export const createRoomData = createAsyncThunk(
  "rooms/createRoomData",
  async (roomData) => {
    const newRoom = await createRoom(roomData);
    return newRoom;
   
  }
);

export const updateRoomData = createAsyncThunk(
  "rooms/updateRoomData",
  async (roomData) => {
    const updatedRoom = await updateRoom(roomData);
    return updatedRoom;
  }
);

export const deleteRoomData = createAsyncThunk(
  "rooms/deleteRoomData",
  async (roomId) => {
    const delRoom = await deleteRoom(roomId);
    //wait deleteRoom(roomId);
    return delRoom;
  }
);



const roomsSlice = createSlice({
  name: "rooms",
  initialState: {
    rooms: [],
    data: {},
    userRooms:[],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder
    
    .addCase(getUserRooms.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    })

    .addCase(getUserRooms.fulfilled, (state, action) => {
      state.isLoading = false;
      state.userRooms = action.payload;
    })

    .addCase(getUserRooms.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.error.message;
    }) 


      .addCase(getRoomsData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(getRoomsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.rooms = action.payload;
      })

      .addCase(getRoomsData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(fetchRoomsData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(fetchRoomsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.rooms = action.payload;
      })

      .addCase(fetchRoomsData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(createRoomData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(createRoomData.fulfilled, (state, action) => {
        console.log("respo", current(state));
        state.isLoading = false;
      })

      .addCase(createRoomData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(updateRoomData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(updateRoomData.fulfilled, (state, action) => {
        state.isLoading = false;
      })

      .addCase(updateRoomData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(deleteRoomData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(deleteRoomData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data = action.payload;
      })

      .addCase(deleteRoomData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      });
  },
});

export default roomsSlice.reducer;
