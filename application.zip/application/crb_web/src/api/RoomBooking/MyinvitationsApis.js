import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/bookings`;
export const getUserToken = () => {
    const tokenStr = sessionStorage.getItem("userToken");
    return tokenStr ? `Bearer ${tokenStr}` : null;
  };

//get call to get My Invitations
export const getMyInvitations = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/myinvitations`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch Invitations");
  }
};
