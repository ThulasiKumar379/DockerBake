import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { getMyInvitations } from "./MyinvitationsApis";

export const getMyInvitationsData = createAsyncThunk(
  "bookings/getMyInvitationsData",
  async () => {
    const myInvitations = await getMyInvitations();
    return myInvitations;
  }
);
const myInviationsSlice = createSlice({
  name: "myInvitations",
  initialState: {
    myInvitations: [],
    data: {},
    isLoading: false,
    error: null,
  },

  reducers: {},
  extraReducers: (builder) => {
    builder

      .addCase(getMyInvitationsData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(getMyInvitationsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.myInvitations = action.payload;
        console.log(">>>>", action.payload);
      })

      .addCase(getMyInvitationsData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      });
  },
});
export default myInviationsSlice.reducer;
