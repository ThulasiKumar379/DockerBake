import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/bookings`;
const tokenStr = sessionStorage.getItem("userToken");

//get call to get mybookings
export const getMyBookings = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/mybookings`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
    
  } catch (error) {
    throw new Error("Failed to fetch building");
  }
};