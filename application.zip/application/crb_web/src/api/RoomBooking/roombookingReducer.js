import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import {
  getRoomBookings,
  createRoomBooking,
  fetchAvailableRooms,
  updateRoom,
  bookingCancel,
  bookingAcceptReject,
  getbookingslots,
  getBookingDetailsById,
  fetchRoomDetails
} from "./roomBookingApi";

export const getRoomBookingsData = createAsyncThunk(
  "bookings/getRoomBookingsData",
  async (dates) => {
    const bookings = await getRoomBookings(dates);
    return bookings;
  }
);

export const getBookingById = createAsyncThunk(
  "bookings/getBookingById",
  async (bookingId) => {
    const bookingDetails = await getBookingDetailsById(bookingId);
    return bookingDetails;
  }
);
export const createBookingData = createAsyncThunk(
  "bookings/createBookingData",
  async (roomBookingData) => {
    const newBooking = await createRoomBooking(roomBookingData);
    return newBooking;
  }
);

export const fetchAvailableRoomsData = createAsyncThunk(
  "bookings/fetchAvailableRoomsData",
  async (value) => {
    const availableRooms = await fetchAvailableRooms(value);
    return availableRooms;
  }
);
export const fetchRoomDetailsData = createAsyncThunk(
  "bookings/fetchRoomDetailsData",
  async (data) => {
    const roomDetails = await fetchRoomDetails(data); 
    return roomDetails;
  }
);


export const updateBookingData = createAsyncThunk(
  "bookings/updateBookingData",
  async (roomBookingData) => {
    const updatedBooking = await updateRoom(roomBookingData);
    return updatedBooking;
  }
);

export const bookingCancelData = createAsyncThunk(
  "bookings/updatebookingCancelData",
  async (roomBookingData) => {
    const cancelledBooking = await bookingCancel(roomBookingData);
    return cancelledBooking;
  }
);

export const bookingAcceptRejectData = createAsyncThunk(
  "bookings/updateAcceptRejectData",
  async (roomBookingData) => {
    const acceptedrejectedBooking = await bookingAcceptReject(roomBookingData);
    return acceptedrejectedBooking;
  }
);

export const getBookingSlotsData = createAsyncThunk(
  "bookings/availableSlots",
  async () => {
    const bookingSlots = await getbookingslots();
    return bookingSlots;
  }
);

const roomBookingSlice = createSlice({
  name: "bookings",
  initialState: {
    bookings: [],
    availableRooms: [],
    data: {},
    roomDetails: [],
    bookingSlots: [],
    bookingDetails:[],
    isLoading: false,
    error: null,
  },

  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchRoomDetailsData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchRoomDetailsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.roomDetails = action.payload;
      })
      .addCase(fetchRoomDetailsData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(getRoomBookingsData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(getRoomBookingsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = action.payload;
      })

      .addCase(getRoomBookingsData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      })

      .addCase(createBookingData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(createBookingData.fulfilled, (state, action) => {
        state.isLoading = false;
      })

      .addCase(createBookingData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      })

      .addCase(updateBookingData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(updateBookingData.fulfilled, (state, action) => {
        state.isLoading = false;
      })
      .addCase(updateBookingData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })

      .addCase(fetchAvailableRoomsData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(fetchAvailableRoomsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.availableRooms = action.payload.data;
      })
      .addCase(fetchAvailableRoomsData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      })

      
      .addCase(bookingCancelData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(bookingCancelData.fulfilled, (state, action) => {
        state.isLoading = false;
      })
      .addCase(bookingCancelData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      })

      .addCase(bookingAcceptRejectData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(bookingAcceptRejectData.fulfilled, (state, action) => {
        state.isLoading = false;
      })

      .addCase(bookingAcceptRejectData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      })

      .addCase(getBookingSlotsData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(getBookingSlotsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookingSlots = action.payload; 
      })

      .addCase(getBookingSlotsData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      }) 

      .addCase(getBookingById.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(getBookingById.fulfilled, (state, action) => {
        state.isLoading = false; 
        if(action.payload.status){ 
          state.bookingDetails = action.payload.data; 
        }
        else{
          state.bookingDetails = []; 
        }
      
      })

      .addCase(getBookingById.rejected, (state, action) => {
        state.isLoading = false; 
        state.error = action.error.message;
      }) 

  }
})
export default roomBookingSlice.reducer;
