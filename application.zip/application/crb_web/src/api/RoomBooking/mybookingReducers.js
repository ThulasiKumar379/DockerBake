import { createSlice, createAsyncThunk} from "@reduxjs/toolkit";
import { getMyBookings } from "./myBookingsApi";

export const getMyBookingsData = createAsyncThunk(
  "bookings/getMyBookingsData",
  async () => {
    const myBookings = await getMyBookings();
    return myBookings;
   
  }
);
const myBookingsSlice = createSlice({
  name: "myBookings",
  initialState: {
    myBookings: [],
    data: {},
    isLoading: false,
    error: null,
  },

  reducers: {},
  extraReducers: (builder) => {
    builder

      .addCase(getMyBookingsData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(getMyBookingsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.myBookings = action.payload;
        console.log(">>>>",action.payload)
      })

      .addCase(getMyBookingsData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      });
  },
});
export default myBookingsSlice.reducer;
