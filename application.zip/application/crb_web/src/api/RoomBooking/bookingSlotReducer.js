import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {getbookingslots} from "./bookingSlotsApi"

export const getBookingSlotsData = createAsyncThunk(
    "bookings/availableSlots",
    async () => {
      const bookingSlots = await getbookingslots();
     // return bookingSlots;
     console.log(bookingSlots,"aaaaaaaaaaaaa")
    }
  );

  const bookingSlotsSlice = createSlice({
    name: "bookingslot",
    initialState: {
      bookings: [],
      availableRooms: [],
      data: {},
      isLoading: false,
      error: null,
    },
  
    reducers: {},
    extraReducers: (builder) => {
      builder
      .addCase(getBookingSlotsData.pending, (state) => {
        state.isLoading = true;

        state.error = null;
      })

      .addCase(getBookingSlotsData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookingslot = action.payload;
        console.log(action.payload,"asssritha")
      })

      .addCase(getBookingSlotsData.rejected, (state, action) => {
        state.isLoading = false;

        state.error = action.error.message;
      })
    },
});

export default bookingSlotsSlice.reducer;