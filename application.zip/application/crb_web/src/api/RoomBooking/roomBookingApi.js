import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/bookings`;
const tokenStr = sessionStorage.getItem("userToken");


// get call to get all room bookings
export const getBookingDetailsById = async (booking_id) => {
  try {
    const response = await axios.get(`${BASE_URL}/getBookingById?booking_id=${booking_id}`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
    
  } catch (error) {
    throw new Error("Failed to get room booking");
  }
};


// get call to get all room bookings
export const getRoomBookings = async (dates) => {
  try { 
    const response = await axios.get(`${BASE_URL}/getBookings`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
         params:dates,
    });  
    return response.data;
    
  } catch (error) {
    throw new Error("Failed to get room booking");
  }
};

// Post call to create a new room
export const createRoomBooking = async (roomBookingData) => {
  try {
    console.log("api hitting")
    const response = await axios({
      method: "POST",
      headers: { Authorization: `Bearer ${tokenStr}` },
      url: `${BASE_URL}/createBooking`,
      data: roomBookingData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create room booking");
  }
};

// Update / Edit Room
export const updateRoom = async (updateRoomBooking) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: `Bearer ${tokenStr}` },
      url: `${BASE_URL}/updateBooking`,
      data: updateRoomBooking,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update room Booking");
  }
};

// get calls to fetch available room cards

const getDates = (data) => {
  const dates = [];
  for (const dateString of data) {
    const date = new Date(dateString);
    const formattedDate = date.toISOString().substring(0, 19);
    dates.push(formattedDate);
  
  }
  return dates;
};
export const fetchAvailableRooms = async (value) => {
  const dates = getDates(value);
  try {
    const response = await axios.get(
      `${BASE_URL}/availableRooms?startDate=${dates[0]}&endDate=${dates[1]}`,
      {
        headers: { Authorization: `Bearer ${tokenStr}` },
      }
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch available rooms");
  }
};

// Post call to fetch room details
export const fetchRoomDetails = async (roomdetails) => {
  try {
    // const response = await axios({
    //   method: "GET",
    //   headers: { Authorization: `Bearer ${tokenStr}` },
    //   url: `${BASE_URL}/fetchRoomDetails`,
    //   params:roomdetails
    // });
    console.log('roomdetailsroomdetails',roomdetails)
    const response = await axios.get(`${BASE_URL}/fetchRoomDetails`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
         params:roomdetails,
    });  
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch room details");
  }
};
// put call to cancel booking
export const bookingCancel = async (currentRow) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: `Bearer ${tokenStr}` },
      url: `${BASE_URL}/bookingCancel`,
      data: { booking_id: currentRow },
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to cancel room Booking");
  }
};

// put call to accept/decline booking
export const bookingAcceptReject = async (currentRow) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: `Bearer ${tokenStr}` },
      url: `${BASE_URL}/bookingAcceptReject`,
      data: { booking_id: currentRow },
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to cancel room Booking");
  }
};

export const getbookingslots = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/availableSlots?startDate=2023-08-21&endDate=2023-08-26&room_id=200`, {
      headers: { Authorization: `Bearer ${tokenStr}` },
    });
    return response.data;
    console.log("apis",response.data)
  } catch (error) {
    throw new Error("Failed to fetch building");
  }
};