import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/bookings`;
const tokenStr = sessionStorage.getItem("userToken");

export const getbookingslots = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/availableSlots?startDate=2023-08-21&endDate=2023-08-26&room_id=200`, {
        headers: { Authorization: `Bearer ${tokenStr}` },
      });
      return response.data;
      console.log("apis",response.data)
    } catch (error) {
      throw new Error("Failed to fetch building");
    }
  };