import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/department`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// fetch call to fetch all departments
export const fetchDepartments = async (param1, param2) => {
  try {
    const response = await axios.get(`${BASE_URL}/fetchDepartments`, {
      headers: { Authorization: getUserToken() },
      params: {
        key1: param1,
        key2: param2,
      },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch departments");
  }
};
// get call to get all departments in table
export const getDepartments = async (param1, param2) => {
  try {
    const response = await axios.get(`${BASE_URL}/getDepartmentinfo`, {
      headers: { Authorization: getUserToken() },
      params: {
        key1: param1,
        key2: param2,
      },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch departments");
  }
};
// Post call to create a new department
export const createDepartment = async (departmentData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createDepartment`,
      data: departmentData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create department");
  }
};

// Update / Edit Department
export const updateDepartment = async (departmentedit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/editDepartment`,
      data: departmentedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update department");
  }
};
export const deleteDepartment = async (payload) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/departmentActDec`,
      data: payload,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to delete department");
  }
};

