import { createSlice, createAsyncThunk,} from "@reduxjs/toolkit";
import { fetchDepartments,getDepartments,createDepartment,updateDepartment,deleteDepartment } from "./departmentApis";

export const fetchDepartmentsData = createAsyncThunk(
  "departments/fetchDepartmentsData",
  async () => {
    const departments = await fetchDepartments();
    return departments;
  }
);
export const getDepartmentsData = createAsyncThunk(
  "departments/getDepartmentsData",
  async () => {
    const getdepartments = await getDepartments();
    return getdepartments;
  }
);

export const createDepartmentData = createAsyncThunk(
  "departments/createDepartmentData",
  async (departmentData) => {
    const newDepartment = await createDepartment(departmentData);
    return newDepartment;
   
  }
);

export const updateDepartmentData = createAsyncThunk(
  "departments/updateDepartmentData",
  async (departmentData) => {
    const updatedDepartment = await updateDepartment(departmentData);
    return updatedDepartment;
  }
);
export const deleteDepartmentData = createAsyncThunk(
  "departments/deleteDepartmentData",
  async (departmentId) => {
    const delDepartment=await deleteDepartment(departmentId)
    return delDepartment;
  }
);



const departmentsSlice = createSlice({
  name: "departments",
  initialState: {
    departments: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchDepartmentsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchDepartmentsData.fulfilled, (state, action) => {
        state.loading = false;
        state.departments = action.payload;
      })

      .addCase(fetchDepartmentsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(getDepartmentsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(getDepartmentsData.fulfilled, (state, action) => {
        state.loading = false;
        state.departments = action.payload;
      })

      .addCase(getDepartmentsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(createDepartmentData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createDepartmentData.fulfilled, (state,) => {
        state.loading = false;
      })

      .addCase(createDepartmentData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(updateDepartmentData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(updateDepartmentData.fulfilled, (state, action) => {
        state.loading = false;
      })

      .addCase(updateDepartmentData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(deleteDepartmentData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(deleteDepartmentData.fulfilled, (state, action) => {
        state.loading = false;
        state.data=action.payload
      })

      .addCase(deleteDepartmentData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default departmentsSlice.reducer;