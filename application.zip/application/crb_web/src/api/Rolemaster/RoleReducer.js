import { createSlice, createAsyncThunk, } from "@reduxjs/toolkit";
import { fetchRoles,getRoles, createRole, updateRole, deleterole } from "./RoleApi"


export const fetchRolesData = createAsyncThunk(
  "roles/fetchRolesData",
  async () => {
    const roles = await fetchRoles();
    return roles;
  }
);
export const getRolesData = createAsyncThunk(
  "roles/getRolesData",
  async () => {
    const getroles = await getRoles();
    return getroles;
  }
);

export const createRoleData = createAsyncThunk(
  "roles/createRoleData",
  async (roleData) => {
    const newRole = await createRole(roleData);
    return newRole;
   
  }
);

export const updateRoleData = createAsyncThunk(
  "roles/updateRoleData",
  async (roleData) => {
    const updatedRole = await updateRole(roleData);
    return updatedRole;
  }
);

export const deleteRoleData = createAsyncThunk(
  "roles/deleteRoleData",
  async (roleId) => {
  const delRole=  await deleterole(roleId);
    return delRole;
  }
);



const rolesSlice = createSlice({
  name: "roles",
  initialState: {
    roles: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchRolesData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchRolesData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })

      .addCase(fetchRolesData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(getRolesData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(getRolesData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })

      .addCase(getRolesData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(createRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createRoleData.fulfilled, (state) => {
        state.loading = false;
      })

      .addCase(createRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(updateRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(updateRoleData.fulfilled, (state) => {
        state.loading = false;
      })

      .addCase(updateRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(deleteRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(deleteRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.data=action.payload;
      })

      .addCase(deleteRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default rolesSlice.reducer;
