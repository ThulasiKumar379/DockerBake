import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}/roles`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// fetch call to fetch all roles
export const fetchRoles = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/fetchRoles`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch roles");
  }
};
// get call to get all roles
export const getRoles = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/getroleinfo`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to get roles");
  }
};

// Post call to create a new role
export const createRole = async (roleData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/rolescreation`,
      data: roleData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create role");
  }
};

// Update / Edit Role
export const updateRole = async (roleedit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/editRole`,
      data: roleedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update role");
  }
};

export const deleterole = async (payload) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/deactiverole`,
      data: payload,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to delete role");
  }
};
