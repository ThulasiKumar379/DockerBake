import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchtimings,edittimings,getCompanyTimings} from "../Settings/timingapi";

export const fetchtimingsData = createAsyncThunk(
  "settings/fetchtimingsData",
  async () => {
    const settings = await fetchtimings();
    return settings;
  }
); 
export const edittimingsData = createAsyncThunk(
  "settings/edittimingsData",
  async (TimingData) => {
    console.log("timing Reducer",TimingData)
    const updatedTiming = await edittimings(TimingData);
    return updatedTiming;
  }
);

export const fetchCompanyTimings = createAsyncThunk(
  "settings/fetchCompanyTimings",
  async (TimingData) => { 
    const updatedTiming = await getCompanyTimings(TimingData);
    return updatedTiming;
  }
); 

const settingsSlice = createSlice({
  name: "settings",
  initialState: {
    Settings: [],
    CompanyTimings: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder
    .addCase(fetchCompanyTimings.pending, (state) => {
      state.loading = true;
      state.error = null;
    })

    .addCase(fetchCompanyTimings.fulfilled, (state, action) => {
      state.loading = false;
      state.CompanyTimings = action.payload;
    })

    .addCase(fetchCompanyTimings.rejected, (state, action) => {
      state.loading = false;
      state.error = action.error.message;
    }) 
      .addCase(fetchtimingsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchtimingsData.fulfilled, (state, action) => {
        state.loading = false;
        state.Settings = action.payload;
      })

      .addCase(fetchtimingsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(edittimingsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(edittimingsData.fulfilled, (state, action) => {
        state.loading = false;
        // const departmentIndex = state.departments.findIndex(
        //   (department) => department.id === departmentId
        // );

        // if (departmentIndex !== -1) {
        //   state.departments[departmentIndex] = {
        //     ...state.departments[departmentIndex],
        //     ...departmentData,
        //   };
        // }
      })

      .addCase(edittimingsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
 
  },
});

export default settingsSlice.reducer;