import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { fetchSettings,createSetting,updateSetting } from "./settingApi";

export const fetchSettingsData = createAsyncThunk(
  "settings/fetchSettingsData",
  async () => {
    const settings = await fetchSettings();
    return settings;
  }
);

export const createSettingData = createAsyncThunk(
  "settings/createSettingData",
  async (settingData) => {
    console.log()
    const newSetting = await createSetting(settingData);
    return newSetting;
   
  }
);

export const updateSettingData = createAsyncThunk(
  "settings/updateSettingData",
  async (SettingData) => {
    console.log("setting Reducer",SettingData)
    const updatedSetting = await updateSetting(SettingData);
    return updatedSetting;
  }
);

// export const deleteDepartmentData = createAsyncThunk(
//   "departments/deleteDepartmentData",
//   async (departmentId) => {
//     await deleteDepartment(departmentId);
//     return departmentId;
//   }
// );



const settingsSlice = createSlice({
  name: "settings",
  initialState: {
    Settings: [],
    isLoading: false,
    error: null,
  },

  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchSettingsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchSettingsData.fulfilled, (state, action) => {
        state.loading = false;
        state.Settings = action.payload;
      })

      .addCase(fetchSettingsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(createSettingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createSettingData.fulfilled, (state, action) => {
        console.log("respo", current(state));

        state.loading = false;
      })

      .addCase(createSettingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(updateSettingData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(updateSettingData.fulfilled, (state, action) => {
        state.loading = false;
        const { booking_id, booked_room_color } = action.payload;
        // const departmentIndex = state.departments.findIndex(
        //   (department) => department.id === departmentId
        // );

        // if (departmentIndex !== -1) {
        //   state.departments[departmentIndex] = {
        //     ...state.departments[departmentIndex],
        //     ...departmentData,
        //   };
        // }
      })

      .addCase(updateSettingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

    //   .addCase(deleteSettingData.pending, (state) => {
    //     state.loading = true;
    //     state.error = null;
    //   })

    //   .addCase(deleteDepartmentData.fulfilled, (state, action) => {
    //     state.loading = false;
        // const departmentId = action.payload;
        // state.departments = state.departments.filter((department) => department.id !== departmentId);
    //   })

    //   .addCase(deleteDepartmentData.rejected, (state, action) => {
    //     state.loading = false;
    //     state.error = action.error.message;
    //   });
  },
});

export default settingsSlice.reducer;