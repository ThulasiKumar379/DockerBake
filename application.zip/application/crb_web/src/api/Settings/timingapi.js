import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/settings`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// get call to get all departments
export const fetchtimings = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/gettimings`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch Settings");
  }
};

// Post call to create a new department
// export const createSetting = async (settingData) => {
//   try {
//     const response = await axios({
//       method: "POST",
//       headers: { Authorization: `Bearer ${tokenStr}` },
//       url: `${BASE_URL}/createSetting`,
//       data: settingData,
//     });

//     return response.data;
//   } catch (error) {
//     throw new Error("Failed to create setting");
//   }
// };

export const edittimings = async (settingedit) => {
  console.log("setting apis", settingedit);
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/edittimings`,
      data: settingedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update settings");
  }
};
// get call to get all departments
export const getCompanyTimings = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/getCompanyTimings`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch Settings");
  }
};