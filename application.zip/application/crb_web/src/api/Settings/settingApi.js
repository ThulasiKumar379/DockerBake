import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/setting`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
export const fetchSettings = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/getSettings`, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch Settings");
  }
};

// Post call to create a new department
export const createSetting = async (settingData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createSetting`,
      data: settingData,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create setting");
  }
};

export const updateSetting = async (settingedit) => {
  console.log("setting apis", settingedit);
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/updateSetting`,
      data: settingedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update setting");
  }
};
