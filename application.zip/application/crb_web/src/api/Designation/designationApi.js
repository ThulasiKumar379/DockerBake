import axios from "axios";
const BASE_URL = `${process.env.REACT_APP_BASE_URL}/designations`;
export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};
// get call to get all designations
// export const fetchDesignations = async (dept) => { 
//   try { 
//     let urlParms=''
//   if (Array.isArray(dept)) {
//     if (dept.length > 0) {
//       const deptIds = dept.map((l) => l); 
//       urlParms = `${BASE_URL}/fetchDesignations?department_id=${deptIds}`;
//     } else {
//       urlParms = `${BASE_URL}/fetchDesignations`;
//     }
//   } else { 
//     urlParms = `${BASE_URL}/fetchDesignations`;
//   }  
//   const response = await axios.get(urlParms, {
//     headers: { Authorization: getUserToken() },
//   });
//     return response.data;
//   } catch (error) {
//     throw new Error("Failed to fetch designation");
//   }
// };
export const fetchDesignations = async (dept) => {
  console.log(dept, "urlparam");
  let urlParms;

  if (Array.isArray(dept)) {
    if (dept.length > 0) {
      const departmentId = dept.map((l) => l.department_id);
      console.log({ departmentId });
      urlParms = `${BASE_URL}/fetchDesignations?department_id=${departmentId}`;
    } else {
      urlParms = `${BASE_URL}/fetchDesignations`;
    }
  } else {
    const { department_id } = dept;
    urlParms = `${BASE_URL}/fetchDesignations?department_id=${department_id}`;
  }

  try {
    const response = await axios.get(urlParms, {
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch buildings: ${error.message}`);
  }
};
export const getDesignations = async (dept) => { 
 let urlParms=''
  if (Array.isArray(dept)) {
    if (dept.length > 0) {
      const deptIds = dept.map((l) => l);
      urlParms = `${BASE_URL}/getDesignations?department_ids=${deptIds}`;
    } else {
      urlParms = `${BASE_URL}/getDesignations`;
    }
  } else { 
    urlParms = `${BASE_URL}/getDesignations`;
  }

  try {
    const response = await axios.get(urlParms, {
      headers: { Authorization: getUserToken() },
    });
    return response.data.data;
  } catch (error) {
    throw new Error(`Failed to fetch desginations: ${error.message}`);
  }

};
 

// Post call to create a new designation
export const createDesignation = async (designationData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/createDesignation`,
      data: designationData,
      
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to create designation");
  }
};

// Update / Edit Designation
export const updateDesignation = async (designationedit) => {
  try {
    const response = await axios({
      method: "PUT",
      headers: { Authorization: getUserToken() },
      url: `${BASE_URL}/updateDesignation`,
      data: designationedit,
    });

    return response.data;
  } catch (error) {
    throw new Error("Failed to update designation");
  }
};

export const deleteDesignation = async (currentRow) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}/deleteDesignation?designation_id=${currentRow}`,
      {
        headers: { Authorization: getUserToken() },
        data: { designation_id: currentRow },
      }
    );
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete designation");
  }
};
