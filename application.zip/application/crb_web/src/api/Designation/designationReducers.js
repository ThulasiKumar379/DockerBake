import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  fetchDesignations,
  createDesignation,
  updateDesignation,
  deleteDesignation,
  getDesignations,
} from "./designationApi";

export const fetchDesignationsData = createAsyncThunk(
  "designations/fetchDesignationsData",
  async (departments) => {
    const designations = await fetchDesignations(departments);
    
    return designations;
  }
);
export const createDesignationData = createAsyncThunk(
  "designations/createDesignationData",
  async (designationData) => {
    const newDesignation = await createDesignation(designationData);
    return newDesignation;
  }
);

export const updateDesignationData = createAsyncThunk(
  "designations/updateDesignationData",
  async (designationData) => {
    const updatedDesignation = await updateDesignation(designationData);
    return updatedDesignation;
  }
);

export const deleteDesignationData = createAsyncThunk(
  "designations/deleteDesignationData",
  async (designationId) => {
    const deldesg = await deleteDesignation(designationId);
    //await deleteDesignation(designationId);
    return deldesg;
  }
);

export const getDesignationsData = createAsyncThunk(
  "designations/getDesignationsData",
  async (params) => {
    const getdesgn = await getDesignations(params);
    return getdesgn;
  }
);

const designationsSlice = createSlice({
  name: "designations",
  initialState: {
    designations: [],
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchDesignationsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(fetchDesignationsData.fulfilled, (state, action) => {
        state.loading = false;
        state.designations = action.payload;
      })

      .addCase(fetchDesignationsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(createDesignationData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(createDesignationData.fulfilled, (state, action) => {
        state.loading = false;
      })

      .addCase(createDesignationData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(updateDesignationData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(updateDesignationData.fulfilled, (state, action) => {
        state.loading = false;
      })

      .addCase(updateDesignationData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      .addCase(deleteDesignationData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(deleteDesignationData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        // const designationId = action.payload;
        // state.designations = state.designations.filter((designation) => designation.id !== designationId);
      })
      .addCase(deleteDesignationData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(getDesignationsData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })

      .addCase(getDesignationsData.fulfilled, (state, action) => {
        state.loading = false;
        state.designations = action.payload;
      })

      .addCase(getDesignationsData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });

  },
});
export default designationsSlice.reducer;
