import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchUserProfile, updateUserPassword, uploadProfilePic,fetchProfilePicUrl } from "./userProfileApi";

export const fetchUsersData = createAsyncThunk(
  // console.log('Redux State:', fetchUserProfile()),
  "users/fetchUsersData",
  async () => {
    const users = await fetchUserProfile();
    // console.log('Redux State:', users);
    return users;
  }
);


// export const fetchUsersData = createAsyncThunk(
//   "users/fetchUserDetails",
//   async () => {
//     const response = await fetchUserProfile();
    
//     console.log("data :",response)
//     return response;
//   }
// );
// export const updatePassword = createAsyncThunk(
//   "users/updateUserProfile",
//   async (userpwd) => {
//     const updateProfile = await updateUserPassword(userpwd);
//     console.log("updateProfile",updateProfile)
//     return updateProfile;
//   }
// );

export const uploadProfilePicture = createAsyncThunk(
  "users/uploadProfilePic",
  async (formData) => {
    const response = await uploadProfilePic(formData);
    return response;
  }
);
export const fetchProfilePic = createAsyncThunk(
  "users/fetchProfilePic",
  async (token) => {
    const imageUrl = await fetchProfilePicUrl(token);
    return imageUrl;
  }
);

export const updatePassword = createAsyncThunk(
  "users/updateUserProfile",
  async (passwordData, { rejectWithValue }) => {
    try {
      const updateProfile = await updateUserPassword(passwordData);
      console.log("updateProfile",updateProfile)
      return updateProfile;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || "Update failed");
    }
  }
);

const usersSlice = createSlice({
  name: "users",
  initialState: {
    users: [],
    data: {},
    profilePicUrl: "", 
    isLoading: false,
    error: null,
  },
  reducers: {},

  extraReducers: (builder) => {
    builder

      .addCase(fetchUsersData.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(fetchUsersData.fulfilled, (state, action) => {
        state.isLoading = false;
        state.users = action.payload.userData;
      })

      .addCase(fetchUsersData.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      
      // .addCase(updatePassword.pending, (state) => {
      //   state.isLoading = true;
      //   state.error = null;
      // })

      // .addCase(updatePassword.fulfilled, (state, action) => {
      //   state.isLoading = false;
      //   state.users = action.payload;
      // })

      // .addCase(updatePassword.rejected, (state, action) => {
      //   state.isLoading = false;
      //   state.error = action.error.message;
      // })

      .addCase(uploadProfilePicture.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(uploadProfilePicture.fulfilled, (state, action) => {
        state.isLoading = false;
      })

      .addCase(uploadProfilePicture.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      .addCase(fetchProfilePic.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })

      .addCase(fetchProfilePic.fulfilled, (state, action) => {
        state.isLoading = false;
        state.profilePicUrl = action.payload;
      })

      .addCase(fetchProfilePic.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      .addCase(updatePassword.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updatePassword.fulfilled, (state, action) => {
        state.isLoading = false;
      })
      .addCase(updatePassword.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

export default usersSlice.reducer;