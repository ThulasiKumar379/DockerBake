import axios from "axios";

const BASE_URL = `${process.env.REACT_APP_BASE_URL}`;

export const getUserToken = () => {
  const tokenStr = sessionStorage.getItem("userToken");
  return tokenStr ? `Bearer ${tokenStr}` : null;
};

// export const fetchUserProfile = async () => {
//   try {
//     const response = await axios.get(`${BASE_URL}/users/getUser?user_id=52`, {
//       headers: { Authorization: getUserToken() },
//     });
//     // console.log("response:", response); 
//     return response.data;
//   } catch (error) {
//     console.error("Error in fetchUserProfile:", error);
//     throw error;
//   }
// };

export const fetchUserProfile = async () => {
  try {
    const token = sessionStorage.getItem('userToken');
    if (!token) {
      throw new Error("No user token found in local storage");
    }
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const payload = JSON.parse(atob(base64));
    const userId = payload.userdata.user_id;
    if (!userId) {
      throw new Error("No user ID found in token payload");
    }
    const response = await axios.get(`${BASE_URL}/users/getUser?user_id=${userId}`, {
      headers: { Authorization: getUserToken()},
    });
    return response.data;
  } catch (error) {
    console.error("Error in fetchUserProfile:", error);
    throw error;
  }
};



export const updateUserPassword = async (passwordData) => {
  try {
    const response = await axios({
      method: "POST",
      url: `${BASE_URL}/userprofile/updatepassword`,
      data: {
        Currentpassword: passwordData.Currentpassword,
        Newpassword: passwordData.Newpassword,
        Confirmpassword: passwordData.Confirmpassword,
      },
      headers: { Authorization: getUserToken() },
    });
    return response.data;
  } catch (error) {
    const backendMessage = error.response?.data?.message || "Failed to update user password";
    console.error("Backend error message:", backendMessage);
    throw new Error(backendMessage);
  }
};

// export const uploadProfilePic = async (formData) => {
//   try {
//     const response = await axios.post(
//       `${BASE_URL}/userprofile/profilepicupload`,
//       formData,
//       {
//         headers: {
//           Authorization: getUserToken(),
//           "Content-Type": "multipart/form-data",
//         },
//       }
//     );    
//     console.log("response:", response); 

//     return response.data;
//   } catch (error) {
//     throw new Error("Failed to upload profile picture");
//   }
// };
export const uploadProfilePic = async (formData) => {
  try {
    const response = await axios({
      method: "POST",
      headers: {
        Authorization: getUserToken(),
        "Content-Type": "multipart/form-data",
      },
      url: `${BASE_URL}/userprofile/profilepicupload`,
      data: formData,
    });
    console.log("response:", response); 
    return response.data;
  } catch (error) {
    throw new Error("Failed to  upload profile picture");
  }
};

export const fetchProfilePicUrl = async (token) => {
  try {
    const response = await axios.get(`${BASE_URL}/userprofile/getprofilepic/${token}`, {
      responseType: 'arraybuffer',
    });

    const blob = new Blob([response.data], { type: 'image/jpeg' });
    const imageUrl = URL.createObjectURL(blob);

    return imageUrl;
  } catch (error) {
    console.error('Error fetching profile picture URL:', error);
    throw error;
  }
};

export const deleteProfilePicture = async () => {
  try {
    const token = sessionStorage.getItem("userToken");
    if (!token) {
      throw new Error("User token not found");
    }
    const response = await axios.delete(`${BASE_URL}/userprofile/profilepicdelete`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    throw new Error("Failed to delete profile picture");
  }
};
