import React from "react";
import { Typography, Button } from "@mui/material";
import './App.css';
import { useNavigate } from "react-router-dom";
export const New = () => {
    const navigate = useNavigate()
    return (<div className="Loginagaincontainer">
        <div className="Loginagainsubcontainer">
            <Typography variant="h4">Password Updated<br /> Sucessfully</Typography>
            <Button variant="contained" style={{ background: "#002046" }} onClick={() => navigate("/")}>Login</Button><br />
        </div>
    </div>)
}