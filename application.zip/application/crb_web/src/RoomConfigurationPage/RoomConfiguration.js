import React from "react";
import TableRoomConfig from "./TableRoomConfig";

export const RoomConfiguration = () => {
  return (
    <>
      <div>
        <TableRoomConfig />
      </div>
    </>
  );
};
