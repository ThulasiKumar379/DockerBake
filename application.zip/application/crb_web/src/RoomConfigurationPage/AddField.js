import Grid from "@mui/material/Grid";
import {
  TextField,
  Button,
  Box,
  Checkbox,
  MenuItem,
  FormControl,
  Typography,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close"
import React from "react";
import { styled } from "@mui/system";
export const Add = ({ onClose }) => {
  const HandleCancel = () => {
    onClose();
  };
  const RequiredAsterisk = styled("span")({
    color: "red",
  });
  return (
    <div>
      <FormControl>
        <Box sx={{ width: "100%" }}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{
              borderBottom: "1px solid #e9ecef",
              marginBottom: "20px",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            Add Field
            <div style={{ textAlign: "right", display: "inline" }}>
              <CloseIcon onClick={HandleCancel}>X</CloseIcon>
            </div>
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label={
                  <span>
                    Field Name
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>
                }
                variant="outlined"
              ></TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="outlined-select-currency"
                select
                label={
                  <span>
                    Field Type
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>
                }
                size="small"
                defaultValue="Designation1"
              >
                <div>
                  <MenuItem>Input Text</MenuItem>
                  <MenuItem>Drop Down</MenuItem>
                  <MenuItem>Checkbox</MenuItem>
                  <MenuItem>Radio Button</MenuItem>
                </div>
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label="Default Value"
                variant="outlined"
              ></TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label="options"
                variant="outlined"
              ></TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label="Min Size"
                variant="outlined"
              ></TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label="Max Size"
                variant="outlined"
              ></TextField>
            </Grid>
            <Grid xs={12} sm={6}>
              <TextField
                fullWidth
                id="outlined-multiline-static"
                placeholder="Remarks"
                multiline
                rows={4}
                sx={{margin:"15px 10px"}}
              />
            </Grid>
            <Grid xs={12} sm={6}>
              <Checkbox defaultChecked sx={{margin:"5px 10px"}}  required />
              Required <RequiredAsterisk>*</RequiredAsterisk>
            </Grid>
          </Grid>

          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <div style={{ marginRight: "2%" }}>
              <Button className="bookingbtn1" onClick={HandleCancel}>
                Cancel
              </Button>
            </div>
            <Button className="bookingbtn">Create</Button>
          </div>
        </Box>
      </FormControl>
    </div>
  );
};
