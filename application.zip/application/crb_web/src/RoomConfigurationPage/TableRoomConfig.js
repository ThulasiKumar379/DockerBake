import * as React from "react";
import Table from "../Components/Table";
import {
  Stack,
  Tooltip,
  Button,
  Grid,
  Dialog,
  DialogContent,
  Typography,
} from "@mui/material";
import { Info as InfoIcon, Add as AddIcon } from "@mui/icons-material";
import { Add } from "./AddField";
import { checkUserAccess } from "../CheckUserAccess";
export default function TableRoomConfig() {
  const hasAccess=checkUserAccess("room_configuratio")

  const [openadd, setOpenAdd] = React.useState(false);
  const handleClickadd = () => {
    setOpenAdd(true);
  };
  const handleCloseadd = () => {
    setOpenAdd(false);
  };
  const data = [
    {
      name: "Datafield 1",
      field: "Room",
      id: 1,
      status: "Active",
    },
    {
      name: "Datafield 2",
      field: "Title of the meeting",
      id: 2,
      status: "Inactive",
    },
    {
      name: "Datafield 3",
      field: "Date picker",
      id: 3,
      status: "Active",
    },
    {
      name: "Datafield 4",
      field: "Start time",
      id: 4,
      status: "Inactive",
    },
    {
      name: "Datafield 5",
      field: "End Time",
      id: 5,
      status: "Active",
    },
    {
      name: "Datafield 6",
      field: "Duration",
      id: 6,
      status: "Inactive",
    },
    {
      name: "Datafield 7",
      field: "Room Capacity",
      id: 7,
      status: "Inactive",
    },
    {
      name: "Datafield 8",
      field: "Total Attendees",
      id: 8,
      status: "Active",
    },
    {
      name: "Datafield 9",
      field: "Reccurance Frequency",
      id: 9,
      status: "Active",
    },
    {
      name: "Datafield 10",
      field: "Purpose of Booking",
      id: 10,
      status: "Inactive",
    },
    {
      name: "Datafield 11",
      field: "Attendees",
      id: 11,
      status: "Active",
    },
    {
      name: "Datafield 12",
      field: "Amenities",
      id: 12,
      status: "Active",
    },
    {
      name: "Datafield 13",
      field: "Amenities Type",
      id: 13,
      status: "Inactive",
    },
    {
      name: "Datafield 14",
      field: "Notes",
      id: 14,
      status: "Inactive",
    },
  ];
  const columns = [
    {
      field: "id",
      headerName: "S.No",
      flex: 1,
      headerClassName: "super-app-theme--header",
      minWidth: 150,
    },
    {
      field: "field",
      headerName: "Field Name",
      flex: 1,
      headerClassName: "super-app-theme--header",
      minWidth: 150,
    },

    {
      field: "status",
      headerName: "Status",
      flex: 1,
      headerClassName: "super-app-theme--header",
      minWidth: 150,
    },
    {
      field: "operation",
      headerName: "Operation",
      width: 150,
      sortable: false,
      disableClickEventBubbling: true,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => {
        return (
          <Stack direction="row" spacing={2}>
            <Tooltip title="Mandatory field cannot be edited">
              <Button color="primary" size="small">
                <InfoIcon />
              </Button>
            </Tooltip>
          </Stack>
        );
      },
    },
  ];
  return (
    <div style={{ width: "100%" }}>
      <Grid container lg={12} sx={{ marginBottom: "20px", marginTop: "10px" }}>
        <Grid item xs={12} sm={12} md={8} lg={10}>
          <Typography variant="h4" sx={{ fontWeight: "600", margin: "10px 0" }}>
            Room Configuration
          </Typography>
        </Grid>
        <Grid
          item
          xs={12}
          sm={12}
          md={4}
          lg={2}
          sx={{ display: "flex", alignItems: "center" }}
        >
          {hasAccess.exists&&(
          <Button
            variant="contained"
            fullWidth
            sx={{
              padding: "9px", 
              backgroundColor: "#0B78A1 !important",
              borderRadius: 0,
              fontSize: "0.75rem !important",
              lineHeight: "1.125rem",
              letterSpacing: 0,
            }}
            onClick={handleClickadd}
            startIcon={<AddIcon />}
          >
            Add Field
          </Button>
          )}
        </Grid>
      </Grid>
      <Table data={data} columns={columns} id="id" />
      <div>
        <Dialog open={openadd}>
          <DialogContent>
            <Add onClose={handleCloseadd} />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
