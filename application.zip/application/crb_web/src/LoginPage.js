import React, { useEffect } from "react";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import "react-toastify/dist/ReactToastify.css";
import { toast, ToastContainer } from "react-toastify";
import Cookies from 'js-cookie';
import {
  TextField,
  Checkbox,
  Button,
  FormControlLabel,
  IconButton,
  InputAdornment,
  Dialog,
  DialogContent,
  Grid,
} from "@mui/material";
import { styled } from "@mui/system";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import confroologo from "./Components/Images/confroologo.png";
import loginbg from "./Components/Images/loginbg.jpg";
import microsoft from "./Components/Images/microsoft.png";
import google from "./Components/Images/google.png";
import Otpone from "./MuiOtpIput";
import ChangePassword from "./ChangePassword";
import { secretKey } from "./config/apiConfig";
import { fetchUserLogin } from "./api/Auth/authReducer";
import ForgotPassword from "./ForgotPaasword";
import { Link } from "react-router-dom";
import CryptoJS from 'crypto-js';
const Loginpage = () => {
  const fullWidth = true;
  const maxWidth = "sm";
  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => setShowPassword(!showPassword);
  const handleMouseDownPassword = () => setShowPassword(!showPassword);
  const email = "";
  const [open, setOpen] = useState(false); // State for controlling the dialog
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.auth);
  const [, setShowChangePasswordPopup] = useState(false);
  const [validationErrors, setValidationErrors] = useState({
    email: "",
    password: "",
  });
  const [pwOpen, setPwOpen] = useState(false);
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;
  const [rememberMeChecked, setRememberMeChecked] = useState(false);

   useEffect(() => {
  const rememberedEmail = Cookies.get('rememberedEmail');
  const rememberedPassword = Cookies.get('rememberedPassword');
  
  if (rememberedEmail && rememberedPassword) {
    setCred({
      email: rememberedEmail,
      password: rememberedPassword,
    });
     setRememberMeChecked(true);
  }
}, []);

  const handleCloseOtp = () => {
    setOpen(false);
  };
  const [cred, setCred] = useState({
    email: "",
    password: "",
  });
  const handleClickOtp = () => {
    setOpen(true);
  };
  const handleChangePassword = (newPassword, confirmPassword) => {
    setShowChangePasswordPopup(false);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    let trimmedValue = value;
    setCred((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    if (name === "password") {
      trimmedValue = value.trim();
    }
    if (name === "email") {
      trimmedValue = value.trim();
    }
    setCred((prevData) => ({
      ...prevData,
      [name]: trimmedValue,
    }));
    setValidationErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
  };

  const userToken = sessionStorage.getItem("userToken")
    ? sessionStorage.getItem("userToken")
    : null;
  let errors = {
    email: "",
    password: "",
  };

  const validateInputs = () => {
    const newErrors = {};

    if (!cred.email) {
      newErrors.email = "Email is required";
    }

    if (!cred.password) {
      newErrors.password = "Password is required";
    } else if (cred.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters long";
    }

    setValidationErrors(newErrors);

    return Object.values(newErrors).every((error) => error === "");
  };

  useEffect(() => {
    if (userToken && userToken !== "") {
      navigate("/");
    }
  }, [navigate, userInfo, userToken]);

  const encryptData = (data) => {
    return CryptoJS.AES.encrypt(JSON.stringify(data), secretKey).toString();
  };
 
  const handleLogin = async () => {
    if (validateInputs()) {
      if (emailRegex.test(cred.email) && cred.password.length >= 6) {
        try {
          const response = await dispatch(fetchUserLogin(cred));
          if (response) {
            const { data, status, errorMessage } = response.payload || {};
            if (status && data && data.permissions) {
              localStorage.setItem('userName', data.username);
              const encryptedPermissions = encryptData(data.permissions);
              localStorage.setItem('permissions', encryptedPermissions);
              const rememberMe = document.getElementById("rememberMe").checked;
            if (rememberMe) {
              // Set cookies for email and password
              Cookies.set('rememberedEmail', cred.email, { expires: 30 }); // Expires in 30 days
              Cookies.set('rememberedPassword', cred.password, { expires: 30 }); // Expires in 30 days
            }
              window.location.reload();
            } else {
              toast.error(errorMessage || "Please Check Username and Password");
            }
          } else {
            toast.error("An error occurred. Please try again.");
          }
        } catch (error) {
          toast.error("An error occurred. Please try again.");
        }
      } else if (!emailRegex.test(cred.email) && passwordRegex.test(cred.password)) {
        errors.email = "please check Email";
      } else {
        setValidationErrors({
          email: "Invalid email",
          password: "Invalid password",
        });
      }
    }
  };
    const handleRememberMe = () => {
    const rememberMe = document.getElementById("rememberMe").checked;
      setRememberMeChecked(rememberMe);
    if (!rememberMe) {
      // Clear cookies if "Remember Me" is unchecked
      Cookies.remove('rememberedEmail');
      Cookies.remove('rememberedPassword');
    }
  };

  const handlePwOpen = () => {
    setPwOpen(true);
  };

  const handlePwClose = () => {
    setPwOpen(false);
  };
  const RequiredAsterisk = styled("span")({
    color: "red",
  });

  return (
    <>
      <div
        className="mainone"
        style={{
          backgroundImage: `url(${loginbg})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          backgroundPosition: "right",
          height: "100vh",
        }}
      >
        <ToastContainer
          position="bottom-right"
          autoClose={3000}
          hideProgressBar={false}
          pauseOnHover={false}
          draggable={true}
        />
        <div className="SubContainter" style={{}}>
          <div style={{ marginBottom: "2%" }}>
            <img src={confroologo} style={{ width: "80px" }} alt="logo"></img>
          </div>
          <Grid container>
            <Grid item xs={12}>
              <TextField
                fullWidth
                variant="filled"
                style={{
                  background: " #FFFFFF 0% 0% no-repeat padding-box",
                  border: "1px solid #290472",
                  borderRadius: "7px",
                  opacity: "1",
                }}
                floatinglabelstyle={{ color: "#B5B5B6 !important" }}
                name="email"
                sx={{
                  marginBottom: "15px",
                  "& label": {
                    "&.Mui-focused": {
                      color: "#B5B5B6 !important",
                    },
                  },
                  "& input:-internal-autofill-selected": {
                    backgroundColor: "#fff !important",
                  },
                }}
                size="small"
                label={
                  <span>
                    Username or Email
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>
                }
                value={cred.email}
                onChange={(e) => handleChange(e)}
                InputLabelProps={{
                  style: { color: "#B5B5B6 !important" },
                }}
                error={!!validationErrors.email}
                helperText={validationErrors.email}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                variant="filled"
                style={{
                  background: " #FFFFFF 0% 0% no-repeat padding-box",
                  border: "1px solid #290472",
                  borderRadius: "7px",
                  opacity: "1",
                }}
                InputLabelProps={{
                  style: { color: "#fff" },
                }}
                name="password"
                sx={{ marginBottom: "15px" }}
                type={showPassword ? "text" : "password"}
                label={
                  <span>
                    Password
                    <RequiredAsterisk>*</RequiredAsterisk>
                  </span>
                }
                size="small"
                value={cred.password}
                onChange={(e) => handleChange(e)}
                error={!!validationErrors.password}
                helperText={validationErrors.password}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {showPassword ? <Visibility /> : <VisibilityOff />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
          </Grid>
          <div className="labelWrapper" style={{ alignItems: "center" }}>
            <div className="labelWrapperItem">
              <FormControlLabel
                 control={<Checkbox id="rememberMe" sx={{ color: "#F7F7F7" }}  checked={rememberMeChecked} onChange={handleRememberMe} />}
                label="Remember Me"
                sx={{
                  color: "#F7F7F7 !important",
                  marginRight: "0",
                  marginBottom: "0",
                }}
              />
            </div>
            <div className="labelWrapperItem">
              <Link
                to="/forgotpassword"
                className="redLink"
                onClick={handleClickOtp}
              >
                Forgot Password?
              </Link>
            </div> 
          </div>
          <div style={{ marginBottom: "15px" }}>
            <Button
              className="loginButton"
              variant="outlined"
              onClick={() => handleLogin()}
            >
              Login
            </Button>
          </div>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              color: "#F5f5f5",
              marginBottom: "15px",
            }}
          >
            <div className="line"></div>
            {/* <div
              style={{ flex: 1.5, height: "1.5px", background: "#F5f5f5" }}
            /> */}
            {/* <div
              style={{ width: "120px", textAlign: "center", color: "#f5f5f5" }}
            >
              or login with
            </div> */}
            <div
              style={{ flex: 1.5, height: "1.5px", background: "#F5f5f5" }}
            />
          </div>
          <Grid
            container
            className="SocialAcc"
            spacing={1}
            sx={{ marginBottom: "50px" }}
          >
            {/* <Grid item xs={12} sm={6} sx={{ marginBottom: "10px" }}>
              <Button
                fullWidth
                variant="outlined"
                className="googleBtn"
                style={{
                  color: "#F7F7F7",
                  textTransform: "none",
                  background:
                    "transparent linear-gradient(258deg, #3E0BA1 0%, #1F0651 100%) 0% 0% no-repeat padding-box",
                  boxShadow: "15px 19px 49px #620EB6",
                  border: "2px solid #FFFFFF",
                  borderRadius: "7px",
                  fontSize: "14px",
                  fontWeight: "400",
                }}
              >
                <img
                  src={google}
                  style={{
                    width: "15px",
                    marginRight: "10px",
                    padding: "0",
                  }}
                  alt="google"
                />
                Sign in with Google
              </Button>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Button
                fullWidth
                variant="outlined"
                className="microsoftBtn"
                style={{
                  color: "#F7F7F7",
                  textTransform: "none",
                  background:
                    "transparent linear-gradient(258deg, #3E0BA1 0%, #1F0651 100%) 0% 0% no-repeat padding-box",
                  boxShadow: "15px 19px 49px #620EB6",
                  border: "2px solid #FFFFFF",
                  borderRadius: "7px",
                  fontSize: "14px",
                  fontWeight: "400",
                }}
              >
                <img
                  src={microsoft}
                  style={{
                    width: "15px",
                    marginRight: "10px",
                    padding: "0",
                  }}
                  alt=""
                />
                Sign in with Microsoft
              </Button>
            </Grid> */}
          </Grid>
          {/* <div style={{}}>
            <FormControlLabel
              control={<Checkbox sx={{ color: "#F7F7F7" }} />}
              label={
                <span>
                  Terms and conditions
                  <RequiredAsterisk>*</RequiredAsterisk>
                </span>
              }
              sx={{ color: "#F7F7F7 !important" }}
            />
          </div> */}
          {/* <div style={{ marginTop: "3%" }}>
            <></>
          </div> */}
        </div>
      </div>
      <Dialog
        fullWidth={fullWidth}
        maxWidth={maxWidth}
        open={open}
        onClose={handleCloseOtp}
        style={{
          backgroundColor: "rgba(98, 14, 182, 0.5)", // Transparent bluish color
          backdropFilter: "blur(0px)",
          WebkitBackdropFilter: "blur(0px)",
          opacity: 1,
        }}
      >
        <DialogContent
          sx={{
            padding: "15px 10px",
          }}
        >
          <Otpone
            onClose={handleCloseOtp}
            open1={open}
            handlePwOpen={handlePwOpen}
            handleChangePassword={handleChangePassword}
          />
        </DialogContent>
      </Dialog>
      <Dialog open={pwOpen} onClose={handlePwClose}>
        <ChangePassword
          email={email}
          onClose={handlePwClose}
          handleChangePassword={handleChangePassword}
        />
      </Dialog>
    </>
  );
};
export default Loginpage;
