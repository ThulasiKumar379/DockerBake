import React from "react";
import ReactDOM from "react-dom/client";
import "react-toastify/dist/ReactToastify.css";
import App from "./App";
import { Provider } from "react-redux";
import store from "./store";
import { resetPermissions } from "./CheckUserAccess"; 
import { createRoot } from "react-dom/client";

let hours = 1440;  
let now = new Date().getTime();
let setupTime = sessionStorage.getItem("setupTime");

if (setupTime == null) {
  sessionStorage.setItem("setupTime", now);
} else {
  if (now - setupTime > hours * 60 * 60 * 1000) {
    sessionStorage.clear();
    localStorage.clear();
    sessionStorage.setItem("setupTime", now);
  }
}
  setInterval(() => {
    resetPermissions();
  }, 30000); 

const root = document.getElementById("root");
 
createRoot(root).render(  
  <Provider store={store}>
       <App />
    </Provider>
);
