 import React, { useState } from "react";
import { TextField, Button, Typography, InputAdornment } from "@mui/material";
import EmailIcon from "@mui/icons-material/Email";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { initiateForgotPassword, verifyOtpThunk } from "./api/Auth/authReducer";


const ForgotPassword = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [email, setEmail] = useState("");
  const [otpGenerated, setOtpGenerated] = useState(false);
  const [otpError, setOtpError] = useState("");

  const handleGenerateOtp = async () => {
    try {
     let response = await dispatch(initiateForgotPassword({ email }));
     console.log("otp",response)

      setOtpGenerated(true);
    } catch (error) {
      // Handle error, e.g., show an error message
      console.error("Failed to initiate forgot password:", error);
    }
  };

  const handleVerifyOtp = async () => {
    // Implement logic to get OTP from user input
    // const otp = prompt("Enter OTP");

    // if (otp) {
    //   try {
    //     const response = await dispatch(verifyOtpThunk({ otp }));

    //     console.log("forgotp Verify OTP response:", response);

    //     if (response.status === true) {
    //       // OTP verification successful, navigate to the change password route
    //       navigate(`/changepassword/${email}`);
    //     } else {
    //       // Handle the case where OTP verification failed
    //       console.error("forgotp OTP verification failed. Status:", response.status);
    //       // You can show an error message or perform other actions as needed
    //     }
    //   } catch (error) {
    //     // Handle any errors that occurred during OTP verification
    //     console.error("Error during OTP verification:", error);
    //   }
    // }
  };

  return (
    <div className="main">
      <div className="submain">
        <Typography variant="h4">Forgot Password</Typography>
        <br />
        <Typography variant="p">
          {otpGenerated
            ? "The OTP has been sent to your mailbox."
            : "The OTP will be sent to your mailbox."}
        </Typography>{" "}
        <br /><br />
        <TextField
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <EmailIcon style={{ color: "#002046" }} />
              </InputAdornment>
            ),
          }}
          label="Email Id"
          required
          style={{ width: 265 }}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        ></TextField>{" "}
        <br /> <br />
        {otpGenerated ? 
        (
          <Button
            variant="contained"
            style={{ background: "#002046" }}
            onClick={handleVerifyOtp}
          >
            Verify OTP
          </Button>
        ) :
         (
          <Button
            variant="contained"
            style={{ background: "#002046" }}
            onClick={handleGenerateOtp}
          >
            Generate OTP
          </Button>
          
        )}
        
        <br /><br />
      </div>
    </div>
  );
};

export default ForgotPassword;
