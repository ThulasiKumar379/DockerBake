import DashboardCalendar from '../Components/Dashboard/DashboardCalendar'
import React from 'react'

const Home = () => {
  return (
    <div>
        <DashboardCalendar/>
    </div>
  )
}

export default Home